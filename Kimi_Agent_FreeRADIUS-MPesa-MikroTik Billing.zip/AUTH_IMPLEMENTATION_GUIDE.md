# 🔐 Authentication Implementation Guide

## Overview

Your ISP Billing System now has a **complete, production-ready authentication system** with:

- ✅ **Phone Number Login** (OTP via SMS)
- ✅ **Email/Password Login**
- ✅ **Google OAuth Login**
- ✅ **Session Management** with refresh tokens
- ✅ **Role-Based Access Control**

---

## 📁 Files Created

### Backend
```
isp-billing-backend/src/
├── services/auth/
│   ├── phoneAuthService.ts     # Phone OTP authentication
│   ├── emailAuthService.ts     # Email/password authentication
│   └── oauthService.ts         # Google OAuth integration
├── routes/auth/index.ts        # Auth API routes
├── middleware/auth.ts          # Auth middleware & guards
└── migrations/003_auth_enhancements.ts  # Database updates
```

### Frontend
```
app/src/
├── services/authService.ts     # Auth API client
├── stores/authStore.ts         # Zustand auth state
└── components/auth/
    ├── LoginPage.tsx           # Main login page
    ├── PhoneLogin.tsx          # Phone OTP login
    ├── EmailLogin.tsx          # Email/password login
    ├── GoogleLogin.tsx         # Google OAuth
    ├── RegisterForm.tsx        # Registration form
    ├── ForgotPasswordForm.tsx  # Password reset
    └── ProtectedRoute.tsx      # Route guard
```

---

## 🔧 Configuration

### Environment Variables (.env)

```bash
# JWT Secrets
JWT_SECRET=your-super-secret-jwt-key-min-32-characters
JWT_REFRESH_SECRET=your-refresh-secret-key

# SMS Provider (Africa's Talking recommended for Kenya)
SMS_PROVIDER=africastalking
SMS_API_KEY=your_africastalking_api_key
SMS_USERNAME=your_africastalking_username
SMS_SENDER_ID=YOURBRAND

# OR Twilio (alternative)
SMS_PROVIDER=twilio
TWILIO_ACCOUNT_SID=your_account_sid
TWILIO_AUTH_TOKEN=your_auth_token
TWILIO_PHONE_NUMBER=your_twilio_number

# Google OAuth
GOOGLE_CLIENT_ID=your_google_client_id
GOOGLE_CLIENT_SECRET=your_google_client_secret
GOOGLE_REDIRECT_URI=https://yourdomain.com/api/auth/google/callback

# Frontend URL (for OAuth callback)
FRONTEND_URL=https://yourdomain.com
```

---

## 📱 Authentication Methods

### 1. Phone Number Login (OTP)

**Flow:**
1. User enters phone number
2. System sends 6-digit OTP via SMS
3. User enters OTP to verify
4. If phone exists → Login
5. If phone doesn't exist → Auto-create account (for customers)

**API Endpoints:**
```
POST /api/auth/phone/send-otp
POST /api/auth/phone/verify-otp
```

### 2. Email/Password Login

**Features:**
- Registration with email verification
- Secure password hashing (bcrypt)
- Password reset via email
- Account lockout after failed attempts
- Session tracking

**API Endpoints:**
```
POST /api/auth/email/register
POST /api/auth/email/login
POST /api/auth/email/verify
POST /api/auth/email/forgot-password
POST /api/auth/email/reset-password
```

### 3. Google OAuth

**Flow:**
1. User clicks "Sign in with Google"
2. Redirect to Google OAuth consent screen
3. Google redirects back with authorization code
4. System exchanges code for access token
5. Creates/links user account

**API Endpoints:**
```
GET  /api/auth/google          # Initiate OAuth
GET  /api/auth/google/callback # OAuth callback
```

---

## 🔒 Security Features

### JWT Tokens
- **Access Token:** 15 minutes expiry
- **Refresh Token:** 7 days expiry
- **Auto-refresh:** Frontend automatically refreshes expired tokens

### Password Security
- Bcrypt hashing (12 rounds)
- Minimum 8 characters
- Password history tracking
- Secure reset tokens (1 hour expiry)

### Rate Limiting
- Max 5 login attempts per 15 minutes
- OTP cooldown: 5 minutes between requests
- OTP expiry: 10 minutes

### Session Management
- Sessions stored in Redis
- Automatic session cleanup
- Multi-device support
- Logout from all devices option

---

## 🎨 Frontend Usage

### Login Page
```tsx
import { LoginPage } from './components/auth';

function App() {
  return (
    <LoginPage 
      onLoginSuccess={() => {
        // Redirect to dashboard
        navigate('/dashboard');
      }}
    />
  );
}
```

### Protected Routes
```tsx
import { ProtectedRoute } from './components/auth';

<Route
  path="/admin"
  element={
    <ProtectedRoute requiredRoles={['admin', 'manager']}>
      <AdminDashboard />
    </ProtectedRoute>
  }
/>
```

### Auth Store Usage
```tsx
import { useAuthStore } from './stores/authStore';

function MyComponent() {
  const { 
    user, 
    isAuthenticated, 
    loginWithEmail, 
    logout,
    hasRole 
  } = useAuthStore();

  // Check authentication
  if (!isAuthenticated) return <LoginPage />;

  // Check role
  if (hasRole('admin')) {
    return <AdminPanel />;
  }

  // Login
  const handleLogin = async () => {
    const result = await loginWithEmail(email, password);
    if (result.success) {
      // Login successful
    }
  };

  // Logout
  const handleLogout = () => {
    logout();
  };
}
```

---

## 📊 Database Schema Updates

### New Tables
- `user_sessions` - Active user sessions
- `login_attempts` - Security tracking
- `oauth_connections` - Multiple OAuth providers per user
- `password_history` - Prevent password reuse
- `api_keys` - External API access

### Updated Tables
- `users` - Added OAuth fields, 2FA, session tracking

---

## 🚀 Setup Instructions

### 1. Get M-Pesa Credentials
```bash
# Already configured in your .env
MPESA_CONSUMER_KEY=...
MPESA_CONSUMER_SECRET=...
```

### 2. Setup SMS Provider

**Africa's Talking (Recommended for Kenya):**
1. Sign up at https://africastalking.com
2. Get API key and username
3. Add to `.env`

**Twilio (Alternative):**
1. Sign up at https://twilio.com
2. Get Account SID, Auth Token, and phone number
3. Add to `.env`

### 3. Setup Google OAuth
1. Go to https://console.cloud.google.com
2. Create a new project
3. Enable Google+ API
4. Create OAuth 2.0 credentials
5. Add authorized redirect URI: `https://yourdomain.com/api/auth/google/callback`
6. Copy Client ID and Secret to `.env`

### 4. Run Migrations
```bash
cd isp-billing-backend
docker-compose exec api npm run migrate
```

---

## 🔗 API Endpoints Summary

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/phone/send-otp` | Send OTP to phone |
| POST | `/api/auth/phone/verify-otp` | Verify OTP and login |
| POST | `/api/auth/email/register` | Register with email |
| POST | `/api/auth/email/login` | Login with email |
| POST | `/api/auth/email/verify` | Verify email address |
| POST | `/api/auth/email/forgot-password` | Request password reset |
| POST | `/api/auth/email/reset-password` | Reset password |
| GET | `/api/auth/google` | Initiate Google OAuth |
| GET | `/api/auth/google/callback` | Google OAuth callback |
| POST | `/api/auth/refresh` | Refresh access token |
| POST | `/api/auth/logout` | Logout user |
| GET | `/api/auth/me` | Get current user |
| PUT | `/api/auth/me` | Update profile |
| PUT | `/api/auth/password` | Change password |

---

## 🧪 Testing

### Phone Login
```bash
# Send OTP
curl -X POST http://localhost:5000/api/auth/phone/send-otp \
  -H "Content-Type: application/json" \
  -d '{"phoneNumber": "254712345678"}'

# Verify OTP
curl -X POST http://localhost:5000/api/auth/phone/verify-otp \
  -H "Content-Type: application/json" \
  -d '{"phoneNumber": "254712345678", "otp": "123456"}'
```

### Email Login
```bash
# Register
curl -X POST http://localhost:5000/api/auth/email/register \
  -H "Content-Type: application/json" \
  -d '{"email": "user@example.com", "password": "password123", "firstName": "John", "lastName": "Doe"}'

# Login
curl -X POST http://localhost:5000/api/auth/email/login \
  -H "Content-Type: application/json" \
  -d '{"email": "user@example.com", "password": "password123"}'
```

---

## 📱 User Flow

1. **Landing Page** → User sees login options
2. **Choose Method** → Phone / Email / Google
3. **Authenticate** → Enter credentials
4. **Success** → Redirect to dashboard
5. **Token Refresh** → Automatic behind the scenes
6. **Logout** → Clear tokens and session

---

Your authentication system is **production-ready**! 🎉
