# OLT Integration Guide for ISP Billing System

## Overview

The OLT (Optical Line Terminal) Integration module provides comprehensive management capabilities for multi-vendor GPON/XGS-PON OLTs directly from your ISP Billing System. This guide covers all aspects of the OLT integration including setup, configuration, and advanced features.

## Supported Vendors

| Vendor | Models | Protocols | Features |
|--------|--------|-----------|----------|
| **Huawei** | MA5600T, MA5800, EA5800 | SSH, Telnet, SNMP | Full support |
| **ZTE** | C220, C300, C320, C350, C600 | SSH, Telnet, SNMP | Full support |
| **Nokia/Alcatel-Lucent** | ISAM 7302, ISAM 7330, ISAM 7360 | SSH, Telnet | Full support |
| **FiberHome** | AN5516-01, AN5516-04, AN5516-06 | SSH, Telnet, SNMP | Full support |

## Architecture

### Adapter Pattern
The OLT integration uses an adapter pattern that allows seamless integration of new vendors:

```
BaseOLTAdapter (Abstract)
├── HuaweiOLTAdapter
├── ZTEOLTAdapter
├── NokiaOLTAdapter
└── FiberHomeOLTAdapter
```

### Key Components

1. **OLTManager** - Central management service
2. **BaseOLTAdapter** - Abstract base class for all vendors
3. **Vendor Adapters** - Vendor-specific implementations
4. **Database Schema** - Stores OLT, PON port, and ONU data
5. **REST API** - Full API for frontend integration

## Features

### Core Features
- ✅ Multi-vendor OLT support
- ✅ Real-time OLT status monitoring
- ✅ PON port management
- ✅ ONU provisioning/deprovisioning
- ✅ Bulk operations
- ✅ Custom command execution
- ✅ Alarm management
- ✅ Performance metrics

### Creative Features
- 🤖 **AI-Powered Optimization** - Smart suggestions for bandwidth, failures, upgrades
- 🔄 **Self-Healing** - Automatic reset of offline/LOS ONUs
- 🔍 **Auto-Discovery** - Find and auto-provision unprovisioned ONUs
- 📊 **Predictive Analytics** - Failure prediction and anomaly detection

## API Endpoints

### OLT Management
```
GET    /api/olt                    - List all OLTs
POST   /api/olt                    - Add new OLT
GET    /api/olt/:oltId             - Get OLT details
GET    /api/olt/:oltId/status      - Get OLT real-time status
DELETE /api/olt/:oltId             - Remove OLT
```

### PON Ports
```
GET /api/olt/:oltId/ports          - Get PON ports
```

### ONU Management
```
GET    /api/olt/:oltId/onu                    - List ONUs
POST   /api/olt/:oltId/onu                    - Provision ONU
DELETE /api/olt/:oltId/onu/:onuId             - Deprovision ONU
POST   /api/olt/:oltId/onu/:onuId/reset       - Reset ONU
PUT    /api/olt/:oltId/onu/:onuId             - Update ONU config
```

### Advanced Features
```
POST /api/olt/:oltId/self-healing      - Run self-healing
GET  /api/olt/:oltId/ai-optimizations  - Get AI suggestions
POST /api/olt/:oltId/auto-discover     - Auto-discover ONUs
POST /api/olt/:oltId/command           - Execute custom command
GET  /api/olt/:oltId/performance       - Get performance metrics
GET  /api/olt/:oltId/alarms            - Get active alarms
```

### Bulk Operations
```
POST /api/olt/:oltId/bulk-provision    - Bulk provision ONUs
POST /api/olt/:oltId/bulk-reset        - Bulk reset ONUs
```

### Dashboard
```
GET /api/olt/dashboard/stats           - Get dashboard statistics
```

## Database Schema

### Tables

#### olts
```sql
CREATE TABLE olts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(255) NOT NULL,
  vendor VARCHAR(50) NOT NULL,
  model VARCHAR(100),
  ip_address INET NOT NULL,
  port INTEGER DEFAULT 22,
  protocol VARCHAR(20) DEFAULT 'ssh',
  username VARCHAR(100),
  password VARCHAR(255),
  enable_password VARCHAR(255),
  snmp_community VARCHAR(100),
  snmp_version VARCHAR(10),
  location VARCHAR(255),
  coordinates POINT,
  capacity JSONB,
  is_active BOOLEAN DEFAULT true,
  last_seen_at TIMESTAMP,
  firmware_version VARCHAR(100),
  system_uptime INTEGER,
  company_id UUID REFERENCES companies(id),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### pon_ports
```sql
CREATE TABLE pon_ports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  olt_id UUID REFERENCES olts(id),
  shelf INTEGER,
  slot INTEGER,
  port_number INTEGER NOT NULL,
  status VARCHAR(20) DEFAULT 'offline',
  type VARCHAR(20) DEFAULT 'gpon',
  onu_count INTEGER DEFAULT 0,
  max_onus INTEGER DEFAULT 128,
  transmit_power DECIMAL(6,2),
  receive_power DECIMAL(6,2),
  temperature DECIMAL(5,2),
  last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### onus
```sql
CREATE TABLE onus (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  olt_id UUID REFERENCES olts(id),
  pon_port_id UUID REFERENCES pon_ports(id),
  onu_id INTEGER NOT NULL,
  serial_number VARCHAR(50) NOT NULL,
  mac_address VARCHAR(17),
  vendor_id VARCHAR(50),
  model VARCHAR(100),
  firmware_version VARCHAR(100),
  status VARCHAR(20) DEFAULT 'offline',
  admin_state VARCHAR(20) DEFAULT 'enabled',
  auth_mode VARCHAR(20) DEFAULT 'sn',
  rx_power DECIMAL(6,2),
  tx_power DECIMAL(6,2),
  olt_rx_power DECIMAL(6,2),
  distance DECIMAL(8,2),
  temperature DECIMAL(5,2),
  voltage DECIMAL(5,2),
  customer_id UUID REFERENCES customers(id),
  description TEXT,
  last_online_at TIMESTAMP,
  offline_count INTEGER DEFAULT 0,
  uptime INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### olt_alarms
```sql
CREATE TABLE olt_alarms (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  olt_id UUID REFERENCES olts(id),
  severity VARCHAR(20) NOT NULL,
  category VARCHAR(50),
  type VARCHAR(100),
  description TEXT,
  source VARCHAR(255),
  acknowledged BOOLEAN DEFAULT false,
  acknowledged_by UUID REFERENCES users(id),
  acknowledged_at TIMESTAMP,
  cleared BOOLEAN DEFAULT false,
  cleared_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

## Configuration

### Adding an OLT

1. Navigate to **OLT Management** in the sidebar
2. Click **Add OLT**
3. Fill in the configuration:
   - **Name**: Descriptive name (e.g., "OLT-Main-Office")
   - **Vendor**: Select from supported vendors
   - **Model**: Select the specific model
   - **IP Address**: Management IP of the OLT
   - **Port**: SSH (22), Telnet (23), or SNMP (161)
   - **Protocol**: SSH, Telnet, or SNMP
   - **Credentials**: Username, password, enable password
   - **SNMP**: Community string and version (if using SNMP)
   - **Location**: Physical location (optional)

### Self-Healing Configuration

The self-healing system automatically fixes common issues:

```typescript
{
  enabled: true,
  checkInterval: 5, // minutes
  actions: {
    restartOfflineOnus: true,    // Reset ONUs offline > 30 min
    resetLosOnus: true,          // Reset ONUs with LOS
    rebalanceLoad: false,        // Auto-rebalance PON ports
    autoUpgradeFirmware: false   // Auto-upgrade firmware
  },
  thresholds: {
    maxOfflineDuration: 30,      // minutes
    maxLosDuration: 15,          // minutes
    minSignalQuality: -27        // dBm
  }
}
```

### AI Optimization

AI-powered features analyze your network and provide suggestions:

```typescript
{
  enabled: true,
  features: {
    predictFailures: true,      // Predict equipment failures
    optimizeBandwidth: true,    // Suggest bandwidth optimizations
    suggestUpgrades: true,      // Recommend XGS-PON upgrades
    detectAnomalies: true       // Detect unusual patterns
  }
}
```

## Usage Examples

### Provision a New ONU

```bash
curl -X POST https://api.yourisp.com/olt/123/onu \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "serialNumber": "HWTC12345678",
    "ponPortId": "pon-uuid-here",
    "customerId": "customer-uuid",
    "serviceProfile": "INTERNET_100M",
    "description": "John Doe - Home"
  }'
```

### Execute Custom Command

```bash
curl -X POST https://api.yourisp.com/olt/123/command \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "command": "display ont info 0/1/1 all"
  }'
```

### Run Self-Healing

```bash
curl -X POST https://api.yourisp.com/olt/123/self-healing \
  -H "Authorization: Bearer YOUR_TOKEN"
```

Response:
```json
{
  "success": true,
  "data": {
    "actions": [
      "Reset ONU HWTC12345678 (offline for 45 min)",
      "Reset ONU HWTC87654321 (LOS detected)"
    ],
    "issues": [
      "ONU HWTC12345678 offline for 45 minutes",
      "ONU HWTC87654321 has LOS"
    ]
  }
}
```

## Frontend Components

### OLT Management Page

The OLT Management page provides:
- Dashboard with OLT statistics
- OLT list with connection status
- Real-time OLT status display
- PON port visualization
- ONU management with search/filter
- AI optimization suggestions
- Self-healing controls
- Custom command terminal

### Key Features

1. **Visual PON Port Status** - Color-coded port status (green=online, red=offline)
2. **ONU Signal Quality** - Display RX/TX power with quality indicators
3. **Customer Linking** - Link ONUs to customer accounts
4. **Bulk Operations** - Provision/reset multiple ONUs at once
5. **Command History** - Log of all executed commands

## Troubleshooting

### Common Issues

#### Connection Failed
- Verify IP address and port
- Check firewall rules
- Verify credentials
- Ensure OLT management is enabled

#### ONU Not Provisioning
- Check serial number format
- Verify PON port has available slots
- Check ONU is compatible with OLT
- Verify service/line profiles exist

#### Poor Signal Quality
- Check fiber connections
- Verify ONU distance (<20km typical)
- Check for fiber bends or damage
- Verify optical power levels

### Debug Mode

Enable debug logging:

```typescript
// In oltManager.ts
logger.setLevel('debug');
```

## Security Considerations

1. **Credential Storage** - Passwords are encrypted at rest
2. **Access Control** - Role-based access to OLT operations
3. **Command Logging** - All commands are logged for audit
4. **Session Timeout** - SSH sessions timeout after inactivity
5. **Rate Limiting** - Commands are rate-limited to prevent abuse

## Performance Optimization

### Caching
- OLT status cached for 2 minutes
- ONU data cached per session
- PON port data cached for 1 minute

### Connection Pooling
- SSH connections reused when possible
- Automatic connection cleanup
- Health checks every 5 minutes

## Future Enhancements

Planned features for future releases:
- 🌐 XGS-PON support
- 📡 10G PON monitoring
- 🤖 ML-based failure prediction
- 📱 Mobile app for OLT management
- 🔗 Integration with network monitoring tools

## Support

For technical support:
- Email: support@yourisp.com
- Documentation: https://docs.yourisp.com/olt
- API Reference: https://api.yourisp.com/docs

---

**Version**: 1.0.0  
**Last Updated**: 2024  
**Compatible With**: ISP Billing System v2.0+
