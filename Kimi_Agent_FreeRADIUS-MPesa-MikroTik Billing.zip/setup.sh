#!/bin/bash

# ISP Billing System - Quick Setup Script
# This script automates the deployment of the ISP Billing System

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
INSTALL_DIR="/opt/isp-billing"
DB_NAME="isp_billing"
DB_USER="isp_user"
BACKEND_PORT=5000
FRONTEND_PORT=3000

# Helper functions
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

# Check if running as root
check_root() {
    if [[ $EUID -eq 0 ]]; then
        print_error "This script should not be run as root for security reasons"
        print_status "Please run as a regular user with sudo privileges"
        exit 1
    fi
}

# Check system requirements
check_requirements() {
    print_status "Checking system requirements..."
    
    # Check OS
    if ! command -v apt-get &> /dev/null; then
        print_error "This script requires Debian/Ubuntu-based system"
        exit 1
    fi
    
    # Check RAM
    RAM=$(free -m | awk '/^Mem:/{print $2}')
    if [ "$RAM" -lt 2048 ]; then
        print_warning "System has less than 2GB RAM. Performance may be affected."
    fi
    
    # Check disk space
    DISK=$(df / | awk 'NR==2 {print $4}')
    if [ "$DISK" -lt 10485760 ]; then  # 10GB in KB
        print_error "Insufficient disk space. At least 10GB required."
        exit 1
    fi
    
    print_success "System requirements check passed"
}

# Install system dependencies
install_dependencies() {
    print_status "Installing system dependencies..."
    
    sudo apt-get update
    
    # Install basic tools
    sudo apt-get install -y \
        curl \
        wget \
        git \
        build-essential \
        software-properties-common \
        apt-transport-https \
        ca-certificates \
        gnupg \
        lsb-release
    
    print_success "Basic tools installed"
}

# Install Node.js
install_nodejs() {
    print_status "Installing Node.js 18..."
    
    if ! command -v node &> /dev/null; then
        curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
        sudo apt-get install -y nodejs
    fi
    
    NODE_VERSION=$(node --version)
    print_success "Node.js installed: $NODE_VERSION"
}

# Install PostgreSQL
install_postgresql() {
    print_status "Installing PostgreSQL..."
    
    if ! command -v psql &> /dev/null; then
        sudo apt-get install -y postgresql postgresql-contrib
        sudo systemctl enable postgresql
        sudo systemctl start postgresql
    fi
    
    print_success "PostgreSQL installed"
}

# Install Redis
install_redis() {
    print_status "Installing Redis..."
    
    if ! command -v redis-cli &> /dev/null; then
        sudo apt-get install -y redis-server
        sudo systemctl enable redis-server
        sudo systemctl start redis-server
    fi
    
    print_success "Redis installed"
}

# Install Nginx
install_nginx() {
    print_status "Installing Nginx..."
    
    if ! command -v nginx &> /dev/null; then
        sudo apt-get install -y nginx
        sudo systemctl enable nginx
    fi
    
    print_success "Nginx installed"
}

# Install PM2
install_pm2() {
    print_status "Installing PM2..."
    
    if ! command -v pm2 &> /dev/null; then
        sudo npm install -g pm2
    fi
    
    print_success "PM2 installed"
}

# Setup database
setup_database() {
    print_status "Setting up database..."
    
    # Generate random password
    DB_PASSWORD=$(openssl rand -base64 32)
    
    # Create database and user
    sudo -u postgres psql << EOF
DROP DATABASE IF EXISTS $DB_NAME;
DROP USER IF EXISTS $DB_USER;
CREATE DATABASE $DB_NAME;
CREATE USER $DB_USER WITH ENCRYPTED PASSWORD '$DB_PASSWORD';
GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;
\q
EOF
    
    # Enable extensions
    sudo -u postgres psql -d $DB_NAME -c "CREATE EXTENSION IF NOT EXISTS uuid-ossp;"
    sudo -u postgres psql -d $DB_NAME -c "CREATE EXTENSION IF NOT EXISTS pgcrypto;"
    
    # Save credentials
    echo "DB_PASSWORD=$DB_PASSWORD" > ~/.isp_billing_db_credentials
    chmod 600 ~/.isp_billing_db_credentials
    
    print_success "Database configured"
    print_status "Database password saved to ~/.isp_billing_db_credentials"
}

# Create application directory
setup_app_directory() {
    print_status "Setting up application directory..."
    
    sudo mkdir -p $INSTALL_DIR
    sudo chown $USER:$USER $INSTALL_DIR
    
    print_success "Application directory created at $INSTALL_DIR"
}

# Create environment file
create_env_file() {
    print_status "Creating environment configuration..."
    
    DB_PASSWORD=$(cat ~/.isp_billing_db_credentials | cut -d= -f2)
    JWT_SECRET=$(openssl rand -base64 64)
    
    cat > $INSTALL_DIR/backend/.env << EOF
# Server
NODE_ENV=production
PORT=$BACKEND_PORT
HOST=0.0.0.0

# Database
DB_HOST=localhost
DB_PORT=5432
DB_NAME=$DB_NAME
DB_USER=$DB_USER
DB_PASSWORD=$DB_PASSWORD
DB_SSL=false

# Redis
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_PASSWORD=

# JWT
JWT_SECRET=$JWT_SECRET
JWT_EXPIRES_IN=24h
JWT_REFRESH_EXPIRES_IN=7d

# Frontend URL (update after deployment)
FRONTEND_URL=http://localhost:$FRONTEND_PORT
CORS_ORIGIN=http://localhost:$FRONTEND_PORT

# M-Pesa (Configure these with your credentials)
MPESA_CONSUMER_KEY=your_consumer_key
MPESA_CONSUMER_SECRET=your_consumer_secret
MPESA_PASSKEY=your_passkey
MPESA_SHORTCODE=your_shortcode
MPESA_ENVIRONMENT=sandbox

# SMS (Configure these with your credentials)
AFRICASTALKING_API_KEY=your_api_key
AFRICASTALKING_USERNAME=your_username
AFRICASTALKING_SENDER_ID=your_sender_id

# Email (Configure these with your credentials)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password
SMTP_FROM=noreply@your-domain.com

# Google OAuth (Configure these with your credentials)
GOOGLE_CLIENT_ID=your_google_client_id
GOOGLE_CLIENT_SECRET=your_google_client_secret

# File Upload
UPLOAD_MAX_SIZE=10485760
UPLOAD_PATH=./uploads

# Logging
LOG_LEVEL=info
LOG_FILE=./logs/app.log
EOF
    
    print_success "Environment file created"
}

# Setup backend
setup_backend() {
    print_status "Setting up backend..."
    
    cd $INSTALL_DIR/backend
    
    # Install dependencies
    npm install
    
    # Build application
    npm run build
    
    # Run migrations
    npm run migrate
    
    print_success "Backend setup complete"
}

# Setup frontend
setup_frontend() {
    print_status "Setting up frontend..."
    
    cd $INSTALL_DIR/frontend
    
    # Install dependencies
    npm install
    
    # Build application
    npm run build
    
    print_success "Frontend setup complete"
}

# Start services
start_services() {
    print_status "Starting services..."
    
    # Start backend
    cd $INSTALL_DIR/backend
    pm2 start dist/server.js --name "isp-backend" -- --port $BACKEND_PORT
    
    # Start frontend
    cd $INSTALL_DIR/frontend
    pm2 start "npx serve -s dist -l $FRONTEND_PORT" --name "isp-frontend"
    
    # Save PM2 config
    pm2 save
    pm2 startup
    
    print_success "Services started"
}

# Configure Nginx
configure_nginx() {
    print_status "Configuring Nginx..."
    
    sudo tee /etc/nginx/sites-available/isp-billing << 'EOF'
# Backend API
server {
    listen 80;
    server_name _;
    
    location /api/ {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
    
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
EOF
    
    sudo ln -sf /etc/nginx/sites-available/isp-billing /etc/nginx/sites-enabled/default
    sudo nginx -t && sudo systemctl restart nginx
    
    print_success "Nginx configured"
}

# Create systemd services
create_systemd_services() {
    print_status "Creating systemd services..."
    
    # Backend service
    sudo tee /etc/systemd/system/isp-backend.service << EOF
[Unit]
Description=ISP Billing Backend
After=network.target postgresql.service redis.service

[Service]
Type=simple
User=$USER
WorkingDirectory=$INSTALL_DIR/backend
ExecStart=/usr/bin/node dist/server.js
Restart=always
RestartSec=10
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
EOF
    
    # Frontend service
    sudo tee /etc/systemd/system/isp-frontend.service << EOF
[Unit]
Description=ISP Billing Frontend
After=network.target

[Service]
Type=simple
User=$USER
WorkingDirectory=$INSTALL_DIR/frontend
ExecStart=/usr/bin/npx serve -s dist -l 3000
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF
    
    sudo systemctl daemon-reload
    sudo systemctl enable isp-backend isp-frontend
    
    print_success "Systemd services created"
}

# Print final instructions
print_final_instructions() {
    echo ""
    echo "=========================================="
    echo -e "${GREEN}ISP Billing System Setup Complete!${NC}"
    echo "=========================================="
    echo ""
    echo "Access your application:"
    echo "  - Frontend: http://localhost:$FRONTEND_PORT"
    echo "  - Backend API: http://localhost:$BACKEND_PORT"
    echo ""
    echo "Default admin credentials:"
    echo "  - Email: admin@ispbilling.com"
    echo "  - Password: admin123"
    echo ""
    echo "Important next steps:"
    echo "  1. Change the default admin password"
    echo "  2. Configure M-Pesa credentials in $INSTALL_DIR/backend/.env"
    echo "  3. Configure SMS gateway credentials"
    echo "  4. Set up SSL with Let's Encrypt"
    echo "  5. Configure your domain name"
    echo ""
    echo "Useful commands:"
    echo "  - View logs: pm2 logs"
    echo "  - Restart: pm2 restart all"
    echo "  - Stop: pm2 stop all"
    echo ""
    echo "Database credentials saved to: ~/.isp_billing_db_credentials"
    echo ""
    echo "For support, visit: https://docs.yourisp.com"
    echo ""
}

# Main installation flow
main() {
    echo "=========================================="
    echo "ISP Billing System - Setup Script"
    echo "=========================================="
    echo ""
    
    check_root
    check_requirements
    
    print_status "Starting installation..."
    
    install_dependencies
    install_nodejs
    install_postgresql
    install_redis
    install_nginx
    install_pm2
    
    setup_database
    setup_app_directory
    
    # Note: In a real scenario, you would clone your repositories here
    print_status "Please ensure your backend and frontend code is in:"
    print_status "  - Backend: $INSTALL_DIR/backend"
    print_status "  - Frontend: $INSTALL_DIR/frontend"
    
    read -p "Press Enter to continue after placing your code..."
    
    create_env_file
    setup_backend
    setup_frontend
    start_services
    configure_nginx
    create_systemd_services
    
    print_final_instructions
}

# Run main function
main "$@"
