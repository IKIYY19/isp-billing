import api from './api';

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface RegisterData {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  phone?: string;
  companyName?: string;
}

export interface PhoneLoginData {
  phoneNumber: string;
}

export interface OTPVerifyData {
  phoneNumber: string;
  otp: string;
  trackingId: string;
}

export interface AuthResponse {
  user: {
    id: string;
    email: string;
    firstName: string;
    lastName: string;
    phone?: string;
    role: string;
    companyId?: string;
  };
  tokens: {
    accessToken: string;
    refreshToken: string;
    expiresAt: number;
  };
}

class AuthService {
  async login(credentials: LoginCredentials): Promise<AuthResponse> {
    const response = await api.post('/auth/login', credentials);
    return response.data;
  }

  async register(data: RegisterData): Promise<AuthResponse> {
    const response = await api.post('/auth/register', data);
    return response.data;
  }

  async loginWithPhone(data: PhoneLoginData): Promise<{ trackingId: string; message: string }> {
    const response = await api.post('/auth/phone/login', data);
    return response.data;
  }

  async verifyOTP(data: OTPVerifyData): Promise<AuthResponse> {
    const response = await api.post('/auth/phone/verify', data);
    return response.data;
  }

  async googleLogin(token: string): Promise<AuthResponse> {
    const response = await api.post('/auth/google', { token });
    return response.data;
  }

  async refreshToken(refreshToken: string): Promise<{ accessToken: string; expiresAt: number }> {
    const response = await api.post('/auth/refresh', { refreshToken });
    return response.data;
  }

  async logout(): Promise<void> {
    await api.post('/auth/logout', {});
  }

  async forgotPassword(email: string): Promise<{ message: string }> {
    const response = await api.post('/auth/forgot-password', { email });
    return response.data;
  }

  async resetPassword(token: string, newPassword: string): Promise<{ message: string }> {
    const response = await api.post('/auth/reset-password', { token, newPassword });
    return response.data;
  }

  async changePassword(currentPassword: string, newPassword: string): Promise<{ message: string }> {
    const response = await api.post('/auth/change-password', { currentPassword, newPassword });
    return response.data;
  }

  async getProfile(): Promise<AuthResponse['user']> {
    const response = await api.get('/auth/profile');
    return response.data;
  }

  async updateProfile(data: Partial<AuthResponse['user']>): Promise<AuthResponse['user']> {
    const response = await api.put('/auth/profile', data);
    return response.data;
  }
}

export const authService = new AuthService();
export default authService;
