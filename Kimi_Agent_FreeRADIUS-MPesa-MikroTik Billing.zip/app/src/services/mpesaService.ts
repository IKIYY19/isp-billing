import api from './api';

export interface STKPushRequest {
  phoneNumber: string;
  amount: number;
  accountNumber: string;
  description?: string;
  customerId?: string;
  invoiceId?: string;
}

export interface STKPushResponse {
  success: boolean;
  merchantRequestId?: string;
  checkoutRequestId?: string;
  message?: string;
  error?: string;
}

export interface PaymentStatus {
  success: boolean;
  resultCode?: string;
  resultDesc?: string;
  amount?: number;
  mpesaReceiptNumber?: string;
  transactionDate?: string;
  phoneNumber?: string;
  status: 'pending' | 'completed' | 'failed' | 'cancelled';
}

export interface MPesaPayment {
  id: string;
  transactionId: string;
  amount: number;
  method: 'mpesa';
  status: 'pending' | 'completed' | 'failed' | 'refunded' | 'cancelled';
  mpesaReceipt?: string;
  mpesaPhone?: string;
  createdAt: string;
}

export interface PendingPayment {
  checkoutRequestId: string;
  phoneNumber: string;
  amount: number;
  accountReference: string;
  status: string;
  createdAt: string;
}

export interface CustomerPaymentInfo {
  customer: {
    id: string;
    accountNumber: string;
    firstName: string;
    lastName: string;
    email?: string;
    phone: string;
    balance: number;
    status: string;
    plan?: {
      name: string;
      price: number;
    };
    lastPayment?: MPesaPayment;
    outstandingAmount: number;
  };
}

class MPesaService {
  // ============================================
  // STK Push Payments
  // ============================================

  async initiateSTKPush(data: STKPushRequest): Promise<STKPushResponse> {
    const response = await api.post('/mpesa/stkpush', data);
    return response.data;
  }

  async queryPaymentStatus(checkoutRequestId: string): Promise<PaymentStatus> {
    const response = await api.post('/mpesa/query', { checkoutRequestId });
    return response.data.data;
  }

  // ============================================
  // Public Payment (No Auth Required)
  // ============================================

  async getCustomerByAccountNumber(accountNumber: string): Promise<CustomerPaymentInfo> {
    const response = await api.get(`/mpesa/customer/${accountNumber}`);
    return response.data.data;
  }

  async makePublicPayment(data: { accountNumber: string; phoneNumber: string; amount: number }): Promise<STKPushResponse> {
    const response = await api.post('/mpesa/pay', data);
    return response.data;
  }

  // ============================================
  // Payment History
  // ============================================

  async getCustomerPaymentHistory(customerId: string, limit: number = 50): Promise<{ payments: MPesaPayment[] }> {
    const response = await api.get(`/mpesa/history/${customerId}?limit=${limit}`);
    return response.data.data;
  }

  async getPendingPayments(): Promise<{ pending: PendingPayment[] }> {
    const response = await api.get('/mpesa/pending');
    return response.data.data;
  }

  // ============================================
  // Admin Operations
  // ============================================

  async retryFailedPayments(): Promise<void> {
    await api.post('/mpesa/retry', {});
  }

  async simulatePayment(data: { phoneNumber: string; amount: number; accountNumber: string }): Promise<any> {
    const response = await api.post('/mpesa/simulate', data);
    return response.data.data;
  }

  async registerC2BUrls(validationUrl: string, confirmationUrl: string): Promise<any> {
    const response = await api.post('/mpesa/register-urls', { validationUrl, confirmationUrl });
    return response.data.data;
  }

  async getConfig(): Promise<{ config: any }> {
    const response = await api.get('/mpesa/config');
    return response.data.data;
  }
}

export const mpesaService = new MPesaService();
export default mpesaService;
