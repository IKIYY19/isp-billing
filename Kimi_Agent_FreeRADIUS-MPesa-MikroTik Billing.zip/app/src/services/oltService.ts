import api from './api';
import type { 
  OLT, 
  OLTStatus, 
  PONPort, 
  ONU, 
  ONUProvisioningData, 
  AIOptimization, 
  OLTAlarm, 
  OLTPerformance 
} from '../types';

export type { OLT, OLTStatus, PONPort, ONU, ONUProvisioningData, AIOptimization, OLTAlarm, OLTPerformance };

export interface OLTDashboardStats {
  oltCount: number;
  totalPorts: number;
  totalONUs: number;
  onlineONUs: number;
  offlineONUs: number;
  activeAlarms: number;
  utilization: number;
}

export interface OLTAutoDiscoveryResult {
  discovered: Array<{ serialNumber: string; ponPortId: string; signalQuality: string }>;
  autoProvisioned: number;
}

export interface OLTSelfHealingResult {
  actions: string[];
  issues: string[];
}

class OLTService {
  // ============================================
  // OLT Management
  // ============================================

  async getAllOLTs(): Promise<{ olts: OLT[] }> {
    const response = await api.get('/olt');
    return response.data.data;
  }

  async getOLT(oltId: string): Promise<{ olt: OLT }> {
    const response = await api.get(`/olt/${oltId}`);
    return response.data.data;
  }

  async addOLT(data: Omit<OLT, 'id' | 'isActive' | 'lastSeenAt' | 'firmwareVersion'>): Promise<{ olt: OLT }> {
    const response = await api.post('/olt', data);
    return response.data.data;
  }

  async updateOLT(oltId: string, data: Partial<OLT>): Promise<{ olt: OLT }> {
    const response = await api.put(`/olt/${oltId}`, data);
    return response.data.data;
  }

  async deleteOLT(oltId: string): Promise<void> {
    await api.delete(`/olt/${oltId}`);
  }

  async getOLTStatus(oltId: string): Promise<OLTStatus> {
    const response = await api.get(`/olt/${oltId}/status`);
    return response.data.data.status;
  }

  // ============================================
  // PON Ports
  // ============================================

  async getPONPorts(oltId: string): Promise<{ ports: PONPort[] }> {
    const response = await api.get(`/olt/${oltId}/ports`);
    return response.data.data;
  }

  // ============================================
  // ONU Management
  // ============================================

  async getONUs(oltId: string, ponPortId?: string): Promise<{ onus: ONU[] }> {
    const params: Record<string, string> = ponPortId ? { portId: ponPortId } : {};
    const response = await api.get(`/olt/${oltId}/onu`, { params });
    return response.data?.data || { onus: [] };
  }

  async provisionONU(oltId: string, data: ONUProvisioningData): Promise<{ onuId: string; success: boolean; message?: string }> {
    const response = await api.post(`/olt/${oltId}/onu`, data);
    return response.data?.data || { onuId: '', success: false };
  }

  async deprovisionONU(oltId: string, onuId: string): Promise<{ success: boolean; message?: string }> {
    const response = await api.delete(`/olt/${oltId}/onu/${onuId}`);
    return response.data?.data || { success: true };
  }

  async resetONU(oltId: string, onuId: string): Promise<{ success: boolean; message?: string }> {
    const response = await api.post(`/olt/${oltId}/onu/${onuId}/reset`, {});
    return response.data?.data || { success: true };
  }

  async updateONU(oltId: string, onuId: string, data: Partial<ONU>): Promise<{ onu: ONU }> {
    const response = await api.put(`/olt/${oltId}/onu/${onuId}`, data);
    return response.data?.data || { onu: {} as ONU };
  }

  // ============================================
  // Alarms & Performance
  // ============================================

  async getAlarms(oltId: string): Promise<{ alarms: OLTAlarm[] }> {
    const response = await api.get(`/olt/${oltId}/alarms`);
    return response.data?.data || { alarms: [] };
  }

  async acknowledgeAlarm(oltId: string, alarmId: string): Promise<void> {
    await api.post(`/olt/${oltId}/alarms/${alarmId}/acknowledge`, {});
  }

  async clearAlarm(oltId: string, alarmId: string): Promise<void> {
    await api.post(`/olt/${oltId}/alarms/${alarmId}/clear`, {});
  }

  async getPerformance(oltId: string): Promise<{ performance: OLTPerformance }> {
    const response = await api.get(`/olt/${oltId}/performance`);
    return response.data?.data || { performance: {} as OLTPerformance };
  }

  // ============================================
  // Commands
  // ============================================

  async executeCommand(oltId: string, command: string): Promise<{ output: string; success: boolean }> {
    const response = await api.post(`/olt/${oltId}/command`, { command });
    return response.data?.data || { output: '', success: false };
  }

  // ============================================
  // Self-Healing & AI Features
  // ============================================

  async runSelfHealing(oltId: string): Promise<OLTSelfHealingResult> {
    const response = await api.post(`/olt/${oltId}/self-healing`, {});
    return response.data?.data || { actions: [], issues: [] };
  }

  async getAIOptimizations(oltId: string): Promise<{ suggestions: AIOptimization[] }> {
    const response = await api.get(`/olt/${oltId}/ai-optimizations`);
    return response.data?.data || { suggestions: [] };
  }

  async autoDiscoverONUs(oltId: string): Promise<OLTAutoDiscoveryResult> {
    const response = await api.post(`/olt/${oltId}/auto-discover`, {});
    return response.data?.data || { discovered: [], autoProvisioned: 0 };
  }

  // ============================================
  // Dashboard
  // ============================================

  async getDashboardStats(): Promise<OLTDashboardStats> {
    const response = await api.get('/olt/dashboard/stats');
    return response.data.data;
  }

  // ============================================
  // Bulk Operations
  // ============================================

  async bulkProvisionONUs(oltId: string, data: ONUProvisioningData[]): Promise<{ results: Array<{ serialNumber: string; success: boolean; message: string; onuId?: string }> }> {
    const response = await api.post(`/olt/${oltId}/bulk-provision`, { onus: data });
    return response.data.data;
  }

  async bulkResetONUs(oltId: string, onuIds: string[]): Promise<{ results: Array<{ onuId: string; success: boolean; message: string }> }> {
    const response = await api.post(`/olt/${oltId}/bulk-reset`, { onuIds });
    return response.data.data;
  }
}

export const oltService = new OLTService();
export default oltService;
