import api from './api';

export interface MikrotikRouter {
  id: string;
  name: string;
  ipAddress: string;
  port: number;
  username: string;
  password: string;
  apiPort: number;
  apiUseSsl: boolean;
  location?: string;
  description?: string;
  isActive: boolean;
  lastConnected?: string;
  version?: string;
  companyId?: string;
}

export interface RouterStatus {
  connected: boolean;
  version?: string;
  uptime?: string;
  cpuUsage?: number;
  memoryUsage?: number;
  diskUsage?: number;
  totalUsers?: number;
  activeUsers?: number;
  interfaces?: InterfaceInfo[];
  routes?: RouteInfo[];
  firewallRules?: number;
  queues?: number;
  health?: RouterHealth;
  lastError?: string;
}

export interface InterfaceInfo {
  name: string;
  type: string;
  status: 'up' | 'down' | 'disabled';
  macAddress?: string;
  ipAddress?: string;
  rxBytes: number;
  txBytes: number;
  rxPackets: number;
  txPackets: number;
  rxErrors: number;
  txErrors: number;
  rxDrops: number;
  txDrops: number;
  running: boolean;
  comment?: string;
}

export interface RouteInfo {
  dst: string;
  gateway: string;
  distance: number;
  scope: number;
  targetScope: number;
  active: boolean;
  dynamic: boolean;
  comment?: string;
}

export interface RouterHealth {
  voltage?: number;
  temperature?: number;
  cpuTemperature?: number;
  fanSpeed?: number;
  fanSpeed2?: number;
  powerConsumption?: number;
}

export interface ActiveUser {
  id: string;
  name: string;
  address: string;
  macAddress: string;
  uptime: string;
  service: string;
  comment?: string;
  bytesIn: number;
  bytesOut: number;
  packetsIn: number;
  packetsOut: number;
}

export interface LogEntry {
  time: string;
  topics: string;
  message: string;
}

export interface TroubleshootingResult {
  issues: string[];
  recommendations: string[];
  autoFixes: string[];
  commands: string[];
}

export interface DashboardStats {
  routerCount: number;
  onlineRouters: number;
  offlineRouters: number;
  totalUsers: number;
  avgCpu: number;
  avgMemory: number;
  totalInterfaces: number;
  networkHealth: number;
}

class MikrotikService {
  // ============================================
  // Router Management
  // ============================================

  async getAllRouters(): Promise<{ routers: MikrotikRouter[] }> {
    const response = await api.get('/mikrotik');
    return response.data.data;
  }

  async getRouter(routerId: string): Promise<{ router: MikrotikRouter }> {
    const response = await api.get(`/mikrotik/${routerId}`);
    return response.data.data;
  }

  async addRouter(data: Omit<MikrotikRouter, 'id' | 'isActive' | 'lastConnected' | 'version'>): Promise<{ router: MikrotikRouter }> {
    const response = await api.post('/mikrotik', data);
    return response.data.data;
  }

  async testConnection(data: Partial<MikrotikRouter>): Promise<{ success: boolean; message: string; status?: RouterStatus }> {
    const response = await api.post('/mikrotik/test', data);
    return response.data;
  }

  async updateRouter(routerId: string, data: Partial<MikrotikRouter>): Promise<{ router: MikrotikRouter }> {
    const response = await api.put(`/mikrotik/${routerId}`, data);
    return response.data.data;
  }

  async deleteRouter(routerId: string): Promise<void> {
    await api.delete(`/mikrotik/${routerId}`);
  }

  // ============================================
  // Monitoring
  // ============================================

  async getRouterStatus(routerId: string): Promise<RouterStatus> {
    const response = await api.get(`/mikrotik/${routerId}/status`);
    return response.data.data.status;
  }

  async getInterfaces(routerId: string): Promise<{ interfaces: InterfaceInfo[] }> {
    const response = await api.get(`/mikrotik/${routerId}/interfaces`);
    return response.data.data;
  }

  async getRoutes(routerId: string): Promise<{ routes: RouteInfo[] }> {
    const response = await api.get(`/mikrotik/${routerId}/routes`);
    return response.data.data;
  }

  async getActiveUsers(routerId: string): Promise<{ users: ActiveUser[] }> {
    const response = await api.get(`/mikrotik/${routerId}/users`);
    return response.data.data;
  }

  async getLogs(routerId: string, limit: number = 100): Promise<{ logs: LogEntry[] }> {
    const response = await api.get(`/mikrotik/${routerId}/logs?limit=${limit}`);
    return response.data.data;
  }

  async getRealtimeMetrics(routerId: string): Promise<{ metrics: any }> {
    const response = await api.get(`/mikrotik/${routerId}/realtime`);
    return response.data.data;
  }

  // ============================================
  // Command Execution
  // ============================================

  async executeCommand(routerId: string, command: string): Promise<{ output: string }> {
    const response = await api.post(`/mikrotik/${routerId}/command`, { command });
    return response.data.data;
  }

  // ============================================
  // Troubleshooting
  // ============================================

  async runTroubleshooting(routerId: string): Promise<TroubleshootingResult> {
    const response = await api.post(`/mikrotik/${routerId}/troubleshoot`, {});
    return response.data?.data || { issues: [], recommendations: [], autoFixes: [], commands: [] };
  }

  async autoFix(routerId: string, fixes: string[]): Promise<{ results: string[] }> {
    const response = await api.post(`/mikrotik/${routerId}/autofix`, { fixes });
    return response.data?.data || { results: [] };
  }

  // ============================================
  // Dashboard
  // ============================================

  async getDashboardStats(): Promise<DashboardStats> {
    const response = await api.get('/mikrotik/dashboard/stats');
    return response.data.data;
  }

  // ============================================
  // Bulk Operations
  // ============================================

  async bulkCommand(routerIds: string[], command: string): Promise<{ results: Array<{ routerId: string; success: boolean; output: string }> }> {
    const response = await api.post('/mikrotik/bulk/command', { routerIds, command });
    return response.data.data;
  }
}

export const mikrotikService = new MikrotikService();
export default mikrotikService;
