import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Plus, 
  Edit2, 
  Trash2, 
  Power, 
  PowerOff, 
  RefreshCw, 
  Router, 
  Cpu, 
  HardDrive,
  Users,
  Clock,
  Activity,
  Settings,
  X,
  CheckCircle,
  XCircle
} from 'lucide-react';
import type { MikrotikRouter } from '../types';
// getStatusColor is available in lib/utils.ts

// Mock data
const mockRouters: MikrotikRouter[] = [
  {
    id: '1',
    name: 'Main Tower',
    ipAddress: '192.168.100.1',
    port: 8291,
    username: 'admin',
    password: '********',
    apiPort: 8728,
    apiUseSsl: false,
    isActive: true,
    lastConnected: '2024-06-15T10:30:00',
    version: '7.12.1',
    uptime: '45d 12h 30m',
    cpuUsage: 35,
    memoryUsage: 62,
    totalUsers: 156,
    location: 'Nairobi CBD',
    description: 'Primary distribution router',
  },
  {
    id: '2',
    name: 'Westlands AP',
    ipAddress: '192.168.100.2',
    port: 8291,
    username: 'admin',
    password: '********',
    apiPort: 8728,
    apiUseSsl: false,
    isActive: true,
    lastConnected: '2024-06-15T09:45:00',
    version: '7.11.2',
    uptime: '30d 8h 15m',
    cpuUsage: 28,
    memoryUsage: 45,
    totalUsers: 89,
    location: 'Westlands',
    description: 'Westlands access point',
  },
  {
    id: '3',
    name: 'Karen Backup',
    ipAddress: '192.168.100.3',
    port: 8291,
    username: 'admin',
    password: '********',
    apiPort: 8728,
    apiUseSsl: false,
    isActive: false,
    lastConnected: '2024-06-10T14:20:00',
    location: 'Karen',
    description: 'Backup router for Karen area',
  },
  {
    id: '4',
    name: 'Kilimani Hub',
    ipAddress: '192.168.100.4',
    port: 8291,
    username: 'admin',
    password: '********',
    apiPort: 8728,
    apiUseSsl: false,
    isActive: true,
    lastConnected: '2024-06-15T11:00:00',
    version: '7.12.1',
    uptime: '15d 6h 45m',
    cpuUsage: 42,
    memoryUsage: 58,
    totalUsers: 124,
    location: 'Kilimani',
    description: 'Kilimani distribution hub',
  },
];

export default function MikrotikRouters() {
  const [routers, setRouters] = useState<MikrotikRouter[]>(mockRouters);
  const [_showAddModal, _setShowAddModal] = useState(false);
  const [_showEditModal, _setShowEditModal] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [selectedRouter, setSelectedRouter] = useState<MikrotikRouter | null>(null);

  const handleDelete = (router: MikrotikRouter) => {
    setSelectedRouter(router);
    setShowDeleteConfirm(true);
  };

  const confirmDelete = () => {
    if (selectedRouter) {
      setRouters(prev => prev.filter(r => r.id !== selectedRouter.id));
      setShowDeleteConfirm(false);
      setSelectedRouter(null);
    }
  };

  const handleEdit = (_router: MikrotikRouter) => {
    // Edit functionality to be implemented
  };

  const handleViewDetails = (router: MikrotikRouter) => {
    setSelectedRouter(router);
    setShowDetailsModal(true);
  };

  const toggleRouterStatus = (router: MikrotikRouter) => {
    setRouters(prev => prev.map(r => 
      r.id === router.id ? { ...r, isActive: !r.isActive } : r
    ));
  };

  const onlineRouters = routers.filter(r => r.isActive).length;
  const totalUsers = routers.reduce((sum, r) => sum + (r.totalUsers || 0), 0);
  const avgCpu = routers.filter(r => r.isActive).reduce((sum, r) => sum + (r.cpuUsage || 0), 0) / onlineRouters || 0;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground">MikroTik Routers</h2>
          <p className="text-muted-foreground">Manage your network infrastructure</p>
        </div>
        <button
          onClick={() => {/* Add router modal to be implemented */}}
          className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
        >
          <Plus className="w-4 h-4" />
          Add Router
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-success/20 rounded-lg flex items-center justify-center">
              <Router className="w-5 h-5 text-success" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Online Routers</p>
              <p className="text-2xl font-bold text-foreground">{onlineRouters}/{routers.length}</p>
            </div>
          </div>
        </div>
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary/20 rounded-lg flex items-center justify-center">
              <Users className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Connected Users</p>
              <p className="text-2xl font-bold text-foreground">{totalUsers}</p>
            </div>
          </div>
        </div>
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-warning/20 rounded-lg flex items-center justify-center">
              <Cpu className="w-5 h-5 text-warning" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Avg CPU Usage</p>
              <p className="text-2xl font-bold text-foreground">{avgCpu.toFixed(1)}%</p>
            </div>
          </div>
        </div>
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-secondary/20 rounded-lg flex items-center justify-center">
              <Activity className="w-5 h-5 text-secondary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Network Health</p>
              <p className="text-2xl font-bold text-success">98.5%</p>
            </div>
          </div>
        </div>
      </div>

      {/* Routers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {routers.map((router, index) => (
          <motion.div
            key={router.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="glass rounded-xl p-5 hover:shadow-lg transition-all duration-300"
          >
            {/* Header */}
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                  router.isActive ? 'bg-success/20' : 'bg-destructive/20'
                }`}>
                  <Router className={`w-6 h-6 ${router.isActive ? 'text-success' : 'text-destructive'}`} />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground">{router.name}</h3>
                  <p className="text-sm text-muted-foreground">{router.ipAddress}</p>
                </div>
              </div>
              <button
                onClick={() => toggleRouterStatus(router)}
                className={`p-2 rounded-lg transition-colors ${
                  router.isActive 
                    ? 'bg-success/20 text-success hover:bg-success/30' 
                    : 'bg-destructive/20 text-destructive hover:bg-destructive/30'
                }`}
              >
                {router.isActive ? <Power className="w-4 h-4" /> : <PowerOff className="w-4 h-4" />}
              </button>
            </div>

            {/* Status */}
            <div className="flex items-center gap-2 mb-4">
              <div className={`w-2 h-2 rounded-full ${router.isActive ? 'bg-success animate-pulse' : 'bg-destructive'}`} />
              <span className={`text-sm ${router.isActive ? 'text-success' : 'text-destructive'}`}>
                {router.isActive ? 'Online' : 'Offline'}
              </span>
              {router.isActive && router.version && (
                <span className="text-xs text-muted-foreground ml-2">v{router.version}</span>
              )}
            </div>

            {/* Stats */}
            {router.isActive && (
              <div className="grid grid-cols-2 gap-3 mb-4">
                <div className="p-2 bg-muted/50 rounded-lg">
                  <div className="flex items-center gap-1 text-muted-foreground mb-1">
                    <Cpu className="w-3 h-3" />
                    <span className="text-xs">CPU</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
                      <div 
                        className={`h-full rounded-full ${
                          (router.cpuUsage || 0) > 80 ? 'bg-destructive' : 'bg-success'
                        }`}
                        style={{ width: `${router.cpuUsage}%` }}
                      />
                    </div>
                    <span className="text-xs text-foreground">{router.cpuUsage}%</span>
                  </div>
                </div>
                <div className="p-2 bg-muted/50 rounded-lg">
                  <div className="flex items-center gap-1 text-muted-foreground mb-1">
                    <HardDrive className="w-3 h-3" />
                    <span className="text-xs">RAM</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
                      <div 
                        className={`h-full rounded-full ${
                          (router.memoryUsage || 0) > 80 ? 'bg-destructive' : 'bg-primary'
                        }`}
                        style={{ width: `${router.memoryUsage}%` }}
                      />
                    </div>
                    <span className="text-xs text-foreground">{router.memoryUsage}%</span>
                  </div>
                </div>
              </div>
            )}

            {/* Info */}
            <div className="space-y-2 mb-4">
              {router.uptime && (
                <div className="flex items-center gap-2 text-sm">
                  <Clock className="w-4 h-4 text-muted-foreground" />
                  <span className="text-muted-foreground">Uptime:</span>
                  <span className="text-foreground">{router.uptime}</span>
                </div>
              )}
              {router.totalUsers !== undefined && (
                <div className="flex items-center gap-2 text-sm">
                  <Users className="w-4 h-4 text-muted-foreground" />
                  <span className="text-muted-foreground">Users:</span>
                  <span className="text-foreground">{router.totalUsers}</span>
                </div>
              )}
              <div className="flex items-center gap-2 text-sm">
                <Settings className="w-4 h-4 text-muted-foreground" />
                <span className="text-muted-foreground">Location:</span>
                <span className="text-foreground">{router.location}</span>
              </div>
            </div>

            {/* Actions */}
            <div className="flex gap-2">
              <button
                onClick={() => handleViewDetails(router)}
                className="flex-1 px-3 py-2 bg-muted text-foreground rounded-lg hover:bg-muted/80 transition-colors text-sm"
              >
                Details
              </button>
              <button
                onClick={() => handleEdit(router)}
                className="p-2 bg-muted text-foreground rounded-lg hover:bg-muted/80 transition-colors"
              >
                <Edit2 className="w-4 h-4" />
              </button>
              <button
                onClick={() => handleDelete(router)}
                className="p-2 bg-destructive/10 text-destructive rounded-lg hover:bg-destructive/20 transition-colors"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Router Details Modal */}
      <AnimatePresence>
        {showDetailsModal && selectedRouter && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
            onClick={() => setShowDetailsModal(false)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="glass rounded-xl p-6 max-w-lg w-full"
            >
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                    selectedRouter.isActive ? 'bg-success/20' : 'bg-destructive/20'
                  }`}>
                    <Router className={`w-6 h-6 ${selectedRouter.isActive ? 'text-success' : 'text-destructive'}`} />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-foreground">{selectedRouter.name}</h3>
                    <p className="text-sm text-muted-foreground">{selectedRouter.ipAddress}:{selectedRouter.port}</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowDetailsModal(false)}
                  className="p-2 hover:bg-muted rounded-lg transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-4">
                {/* Status */}
                <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                  <span className="text-sm text-muted-foreground">Status</span>
                  <div className="flex items-center gap-2">
                    {selectedRouter.isActive ? (
                      <>
                        <CheckCircle className="w-4 h-4 text-success" />
                        <span className="text-success font-medium">Online</span>
                      </>
                    ) : (
                      <>
                        <XCircle className="w-4 h-4 text-destructive" />
                        <span className="text-destructive font-medium">Offline</span>
                      </>
                    )}
                  </div>
                </div>

                {/* Connection Details */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-3 bg-muted/50 rounded-lg">
                    <p className="text-sm text-muted-foreground mb-1">API Port</p>
                    <p className="text-sm font-medium text-foreground">{selectedRouter.apiPort}</p>
                  </div>
                  <div className="p-3 bg-muted/50 rounded-lg">
                    <p className="text-sm text-muted-foreground mb-1">Version</p>
                    <p className="text-sm font-medium text-foreground">{selectedRouter.version || 'N/A'}</p>
                  </div>
                  <div className="p-3 bg-muted/50 rounded-lg">
                    <p className="text-sm text-muted-foreground mb-1">Uptime</p>
                    <p className="text-sm font-medium text-foreground">{selectedRouter.uptime || 'N/A'}</p>
                  </div>
                  <div className="p-3 bg-muted/50 rounded-lg">
                    <p className="text-sm text-muted-foreground mb-1">Connected Users</p>
                    <p className="text-sm font-medium text-foreground">{selectedRouter.totalUsers || 0}</p>
                  </div>
                </div>

                {/* Resource Usage */}
                {selectedRouter.isActive && (
                  <div className="border-t border-border pt-4">
                    <p className="text-sm font-medium text-foreground mb-3">Resource Usage</p>
                    <div className="space-y-3">
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="text-muted-foreground">CPU</span>
                          <span className="text-foreground">{selectedRouter.cpuUsage}%</span>
                        </div>
                        <div className="h-2 bg-muted rounded-full overflow-hidden">
                          <div 
                            className={`h-full rounded-full transition-all ${
                              (selectedRouter.cpuUsage || 0) > 80 ? 'bg-destructive' : 'bg-success'
                            }`}
                            style={{ width: `${selectedRouter.cpuUsage}%` }}
                          />
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="text-muted-foreground">Memory</span>
                          <span className="text-foreground">{selectedRouter.memoryUsage}%</span>
                        </div>
                        <div className="h-2 bg-muted rounded-full overflow-hidden">
                          <div 
                            className={`h-full rounded-full transition-all ${
                              (selectedRouter.memoryUsage || 0) > 80 ? 'bg-destructive' : 'bg-primary'
                            }`}
                            style={{ width: `${selectedRouter.memoryUsage}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Location & Description */}
                <div className="border-t border-border pt-4">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Location</span>
                      <span className="text-sm text-foreground">{selectedRouter.location}</span>
                    </div>
                    {selectedRouter.description && (
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Description</span>
                        <span className="text-sm text-foreground">{selectedRouter.description}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Actions */}
                <div className="flex justify-end gap-3 pt-4">
                  <button
                    onClick={() => setShowDetailsModal(false)}
                    className="px-4 py-2 text-foreground hover:bg-muted rounded-lg transition-colors"
                  >
                    Close
                  </button>
                  <button className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors flex items-center gap-2">
                    <RefreshCw className="w-4 h-4" />
                    Reconnect
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Delete Confirmation Modal */}
      <AnimatePresence>
        {showDeleteConfirm && selectedRouter && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
            onClick={() => setShowDeleteConfirm(false)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="glass rounded-xl p-6 max-w-md w-full"
            >
              <h3 className="text-xl font-semibold text-foreground mb-4">Remove Router</h3>
              <p className="text-muted-foreground mb-6">
                Are you sure you want to remove <span className="text-foreground font-medium">{selectedRouter.name}</span>? 
                This will delete all associated configuration.
              </p>
              <div className="flex justify-end gap-3">
                <button
                  onClick={() => setShowDeleteConfirm(false)}
                  className="px-4 py-2 text-foreground hover:bg-muted rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={confirmDelete}
                  className="px-4 py-2 bg-destructive text-destructive-foreground rounded-lg hover:bg-destructive/90 transition-colors"
                >
                  Remove
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
