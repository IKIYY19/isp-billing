import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  MessageSquare, 
  Plus, 
  Search,
  Clock,
  CheckCircle,
  User,
  Send,
  Paperclip,
  Tag
} from 'lucide-react';
import { formatDate, formatDistanceToNow } from '../lib/utils';

interface Ticket {
  id: string;
  subject: string;
  description: string;
  status: 'open' | 'in_progress' | 'resolved' | 'closed';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  category: string;
  customerName: string;
  customerId: string;
  assignedTo?: string;
  createdAt: string;
  updatedAt: string;
  messages: TicketMessage[];
}

interface TicketMessage {
  id: string;
  sender: string;
  senderRole: 'customer' | 'agent' | 'admin';
  message: string;
  attachments?: string[];
  createdAt: string;
}

const mockTickets: Ticket[] = [
  {
    id: 'TKT-001',
    subject: 'Internet connection very slow',
    description: 'My internet has been very slow for the past 2 days. I am on the Premium 10Mbps plan.',
    status: 'in_progress',
    priority: 'high',
    category: 'Technical',
    customerName: 'John Doe',
    customerId: 'CUST-001',
    assignedTo: 'Support Agent Mike',
    createdAt: '2024-06-15T10:30:00',
    updatedAt: '2024-06-15T14:20:00',
    messages: [
      {
        id: '1',
        sender: 'John Doe',
        senderRole: 'customer',
        message: 'My internet has been very slow for the past 2 days. I am on the Premium 10Mbps plan.',
        createdAt: '2024-06-15T10:30:00',
      },
      {
        id: '2',
        sender: 'Support Agent Mike',
        senderRole: 'agent',
        message: 'Hi John, I apologize for the inconvenience. Let me check your connection from our end. Could you please restart your router and let me know the results?',
        createdAt: '2024-06-15T11:00:00',
      },
      {
        id: '3',
        sender: 'John Doe',
        senderRole: 'customer',
        message: 'I restarted the router but the speed is still slow. Getting around 2Mbps instead of 10Mbps.',
        createdAt: '2024-06-15T12:30:00',
      },
    ],
  },
  {
    id: 'TKT-002',
    subject: 'Cannot login to customer portal',
    description: 'I forgot my password and the reset link is not working.',
    status: 'open',
    priority: 'medium',
    category: 'Account',
    customerName: 'Jane Smith',
    customerId: 'CUST-002',
    createdAt: '2024-06-15T09:00:00',
    updatedAt: '2024-06-15T09:00:00',
    messages: [
      {
        id: '1',
        sender: 'Jane Smith',
        senderRole: 'customer',
        message: 'I forgot my password and the reset link is not working. Please help.',
        createdAt: '2024-06-15T09:00:00',
      },
    ],
  },
  {
    id: 'TKT-003',
    subject: 'Request to upgrade plan',
    description: 'I would like to upgrade from Basic 5Mbps to Premium 10Mbps.',
    status: 'resolved',
    priority: 'low',
    category: 'Billing',
    customerName: 'David Brown',
    customerId: 'CUST-005',
    assignedTo: 'Sales Agent Sarah',
    createdAt: '2024-06-14T16:00:00',
    updatedAt: '2024-06-15T08:00:00',
    messages: [
      {
        id: '1',
        sender: 'David Brown',
        senderRole: 'customer',
        message: 'I would like to upgrade from Basic 5Mbps to Premium 10Mbps. What is the process?',
        createdAt: '2024-06-14T16:00:00',
      },
      {
        id: '2',
        sender: 'Sales Agent Sarah',
        senderRole: 'agent',
        message: 'Hi David, I can help you with that. The upgrade will take effect immediately and you will be charged the prorated difference. Would you like me to proceed?',
        createdAt: '2024-06-14T17:00:00',
      },
      {
        id: '3',
        sender: 'David Brown',
        senderRole: 'customer',
        message: 'Yes please proceed with the upgrade.',
        createdAt: '2024-06-14T18:00:00',
      },
      {
        id: '4',
        sender: 'Sales Agent Sarah',
        senderRole: 'agent',
        message: 'Your plan has been successfully upgraded to Premium 10Mbps. You should see the improved speeds immediately. Thank you for choosing us!',
        createdAt: '2024-06-15T08:00:00',
      },
    ],
  },
];

const getStatusColor = (status: Ticket['status']) => {
  switch (status) {
    case 'open': return 'bg-primary/20 text-primary';
    case 'in_progress': return 'bg-warning/20 text-warning';
    case 'resolved': return 'bg-success/20 text-success';
    case 'closed': return 'bg-muted text-muted-foreground';
  }
};

const getPriorityColor = (priority: Ticket['priority']) => {
  switch (priority) {
    case 'urgent': return 'text-destructive';
    case 'high': return 'text-warning';
    case 'medium': return 'text-primary';
    case 'low': return 'text-muted-foreground';
  }
};

export default function SupportTickets() {
  const [tickets, setTickets] = useState<Ticket[]>(mockTickets);
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);
  const [_showNewTicketModal, setShowNewTicketModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterPriority, setFilterPriority] = useState<string>('all');
  const [newMessage, setNewMessage] = useState('');

  const filteredTickets = tickets.filter(ticket => {
    const matchesSearch = 
      ticket.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ticket.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ticket.id.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = filterStatus === 'all' || ticket.status === filterStatus;
    const matchesPriority = filterPriority === 'all' || ticket.priority === filterPriority;
    
    return matchesSearch && matchesStatus && matchesPriority;
  });

  const stats = {
    total: tickets.length,
    open: tickets.filter(t => t.status === 'open').length,
    inProgress: tickets.filter(t => t.status === 'in_progress').length,
    resolved: tickets.filter(t => t.status === 'resolved').length,
    urgent: tickets.filter(t => t.priority === 'urgent').length,
  };

  const handleSendMessage = () => {
    if (!selectedTicket || !newMessage.trim()) return;
    
    const message: TicketMessage = {
      id: Date.now().toString(),
      sender: 'Admin',
      senderRole: 'admin',
      message: newMessage,
      createdAt: new Date().toISOString(),
    };
    
    setTickets(prev => prev.map(t => 
      t.id === selectedTicket.id 
        ? { ...t, messages: [...t.messages, message], updatedAt: new Date().toISOString() }
        : t
    ));
    
    setSelectedTicket(prev => prev ? { ...prev, messages: [...prev.messages, message] } : null);
    setNewMessage('');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Support Tickets</h2>
          <p className="text-muted-foreground">Manage customer support requests</p>
        </div>
        <button
          onClick={() => setShowNewTicketModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
        >
          <Plus className="w-4 h-4" />
          New Ticket
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <div className="glass rounded-xl p-4">
          <p className="text-sm text-muted-foreground">Total Tickets</p>
          <p className="text-2xl font-bold text-foreground">{stats.total}</p>
        </div>
        <div className="glass rounded-xl p-4">
          <p className="text-sm text-muted-foreground">Open</p>
          <p className="text-2xl font-bold text-primary">{stats.open}</p>
        </div>
        <div className="glass rounded-xl p-4">
          <p className="text-sm text-muted-foreground">In Progress</p>
          <p className="text-2xl font-bold text-warning">{stats.inProgress}</p>
        </div>
        <div className="glass rounded-xl p-4">
          <p className="text-sm text-muted-foreground">Resolved</p>
          <p className="text-2xl font-bold text-success">{stats.resolved}</p>
        </div>
        <div className="glass rounded-xl p-4">
          <p className="text-sm text-muted-foreground">Urgent</p>
          <p className="text-2xl font-bold text-destructive">{stats.urgent}</p>
        </div>
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Tickets List */}
        <div className="lg:col-span-1 space-y-4">
          {/* Filters */}
          <div className="glass rounded-xl p-4 space-y-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search tickets..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-muted border border-border rounded-lg text-sm"
              />
            </div>
            <div className="flex gap-2">
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="flex-1 px-3 py-2 bg-muted border border-border rounded-lg text-sm"
              >
                <option value="all">All Status</option>
                <option value="open">Open</option>
                <option value="in_progress">In Progress</option>
                <option value="resolved">Resolved</option>
                <option value="closed">Closed</option>
              </select>
              <select
                value={filterPriority}
                onChange={(e) => setFilterPriority(e.target.value)}
                className="flex-1 px-3 py-2 bg-muted border border-border rounded-lg text-sm"
              >
                <option value="all">All Priority</option>
                <option value="urgent">Urgent</option>
                <option value="high">High</option>
                <option value="medium">Medium</option>
                <option value="low">Low</option>
              </select>
            </div>
          </div>

          {/* Ticket Cards */}
          <div className="space-y-2 max-h-[500px] overflow-y-auto scrollbar-thin">
            {filteredTickets.map((ticket) => (
              <motion.div
                key={ticket.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                onClick={() => setSelectedTicket(ticket)}
                className={`glass rounded-xl p-4 cursor-pointer transition-all ${
                  selectedTicket?.id === ticket.id 
                    ? 'border-2 border-primary' 
                    : 'hover:bg-muted/50'
                }`}
              >
                <div className="flex items-start justify-between mb-2">
                  <span className="text-xs font-mono text-muted-foreground">{ticket.id}</span>
                  <span className={`px-2 py-0.5 rounded-full text-xs ${getStatusColor(ticket.status)}`}>
                    {ticket.status.replace('_', ' ')}
                  </span>
                </div>
                <h4 className="font-medium text-foreground mb-1 line-clamp-1">{ticket.subject}</h4>
                <p className="text-sm text-muted-foreground mb-2 line-clamp-2">{ticket.description}</p>
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <User className="w-3 h-3" />
                    <span className="text-muted-foreground">{ticket.customerName}</span>
                  </div>
                  <span className={`font-medium ${getPriorityColor(ticket.priority)}`}>
                    {ticket.priority}
                  </span>
                </div>
                <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
                  <Clock className="w-3 h-3" />
                  <span>{formatDistanceToNow(ticket.createdAt)}</span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Ticket Detail */}
        <div className="lg:col-span-2">
          {selectedTicket ? (
            <div className="glass rounded-xl h-full flex flex-col">
              {/* Header */}
              <div className="p-4 border-b border-border">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="text-lg font-semibold text-foreground">{selectedTicket.subject}</h3>
                    <p className="text-sm text-muted-foreground">{selectedTicket.id}</p>
                  </div>
                  <div className="flex gap-2">
                    <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(selectedTicket.status)}`}>
                      {selectedTicket.status.replace('_', ' ')}
                    </span>
                    <span className={`px-2 py-1 rounded-full text-xs bg-muted ${getPriorityColor(selectedTicket.priority)}`}>
                      {selectedTicket.priority}
                    </span>
                  </div>
                </div>
                <div className="flex flex-wrap gap-4 text-sm">
                  <div className="flex items-center gap-2">
                    <User className="w-4 h-4 text-muted-foreground" />
                    <span className="text-foreground">{selectedTicket.customerName}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Tag className="w-4 h-4 text-muted-foreground" />
                    <span className="text-foreground">{selectedTicket.category}</span>
                  </div>
                  {selectedTicket.assignedTo && (
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-muted-foreground" />
                      <span className="text-foreground">Assigned to: {selectedTicket.assignedTo}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Messages */}
              <div className="flex-1 p-4 overflow-y-auto max-h-[400px] space-y-4">
                {selectedTicket.messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex ${message.senderRole === 'customer' ? 'justify-start' : 'justify-end'}`}
                  >
                    <div className={`max-w-[80%] ${
                      message.senderRole === 'customer' 
                        ? 'bg-muted' 
                        : 'bg-primary/20'
                    } rounded-xl p-3`}>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-sm font-medium text-foreground">{message.sender}</span>
                        <span className="text-xs text-muted-foreground">
                          {formatDate(message.createdAt)}
                        </span>
                      </div>
                      <p className="text-sm text-foreground">{message.message}</p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Reply Input */}
              <div className="p-4 border-t border-border">
                <div className="flex gap-2">
                  <textarea
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    placeholder="Type your reply..."
                    rows={2}
                    className="flex-1 px-4 py-2 bg-muted border border-border rounded-lg resize-none"
                  />
                  <div className="flex flex-col gap-2">
                    <button className="p-2 hover:bg-muted rounded-lg text-muted-foreground">
                      <Paperclip className="w-5 h-5" />
                    </button>
                    <button 
                      onClick={handleSendMessage}
                      className="p-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90"
                    >
                      <Send className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="glass rounded-xl h-full flex items-center justify-center">
              <div className="text-center">
                <MessageSquare className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">Select a ticket to view details</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
