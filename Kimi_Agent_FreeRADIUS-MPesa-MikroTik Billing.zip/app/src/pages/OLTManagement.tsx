import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { oltService } from '../services/oltService';
import type { OLT, OLTStatus, PONPort, ONU, ONUProvisioningData, AIOptimization } from '../services/oltService';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import OLTNetworkTopology from '@/components/olt/OLTNetworkTopology';
import OLTPerformanceCharts from '@/components/olt/OLTPerformanceCharts';
import OLTDashboard from '@/components/olt/OLTDashboard';
import { 
  Server,
  Plus,
  RefreshCw,
  Activity,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Zap,
  Cpu,
  Thermometer,
  Wifi,
  Signal,
  Search,
  Brain,
  Wrench,
  Trash2,
  Terminal,
  Network,
  BarChart3
} from 'lucide-react';

const VENDORS = [
  { id: 'huawei', name: 'Huawei', models: ['MA5600T', 'MA5800', 'EA5800'] },
  { id: 'zte', name: 'ZTE', models: ['C220', 'C300', 'C320', 'C350', 'C600'] },
  { id: 'nokia', name: 'Nokia/Alcatel-Lucent', models: ['ISAM 7302', 'ISAM 7330', 'ISAM 7360'] },
  { id: 'fiberhome', name: 'FiberHome', models: ['AN5516-01', 'AN5516-04', 'AN5516-06'] }
];

const PROTOCOLS = ['ssh', 'telnet', 'snmp'];

export default function OLTManagement() {
  const [olts, setOLTs] = useState<OLT[]>([]);
  const [oltStatuses, setOltStatuses] = useState<Map<string, OLTStatus>>(new Map());
  const [selectedOLT, setSelectedOLT] = useState<OLT | null>(null);
  const [ponPorts, setPonPorts] = useState<PONPort[]>([]);
  const [onus, setOnus] = useState<ONU[]>([]);
  const [aiOptimizations, setAiOptimizations] = useState<AIOptimization[]>([]);
  const [selfHealingResult, setSelfHealingResult] = useState<{ actions: string[]; issues: string[] } | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Dialog states
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showCommandDialog, setShowCommandDialog] = useState(false);
  const [showProvisionDialog, setShowProvisionDialog] = useState(false);
  const [commandOutput, setCommandOutput] = useState('');
  const [customCommand, setCustomCommand] = useState('');

  // Form states
  const [newOLT, setNewOLT] = useState({
    name: '',
    vendor: 'huawei',
    model: '',
    ipAddress: '',
    port: 22,
    protocol: 'ssh',
    username: '',
    password: '',
    enablePassword: '',
    snmpCommunity: 'public',
    snmpVersion: 'v2c',
    location: ''
  });

  const [provisionData, setProvisionData] = useState<ONUProvisioningData>({
    serialNumber: '',
    ponPortId: '',
    customerId: '',
    serviceProfile: '',
    lineProfile: '',
    description: ''
  });

  useEffect(() => {
    fetchOLTs();
  }, []);

  const fetchOLTs = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await oltService.getAllOLTs();
      setOLTs(data.olts);

      // Fetch status for each OLT
      const statusMap = new Map<string, OLTStatus>();
      for (const olt of data.olts) {
        try {
          const status = await oltService.getOLTStatus(olt.id);
          statusMap.set(olt.id, status);
        } catch (err) {
          console.error(`Failed to fetch status for OLT ${olt.id}:`, err);
        }
      }
      setOltStatuses(statusMap);
    } catch (err: any) {
      setError(err.message || 'Failed to fetch OLTs');
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await fetchOLTs();
    setRefreshing(false);
  };

  const handleAddOLT = async () => {
    try {
      setError(null);
      await oltService.addOLT(newOLT);
      setShowAddDialog(false);
      setNewOLT({
        name: '',
        vendor: 'huawei',
        model: '',
        ipAddress: '',
        port: 22,
        protocol: 'ssh',
        username: '',
        password: '',
        enablePassword: '',
        snmpCommunity: 'public',
        snmpVersion: 'v2c',
        location: ''
      });
      fetchOLTs();
    } catch (err: any) {
      setError(err.message || 'Failed to add OLT');
    }
  };

  const handleDeleteOLT = async (oltId: string) => {
    if (!confirm('Are you sure you want to remove this OLT?')) return;
    try {
      setError(null);
      await oltService.deleteOLT(oltId);
      fetchOLTs();
    } catch (err: any) {
      setError(err.message || 'Failed to delete OLT');
    }
  };

  const handleSelectOLT = async (olt: OLT) => {
    setSelectedOLT(olt);
    try {
      setError(null);
      const [portsData, onusData, aiData] = await Promise.all([
        oltService.getPONPorts(olt.id),
        oltService.getONUs(olt.id),
        oltService.getAIOptimizations(olt.id)
      ]);
      setPonPorts(portsData.ports);
      setOnus(onusData.onus);
      setAiOptimizations(aiData.suggestions);
    } catch (err: any) {
      setError(err.message || 'Failed to fetch OLT details');
    }
  };

  const handleExecuteCommand = async () => {
    if (!selectedOLT || !customCommand.trim()) return;
    try {
      setError(null);
      const result = await oltService.executeCommand(selectedOLT.id, customCommand);
      setCommandOutput(result.output);
    } catch (err: any) {
      setCommandOutput(`Error: ${err.message}`);
    }
  };

  const handleRunSelfHealing = async () => {
    if (!selectedOLT) return;
    try {
      setError(null);
      const result = await oltService.runSelfHealing(selectedOLT.id);
      setSelfHealingResult(result);
    } catch (err: any) {
      setError(err.message || 'Self-healing failed');
    }
  };

  const handleProvisionONU = async () => {
    if (!selectedOLT) return;
    try {
      setError(null);
      await oltService.provisionONU(selectedOLT.id, provisionData);
      setShowProvisionDialog(false);
      handleSelectOLT(selectedOLT);
    } catch (err: any) {
      setError(err.message || 'Failed to provision ONU');
    }
  };

  const handleResetONU = async (onuId: string) => {
    if (!selectedOLT) return;
    if (!confirm('Are you sure you want to reset this ONU?')) return;
    try {
      setError(null);
      await oltService.resetONU(selectedOLT.id, onuId);
      handleSelectOLT(selectedOLT);
    } catch (err: any) {
      setError(err.message || 'Failed to reset ONU');
    }
  };

  const handleDeprovisionONU = async (onuId: string) => {
    if (!selectedOLT) return;
    if (!confirm('Are you sure you want to deprovision this ONU?')) return;
    try {
      setError(null);
      await oltService.deprovisionONU(selectedOLT.id, onuId);
      handleSelectOLT(selectedOLT);
    } catch (err: any) {
      setError(err.message || 'Failed to deprovision ONU');
    }
  };

  const getHealthColor = (health: string) => {
    switch (health) {
      case 'healthy': return 'bg-green-500';
      case 'degraded': return 'bg-yellow-500';
      case 'critical': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'online':
        return <Badge className="bg-green-500"><CheckCircle className="w-3 h-3 mr-1" /> Online</Badge>;
      case 'offline':
        return <Badge variant="secondary"><XCircle className="w-3 h-3 mr-1" /> Offline</Badge>;
      case 'los':
        return <Badge variant="destructive"><AlertTriangle className="w-3 h-3 mr-1" /> LOS</Badge>;
      case 'auth-fail':
        return <Badge variant="destructive"><AlertTriangle className="w-3 h-3 mr-1" /> Auth Fail</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getAIPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'text-red-500 border-red-500';
      case 'medium': return 'text-yellow-500 border-yellow-500';
      case 'low': return 'text-blue-500 border-blue-500';
      default: return 'text-gray-500 border-gray-500';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">OLT Management</h1>
          <p className="text-muted-foreground">Manage Optical Line Terminals and ONUs</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={handleRefresh} disabled={refreshing}>
            <RefreshCw className={`w-4 h-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
          <Button onClick={() => setShowAddDialog(true)}>
            <Plus className="w-4 h-4 mr-2" />
            Add OLT
          </Button>
        </div>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {/* Global Dashboard */}
      <OLTDashboard />

      <Separator className="my-6" />

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* OLT List */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle>OLTs</CardTitle>
            <CardDescription>Select an OLT to manage</CardDescription>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[500px]">
              <div className="space-y-2">
                {olts.map(olt => {
                  const status = oltStatuses.get(olt.id);
                  return (
                    <div
                      key={olt.id}
                      className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                        selectedOLT?.id === olt.id ? 'border-primary bg-primary/5' : 'hover:bg-muted'
                      }`}
                      onClick={() => handleSelectOLT(olt)}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className={`w-2 h-2 rounded-full ${status?.connected ? 'bg-green-500' : 'bg-red-500'}`} />
                          <span className="font-medium">{olt.name}</span>
                        </div>
                        <div className="flex gap-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDeleteOLT(olt.id);
                            }}
                          >
                            <Trash2 className="w-4 h-4 text-red-500" />
                          </Button>
                        </div>
                      </div>
                      <div className="mt-2 text-sm text-muted-foreground">
                        <div className="flex items-center gap-2">
                          <Network className="w-3 h-3" />
                          {olt.ipAddress}
                        </div>
                        <div className="flex items-center gap-2 mt-1">
                          <Server className="w-3 h-3" />
                          {olt.vendor} {olt.model}
                        </div>
                        {status && (
                          <div className="flex items-center gap-4 mt-2">
                            <span className="flex items-center gap-1">
                              <Wifi className="w-3 h-3" />
                              {status.onuCount} ONUs
                            </span>
                            <span className="flex items-center gap-1">
                              <Signal className="w-3 h-3" />
                              {status.ponPorts} Ports
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>

        {/* OLT Details */}
        <Card className="lg:col-span-2">
          {selectedOLT ? (
            <>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      {selectedOLT.name}
                      {oltStatuses.get(selectedOLT.id)?.health && (
                        <Badge className={getHealthColor(oltStatuses.get(selectedOLT.id)!.health)}>
                          {oltStatuses.get(selectedOLT.id)!.health}
                        </Badge>
                      )}
                    </CardTitle>
                    <CardDescription>
                      {selectedOLT.vendor} {selectedOLT.model} • {selectedOLT.ipAddress}
                    </CardDescription>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={() => setShowCommandDialog(true)}>
                      <Terminal className="w-4 h-4 mr-2" />
                      Command
                    </Button>
                    <Button variant="outline" size="sm" onClick={handleRunSelfHealing}>
                      <Wrench className="w-4 h-4 mr-2" />
                      Self-Heal
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="overview">
                  <TabsList className="grid w-full grid-cols-7">
                    <TabsTrigger value="overview">Overview</TabsTrigger>
                    <TabsTrigger value="topology">Topology</TabsTrigger>
                    <TabsTrigger value="performance">Performance</TabsTrigger>
                    <TabsTrigger value="ports">PON Ports</TabsTrigger>
                    <TabsTrigger value="onus">ONUs</TabsTrigger>
                    <TabsTrigger value="ai">AI Optimizations</TabsTrigger>
                    <TabsTrigger value="actions">Actions</TabsTrigger>
                  </TabsList>

                  {/* Overview Tab */}
                  <TabsContent value="overview" className="space-y-4">
                    {oltStatuses.get(selectedOLT.id)?.system && (
                      <div className="grid grid-cols-3 gap-4">
                        <Card>
                          <CardContent className="p-4">
                            <div className="flex items-center gap-2">
                              <Cpu className="w-5 h-5 text-blue-500" />
                              <div>
                                <p className="text-sm text-muted-foreground">CPU Usage</p>
                                <p className="text-xl font-bold">
                                  {oltStatuses.get(selectedOLT.id)?.system?.cpuUsage || 0}%
                                </p>
                              </div>
                            </div>
                            <Progress 
                              value={oltStatuses.get(selectedOLT.id)?.system?.cpuUsage || 0} 
                              className="mt-2"
                            />
                          </CardContent>
                        </Card>
                        <Card>
                          <CardContent className="p-4">
                            <div className="flex items-center gap-2">
                              <Activity className="w-5 h-5 text-purple-500" />
                              <div>
                                <p className="text-sm text-muted-foreground">Memory</p>
                                <p className="text-xl font-bold">
                                  {oltStatuses.get(selectedOLT.id)?.system?.memoryUsage || 0}%
                                </p>
                              </div>
                            </div>
                            <Progress 
                              value={oltStatuses.get(selectedOLT.id)?.system?.memoryUsage || 0} 
                              className="mt-2"
                            />
                          </CardContent>
                        </Card>
                        <Card>
                          <CardContent className="p-4">
                            <div className="flex items-center gap-2">
                              <Thermometer className="w-5 h-5 text-orange-500" />
                              <div>
                                <p className="text-sm text-muted-foreground">Temperature</p>
                                <p className="text-xl font-bold">
                                  {oltStatuses.get(selectedOLT.id)?.system?.temperature || 0}°C
                                </p>
                              </div>
                            </div>
                            <Progress 
                              value={oltStatuses.get(selectedOLT.id)?.system?.temperature || 0} 
                              max={100}
                              className="mt-2"
                            />
                          </CardContent>
                        </Card>
                      </div>
                    )}

                    {oltStatuses.get(selectedOLT.id)?.issues && oltStatuses.get(selectedOLT.id)!.issues.length > 0 && (
                      <Alert variant="destructive">
                        <AlertTriangle className="w-4 h-4" />
                        <AlertDescription>
                          <ul className="list-disc list-inside">
                            {oltStatuses.get(selectedOLT.id)!.issues.map((issue, idx) => (
                              <li key={idx}>{issue}</li>
                            ))}
                          </ul>
                        </AlertDescription>
                      </Alert>
                    )}

                    {selfHealingResult && (
                      <Card>
                        <CardHeader>
                          <CardTitle className="text-sm">Self-Healing Results</CardTitle>
                        </CardHeader>
                        <CardContent>
                          {selfHealingResult.actions.length > 0 ? (
                            <div className="space-y-2">
                              <p className="text-sm font-medium">Actions Taken:</p>
                              <ul className="list-disc list-inside text-sm">
                                {selfHealingResult.actions.map((action, idx) => (
                                  <li key={idx} className="text-green-600">{action}</li>
                                ))}
                              </ul>
                            </div>
                          ) : (
                            <p className="text-sm text-muted-foreground">No actions needed</p>
                          )}
                        </CardContent>
                      </Card>
                    )}
                  </TabsContent>

                  {/* Topology Tab */}
                  <TabsContent value="topology">
                    <OLTNetworkTopology oltId={selectedOLT.id} oltName={selectedOLT.name} />
                  </TabsContent>

                  {/* Performance Tab */}
                  <TabsContent value="performance">
                    <OLTPerformanceCharts oltId={selectedOLT.id} />
                  </TabsContent>

                  {/* PON Ports Tab */}
                  <TabsContent value="ports">
                    <div className="grid grid-cols-4 gap-2">
                      {ponPorts.map(port => (
                        <Card key={port.id} className={port.status === 'online' ? 'border-green-500' : 'border-red-500'}>
                          <CardContent className="p-3">
                            <div className="flex items-center justify-between">
                              <span className="font-medium">{port.shelf}/{port.slot}/{port.portNumber}</span>
                              <div className={`w-2 h-2 rounded-full ${port.status === 'online' ? 'bg-green-500' : 'bg-red-500'}`} />
                            </div>
                            <div className="mt-2 text-sm text-muted-foreground">
                              <p>{port.onuCount} / {port.maxOnus} ONUs</p>
                              {port.transmitPower !== undefined && (
                                <p>TX: {port.transmitPower.toFixed(2)} dBm</p>
                              )}
                              {port.receivePower !== undefined && (
                                <p>RX: {port.receivePower.toFixed(2)} dBm</p>
                              )}
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </TabsContent>

                  {/* ONUs Tab */}
                  <TabsContent value="onus">
                    <div className="flex justify-between items-center mb-4">
                      <Input placeholder="Search ONUs..." className="w-64" />
                      <Button onClick={() => setShowProvisionDialog(true)}>
                        <Plus className="w-4 h-4 mr-2" />
                        Provision ONU
                      </Button>
                    </div>
                    <ScrollArea className="h-[400px]">
                      <div className="space-y-2">
                        {onus.map(onu => (
                          <Card key={onu.id}>
                            <CardContent className="p-3">
                              <div className="flex items-center justify-between">
                                <div>
                                  <div className="flex items-center gap-2">
                                    <span className="font-medium">ONU {onu.onuId}</span>
                                    {getStatusBadge(onu.status)}
                                    <Badge variant={onu.adminState === 'enabled' ? 'default' : 'secondary'}>
                                      {onu.adminState}
                                    </Badge>
                                  </div>
                                  <div className="text-sm text-muted-foreground mt-1">
                                    <p>SN: {onu.serialNumber}</p>
                                    <p>MAC: {onu.macAddress}</p>
                                    {onu.customerName && <p>Customer: {onu.customerName}</p>}
                                    {onu.rxPower !== undefined && (
                                      <p>Signal: {onu.rxPower.toFixed(2)} dBm</p>
                                    )}
                                    {onu.distance !== undefined && (
                                      <p>Distance: {onu.distance.toFixed(2)} km</p>
                                    )}
                                  </div>
                                </div>
                                <div className="flex gap-1">
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => handleResetONU(onu.id)}
                                    title="Reset ONU"
                                  >
                                    <RefreshCw className="w-4 h-4" />
                                  </Button>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => handleDeprovisionONU(onu.id)}
                                    title="Deprovision ONU"
                                  >
                                    <Trash2 className="w-4 h-4 text-red-500" />
                                  </Button>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </ScrollArea>
                  </TabsContent>

                  {/* AI Optimizations Tab */}
                  <TabsContent value="ai">
                    {aiOptimizations.length > 0 ? (
                      <div className="space-y-4">
                        {aiOptimizations.map((opt, idx) => (
                          <Card key={idx} className={getAIPriorityColor(opt.priority)}>
                            <CardContent className="p-4">
                              <div className="flex items-start gap-3">
                                <Brain className="w-5 h-5 mt-1" />
                                <div className="flex-1">
                                  <div className="flex items-center gap-2">
                                    <h4 className="font-semibold">{opt.title}</h4>
                                    <Badge variant="outline">{opt.priority}</Badge>
                                  </div>
                                  <p className="text-sm mt-1">{opt.description}</p>
                                  <p className="text-sm mt-2 font-medium">
                                    Recommendation: {opt.recommendation}
                                  </p>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-8">
                        <Brain className="w-12 h-12 mx-auto text-muted-foreground" />
                        <p className="mt-4 text-muted-foreground">No AI optimizations available</p>
                      </div>
                    )}
                  </TabsContent>

                  {/* Actions Tab */}
                  <TabsContent value="actions">
                    <div className="grid grid-cols-2 gap-4">
                      <Card>
                        <CardHeader>
                          <CardTitle className="text-sm">Auto-Discovery</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-muted-foreground mb-4">
                            Discover unprovisioned ONUs on this OLT
                          </p>
                          <Button 
                            variant="outline" 
                            className="w-full"
                            onClick={async () => {
                              try {
                                const result = await oltService.autoDiscoverONUs(selectedOLT.id);
                                alert(`Discovered ${result.discovered.length} ONUs, auto-provisioned ${result.autoProvisioned}`);
                              } catch (err: any) {
                                setError(err.message);
                              }
                            }}
                          >
                            <Search className="w-4 h-4 mr-2" />
                            Run Discovery
                          </Button>
                        </CardContent>
                      </Card>

                      <Card>
                        <CardHeader>
                          <CardTitle className="text-sm">Bulk Operations</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-muted-foreground mb-4">
                            Perform operations on multiple ONUs
                          </p>
                          <Button variant="outline" className="w-full">
                            <Zap className="w-4 h-4 mr-2" />
                            Bulk Reset
                          </Button>
                        </CardContent>
                      </Card>

                      <Card>
                        <CardHeader>
                          <CardTitle className="text-sm">Performance History</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-muted-foreground mb-4">
                            View historical performance data
                          </p>
                          <Button 
                            variant="outline" 
                            className="w-full"
                            onClick={async () => {
                              try {
                                const result = await oltService.getPerformance(selectedOLT.id);
                                console.log('Performance:', result.performance);
                              } catch (err: any) {
                                setError(err.message);
                              }
                            }}
                          >
                            <Activity className="w-4 h-4 mr-2" />
                            View Metrics
                          </Button>
                        </CardContent>
                      </Card>

                      <Card>
                        <CardHeader>
                          <CardTitle className="text-sm">Alarms</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-muted-foreground mb-4">
                            View active alarms on this OLT
                          </p>
                          <Button 
                            variant="outline" 
                            className="w-full"
                            onClick={async () => {
                              try {
                                const result = await oltService.getAlarms(selectedOLT.id);
                                console.log('Alarms:', result.alarms);
                              } catch (err: any) {
                                setError(err.message);
                              }
                            }}
                          >
                            <AlertTriangle className="w-4 h-4 mr-2" />
                            View Alarms
                          </Button>
                        </CardContent>
                      </Card>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </>
          ) : (
            <CardContent className="py-12 text-center">
              <Server className="w-16 h-16 mx-auto text-muted-foreground" />
              <p className="mt-4 text-muted-foreground">Select an OLT to view details</p>
            </CardContent>
          )}
        </Card>
      </div>

      {/* Add OLT Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Add New OLT</DialogTitle>
            <DialogDescription>Configure a new Optical Line Terminal</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>OLT Name</Label>
                <Input
                  value={newOLT.name}
                  onChange={e => setNewOLT({ ...newOLT, name: e.target.value })}
                  placeholder="e.g., OLT-Main-Office"
                />
              </div>
              <div className="space-y-2">
                <Label>Vendor</Label>
                <Select
                  value={newOLT.vendor}
                  onValueChange={value => setNewOLT({ ...newOLT, vendor: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {VENDORS.map(v => (
                      <SelectItem key={v.id} value={v.id}>{v.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label>Model</Label>
              <Select
                value={newOLT.model}
                onValueChange={value => setNewOLT({ ...newOLT, model: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select model" />
                </SelectTrigger>
                <SelectContent>
                  {VENDORS.find(v => v.id === newOLT.vendor)?.models.map(m => (
                    <SelectItem key={m} value={m}>{m}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>IP Address</Label>
                <Input
                  value={newOLT.ipAddress}
                  onChange={e => setNewOLT({ ...newOLT, ipAddress: e.target.value })}
                  placeholder="192.168.1.1"
                />
              </div>
              <div className="space-y-2">
                <Label>Port</Label>
                <Input
                  type="number"
                  value={newOLT.port}
                  onChange={e => setNewOLT({ ...newOLT, port: parseInt(e.target.value) })}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Protocol</Label>
              <Select
                value={newOLT.protocol}
                onValueChange={value => setNewOLT({ ...newOLT, protocol: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {PROTOCOLS.map(p => (
                    <SelectItem key={p} value={p}>{p.toUpperCase()}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <Separator />

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Username</Label>
                <Input
                  value={newOLT.username}
                  onChange={e => setNewOLT({ ...newOLT, username: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label>Password</Label>
                <Input
                  type="password"
                  value={newOLT.password}
                  onChange={e => setNewOLT({ ...newOLT, password: e.target.value })}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Enable Password (optional)</Label>
              <Input
                type="password"
                value={newOLT.enablePassword}
                onChange={e => setNewOLT({ ...newOLT, enablePassword: e.target.value })}
              />
            </div>

            {newOLT.protocol === 'snmp' && (
              <>
                <Separator />
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>SNMP Community</Label>
                    <Input
                      value={newOLT.snmpCommunity}
                      onChange={e => setNewOLT({ ...newOLT, snmpCommunity: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>SNMP Version</Label>
                    <Select
                      value={newOLT.snmpVersion}
                      onValueChange={value => setNewOLT({ ...newOLT, snmpVersion: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="v1">v1</SelectItem>
                        <SelectItem value="v2c">v2c</SelectItem>
                        <SelectItem value="v3">v3</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </>
            )}

            <div className="space-y-2">
              <Label>Location (optional)</Label>
              <Input
                value={newOLT.location}
                onChange={e => setNewOLT({ ...newOLT, location: e.target.value })}
                placeholder="e.g., Main Office, Nairobi"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddDialog(false)}>Cancel</Button>
            <Button onClick={handleAddOLT}>Add OLT</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Command Dialog */}
      <Dialog open={showCommandDialog} onOpenChange={setShowCommandDialog}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Execute Command</DialogTitle>
            <DialogDescription>Run a custom command on {selectedOLT?.name}</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="flex gap-2">
              <Input
                value={customCommand}
                onChange={e => setCustomCommand(e.target.value)}
                placeholder="Enter command..."
                className="flex-1"
              />
              <Button onClick={handleExecuteCommand}>Execute</Button>
            </div>
            {commandOutput && (
              <div className="bg-muted p-4 rounded-lg font-mono text-sm whitespace-pre-wrap max-h-96 overflow-auto">
                {commandOutput}
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Provision ONU Dialog */}
      <Dialog open={showProvisionDialog} onOpenChange={setShowProvisionDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Provision ONU</DialogTitle>
            <DialogDescription>Add a new ONU to {selectedOLT?.name}</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Serial Number</Label>
              <Input
                value={provisionData.serialNumber}
                onChange={e => setProvisionData({ ...provisionData, serialNumber: e.target.value })}
                placeholder="HWTC12345678"
              />
            </div>
            <div className="space-y-2">
              <Label>PON Port</Label>
              <Select
                value={provisionData.ponPortId}
                onValueChange={value => setProvisionData({ ...provisionData, ponPortId: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select PON port" />
                </SelectTrigger>
                <SelectContent>
                  {ponPorts.map(port => (
                    <SelectItem key={port.id} value={port.id}>
                      {port.shelf}/{port.slot}/{port.portNumber}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Service Profile (optional)</Label>
              <Input
                value={provisionData.serviceProfile}
                onChange={e => setProvisionData({ ...provisionData, serviceProfile: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label>Line Profile (optional)</Label>
              <Input
                value={provisionData.lineProfile}
                onChange={e => setProvisionData({ ...provisionData, lineProfile: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label>Description (optional)</Label>
              <Input
                value={provisionData.description}
                onChange={e => setProvisionData({ ...provisionData, description: e.target.value })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowProvisionDialog(false)}>Cancel</Button>
            <Button onClick={handleProvisionONU}>Provision</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
