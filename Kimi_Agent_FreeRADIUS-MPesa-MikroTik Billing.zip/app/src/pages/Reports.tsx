import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  TrendingUp, 
  Users, 
  CreditCard, 
  Download,
  Activity
} from 'lucide-react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar,
  PieChart as RePieChart,
  Pie,
  Cell,
  Legend
} from 'recharts';
import { formatCurrency } from '../lib/utils';

// Mock data
const revenueData = [
  { month: 'Jan', revenue: 220000, expenses: 150000, profit: 70000 },
  { month: 'Feb', revenue: 245000, expenses: 155000, profit: 90000 },
  { month: 'Mar', revenue: 238000, expenses: 160000, profit: 78000 },
  { month: 'Apr', revenue: 260000, expenses: 162000, profit: 98000 },
  { month: 'May', revenue: 275000, expenses: 165000, profit: 110000 },
  { month: 'Jun', revenue: 285000, expenses: 170000, profit: 115000 },
];

const userGrowthData = [
  { month: 'Jan', newUsers: 45, churnedUsers: 12, totalUsers: 980 },
  { month: 'Feb', newUsers: 52, churnedUsers: 8, totalUsers: 1024 },
  { month: 'Mar', newUsers: 38, churnedUsers: 15, totalUsers: 1047 },
  { month: 'Apr', newUsers: 61, churnedUsers: 10, totalUsers: 1098 },
  { month: 'May', newUsers: 55, churnedUsers: 14, totalUsers: 1139 },
  { month: 'Jun', newUsers: 48, churnedUsers: 11, totalUsers: 1176 },
];

const paymentMethodData = [
  { name: 'M-Pesa', value: 185000, count: 148 },
  { name: 'Cash', value: 45000, count: 32 },
  { name: 'Bank Transfer', value: 35000, count: 18 },
  { name: 'Other', value: 20000, count: 12 },
];

const planDistribution = [
  { name: 'Basic 5Mbps', users: 332, revenue: 498000 },
  { name: 'Standard 10Mbps', users: 456, revenue: 1140000 },
  { name: 'Premium 20Mbps', users: 289, revenue: 1156000 },
  { name: 'Enterprise 50Mbps', users: 99, revenue: 990000 },
];

const serviceTypeData = [
  { name: 'PPPoE', value: 654, color: '#6366f1' },
  { name: 'Hotspot', value: 332, color: '#06b6d4' },
];

const COLORS = ['#6366f1', '#06b6d4', '#10b981', '#f59e0b', '#ef4444'];

export default function Reports() {
  const [dateRange, setDateRange] = useState('last_30_days');
  const [_reportType, _setReportType] = useState('revenue');

  const totalRevenue = revenueData.reduce((sum, d) => sum + d.revenue, 0);
  const totalProfit = revenueData.reduce((sum, d) => sum + d.profit, 0);
  const totalUsers = userGrowthData[userGrowthData.length - 1].totalUsers;
  const growthRate = ((userGrowthData[userGrowthData.length - 1].newUsers - userGrowthData[0].newUsers) / userGrowthData[0].newUsers * 100).toFixed(1);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Reports & Analytics</h2>
          <p className="text-muted-foreground">Comprehensive business insights and statistics</p>
        </div>
        <div className="flex gap-2">
          <select
            value={dateRange}
            onChange={(e) => setDateRange(e.target.value)}
            className="px-4 py-2 bg-muted border border-border rounded-lg text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
          >
            <option value="last_7_days">Last 7 Days</option>
            <option value="last_30_days">Last 30 Days</option>
            <option value="last_3_months">Last 3 Months</option>
            <option value="last_6_months">Last 6 Months</option>
            <option value="last_year">Last Year</option>
          </select>
          <button className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors">
            <Download className="w-4 h-4" />
            Export
          </button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass rounded-xl p-5"
        >
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 bg-primary/20 rounded-lg flex items-center justify-center">
              <CreditCard className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Total Revenue</p>
              <p className="text-2xl font-bold text-foreground">{formatCurrency(totalRevenue)}</p>
            </div>
          </div>
          <div className="flex items-center gap-1 text-sm text-success">
            <TrendingUp className="w-4 h-4" />
            <span>+12.5% from last period</span>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="glass rounded-xl p-5"
        >
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 bg-success/20 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-success" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Net Profit</p>
              <p className="text-2xl font-bold text-foreground">{formatCurrency(totalProfit)}</p>
            </div>
          </div>
          <div className="flex items-center gap-1 text-sm text-success">
            <TrendingUp className="w-4 h-4" />
            <span>+8.3% from last period</span>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="glass rounded-xl p-5"
        >
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 bg-secondary/20 rounded-lg flex items-center justify-center">
              <Users className="w-5 h-5 text-secondary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Total Users</p>
              <p className="text-2xl font-bold text-foreground">{totalUsers}</p>
            </div>
          </div>
          <div className="flex items-center gap-1 text-sm text-success">
            <TrendingUp className="w-4 h-4" />
            <span>+{growthRate}% growth</span>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="glass rounded-xl p-5"
        >
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 bg-warning/20 rounded-lg flex items-center justify-center">
              <Activity className="w-5 h-5 text-warning" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Avg Daily Revenue</p>
              <p className="text-2xl font-bold text-foreground">{formatCurrency(totalRevenue / 180)}</p>
            </div>
          </div>
          <div className="flex items-center gap-1 text-sm text-muted-foreground">
            <span>Per day average</span>
          </div>
        </motion.div>
      </div>

      {/* Revenue Chart */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="glass rounded-xl p-6"
      >
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-lg font-semibold text-foreground">Revenue Overview</h3>
            <p className="text-sm text-muted-foreground">Monthly revenue, expenses, and profit</p>
          </div>
          <div className="flex items-center gap-4 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-primary" />
              <span className="text-muted-foreground">Revenue</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-secondary" />
              <span className="text-muted-foreground">Profit</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-destructive" />
              <span className="text-muted-foreground">Expenses</span>
            </div>
          </div>
        </div>
        <ResponsiveContainer width="100%" height={350}>
          <AreaChart data={revenueData}>
            <defs>
              <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
              </linearGradient>
              <linearGradient id="colorProfit" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="#06b6d4" stopOpacity={0}/>
              </linearGradient>
              <linearGradient id="colorExpenses" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#ef4444" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(148, 163, 184, 0.1)" />
            <XAxis dataKey="month" stroke="#94a3b8" fontSize={12} tickLine={false} />
            <YAxis stroke="#94a3b8" fontSize={12} tickLine={false} tickFormatter={(value) => `KES ${value / 1000}k`} />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: 'hsl(222 35% 8%)', 
                border: '1px solid hsl(217 33% 17%)',
                borderRadius: '8px',
              }}
              formatter={(value: number) => formatCurrency(value)}
            />
            <Area type="monotone" dataKey="revenue" stroke="#6366f1" strokeWidth={2} fillOpacity={1} fill="url(#colorRevenue)" />
            <Area type="monotone" dataKey="profit" stroke="#06b6d4" strokeWidth={2} fillOpacity={1} fill="url(#colorProfit)" />
            <Area type="monotone" dataKey="expenses" stroke="#ef4444" strokeWidth={2} fillOpacity={1} fill="url(#colorExpenses)" />
          </AreaChart>
        </ResponsiveContainer>
      </motion.div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* User Growth */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="glass rounded-xl p-6"
        >
          <h3 className="text-lg font-semibold text-foreground mb-2">User Growth</h3>
          <p className="text-sm text-muted-foreground mb-6">New vs churned users over time</p>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={userGrowthData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(148, 163, 184, 0.1)" />
              <XAxis dataKey="month" stroke="#94a3b8" fontSize={12} tickLine={false} />
              <YAxis stroke="#94a3b8" fontSize={12} tickLine={false} />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'hsl(222 35% 8%)', 
                  border: '1px solid hsl(217 33% 17%)',
                  borderRadius: '8px',
                }}
              />
              <Legend />
              <Bar dataKey="newUsers" name="New Users" fill="#10b981" radius={[4, 4, 0, 0]} />
              <Bar dataKey="churnedUsers" name="Churned Users" fill="#ef4444" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Payment Methods */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="glass rounded-xl p-6"
        >
          <h3 className="text-lg font-semibold text-foreground mb-2">Payment Methods</h3>
          <p className="text-sm text-muted-foreground mb-6">Revenue distribution by payment method</p>
          <ResponsiveContainer width="100%" height={250}>
            <RePieChart>
              <Pie
                data={paymentMethodData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={90}
                paddingAngle={5}
                dataKey="value"
              >
                {paymentMethodData.map((_entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'hsl(222 35% 8%)', 
                  border: '1px solid hsl(217 33% 17%)',
                  borderRadius: '8px',
                }}
                formatter={(value: number) => formatCurrency(value)}
              />
              <Legend />
            </RePieChart>
          </ResponsiveContainer>
        </motion.div>
      </div>

      {/* Plan Performance */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7 }}
        className="glass rounded-xl p-6"
      >
        <h3 className="text-lg font-semibold text-foreground mb-2">Plan Performance</h3>
        <p className="text-sm text-muted-foreground mb-6">Revenue and user distribution by plan</p>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={planDistribution} layout="vertical">
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(148, 163, 184, 0.1)" />
            <XAxis type="number" stroke="#94a3b8" fontSize={12} tickLine={false} tickFormatter={(value) => `KES ${value / 1000}k`} />
            <YAxis dataKey="name" type="category" stroke="#94a3b8" fontSize={12} tickLine={false} width={120} />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: 'hsl(222 35% 8%)', 
                border: '1px solid hsl(217 33% 17%)',
                borderRadius: '8px',
              }}
              formatter={(value: number, name: string) => {
                if (name === 'revenue') return formatCurrency(value);
                return value;
              }}
            />
            <Legend />
            <Bar dataKey="users" name="Users" fill="#6366f1" radius={[0, 4, 4, 0]} />
            <Bar dataKey="revenue" name="Revenue" fill="#06b6d4" radius={[0, 4, 4, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </motion.div>

      {/* Service Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          className="glass rounded-xl p-6"
        >
          <h3 className="text-lg font-semibold text-foreground mb-2">Service Distribution</h3>
          <p className="text-sm text-muted-foreground mb-6">Users by service type</p>
          <ResponsiveContainer width="100%" height={250}>
            <RePieChart>
              <Pie
                data={serviceTypeData}
                cx="50%"
                cy="50%"
                outerRadius={90}
                dataKey="value"
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
              >
                {serviceTypeData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'hsl(222 35% 8%)', 
                  border: '1px solid hsl(217 33% 17%)',
                  borderRadius: '8px',
                }}
              />
            </RePieChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Summary Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.9 }}
          className="glass rounded-xl p-6"
        >
          <h3 className="text-lg font-semibold text-foreground mb-4">Summary Statistics</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
              <span className="text-sm text-muted-foreground">Average Revenue Per User</span>
              <span className="font-semibold text-foreground">{formatCurrency(totalRevenue / totalUsers)}</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
              <span className="text-sm text-muted-foreground">Churn Rate</span>
              <span className="font-semibold text-destructive">2.4%</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
              <span className="text-sm text-muted-foreground">Customer Lifetime Value</span>
              <span className="font-semibold text-foreground">{formatCurrency(15000)}</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
              <span className="text-sm text-muted-foreground">Collection Rate</span>
              <span className="font-semibold text-success">94.2%</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
              <span className="text-sm text-muted-foreground">Profit Margin</span>
              <span className="font-semibold text-success">{(totalProfit / totalRevenue * 100).toFixed(1)}%</span>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
