import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Users, 
  CreditCard, 
  FileText, 
  Router, 
  TrendingUp,
  Activity,
  Wifi,
  Network,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar
} from 'recharts';
import type { DashboardStats, RevenueData, UserGrowthData, Customer } from '../types';
import { formatCurrency } from '../lib/utils';

// Mock data
const mockStats: DashboardStats = {
  totalCustomers: 1248,
  activeCustomers: 986,
  expiredCustomers: 182,
  suspendedCustomers: 80,
  monthlyRevenue: 285000,
  pendingPayments: 45000,
  totalInvoices: 156,
  unpaidInvoices: 42,
  networkHealth: 98,
  onlineRouters: 12,
  totalRouters: 14,
  activePPPoE: 654,
  activeHotspot: 332,
};

const revenueData: RevenueData[] = [
  { month: 'Jan', revenue: 220000, expenses: 150000, profit: 70000 },
  { month: 'Feb', revenue: 245000, expenses: 155000, profit: 90000 },
  { month: 'Mar', revenue: 238000, expenses: 160000, profit: 78000 },
  { month: 'Apr', revenue: 260000, expenses: 162000, profit: 98000 },
  { month: 'May', revenue: 275000, expenses: 165000, profit: 110000 },
  { month: 'Jun', revenue: 285000, expenses: 170000, profit: 115000 },
];

const userGrowthData: UserGrowthData[] = [
  { month: 'Jan', newUsers: 45, churnedUsers: 12, totalUsers: 980 },
  { month: 'Feb', newUsers: 52, churnedUsers: 8, totalUsers: 1024 },
  { month: 'Mar', newUsers: 38, churnedUsers: 15, totalUsers: 1047 },
  { month: 'Apr', newUsers: 61, churnedUsers: 10, totalUsers: 1098 },
  { month: 'May', newUsers: 55, churnedUsers: 14, totalUsers: 1139 },
  { month: 'Jun', newUsers: 48, churnedUsers: 11, totalUsers: 1176 },
];

const serviceDistribution = [
  { name: 'PPPoE', value: 654, color: '#6366f1' },
  { name: 'Hotspot', value: 332, color: '#06b6d4' },
];

const recentCustomers: Customer[] = [
  {
    id: '1',
    username: 'john_doe',
    fullName: 'John Doe',
    email: 'john@example.com',
    phone: '+254712345678',
    address: 'Nairobi, Kenya',
    serviceType: 'pppoe',
    planId: '1',
    planName: 'Premium 10Mbps',
    status: 'active',
    expiryDate: '2024-12-31',
    createdAt: '2024-01-15',
    lastConnected: '2024-06-15T10:30:00',
    balance: 0,
  },
  {
    id: '2',
    username: 'jane_smith',
    fullName: 'Jane Smith',
    email: 'jane@example.com',
    phone: '+254723456789',
    address: 'Mombasa, Kenya',
    serviceType: 'hotspot',
    planId: '2',
    planName: 'Basic 5Mbps',
    status: 'active',
    expiryDate: '2024-12-31',
    createdAt: '2024-02-20',
    lastConnected: '2024-06-15T09:45:00',
    balance: 500,
  },
  {
    id: '3',
    username: 'mike_johnson',
    fullName: 'Mike Johnson',
    email: 'mike@example.com',
    phone: '+254734567890',
    address: 'Kisumu, Kenya',
    serviceType: 'pppoe',
    planId: '3',
    planName: 'Enterprise 20Mbps',
    status: 'expired',
    expiryDate: '2024-05-31',
    createdAt: '2023-11-10',
    lastConnected: '2024-05-30T18:20:00',
    balance: -2500,
  },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.5,
      ease: [0.16, 1, 0.3, 1] as const,
    },
  },
};

export default function Dashboard() {
  const [stats] = useState<DashboardStats>(mockStats);
  const [animatedRevenue, setAnimatedRevenue] = useState(0);

  useEffect(() => {
    // Animate revenue counter
    const duration = 2000;
    const steps = 60;
    const increment = stats.monthlyRevenue / steps;
    let current = 0;
    
    const timer = setInterval(() => {
      current += increment;
      if (current >= stats.monthlyRevenue) {
        setAnimatedRevenue(stats.monthlyRevenue);
        clearInterval(timer);
      } else {
        setAnimatedRevenue(Math.floor(current));
      }
    }, duration / steps);

    return () => clearInterval(timer);
  }, [stats.monthlyRevenue]);

  const StatCard = ({ 
    title, 
    value, 
    icon: Icon, 
    trend, 
    trendValue, 
    color 
  }: { 
    title: string; 
    value: string | number; 
    icon: any; 
    trend?: 'up' | 'down'; 
    trendValue?: string;
    color: string;
  }) => (
    <motion.div
      variants={itemVariants}
      className="glass rounded-xl p-5 hover:shadow-lg transition-all duration-300 group"
    >
      <div className="flex items-start justify-between">
        <div>
          <p className="text-muted-foreground text-sm">{title}</p>
          <h3 className="text-2xl font-bold text-foreground mt-1">{value}</h3>
          {trend && (
            <div className={`flex items-center gap-1 mt-2 text-sm ${
              trend === 'up' ? 'text-success' : 'text-destructive'
            }`}>
              {trend === 'up' ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
              <span>{trendValue}</span>
            </div>
          )}
        </div>
        <div className={`w-12 h-12 rounded-xl ${color} flex items-center justify-center group-hover:scale-110 transition-transform`}>
          <Icon className="w-6 h-6 text-white" />
        </div>
      </div>
    </motion.div>
  );

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-6"
    >
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Customers"
          value={stats.totalCustomers}
          icon={Users}
          trend="up"
          trendValue="+12%"
          color="bg-gradient-to-br from-primary to-primary/70"
        />
        <StatCard
          title="Monthly Revenue"
          value={formatCurrency(animatedRevenue)}
          icon={CreditCard}
          trend="up"
          trendValue="+8.5%"
          color="bg-gradient-to-br from-secondary to-secondary/70"
        />
        <StatCard
          title="Active PPPoE"
          value={stats.activePPPoE}
          icon={Network}
          trend="up"
          trendValue="+5%"
          color="bg-gradient-to-br from-success to-success/70"
        />
        <StatCard
          title="Active Hotspot"
          value={stats.activeHotspot}
          icon={Wifi}
          trend="down"
          trendValue="-2%"
          color="bg-gradient-to-br from-warning to-warning/70"
        />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Revenue Chart */}
        <motion.div
          variants={itemVariants}
          className="lg:col-span-2 glass rounded-xl p-6"
        >
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-semibold text-foreground">Revenue Overview</h3>
              <p className="text-sm text-muted-foreground">Monthly revenue and profit</p>
            </div>
            <div className="flex items-center gap-4 text-sm">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-primary" />
                <span className="text-muted-foreground">Revenue</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-secondary" />
                <span className="text-muted-foreground">Profit</span>
              </div>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={revenueData}>
              <defs>
                <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                </linearGradient>
                <linearGradient id="colorProfit" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#06b6d4" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(148, 163, 184, 0.1)" />
              <XAxis 
                dataKey="month" 
                stroke="#94a3b8" 
                fontSize={12}
                tickLine={false}
              />
              <YAxis 
                stroke="#94a3b8" 
                fontSize={12}
                tickLine={false}
                tickFormatter={(value) => `KES ${value / 1000}k`}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'hsl(222 35% 8%)', 
                  border: '1px solid hsl(217 33% 17%)',
                  borderRadius: '8px',
                }}
                formatter={(value: number) => formatCurrency(value)}
              />
              <Area 
                type="monotone" 
                dataKey="revenue" 
                stroke="#6366f1" 
                strokeWidth={2}
                fillOpacity={1} 
                fill="url(#colorRevenue)" 
              />
              <Area 
                type="monotone" 
                dataKey="profit" 
                stroke="#06b6d4" 
                strokeWidth={2}
                fillOpacity={1} 
                fill="url(#colorProfit)" 
              />
            </AreaChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Service Distribution */}
        <motion.div
          variants={itemVariants}
          className="glass rounded-xl p-6"
        >
          <h3 className="text-lg font-semibold text-foreground mb-2">Service Distribution</h3>
          <p className="text-sm text-muted-foreground mb-6">Customers by service type</p>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie
                data={serviceDistribution}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={90}
                paddingAngle={5}
                dataKey="value"
              >
                {serviceDistribution.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'hsl(222 35% 8%)', 
                  border: '1px solid hsl(217 33% 17%)',
                  borderRadius: '8px',
                }}
              />
            </PieChart>
          </ResponsiveContainer>
          <div className="flex justify-center gap-6 mt-4">
            {serviceDistribution.map((item) => (
              <div key={item.name} className="flex items-center gap-2">
                <div 
                  className="w-3 h-3 rounded-full" 
                  style={{ backgroundColor: item.color }}
                />
                <span className="text-sm text-muted-foreground">
                  {item.name} ({item.value})
                </span>
              </div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* User Growth */}
        <motion.div
          variants={itemVariants}
          className="glass rounded-xl p-6"
        >
          <h3 className="text-lg font-semibold text-foreground mb-2">User Growth</h3>
          <p className="text-sm text-muted-foreground mb-6">New vs churned users</p>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={userGrowthData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(148, 163, 184, 0.1)" />
              <XAxis 
                dataKey="month" 
                stroke="#94a3b8" 
                fontSize={12}
                tickLine={false}
              />
              <YAxis 
                stroke="#94a3b8" 
                fontSize={12}
                tickLine={false}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'hsl(222 35% 8%)', 
                  border: '1px solid hsl(217 33% 17%)',
                  borderRadius: '8px',
                }}
              />
              <Bar dataKey="newUsers" fill="#10b981" radius={[4, 4, 0, 0]} />
              <Bar dataKey="churnedUsers" fill="#ef4444" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Recent Customers */}
        <motion.div
          variants={itemVariants}
          className="glass rounded-xl p-6"
        >
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-lg font-semibold text-foreground">Recent Customers</h3>
              <p className="text-sm text-muted-foreground">Latest customer activity</p>
            </div>
            <button className="text-sm text-primary hover:text-primary/80 transition-colors">
              View All
            </button>
          </div>
          <div className="space-y-3">
            {recentCustomers.map((customer, index) => (
              <motion.div
                key={customer.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="flex items-center justify-between p-3 bg-muted/50 rounded-lg hover:bg-muted transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    customer.serviceType === 'pppoe' ? 'bg-primary/20' : 'bg-secondary/20'
                  }`}>
                    {customer.serviceType === 'pppoe' ? (
                      <Network className="w-5 h-5 text-primary" />
                    ) : (
                      <Wifi className="w-5 h-5 text-secondary" />
                    )}
                  </div>
                  <div>
                    <p className="font-medium text-foreground">{customer.fullName}</p>
                    <p className="text-sm text-muted-foreground">{customer.planName}</p>
                  </div>
                </div>
                <div className="text-right">
                  <span className={`px-2 py-1 text-xs rounded-full border ${
                    customer.status === 'active' 
                      ? 'bg-success/20 text-success border-success/30' 
                      : 'bg-destructive/20 text-destructive border-destructive/30'
                  }`}>
                    {customer.status}
                  </span>
                  <p className="text-xs text-muted-foreground mt-1">
                    {customer.phone}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Network Status */}
      <motion.div
        variants={itemVariants}
        className="glass rounded-xl p-6"
      >
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-semibold text-foreground">Network Health</h3>
            <p className="text-sm text-muted-foreground">Real-time network status</p>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-success animate-pulse" />
            <span className="text-sm text-success font-medium">{stats.networkHealth}% Operational</span>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="p-4 bg-muted/50 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Router className="w-5 h-5 text-primary" />
              <span className="text-sm text-muted-foreground">Routers</span>
            </div>
            <p className="text-2xl font-bold text-foreground">
              {stats.onlineRouters}/{stats.totalRouters}
            </p>
            <p className="text-xs text-success mt-1">Online</p>
          </div>
          <div className="p-4 bg-muted/50 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Activity className="w-5 h-5 text-secondary" />
              <span className="text-sm text-muted-foreground">Uptime</span>
            </div>
            <p className="text-2xl font-bold text-foreground">99.9%</p>
            <p className="text-xs text-muted-foreground mt-1">Last 30 days</p>
          </div>
          <div className="p-4 bg-muted/50 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="w-5 h-5 text-success" />
              <span className="text-sm text-muted-foreground">Bandwidth</span>
            </div>
            <p className="text-2xl font-bold text-foreground">85%</p>
            <p className="text-xs text-warning mt-1">Peak usage</p>
          </div>
          <div className="p-4 bg-muted/50 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <FileText className="w-5 h-5 text-warning" />
              <span className="text-sm text-muted-foreground">Pending</span>
            </div>
            <p className="text-2xl font-bold text-foreground">{stats.unpaidInvoices}</p>
            <p className="text-xs text-destructive mt-1">Unpaid invoices</p>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}

// formatNumber function available in lib/utils.ts
