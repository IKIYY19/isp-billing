import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Database, 
  Key, 
  Shield, 
  Plus, 
  Edit2, 
  Trash2, 
  Search,
  CheckCircle,
  Server,
  Activity,
  Users
} from 'lucide-react';
import type { FreeRadiusUser } from '../types';

// Mock data
const mockRadiusUsers: FreeRadiusUser[] = [
  {
    id: '1',
    username: 'john_doe',
    attribute: 'Cleartext-Password',
    op: ':=',
    value: 'password123',
    groupName: 'pppoe_users',
    priority: 1,
  },
  {
    id: '2',
    username: 'jane_smith',
    attribute: 'Cleartext-Password',
    op: ':=',
    value: 'securepass456',
    groupName: 'hotspot_users',
    priority: 1,
  },
  {
    id: '3',
    username: 'mike_johnson',
    attribute: 'Cleartext-Password',
    op: ':=',
    value: 'mike2024',
    groupName: 'pppoe_users',
    priority: 1,
  },
  {
    id: '4',
    username: 'sarah_williams',
    attribute: 'Cleartext-Password',
    op: ':=',
    value: 'sarahpass',
    groupName: 'hotspot_users',
    priority: 1,
  },
  {
    id: '5',
    username: 'david_brown',
    attribute: 'Cleartext-Password',
    op: ':=',
    value: 'davidsecure',
    groupName: 'pppoe_users',
    priority: 1,
  },
];

const radiusStats = {
  totalUsers: 1248,
  pppoeUsers: 654,
  hotspotUsers: 332,
  activeSessions: 589,
  authSuccess: 98.5,
  avgResponseTime: '12ms',
};

export default function FreeRadius() {
  const [users, setUsers] = useState<FreeRadiusUser[]>(mockRadiusUsers);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterGroup, setFilterGroup] = useState<string>('all');
  const [_showAddModal, _setShowAddModal] = useState(false);
  const [_showEditModal, _setShowEditModal] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [selectedUser, setSelectedUser] = useState<FreeRadiusUser | null>(null);

  const filteredUsers = users.filter(user => {
    const matchesSearch = user.username.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesGroup = filterGroup === 'all' || user.groupName === filterGroup;
    return matchesSearch && matchesGroup;
  });

  const handleDelete = (user: FreeRadiusUser) => {
    setSelectedUser(user);
    setShowDeleteConfirm(true);
  };

  const confirmDelete = () => {
    if (selectedUser) {
      setUsers(prev => prev.filter(u => u.id !== selectedUser.id));
      setShowDeleteConfirm(false);
      setSelectedUser(null);
    }
  };

  const handleEdit = (_user: FreeRadiusUser) => {
    // Edit functionality to be implemented
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground">FreeRADIUS</h2>
          <p className="text-muted-foreground">Manage RADIUS authentication server</p>
        </div>
        <div className="flex gap-2">
          <button className="flex items-center gap-2 px-4 py-2 bg-muted text-foreground rounded-lg hover:bg-muted/80 transition-colors">
            <Server className="w-4 h-4" />
            Server Status
          </button>
          <button
            onClick={() => {/* Add user modal to be implemented */}}
            className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
          >
            <Plus className="w-4 h-4" />
            Add User
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary/20 rounded-lg flex items-center justify-center">
              <Database className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Total Users</p>
              <p className="text-2xl font-bold text-foreground">{radiusStats.totalUsers}</p>
            </div>
          </div>
        </div>
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-success/20 rounded-lg flex items-center justify-center">
              <Users className="w-5 h-5 text-success" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Active Sessions</p>
              <p className="text-2xl font-bold text-foreground">{radiusStats.activeSessions}</p>
            </div>
          </div>
        </div>
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-secondary/20 rounded-lg flex items-center justify-center">
              <CheckCircle className="w-5 h-5 text-secondary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Auth Success</p>
              <p className="text-2xl font-bold text-foreground">{radiusStats.authSuccess}%</p>
            </div>
          </div>
        </div>
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-warning/20 rounded-lg flex items-center justify-center">
              <Activity className="w-5 h-5 text-warning" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Avg Response</p>
              <p className="text-2xl font-bold text-foreground">{radiusStats.avgResponseTime}</p>
            </div>
          </div>
        </div>
      </div>

      {/* User Distribution */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="glass rounded-xl p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-primary/20 rounded-lg flex items-center justify-center">
                <Key className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">PPPoE Users</p>
                <p className="text-xl font-bold text-foreground">{radiusStats.pppoeUsers}</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-sm text-muted-foreground">Group</p>
              <p className="text-sm font-medium text-primary">pppoe_users</p>
            </div>
          </div>
        </div>
        <div className="glass rounded-xl p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-secondary/20 rounded-lg flex items-center justify-center">
                <Shield className="w-5 h-5 text-secondary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Hotspot Users</p>
                <p className="text-xl font-bold text-foreground">{radiusStats.hotspotUsers}</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-sm text-muted-foreground">Group</p>
              <p className="text-sm font-medium text-secondary">hotspot_users</p>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="glass rounded-xl p-4">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search RADIUS users..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-muted border border-border rounded-lg text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
            />
          </div>
          <select
            value={filterGroup}
            onChange={(e) => setFilterGroup(e.target.value)}
            className="px-4 py-2 bg-muted border border-border rounded-lg text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
          >
            <option value="all">All Groups</option>
            <option value="pppoe_users">PPPoE Users</option>
            <option value="hotspot_users">Hotspot Users</option>
          </select>
        </div>
      </div>

      {/* Users Table */}
      <div className="glass rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border bg-muted/50">
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Username</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Attribute</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Operator</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Value</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Group</th>
                <th className="px-4 py-3 text-right text-sm font-medium text-muted-foreground">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.map((user, index) => (
                <motion.tr
                  key={user.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="border-b border-border last:border-b-0 hover:bg-muted/30 transition-colors"
                >
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
                        <span className="text-sm font-semibold text-primary">
                          {user.username.charAt(0).toUpperCase()}
                        </span>
                      </div>
                      <span className="font-medium text-foreground">{user.username}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className="text-sm text-foreground">{user.attribute}</span>
                  </td>
                  <td className="px-4 py-3">
                    <span className="text-sm font-mono text-foreground">{user.op}</span>
                  </td>
                  <td className="px-4 py-3">
                    <span className="text-sm text-muted-foreground">••••••••</span>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-1 text-xs rounded-full ${
                      user.groupName === 'pppoe_users' 
                        ? 'bg-primary/20 text-primary' 
                        : 'bg-secondary/20 text-secondary'
                    }`}>
                      {user.groupName}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => handleEdit(user)}
                        className="p-2 hover:bg-muted rounded-lg text-muted-foreground hover:text-foreground transition-colors"
                        title="Edit"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(user)}
                        className="p-2 hover:bg-destructive/10 rounded-lg text-muted-foreground hover:text-destructive transition-colors"
                        title="Delete"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
        {filteredUsers.length === 0 && (
          <div className="p-8 text-center text-muted-foreground">
            No RADIUS users found matching your criteria.
          </div>
        )}
      </div>

      {/* Configuration Info */}
      <div className="glass rounded-xl p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4">Server Configuration</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 bg-muted/50 rounded-lg">
            <p className="text-sm text-muted-foreground mb-1">Authentication Port</p>
            <p className="text-lg font-mono text-foreground">1812</p>
          </div>
          <div className="p-4 bg-muted/50 rounded-lg">
            <p className="text-sm text-muted-foreground mb-1">Accounting Port</p>
            <p className="text-lg font-mono text-foreground">1813</p>
          </div>
          <div className="p-4 bg-muted/50 rounded-lg">
            <p className="text-sm text-muted-foreground mb-1">Shared Secret</p>
            <p className="text-lg font-mono text-foreground">••••••••••••</p>
          </div>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      <AnimatePresence>
        {showDeleteConfirm && selectedUser && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
            onClick={() => setShowDeleteConfirm(false)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="glass rounded-xl p-6 max-w-md w-full"
            >
              <h3 className="text-xl font-semibold text-foreground mb-4">Delete RADIUS User</h3>
              <p className="text-muted-foreground mb-6">
                Are you sure you want to delete user <span className="text-foreground font-medium">{selectedUser.username}</span>? 
                This will prevent them from authenticating.
              </p>
              <div className="flex justify-end gap-3">
                <button
                  onClick={() => setShowDeleteConfirm(false)}
                  className="px-4 py-2 text-foreground hover:bg-muted rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={confirmDelete}
                  className="px-4 py-2 bg-destructive text-destructive-foreground rounded-lg hover:bg-destructive/90 transition-colors"
                >
                  Delete
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
