import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Activity, 
  Wifi, 
  Network, 
  Router, 
  Users, 
  ArrowUp, 
  ArrowDown,
  Zap,
  CheckCircle,
  Clock,
  RefreshCw,
  Maximize2,
  Minimize2
} from 'lucide-react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line
} from 'recharts';
import { formatBytes } from '../lib/utils';

// Live data simulation
const generateLiveData = () => {
  const now = new Date();
  const data = [];
  for (let i = 20; i >= 0; i--) {
    const time = new Date(now.getTime() - i * 5000);
    data.push({
      time: time.toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      download: Math.floor(Math.random() * 500) + 200,
      upload: Math.floor(Math.random() * 300) + 100,
      latency: Math.floor(Math.random() * 20) + 5,
    });
  }
  return data;
};

const liveNodes = [
  { id: 1, name: 'Main Tower', status: 'online', users: 156, load: 65, x: 50, y: 30 },
  { id: 2, name: 'Westlands AP', status: 'online', users: 89, load: 45, x: 25, y: 50 },
  { id: 3, name: 'Kilimani Hub', status: 'online', users: 124, load: 72, x: 75, y: 50 },
  { id: 4, name: 'Karen Backup', status: 'offline', users: 0, load: 0, x: 40, y: 75 },
  { id: 5, name: 'Airport Lounge', status: 'maintenance', users: 45, load: 30, x: 60, y: 75 },
];

const connections = [
  { from: 1, to: 2 },
  { from: 1, to: 3 },
  { from: 1, to: 4 },
  { from: 2, to: 5 },
  { from: 3, to: 5 },
];

export default function NetworkMonitor() {
  const [liveData, setLiveData] = useState(generateLiveData());
  const [selectedNode, setSelectedNode] = useState<typeof liveNodes[0] | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [_packetAnimation, setPacketAnimation] = useState(0);

  // Simulate live data updates
  useEffect(() => {
    const interval = setInterval(() => {
      setLiveData(prev => {
        const newData = [...prev.slice(1)];
        const lastEntry = prev[prev.length - 1];
        newData.push({
          time: new Date().toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' }),
          download: Math.max(100, lastEntry.download + Math.floor(Math.random() * 100) - 50),
          upload: Math.max(50, lastEntry.upload + Math.floor(Math.random() * 60) - 30),
          latency: Math.max(5, lastEntry.latency + Math.floor(Math.random() * 6) - 3),
        });
        return newData;
      });
      setPacketAnimation(prev => (prev + 1) % 100);
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const avgLatency = liveData.reduce((sum, d) => sum + d.latency, 0) / liveData.length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Network Monitor</h2>
          <p className="text-muted-foreground">Real-time network performance and topology</p>
        </div>
        <div className="flex gap-2">
          <div className="flex items-center gap-2 px-4 py-2 glass rounded-lg">
            <div className="w-2 h-2 rounded-full bg-success animate-pulse" />
            <span className="text-sm text-foreground">Live</span>
          </div>
          <button 
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="p-2 glass rounded-lg hover:bg-muted transition-colors"
          >
            {isFullscreen ? <Minimize2 className="w-5 h-5" /> : <Maximize2 className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Live Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass rounded-xl p-4 relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-20 h-20 bg-primary/10 rounded-full blur-2xl" />
          <div className="flex items-center gap-3 relative z-10">
            <div className="w-10 h-10 bg-primary/20 rounded-lg flex items-center justify-center">
              <ArrowDown className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Download</p>
              <p className="text-2xl font-bold text-foreground">{formatBytes(liveData[liveData.length - 1].download * 1024)}/s</p>
            </div>
          </div>
          <div className="mt-2 flex items-center gap-1 text-xs text-success">
            <Activity className="w-3 h-3" />
            <span>Real-time</span>
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="glass rounded-xl p-4 relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-20 h-20 bg-secondary/10 rounded-full blur-2xl" />
          <div className="flex items-center gap-3 relative z-10">
            <div className="w-10 h-10 bg-secondary/20 rounded-lg flex items-center justify-center">
              <ArrowUp className="w-5 h-5 text-secondary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Upload</p>
              <p className="text-2xl font-bold text-foreground">{formatBytes(liveData[liveData.length - 1].upload * 1024)}/s</p>
            </div>
          </div>
          <div className="mt-2 flex items-center gap-1 text-xs text-success">
            <Activity className="w-3 h-3" />
            <span>Real-time</span>
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="glass rounded-xl p-4 relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-20 h-20 bg-warning/10 rounded-full blur-2xl" />
          <div className="flex items-center gap-3 relative z-10">
            <div className="w-10 h-10 bg-warning/20 rounded-lg flex items-center justify-center">
              <Zap className="w-5 h-5 text-warning" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Latency</p>
              <p className="text-2xl font-bold text-foreground">{avgLatency.toFixed(1)}ms</p>
            </div>
          </div>
          <div className="mt-2 flex items-center gap-1 text-xs text-success">
            <CheckCircle className="w-3 h-3" />
            <span>Excellent</span>
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="glass rounded-xl p-4 relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-20 h-20 bg-success/10 rounded-full blur-2xl" />
          <div className="flex items-center gap-3 relative z-10">
            <div className="w-10 h-10 bg-success/20 rounded-lg flex items-center justify-center">
              <Users className="w-5 h-5 text-success" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Active Users</p>
              <p className="text-2xl font-bold text-foreground">{liveNodes.reduce((sum, n) => sum + n.users, 0)}</p>
            </div>
          </div>
          <div className="mt-2 flex items-center gap-1 text-xs text-success">
            <Wifi className="w-3 h-3" />
            <span>Online</span>
          </div>
        </motion.div>
      </div>

      {/* Network Topology */}
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="glass rounded-xl p-6"
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-foreground flex items-center gap-2">
            <Network className="w-5 h-5 text-primary" />
            Network Topology
          </h3>
          <div className="flex gap-4 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-success" />
              <span className="text-muted-foreground">Online</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-destructive" />
              <span className="text-muted-foreground">Offline</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-warning" />
              <span className="text-muted-foreground">Maintenance</span>
            </div>
          </div>
        </div>

        <div className="relative h-80 bg-muted/30 rounded-xl overflow-hidden">
          {/* Connection Lines */}
          <svg className="absolute inset-0 w-full h-full">
            {connections.map((conn, idx) => {
              const fromNode = liveNodes.find(n => n.id === conn.from);
              const toNode = liveNodes.find(n => n.id === conn.to);
              if (!fromNode || !toNode) return null;
              
              return (
                <g key={idx}>
                  <line
                    x1={`${fromNode.x}%`}
                    y1={`${fromNode.y}%`}
                    x2={`${toNode.x}%`}
                    y2={`${toNode.y}%`}
                    stroke="rgba(99, 102, 241, 0.3)"
                    strokeWidth="2"
                  />
                  {/* Animated packet */}
                  <motion.circle
                    r="4"
                    fill="#6366f1"
                    initial={{ 
                      cx: `${fromNode.x}%`, 
                      cy: `${fromNode.y}%` 
                    }}
                    animate={{ 
                      cx: `${toNode.x}%`, 
                      cy: `${toNode.y}%` 
                    }}
                    transition={{ 
                      duration: 2, 
                      repeat: Infinity, 
                      ease: "linear",
                      delay: idx * 0.5
                    }}
                  />
                </g>
              );
            })}
          </svg>

          {/* Nodes */}
          {liveNodes.map((node) => (
            <motion.div
              key={node.id}
              className="absolute transform -translate-x-1/2 -translate-y-1/2 cursor-pointer"
              style={{ left: `${node.x}%`, top: `${node.y}%` }}
              onClick={() => setSelectedNode(node)}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
            >
              <div className={`relative ${
                node.status === 'online' ? 'animate-pulse' : ''
              }`}>
                {/* Glow effect */}
                {node.status === 'online' && (
                  <div className="absolute inset-0 bg-success/30 rounded-full blur-xl" />
                )}
                <div className={`w-14 h-14 rounded-full flex items-center justify-center border-2 ${
                  node.status === 'online' ? 'bg-success/20 border-success' :
                  node.status === 'offline' ? 'bg-destructive/20 border-destructive' :
                  'bg-warning/20 border-warning'
                }`}>
                  <Router className={`w-6 h-6 ${
                    node.status === 'online' ? 'text-success' :
                    node.status === 'offline' ? 'text-destructive' :
                    'text-warning'
                  }`} />
                </div>
                {/* Load indicator */}
                {node.status === 'online' && (
                  <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-background rounded-full flex items-center justify-center border border-border">
                    <span className="text-xs font-bold text-foreground">{node.load}%</span>
                  </div>
                )}
              </div>
              <div className="mt-2 text-center">
                <p className="text-xs font-medium text-foreground whitespace-nowrap">{node.name}</p>
                <p className="text-xs text-muted-foreground">{node.users} users</p>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Live Bandwidth Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="glass rounded-xl p-6"
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-foreground flex items-center gap-2">
              <Activity className="w-5 h-5 text-primary" />
              Live Bandwidth
            </h3>
            <div className="flex items-center gap-2 text-sm">
              <RefreshCw className="w-4 h-4 text-success animate-spin" style={{ animationDuration: '3s' }} />
              <span className="text-muted-foreground">Updating every 2s</span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={250}>
            <AreaChart data={liveData}>
              <defs>
                <linearGradient id="colorDownload" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                </linearGradient>
                <linearGradient id="colorUpload" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#06b6d4" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(148, 163, 184, 0.1)" />
              <XAxis dataKey="time" stroke="#94a3b8" fontSize={10} tickLine={false} />
              <YAxis stroke="#94a3b8" fontSize={10} tickLine={false} />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'hsl(222 35% 8%)', 
                  border: '1px solid hsl(217 33% 17%)',
                  borderRadius: '8px',
                }}
              />
              <Area type="monotone" dataKey="download" stroke="#6366f1" strokeWidth={2} fillOpacity={1} fill="url(#colorDownload)" name="Download" />
              <Area type="monotone" dataKey="upload" stroke="#06b6d4" strokeWidth={2} fillOpacity={1} fill="url(#colorUpload)" name="Upload" />
            </AreaChart>
          </ResponsiveContainer>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="glass rounded-xl p-6"
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-foreground flex items-center gap-2">
              <Clock className="w-5 h-5 text-warning" />
              Network Latency
            </h3>
            <span className="text-sm text-muted-foreground">Last 2 minutes</span>
          </div>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={liveData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(148, 163, 184, 0.1)" />
              <XAxis dataKey="time" stroke="#94a3b8" fontSize={10} tickLine={false} />
              <YAxis stroke="#94a3b8" fontSize={10} tickLine={false} domain={[0, 50]} />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'hsl(222 35% 8%)', 
                  border: '1px solid hsl(217 33% 17%)',
                  borderRadius: '8px',
                }}
                formatter={(value: number) => [`${value}ms`, 'Latency']}
              />
              <Line type="monotone" dataKey="latency" stroke="#f59e0b" strokeWidth={2} dot={false} name="Latency" />
            </LineChart>
          </ResponsiveContainer>
        </motion.div>
      </div>

      {/* Node Details Modal */}
      {selectedNode && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
          onClick={() => setSelectedNode(null)}
        >
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            onClick={(e) => e.stopPropagation()}
            className="glass rounded-xl p-6 max-w-md w-full"
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-semibold text-foreground">{selectedNode.name}</h3>
              <button onClick={() => setSelectedNode(null)} className="p-2 hover:bg-muted rounded-lg">
                <span className="text-2xl">&times;</span>
              </button>
            </div>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                <span className="text-muted-foreground">Status</span>
                <span className={`px-2 py-1 rounded-full text-sm ${
                  selectedNode.status === 'online' ? 'bg-success/20 text-success' :
                  selectedNode.status === 'offline' ? 'bg-destructive/20 text-destructive' :
                  'bg-warning/20 text-warning'
                }`}>
                  {selectedNode.status}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="p-3 bg-muted/50 rounded-lg">
                  <p className="text-sm text-muted-foreground">Connected Users</p>
                  <p className="text-lg font-semibold text-foreground">{selectedNode.users}</p>
                </div>
                <div className="p-3 bg-muted/50 rounded-lg">
                  <p className="text-sm text-muted-foreground">Load</p>
                  <p className="text-lg font-semibold text-foreground">{selectedNode.load}%</p>
                </div>
              </div>
              <div className="p-3 bg-muted/50 rounded-lg">
                <p className="text-sm text-muted-foreground mb-2">Resource Usage</p>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div 
                    className={`h-full rounded-full transition-all ${
                      selectedNode.load > 80 ? 'bg-destructive' :
                      selectedNode.load > 60 ? 'bg-warning' : 'bg-success'
                    }`}
                    style={{ width: `${selectedNode.load}%` }}
                  />
                </div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </div>
  );
}
