import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  AlertTriangle,
  CheckCircle,
  Info,
  Search,
  Calendar,
  Download
} from 'lucide-react';

interface AuditLog {
  id: string;
  timestamp: string;
  user: string;
  userRole: string;
  action: string;
  entity: string;
  entityId: string;
  details: string;
  ipAddress: string;
  severity: 'info' | 'warning' | 'error' | 'success';
}

const mockLogs: AuditLog[] = [
  {
    id: '1',
    timestamp: '2024-06-15 14:32:15',
    user: 'admin',
    userRole: 'Administrator',
    action: 'CREATE',
    entity: 'Customer',
    entityId: 'CUST-1249',
    details: 'Created new customer: John Doe (john_doe)',
    ipAddress: '192.168.1.100',
    severity: 'success',
  },
  {
    id: '2',
    timestamp: '2024-06-15 14:28:33',
    user: 'manager',
    userRole: 'Manager',
    action: 'UPDATE',
    entity: 'Plan',
    entityId: 'PLAN-003',
    details: 'Updated Premium 20Mbps plan price from KES 4,500 to KES 5,000',
    ipAddress: '192.168.1.105',
    severity: 'info',
  },
  {
    id: '3',
    timestamp: '2024-06-15 14:15:22',
    user: 'admin',
    userRole: 'Administrator',
    action: 'DELETE',
    entity: 'Router',
    entityId: 'RTR-005',
    details: 'Deleted router: Karen Backup (192.168.100.5)',
    ipAddress: '192.168.1.100',
    severity: 'warning',
  },
  {
    id: '4',
    timestamp: '2024-06-15 14:10:00',
    user: 'staff',
    userRole: 'Support Staff',
    action: 'PAYMENT',
    entity: 'Invoice',
    entityId: 'INV-2024-156',
    details: 'Recorded M-Pesa payment of KES 2,500 from Jane Smith',
    ipAddress: '192.168.1.110',
    severity: 'success',
  },
  {
    id: '5',
    timestamp: '2024-06-15 13:45:18',
    user: 'system',
    userRole: 'System',
    action: 'SUSPEND',
    entity: 'Customer',
    entityId: 'CUST-0892',
    details: 'Auto-suspended account due to non-payment (grace period expired)',
    ipAddress: '127.0.0.1',
    severity: 'warning',
  },
  {
    id: '6',
    timestamp: '2024-06-15 13:30:45',
    user: 'admin',
    userRole: 'Administrator',
    action: 'LOGIN',
    entity: 'User',
    entityId: 'admin',
    details: 'Successful login from new device',
    ipAddress: '102.67.123.45',
    severity: 'info',
  },
  {
    id: '7',
    timestamp: '2024-06-15 13:15:30',
    user: 'unknown',
    userRole: 'Unknown',
    action: 'LOGIN_FAILED',
    entity: 'User',
    entityId: 'admin',
    details: 'Failed login attempt - Invalid password',
    ipAddress: '45.123.67.89',
    severity: 'error',
  },
  {
    id: '8',
    timestamp: '2024-06-15 12:50:12',
    user: 'manager',
    userRole: 'Manager',
    action: 'BULK_SMS',
    entity: 'Campaign',
    entityId: 'CMP-045',
    details: 'Sent bulk SMS to 156 customers: Payment reminder',
    ipAddress: '192.168.1.105',
    severity: 'success',
  },
];

const getSeverityIcon = (severity: AuditLog['severity']) => {
  switch (severity) {
    case 'success': return <CheckCircle className="w-4 h-4 text-success" />;
    case 'warning': return <AlertTriangle className="w-4 h-4 text-warning" />;
    case 'error': return <AlertTriangle className="w-4 h-4 text-destructive" />;
    default: return <Info className="w-4 h-4 text-primary" />;
  }
};

const getSeverityColor = (severity: AuditLog['severity']) => {
  switch (severity) {
    case 'success': return 'bg-success/10 text-success border-success/30';
    case 'warning': return 'bg-warning/10 text-warning border-warning/30';
    case 'error': return 'bg-destructive/10 text-destructive border-destructive/30';
    default: return 'bg-primary/10 text-primary border-primary/30';
  }
};

const getActionColor = (action: string) => {
  switch (action) {
    case 'CREATE': return 'text-success';
    case 'UPDATE': return 'text-primary';
    case 'DELETE': return 'text-destructive';
    case 'PAYMENT': return 'text-success';
    case 'SUSPEND': return 'text-warning';
    case 'LOGIN_FAILED': return 'text-destructive';
    default: return 'text-muted-foreground';
  }
};

export default function AuditLogs() {
  const [logs] = useState<AuditLog[]>(mockLogs);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterSeverity, setFilterSeverity] = useState<string>('all');
  const [filterEntity, setFilterEntity] = useState<string>('all');
  const [expandedLog, setExpandedLog] = useState<string | null>(null);
  const [dateRange, setDateRange] = useState('today');

  const filteredLogs = logs.filter(log => {
    const matchesSearch = 
      log.user.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.action.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.entity.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.details.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesSeverity = filterSeverity === 'all' || log.severity === filterSeverity;
    const matchesEntity = filterEntity === 'all' || log.entity === filterEntity;
    
    return matchesSearch && matchesSeverity && matchesEntity;
  });

  const stats = {
    total: logs.length,
    info: logs.filter(l => l.severity === 'info').length,
    success: logs.filter(l => l.severity === 'success').length,
    warning: logs.filter(l => l.severity === 'warning').length,
    error: logs.filter(l => l.severity === 'error').length,
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Audit Logs</h2>
          <p className="text-muted-foreground">Track all system activities and changes</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-muted text-foreground rounded-lg hover:bg-muted/80 transition-colors">
          <Download className="w-4 h-4" />
          Export Logs
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <div className="glass rounded-xl p-4">
          <p className="text-sm text-muted-foreground">Total Logs</p>
          <p className="text-2xl font-bold text-foreground">{stats.total}</p>
        </div>
        <div className="glass rounded-xl p-4">
          <p className="text-sm text-muted-foreground">Info</p>
          <p className="text-2xl font-bold text-primary">{stats.info}</p>
        </div>
        <div className="glass rounded-xl p-4">
          <p className="text-sm text-muted-foreground">Success</p>
          <p className="text-2xl font-bold text-success">{stats.success}</p>
        </div>
        <div className="glass rounded-xl p-4">
          <p className="text-sm text-muted-foreground">Warnings</p>
          <p className="text-2xl font-bold text-warning">{stats.warning}</p>
        </div>
        <div className="glass rounded-xl p-4">
          <p className="text-sm text-muted-foreground">Errors</p>
          <p className="text-2xl font-bold text-destructive">{stats.error}</p>
        </div>
      </div>

      {/* Filters */}
      <div className="glass rounded-xl p-4">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search logs..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-muted border border-border rounded-lg text-sm"
            />
          </div>
          <select
            value={dateRange}
            onChange={(e) => setDateRange(e.target.value)}
            className="px-4 py-2 bg-muted border border-border rounded-lg text-sm"
          >
            <option value="today">Today</option>
            <option value="yesterday">Yesterday</option>
            <option value="week">Last 7 Days</option>
            <option value="month">Last 30 Days</option>
          </select>
          <select
            value={filterSeverity}
            onChange={(e) => setFilterSeverity(e.target.value)}
            className="px-4 py-2 bg-muted border border-border rounded-lg text-sm"
          >
            <option value="all">All Severities</option>
            <option value="info">Info</option>
            <option value="success">Success</option>
            <option value="warning">Warning</option>
            <option value="error">Error</option>
          </select>
          <select
            value={filterEntity}
            onChange={(e) => setFilterEntity(e.target.value)}
            className="px-4 py-2 bg-muted border border-border rounded-lg text-sm"
          >
            <option value="all">All Entities</option>
            <option value="Customer">Customer</option>
            <option value="Invoice">Invoice</option>
            <option value="Payment">Payment</option>
            <option value="Router">Router</option>
            <option value="Plan">Plan</option>
          </select>
        </div>
      </div>

      {/* Logs Table */}
      <div className="glass rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border bg-muted/50">
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Time</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">User</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Action</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Entity</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Details</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Severity</th>
              </tr>
            </thead>
            <tbody>
              {filteredLogs.map((log) => (
                <motion.tr
                  key={log.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="border-b border-border last:border-b-0 hover:bg-muted/30 transition-colors cursor-pointer"
                  onClick={() => setExpandedLog(expandedLog === log.id ? null : log.id)}
                >
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-muted-foreground" />
                      <span className="text-sm text-foreground">{log.timestamp}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center">
                        <span className="text-xs text-primary">{log.user.charAt(0).toUpperCase()}</span>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-foreground">{log.user}</p>
                        <p className="text-xs text-muted-foreground">{log.userRole}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`text-sm font-medium ${getActionColor(log.action)}`}>
                      {log.action}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <span className="text-sm text-foreground">{log.entity}</span>
                    <p className="text-xs text-muted-foreground">{log.entityId}</p>
                  </td>
                  <td className="px-4 py-3">
                    <p className="text-sm text-foreground truncate max-w-xs">{log.details}</p>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs border ${getSeverityColor(log.severity)}`}>
                      {getSeverityIcon(log.severity)}
                      {log.severity}
                    </span>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
        {filteredLogs.length === 0 && (
          <div className="p-8 text-center text-muted-foreground">
            No logs found matching your criteria.
          </div>
        )}
      </div>

      {/* Log Detail Modal */}
      {expandedLog && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
          onClick={() => setExpandedLog(null)}
        >
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            onClick={(e) => e.stopPropagation()}
            className="glass rounded-xl p-6 max-w-lg w-full"
          >
            {(() => {
              const log = logs.find(l => l.id === expandedLog);
              if (!log) return null;
              return (
                <>
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-xl font-semibold text-foreground">Log Details</h3>
                    <button onClick={() => setExpandedLog(null)} className="p-2 hover:bg-muted rounded-lg">
                      <span className="text-2xl">&times;</span>
                    </button>
                  </div>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-3 bg-muted/50 rounded-lg">
                        <p className="text-sm text-muted-foreground">Timestamp</p>
                        <p className="text-sm font-medium text-foreground">{log.timestamp}</p>
                      </div>
                      <div className="p-3 bg-muted/50 rounded-lg">
                        <p className="text-sm text-muted-foreground">IP Address</p>
                        <p className="text-sm font-medium text-foreground font-mono">{log.ipAddress}</p>
                      </div>
                    </div>
                    <div className="p-3 bg-muted/50 rounded-lg">
                      <p className="text-sm text-muted-foreground">User</p>
                      <p className="text-sm font-medium text-foreground">{log.user} ({log.userRole})</p>
                    </div>
                    <div className="p-3 bg-muted/50 rounded-lg">
                      <p className="text-sm text-muted-foreground">Action</p>
                      <p className="text-sm font-medium text-foreground">{log.action} on {log.entity}</p>
                      <p className="text-xs text-muted-foreground">{log.entityId}</p>
                    </div>
                    <div className="p-3 bg-muted/50 rounded-lg">
                      <p className="text-sm text-muted-foreground">Details</p>
                      <p className="text-sm text-foreground">{log.details}</p>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                      <span className="text-sm text-muted-foreground">Severity</span>
                      <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs border ${getSeverityColor(log.severity)}`}>
                        {getSeverityIcon(log.severity)}
                        {log.severity}
                      </span>
                    </div>
                  </div>
                </>
              );
            })()}
          </motion.div>
        </motion.div>
      )}
    </div>
  );
}
