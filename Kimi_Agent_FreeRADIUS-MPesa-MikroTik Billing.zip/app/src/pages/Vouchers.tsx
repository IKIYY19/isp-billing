import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Ticket, 
  Plus, 
  Search,
  Copy,
  CheckCircle,
  Users,
  CreditCard,
  QrCode,
  Download,
  Printer,
  RefreshCw,
  Trash2,
  Wifi
} from 'lucide-react';
import { formatDate, formatCurrency } from '../lib/utils';

interface Voucher {
  id: string;
  code: string;
  planName: string;
  duration: string;
  dataLimit?: number;
  price: number;
  status: 'active' | 'used' | 'expired' | 'disabled';
  createdAt: string;
  usedAt?: string;
  usedBy?: string;
  expiryDate: string;
}

const mockVouchers: Voucher[] = [
  {
    id: '1',
    code: 'HOT-7D-ABC123',
    planName: 'Weekly Unlimited',
    duration: '7 days',
    dataLimit: 50,
    price: 500,
    status: 'active',
    createdAt: '2024-06-15T10:00:00',
    expiryDate: '2024-12-31',
  },
  {
    id: '2',
    code: 'HOT-24H-DEF456',
    planName: 'Daily Pass',
    duration: '24 hours',
    dataLimit: 10,
    price: 100,
    status: 'used',
    createdAt: '2024-06-14T09:00:00',
    usedAt: '2024-06-14T10:30:00',
    usedBy: '+254712345678',
    expiryDate: '2024-06-15',
  },
  {
    id: '3',
    code: 'HOT-30D-GHI789',
    planName: 'Monthly Unlimited',
    duration: '30 days',
    price: 1500,
    status: 'active',
    createdAt: '2024-06-15T08:00:00',
    expiryDate: '2024-12-31',
  },
  {
    id: '4',
    code: 'HOT-1H-JKL012',
    planName: 'Hourly Pass',
    duration: '1 hour',
    dataLimit: 2,
    price: 30,
    status: 'expired',
    createdAt: '2024-06-10T10:00:00',
    expiryDate: '2024-06-11',
  },
  {
    id: '5',
    code: 'HOT-7D-MNO345',
    planName: 'Weekly Unlimited',
    duration: '7 days',
    dataLimit: 50,
    price: 500,
    status: 'disabled',
    createdAt: '2024-06-01T10:00:00',
    expiryDate: '2024-12-31',
  },
];

const voucherPlans = [
  { name: 'Hourly Pass', duration: '1 hour', dataLimit: 2, price: 30 },
  { name: 'Daily Pass', duration: '24 hours', dataLimit: 10, price: 100 },
  { name: 'Weekly Unlimited', duration: '7 days', dataLimit: 50, price: 500 },
  { name: 'Monthly Unlimited', duration: '30 days', dataLimit: null, price: 1500 },
];

const getStatusColor = (status: Voucher['status']) => {
  switch (status) {
    case 'active': return 'bg-success/20 text-success';
    case 'used': return 'bg-primary/20 text-primary';
    case 'expired': return 'bg-muted text-muted-foreground';
    case 'disabled': return 'bg-destructive/20 text-destructive';
  }
};

export default function Vouchers() {
  const [vouchers, _setVouchers] = useState<Voucher[]>(mockVouchers);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [showGenerateModal, setShowGenerateModal] = useState(false);
  const [generatedCodes, setGeneratedCodes] = useState<string[]>([]);
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const filteredVouchers = vouchers.filter(voucher => {
    const matchesSearch = 
      voucher.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
      voucher.planName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      voucher.usedBy?.includes(searchQuery);
    
    const matchesStatus = filterStatus === 'all' || voucher.status === filterStatus;
    
    return matchesSearch && matchesStatus;
  });

  const stats = {
    total: vouchers.length,
    active: vouchers.filter(v => v.status === 'active').length,
    used: vouchers.filter(v => v.status === 'used').length,
    revenue: vouchers.filter(v => v.status === 'used').reduce((sum, v) => sum + v.price, 0),
  };

  const generateVoucherCode = () => {
    const prefix = 'HOT';
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let code = prefix + '-';
    for (let i = 0; i < 8; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
  };

  const handleGenerateVouchers = (quantity: number) => {
    const codes: string[] = [];
    for (let i = 0; i < quantity; i++) {
      codes.push(generateVoucherCode());
    }
    setGeneratedCodes(codes);
  };

  const copyToClipboard = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Hotspot Vouchers</h2>
          <p className="text-muted-foreground">Generate and manage prepaid WiFi vouchers</p>
        </div>
        <div className="flex gap-2">
          <button className="flex items-center gap-2 px-4 py-2 bg-muted text-foreground rounded-lg hover:bg-muted/80 transition-colors">
            <Download className="w-4 h-4" />
            Export
          </button>
          <button
            onClick={() => setShowGenerateModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
          >
            <Plus className="w-4 h-4" />
            Generate Vouchers
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary/20 rounded-lg flex items-center justify-center">
              <Ticket className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Total Vouchers</p>
              <p className="text-2xl font-bold text-foreground">{stats.total}</p>
            </div>
          </div>
        </div>
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-success/20 rounded-lg flex items-center justify-center">
              <CheckCircle className="w-5 h-5 text-success" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Active</p>
              <p className="text-2xl font-bold text-success">{stats.active}</p>
            </div>
          </div>
        </div>
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-secondary/20 rounded-lg flex items-center justify-center">
              <Users className="w-5 h-5 text-secondary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Used</p>
              <p className="text-2xl font-bold text-secondary">{stats.used}</p>
            </div>
          </div>
        </div>
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-warning/20 rounded-lg flex items-center justify-center">
              <CreditCard className="w-5 h-5 text-warning" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Voucher Revenue</p>
              <p className="text-2xl font-bold text-warning">{formatCurrency(stats.revenue)}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Generate */}
      <div className="glass rounded-xl p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
          <RefreshCw className="w-5 h-5 text-primary" />
          Quick Generate
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {voucherPlans.map((plan) => (
            <motion.button
              key={plan.name}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => handleGenerateVouchers(10)}
              className="p-4 bg-muted/50 rounded-xl hover:bg-muted transition-colors text-left"
            >
              <Wifi className="w-8 h-8 text-primary mb-2" />
              <p className="font-medium text-foreground">{plan.name}</p>
              <p className="text-sm text-muted-foreground">{plan.duration}</p>
              <p className="text-lg font-bold text-primary mt-1">{formatCurrency(plan.price)}</p>
            </motion.button>
          ))}
        </div>
      </div>

      {/* Filters */}
      <div className="glass rounded-xl p-4">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search vouchers..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-muted border border-border rounded-lg text-sm"
            />
          </div>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-4 py-2 bg-muted border border-border rounded-lg text-sm"
          >
            <option value="all">All Status</option>
            <option value="active">Active</option>
            <option value="used">Used</option>
            <option value="expired">Expired</option>
            <option value="disabled">Disabled</option>
          </select>
        </div>
      </div>

      {/* Vouchers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredVouchers.map((voucher, index) => (
          <motion.div
            key={voucher.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            className="glass rounded-xl p-5 relative overflow-hidden"
          >
            {/* Status Badge */}
            <div className="absolute top-3 right-3">
              <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(voucher.status)}`}>
                {voucher.status}
              </span>
            </div>

            {/* Voucher Icon */}
            <div className="w-12 h-12 bg-primary/20 rounded-xl flex items-center justify-center mb-4">
              <Ticket className="w-6 h-6 text-primary" />
            </div>

            {/* Voucher Code */}
            <div className="mb-4">
              <p className="text-xs text-muted-foreground mb-1">Voucher Code</p>
              <div className="flex items-center gap-2">
                <code className="flex-1 px-3 py-2 bg-muted rounded-lg text-lg font-mono font-bold text-foreground">
                  {voucher.code}
                </code>
                <button
                  onClick={() => copyToClipboard(voucher.code)}
                  className="p-2 hover:bg-muted rounded-lg transition-colors"
                >
                  {copiedCode === voucher.code ? (
                    <CheckCircle className="w-5 h-5 text-success" />
                  ) : (
                    <Copy className="w-5 h-5 text-muted-foreground" />
                  )}
                </button>
              </div>
            </div>

            {/* Plan Details */}
            <div className="space-y-2 mb-4">
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Plan</span>
                <span className="text-sm font-medium text-foreground">{voucher.planName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Duration</span>
                <span className="text-sm text-foreground">{voucher.duration}</span>
              </div>
              {voucher.dataLimit && (
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Data Limit</span>
                  <span className="text-sm text-foreground">{voucher.dataLimit} GB</span>
                </div>
              )}
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Price</span>
                <span className="text-sm font-medium text-primary">{formatCurrency(voucher.price)}</span>
              </div>
            </div>

            {/* Usage Info */}
            {voucher.status === 'used' && (
              <div className="p-3 bg-muted/50 rounded-lg mb-4">
                <p className="text-xs text-muted-foreground">Used by: {voucher.usedBy}</p>
                <p className="text-xs text-muted-foreground">Used at: {formatDate(voucher.usedAt!)}</p>
              </div>
            )}

            {/* Actions */}
            <div className="flex gap-2">
              <button className="flex-1 flex items-center justify-center gap-2 px-3 py-2 bg-muted text-foreground rounded-lg hover:bg-muted/80 transition-colors text-sm">
                <Printer className="w-4 h-4" />
                Print
              </button>
              <button className="flex items-center justify-center gap-2 px-3 py-2 bg-muted text-foreground rounded-lg hover:bg-muted/80 transition-colors text-sm">
                <QrCode className="w-4 h-4" />
              </button>
              {voucher.status === 'active' && (
                <button className="p-2 bg-destructive/10 text-destructive rounded-lg hover:bg-destructive/20 transition-colors">
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
            </div>
          </motion.div>
        ))}
      </div>

      {/* Generate Modal */}
      {showGenerateModal && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
          onClick={() => setShowGenerateModal(false)}
        >
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            onClick={(e) => e.stopPropagation()}
            className="glass rounded-xl p-6 max-w-lg w-full"
          >
            <h3 className="text-xl font-semibold text-foreground mb-4">Generate Vouchers</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-foreground mb-1">Select Plan</label>
                <select className="w-full px-4 py-2 bg-muted border border-border rounded-lg">
                  {voucherPlans.map((plan) => (
                    <option key={plan.name} value={plan.name}>
                      {plan.name} - {formatCurrency(plan.price)} ({plan.duration})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-1">Quantity</label>
                <input
                  type="number"
                  min="1"
                  max="100"
                  defaultValue="10"
                  className="w-full px-4 py-2 bg-muted border border-border rounded-lg"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-1">Expiry Date</label>
                <input
                  type="date"
                  className="w-full px-4 py-2 bg-muted border border-border rounded-lg"
                />
              </div>

              {generatedCodes.length > 0 && (
                <div className="p-4 bg-muted/50 rounded-lg max-h-40 overflow-y-auto">
                  <p className="text-sm font-medium text-foreground mb-2">Generated Codes:</p>
                  <div className="space-y-1">
                    {generatedCodes.map((code, i) => (
                      <code key={i} className="block text-sm font-mono text-muted-foreground">{code}</code>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex justify-end gap-3 pt-4">
                <button
                  onClick={() => setShowGenerateModal(false)}
                  className="px-4 py-2 text-foreground hover:bg-muted rounded-lg"
                >
                  Cancel
                </button>
                <button 
                  onClick={() => handleGenerateVouchers(10)}
                  className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 flex items-center gap-2"
                >
                  <RefreshCw className="w-4 h-4" />
                  Generate
                </button>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </div>
  );
}
