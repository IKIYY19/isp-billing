import { useState, useEffect } from 'react';
import { mpesaService } from '../services/mpesaService';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { 
  Loader2, 
  CheckCircle, 
  AlertCircle, 
  Phone, 
  CreditCard, 
  User,
  Calendar,
  Wallet,
  ArrowRight
} from 'lucide-react';

interface CustomerInfo {
  id: string;
  accountNumber: string;
  firstName: string;
  lastName: string;
  email?: string;
  phone: string;
  balance: number;
  status: string;
  plan?: {
    name: string;
    price: number;
  };
  lastPayment?: {
    amount: number;
    createdAt: string;
    mpesaReceipt?: string;
  };
  outstandingAmount: number;
}

export default function CustomerPayment() {
  const [step, setStep] = useState<'account' | 'amount' | 'phone' | 'processing' | 'success'>('account');
  const [accountNumber, setAccountNumber] = useState('');
  const [amount, setAmount] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [customer, setCustomer] = useState<CustomerInfo | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [checkoutRequestId, setCheckoutRequestId] = useState<string | null>(null);
  const [paymentStatus, setPaymentStatus] = useState<'pending' | 'completed' | 'failed'>('pending');

  // Poll for payment status
  useEffect(() => {
    if (!checkoutRequestId || paymentStatus !== 'pending') return;

    const interval = setInterval(async () => {
      try {
        const status = await mpesaService.queryPaymentStatus(checkoutRequestId);
        
        if (status.status === 'completed') {
          setPaymentStatus('completed');
          setStep('success');
          clearInterval(interval);
        } else if (status.status === 'failed' || status.status === 'cancelled') {
          setPaymentStatus('failed');
          setError(status.resultDesc || 'Payment failed');
          clearInterval(interval);
        }
      } catch (err) {
        // Continue polling on error
      }
    }, 3000);

    // Stop polling after 2 minutes
    const timeout = setTimeout(() => {
      clearInterval(interval);
      if (paymentStatus === 'pending') {
        setError('Payment request timed out. Please try again.');
        setStep('phone');
      }
    }, 120000);

    return () => {
      clearInterval(interval);
      clearTimeout(timeout);
    };
  }, [checkoutRequestId, paymentStatus]);

  const handleAccountLookup = async () => {
    if (!accountNumber.trim()) {
      setError('Please enter your account number');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const data = await mpesaService.getCustomerByAccountNumber(accountNumber.trim());
      setCustomer(data.customer);
      setPhoneNumber(data.customer.phone || '');
      setAmount(data.customer.outstandingAmount > 0 ? data.customer.outstandingAmount.toString() : '');
      setStep('amount');
    } catch (err: any) {
      setError(err.response?.data?.message || 'Account not found');
    } finally {
      setLoading(false);
    }
  };

  const handleProceedToPhone = () => {
    const amountNum = parseFloat(amount);
    if (!amount || amountNum < 1) {
      setError('Please enter a valid amount (minimum KES 1)');
      return;
    }
    setError(null);
    setStep('phone');
  };

  const handlePayment = async () => {
    if (!phoneNumber.trim()) {
      setError('Please enter your M-Pesa phone number');
      return;
    }

    setLoading(true);
    setError(null);
    setStep('processing');

    try {
      const result = await mpesaService.makePublicPayment({
        accountNumber: customer!.accountNumber,
        phoneNumber: phoneNumber.trim(),
        amount: parseFloat(amount)
      });

      if (result.success && result.checkoutRequestId) {
        setCheckoutRequestId(result.checkoutRequestId);
        setPaymentStatus('pending');
      } else {
        setError(result.error || 'Failed to initiate payment');
        setStep('phone');
      }
    } catch (err: any) {
      setError(err.response?.data?.message || 'Payment failed');
      setStep('phone');
    } finally {
      setLoading(false);
    }
  };

  const formatPhoneNumber = (phone: string) => {
    // Format for display
    if (phone.startsWith('254')) {
      return `+${phone.slice(0, 3)} ${phone.slice(3, 6)} ${phone.slice(6, 9)} ${phone.slice(9)}`;
    }
    if (phone.startsWith('0')) {
      return `+254 ${phone.slice(1, 4)} ${phone.slice(4, 7)} ${phone.slice(7)}`;
    }
    return phone;
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-KE', {
      style: 'currency',
      currency: 'KES'
    }).format(amount);
  };

  const resetForm = () => {
    setStep('account');
    setAccountNumber('');
    setAmount('');
    setPhoneNumber('');
    setCustomer(null);
    setError(null);
    setCheckoutRequestId(null);
    setPaymentStatus('pending');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-secondary/20 flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-xl">
        <CardHeader className="text-center">
          <div className="mx-auto w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
            <Wallet className="w-8 h-8 text-primary" />
          </div>
          <CardTitle className="text-2xl">Pay Your Bill</CardTitle>
          <CardDescription>
            Quick and secure payment via M-Pesa
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-6">
          {error && (
            <Alert variant="destructive">
              <AlertCircle className="w-4 h-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {/* Step 1: Account Number */}
          {step === 'account' && (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="accountNumber">Account Number</Label>
                <Input
                  id="accountNumber"
                  placeholder="Enter your account number"
                  value={accountNumber}
                  onChange={(e) => setAccountNumber(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleAccountLookup()}
                />
              </div>
              <Button 
                className="w-full" 
                onClick={handleAccountLookup}
                disabled={loading}
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Looking up...
                  </>
                ) : (
                  <>
                    Continue
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </>
                )}
              </Button>
            </div>
          )}

          {/* Step 2: Customer Info & Amount */}
          {step === 'amount' && customer && (
            <div className="space-y-4">
              {/* Customer Info */}
              <div className="bg-muted p-4 rounded-lg space-y-2">
                <div className="flex items-center gap-2">
                  <User className="w-4 h-4 text-muted-foreground" />
                  <span className="font-medium">{customer.firstName} {customer.lastName}</span>
                </div>
                <div className="flex items-center gap-2">
                  <CreditCard className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">{customer.accountNumber}</span>
                </div>
                {customer.plan && (
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm">{customer.plan.name}</span>
                  </div>
                )}
                <Separator className="my-2" />
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Outstanding Balance</span>
                  <span className={`font-bold ${customer.outstandingAmount > 0 ? 'text-destructive' : 'text-green-500'}`}>
                    {formatCurrency(customer.outstandingAmount)}
                  </span>
                </div>
              </div>

              {/* Amount Input */}
              <div className="space-y-2">
                <Label htmlFor="amount">Amount to Pay (KES)</Label>
                <Input
                  id="amount"
                  type="number"
                  min="1"
                  placeholder="Enter amount"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                />
                {customer.outstandingAmount > 0 && (
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="text-xs"
                    onClick={() => setAmount(customer.outstandingAmount.toString())}
                  >
                    Pay full balance
                  </Button>
                )}
              </div>

              <div className="flex gap-2">
                <Button variant="outline" onClick={resetForm} className="flex-1">
                  Back
                </Button>
                <Button onClick={handleProceedToPhone} className="flex-1">
                  Continue
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </div>
          )}

          {/* Step 3: Phone Number */}
          {step === 'phone' && (
            <div className="space-y-4">
              <div className="bg-muted p-4 rounded-lg">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Amount</span>
                  <span className="font-bold">{formatCurrency(parseFloat(amount))}</span>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="phoneNumber">M-Pesa Phone Number</Label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    id="phoneNumber"
                    placeholder="e.g., 0712345678"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    className="pl-10"
                    onKeyDown={(e) => e.key === 'Enter' && handlePayment()}
                  />
                </div>
                <p className="text-xs text-muted-foreground">
                  You'll receive an M-Pesa prompt on this number to complete payment
                </p>
              </div>

              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setStep('amount')} className="flex-1">
                  Back
                </Button>
                <Button onClick={handlePayment} disabled={loading} className="flex-1">
                  {loading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    'Pay with M-Pesa'
                  )}
                </Button>
              </div>
            </div>
          )}

          {/* Step 4: Processing */}
          {step === 'processing' && (
            <div className="text-center space-y-6 py-8">
              <div className="relative">
                <div className="w-20 h-20 mx-auto border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
                <Phone className="w-8 h-8 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-primary" />
              </div>
              <div className="space-y-2">
                <h3 className="text-lg font-semibold">Check Your Phone</h3>
                <p className="text-muted-foreground">
                  An M-Pesa prompt has been sent to
                </p>
                <p className="font-medium">{formatPhoneNumber(phoneNumber)}</p>
                <p className="text-sm text-muted-foreground mt-4">
                  Please enter your M-Pesa PIN to complete the payment of {formatCurrency(parseFloat(amount))}
                </p>
              </div>
              <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
                <Loader2 className="w-4 h-4 animate-spin" />
                Waiting for confirmation...
              </div>
            </div>
          )}

          {/* Step 5: Success */}
          {step === 'success' && (
            <div className="text-center space-y-6 py-8">
              <div className="w-20 h-20 mx-auto bg-green-100 rounded-full flex items-center justify-center">
                <CheckCircle className="w-10 h-10 text-green-500" />
              </div>
              <div className="space-y-2">
                <h3 className="text-lg font-semibold text-green-600">Payment Successful!</h3>
                <p className="text-muted-foreground">
                  Your payment of {formatCurrency(parseFloat(amount))} has been received
                </p>
                {customer && (
                  <p className="text-sm text-muted-foreground">
                    Account: {customer.accountNumber}
                  </p>
                )}
              </div>
              <Button onClick={resetForm} className="w-full">
                Make Another Payment
              </Button>
            </div>
          )}

          {/* Footer */}
          <div className="text-center pt-4 border-t">
            <p className="text-xs text-muted-foreground">
              Secured by M-Pesa. Your transaction is protected.
            </p>
            <div className="flex items-center justify-center gap-2 mt-2">
              <Badge variant="outline" className="text-xs">Safaricom</Badge>
              <Badge variant="outline" className="text-xs">M-Pesa</Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
