import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Plus, 
  Edit2, 
  Trash2, 
  Wifi, 
  Network, 
  X,
  Zap,
  Clock,
  Database
} from 'lucide-react';
import type { Plan } from '../types';
import { formatCurrency } from '../lib/utils';

// Mock data
const mockPlans: Plan[] = [
  {
    id: '1',
    name: 'Basic 5Mbps',
    description: 'Perfect for light browsing and social media',
    speed: '5Mbps',
    type: 'hotspot',
    status: 'active',
    serviceType: 'hotspot',
    downloadSpeed: 5,
    uploadSpeed: 2,
    price: 1500,
    duration: 1,
    durationUnit: 'month',
    dataLimit: 100,
    isActive: true,
    createdAt: '2024-01-01',
  },
  {
    id: '2',
    name: 'Standard 10Mbps',
    description: 'Great for streaming and remote work',
    speed: '10Mbps',
    type: 'pppoe',
    status: 'active',
    serviceType: 'pppoe',
    downloadSpeed: 10,
    uploadSpeed: 5,
    price: 2500,
    duration: 1,
    durationUnit: 'month',
    isActive: true,
    createdAt: '2024-01-01',
  },
  {
    id: '3',
    name: 'Premium 20Mbps',
    description: 'High-speed for gaming and 4K streaming',
    speed: '20Mbps',
    type: 'pppoe',
    status: 'active',
    serviceType: 'pppoe',
    downloadSpeed: 20,
    uploadSpeed: 10,
    price: 4000,
    duration: 1,
    durationUnit: 'month',
    isActive: true,
    createdAt: '2024-01-01',
  },
  {
    id: '4',
    name: 'Enterprise 50Mbps',
    description: 'Dedicated bandwidth for businesses',
    speed: '50Mbps',
    type: 'pppoe',
    status: 'active',
    serviceType: 'pppoe',
    downloadSpeed: 50,
    uploadSpeed: 25,
    price: 10000,
    duration: 1,
    durationUnit: 'month',
    isActive: true,
    createdAt: '2024-01-01',
  },
  {
    id: '5',
    name: 'Daily Pass',
    description: '24-hour unlimited access',
    speed: '5Mbps',
    type: 'hotspot',
    status: 'active',
    serviceType: 'hotspot',
    downloadSpeed: 5,
    uploadSpeed: 2,
    price: 100,
    duration: 1,
    durationUnit: 'day',
    dataLimit: 10,
    isActive: true,
    createdAt: '2024-01-01',
  },
  {
    id: '6',
    name: 'Weekly Bundle',
    description: '7-day unlimited access',
    speed: '10Mbps',
    type: 'hotspot',
    status: 'active',
    serviceType: 'hotspot',
    downloadSpeed: 10,
    uploadSpeed: 5,
    price: 500,
    duration: 1,
    durationUnit: 'week',
    dataLimit: 50,
    isActive: true,
    createdAt: '2024-01-01',
  },
];

export default function Plans() {
  const [plans, setPlans] = useState<Plan[]>(mockPlans);
  const [showAddModal, setShowAddModal] = useState(false);
  const [_showEditModal, _setShowEditModal] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<Plan | null>(null);
  const [filterType, setFilterType] = useState<string>('all');

  const filteredPlans = plans.filter(plan => 
    filterType === 'all' || plan.serviceType === filterType
  );

  const handleDelete = (plan: Plan) => {
    setSelectedPlan(plan);
    setShowDeleteConfirm(true);
  };

  const confirmDelete = () => {
    if (selectedPlan) {
      setPlans(prev => prev.filter(p => p.id !== selectedPlan.id));
      setShowDeleteConfirm(false);
      setSelectedPlan(null);
    }
  };

  const handleEdit = (_plan: Plan) => {
    // Edit functionality to be implemented
  };

  const getSpeedColor = (speed: number) => {
    if (speed >= 50) return 'from-purple-500 to-pink-500';
    if (speed >= 20) return 'from-primary to-secondary';
    if (speed >= 10) return 'from-success to-emerald-400';
    return 'from-warning to-orange-400';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Service Plans</h2>
          <p className="text-muted-foreground">Manage internet packages and pricing</p>
        </div>
        <div className="flex gap-2">
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="px-4 py-2 bg-muted border border-border rounded-lg text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
          >
            <option value="all">All Types</option>
            <option value="pppoe">PPPoE</option>
            <option value="hotspot">Hotspot</option>
          </select>
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
          >
            <Plus className="w-4 h-4" />
            Add Plan
          </button>
        </div>
      </div>

      {/* Plans Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredPlans.map((plan, index) => (
          <motion.div
            key={plan.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="glass rounded-xl overflow-hidden group hover:shadow-xl transition-all duration-300"
          >
            {/* Card Header */}
            <div className={`h-24 bg-gradient-to-r ${getSpeedColor(plan.downloadSpeed)} relative overflow-hidden`}>
              <div className="absolute inset-0 bg-black/10" />
              <div className="absolute top-4 right-4">
                {plan.serviceType === 'pppoe' ? (
                  <Network className="w-8 h-8 text-white/80" />
                ) : (
                  <Wifi className="w-8 h-8 text-white/80" />
                )}
              </div>
              <div className="absolute bottom-4 left-4">
                <span className="px-2 py-1 bg-white/20 backdrop-blur-sm text-white text-xs rounded-full">
                  {plan.serviceType.toUpperCase()}
                </span>
              </div>
            </div>

            {/* Card Content */}
            <div className="p-5">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="text-lg font-semibold text-foreground">{plan.name}</h3>
                  <p className="text-sm text-muted-foreground">{plan.description}</p>
                </div>
              </div>

              <div className="flex items-baseline gap-1 mb-4">
                <span className="text-3xl font-bold text-foreground">{formatCurrency(plan.price)}</span>
                <span className="text-sm text-muted-foreground">/{plan.durationUnit}</span>
              </div>

              {/* Features */}
              <div className="space-y-2 mb-5">
                <div className="flex items-center gap-2 text-sm">
                  <Zap className="w-4 h-4 text-primary" />
                  <span className="text-foreground">{plan.downloadSpeed} Mbps Down</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Zap className="w-4 h-4 text-secondary" />
                  <span className="text-foreground">{plan.uploadSpeed} Mbps Up</span>
                </div>
                {plan.dataLimit && (
                  <div className="flex items-center gap-2 text-sm">
                    <Database className="w-4 h-4 text-warning" />
                    <span className="text-foreground">{plan.dataLimit} GB Data</span>
                  </div>
                )}
                <div className="flex items-center gap-2 text-sm">
                  <Clock className="w-4 h-4 text-success" />
                  <span className="text-foreground">{plan.duration} {plan.durationUnit}</span>
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-2">
                <button
                  onClick={() => handleEdit(plan)}
                  className="flex-1 flex items-center justify-center gap-2 px-3 py-2 bg-muted text-foreground rounded-lg hover:bg-muted/80 transition-colors"
                >
                  <Edit2 className="w-4 h-4" />
                  Edit
                </button>
                <button
                  onClick={() => handleDelete(plan)}
                  className="flex items-center justify-center gap-2 px-3 py-2 bg-destructive/10 text-destructive rounded-lg hover:bg-destructive/20 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Empty State */}
      {filteredPlans.length === 0 && (
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
            <Wifi className="w-8 h-8 text-muted-foreground" />
          </div>
          <h3 className="text-lg font-medium text-foreground">No plans found</h3>
          <p className="text-muted-foreground">Create your first service plan to get started.</p>
        </div>
      )}

      {/* Add Plan Modal */}
      <AnimatePresence>
        {showAddModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
            onClick={() => setShowAddModal(false)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="glass rounded-xl p-6 max-w-lg w-full max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-semibold text-foreground">Add New Plan</h3>
                <button
                  onClick={() => setShowAddModal(false)}
                  className="p-2 hover:bg-muted rounded-lg transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              
              <form className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-1">Plan Name</label>
                  <input
                    type="text"
                    placeholder="e.g., Premium 20Mbps"
                    className="w-full px-4 py-2 bg-muted border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-foreground mb-1">Description</label>
                  <textarea
                    placeholder="Brief description of the plan"
                    rows={2}
                    className="w-full px-4 py-2 bg-muted border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-1">Service Type</label>
                    <select className="w-full px-4 py-2 bg-muted border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50">
                      <option value="pppoe">PPPoE</option>
                      <option value="hotspot">Hotspot</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-1">Price (KES)</label>
                    <input
                      type="number"
                      placeholder="2500"
                      className="w-full px-4 py-2 bg-muted border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-1">Download Speed (Mbps)</label>
                    <input
                      type="number"
                      placeholder="10"
                      className="w-full px-4 py-2 bg-muted border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-1">Upload Speed (Mbps)</label>
                    <input
                      type="number"
                      placeholder="5"
                      className="w-full px-4 py-2 bg-muted border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-1">Duration</label>
                    <input
                      type="number"
                      placeholder="1"
                      className="w-full px-4 py-2 bg-muted border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-1">Duration Unit</label>
                    <select className="w-full px-4 py-2 bg-muted border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50">
                      <option value="day">Day</option>
                      <option value="week">Week</option>
                      <option value="month">Month</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-1">Data Limit (GB) - Optional</label>
                  <input
                    type="number"
                    placeholder="Unlimited"
                    className="w-full px-4 py-2 bg-muted border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                  />
                </div>

                <div className="flex justify-end gap-3 pt-4">
                  <button
                    type="button"
                    onClick={() => setShowAddModal(false)}
                    className="px-4 py-2 text-foreground hover:bg-muted rounded-lg transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
                  >
                    Create Plan
                  </button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Delete Confirmation Modal */}
      <AnimatePresence>
        {showDeleteConfirm && selectedPlan && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
            onClick={() => setShowDeleteConfirm(false)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="glass rounded-xl p-6 max-w-md w-full"
            >
              <h3 className="text-xl font-semibold text-foreground mb-4">Delete Plan</h3>
              <p className="text-muted-foreground mb-6">
                Are you sure you want to delete <span className="text-foreground font-medium">{selectedPlan.name}</span>? 
                This action cannot be undone.
              </p>
              <div className="flex justify-end gap-3">
                <button
                  onClick={() => setShowDeleteConfirm(false)}
                  className="px-4 py-2 text-foreground hover:bg-muted rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={confirmDelete}
                  className="px-4 py-2 bg-destructive text-destructive-foreground rounded-lg hover:bg-destructive/90 transition-colors"
                >
                  Delete
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
