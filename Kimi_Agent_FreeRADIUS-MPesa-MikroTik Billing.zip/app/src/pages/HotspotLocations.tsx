import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Plus, 
  Edit2, 
  Trash2, 
  MapPin, 
  Wifi, 
  Users, 
  Signal,
  X
} from 'lucide-react';
import type { HotspotLocation } from '../types';
import { getStatusColor } from '../lib/utils';

// Mock data
const mockLocations: HotspotLocation[] = [
  {
    id: '1',
    name: 'Central Park Hotspot',
    routerId: '1',
    routerName: 'Main Tower',
    address: 'Central Park, Nairobi CBD',
    coordinates: { lat: -1.2921, lng: 36.8219 },
    status: 'online',
    totalUsers: 45,
    maxUsers: 100,
    createdAt: '2024-01-15',
  },
  {
    id: '2',
    name: 'Westlands Mall',
    routerId: '2',
    routerName: 'Westlands AP',
    address: 'Westgate Shopping Mall, Westlands',
    coordinates: { lat: -1.2680, lng: 36.8031 },
    status: 'online',
    totalUsers: 78,
    maxUsers: 150,
    createdAt: '2024-02-01',
  },
  {
    id: '3',
    name: 'Airport Lounge',
    routerId: '3',
    routerName: 'Karen Backup',
    address: 'Jomo Kenyatta International Airport',
    coordinates: { lat: -1.3192, lng: 36.9278 },
    status: 'offline',
    totalUsers: 0,
    maxUsers: 200,
    createdAt: '2024-01-20',
  },
  {
    id: '4',
    name: 'Kilimani Plaza',
    routerId: '4',
    routerName: 'Kilimani Hub',
    address: 'Kilimani Road, Nairobi',
    coordinates: { lat: -1.2895, lng: 36.7930 },
    status: 'online',
    totalUsers: 32,
    maxUsers: 80,
    createdAt: '2024-03-01',
  },
  {
    id: '5',
    name: 'University Library',
    routerId: '1',
    routerName: 'Main Tower',
    address: 'University of Nairobi',
    coordinates: { lat: -1.2807, lng: 36.8163 },
    status: 'maintenance',
    totalUsers: 0,
    maxUsers: 300,
    createdAt: '2024-02-15',
  },
];

export default function HotspotLocations() {
  const [locations, setLocations] = useState<HotspotLocation[]>(mockLocations);
  const [_showAddModal, _setShowAddModal] = useState(false);
  const [_showEditModal, _setShowEditModal] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [selectedLocation, setSelectedLocation] = useState<HotspotLocation | null>(null);
  const [filterStatus, setFilterStatus] = useState<string>('all');

  const filteredLocations = locations.filter(location => 
    filterStatus === 'all' || location.status === filterStatus
  );

  const handleDelete = (location: HotspotLocation) => {
    setSelectedLocation(location);
    setShowDeleteConfirm(true);
  };

  const confirmDelete = () => {
    if (selectedLocation) {
      setLocations(prev => prev.filter(l => l.id !== selectedLocation.id));
      setShowDeleteConfirm(false);
      setSelectedLocation(null);
    }
  };

  const handleEdit = (_location: HotspotLocation) => {
    // Edit functionality to be implemented
  };

  const handleViewDetails = (location: HotspotLocation) => {
    setSelectedLocation(location);
    setShowDetailsModal(true);
  };

  const getUtilizationColor = (current: number, max: number) => {
    const percentage = (current / max) * 100;
    if (percentage >= 80) return 'bg-destructive';
    if (percentage >= 60) return 'bg-warning';
    return 'bg-success';
  };

  const onlineLocations = locations.filter(l => l.status === 'online').length;
  const totalUsers = locations.reduce((sum, l) => sum + l.totalUsers, 0);
  const totalCapacity = locations.reduce((sum, l) => sum + l.maxUsers, 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Hotspot Locations</h2>
          <p className="text-muted-foreground">Manage WiFi hotspot access points</p>
        </div>
        <div className="flex gap-2">
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-4 py-2 bg-muted border border-border rounded-lg text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
          >
            <option value="all">All Status</option>
            <option value="online">Online</option>
            <option value="offline">Offline</option>
            <option value="maintenance">Maintenance</option>
          </select>
          <button
            onClick={() => {/* Add location modal to be implemented */}}
            className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
          >
            <Plus className="w-4 h-4" />
            Add Location
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-success/20 rounded-lg flex items-center justify-center">
              <Wifi className="w-5 h-5 text-success" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Online Hotspots</p>
              <p className="text-2xl font-bold text-foreground">{onlineLocations}/{locations.length}</p>
            </div>
          </div>
        </div>
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary/20 rounded-lg flex items-center justify-center">
              <Users className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Connected Users</p>
              <p className="text-2xl font-bold text-foreground">{totalUsers}</p>
            </div>
          </div>
        </div>
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-secondary/20 rounded-lg flex items-center justify-center">
              <Signal className="w-5 h-5 text-secondary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Total Capacity</p>
              <p className="text-2xl font-bold text-foreground">{totalCapacity}</p>
            </div>
          </div>
        </div>
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-warning/20 rounded-lg flex items-center justify-center">
              <MapPin className="w-5 h-5 text-warning" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Utilization</p>
              <p className="text-2xl font-bold text-foreground">{Math.round((totalUsers / totalCapacity) * 100)}%</p>
            </div>
          </div>
        </div>
      </div>

      {/* Locations Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredLocations.map((location, index) => (
          <motion.div
            key={location.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="glass rounded-xl p-5 hover:shadow-lg transition-all duration-300"
          >
            {/* Header */}
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                  location.status === 'online' ? 'bg-success/20' : 
                  location.status === 'maintenance' ? 'bg-warning/20' : 'bg-destructive/20'
                }`}>
                  <Wifi className={`w-6 h-6 ${
                    location.status === 'online' ? 'text-success' : 
                    location.status === 'maintenance' ? 'text-warning' : 'text-destructive'
                  }`} />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground">{location.name}</h3>
                  <p className="text-sm text-muted-foreground">{location.routerName}</p>
                </div>
              </div>
              <span className={`px-2 py-1 text-xs rounded-full border ${getStatusColor(location.status)}`}>
                {location.status}
              </span>
            </div>

            {/* Address */}
            <div className="flex items-center gap-2 text-sm mb-4">
              <MapPin className="w-4 h-4 text-muted-foreground" />
              <span className="text-muted-foreground">{location.address}</span>
            </div>

            {/* Utilization */}
            <div className="mb-4">
              <div className="flex justify-between text-sm mb-2">
                <span className="text-muted-foreground">Utilization</span>
                <span className="text-foreground">{location.totalUsers}/{location.maxUsers}</span>
              </div>
              <div className="h-2 bg-muted rounded-full overflow-hidden">
                <div 
                  className={`h-full rounded-full transition-all ${getUtilizationColor(location.totalUsers, location.maxUsers)}`}
                  style={{ width: `${(location.totalUsers / location.maxUsers) * 100}%` }}
                />
              </div>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 gap-3 mb-4">
              <div className="p-2 bg-muted/50 rounded-lg text-center">
                <p className="text-lg font-semibold text-foreground">{location.totalUsers}</p>
                <p className="text-xs text-muted-foreground">Active Users</p>
              </div>
              <div className="p-2 bg-muted/50 rounded-lg text-center">
                <p className="text-lg font-semibold text-foreground">{location.maxUsers - location.totalUsers}</p>
                <p className="text-xs text-muted-foreground">Available</p>
              </div>
            </div>

            {/* Actions */}
            <div className="flex gap-2">
              <button
                onClick={() => handleViewDetails(location)}
                className="flex-1 px-3 py-2 bg-muted text-foreground rounded-lg hover:bg-muted/80 transition-colors text-sm"
              >
                Details
              </button>
              <button
                onClick={() => handleEdit(location)}
                className="p-2 bg-muted text-foreground rounded-lg hover:bg-muted/80 transition-colors"
              >
                <Edit2 className="w-4 h-4" />
              </button>
              <button
                onClick={() => handleDelete(location)}
                className="p-2 bg-destructive/10 text-destructive rounded-lg hover:bg-destructive/20 transition-colors"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Location Details Modal */}
      <AnimatePresence>
        {showDetailsModal && selectedLocation && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
            onClick={() => setShowDetailsModal(false)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="glass rounded-xl p-6 max-w-lg w-full"
            >
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                    selectedLocation.status === 'online' ? 'bg-success/20' : 
                    selectedLocation.status === 'maintenance' ? 'bg-warning/20' : 'bg-destructive/20'
                  }`}>
                    <Wifi className={`w-6 h-6 ${
                      selectedLocation.status === 'online' ? 'text-success' : 
                      selectedLocation.status === 'maintenance' ? 'text-warning' : 'text-destructive'
                    }`} />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-foreground">{selectedLocation.name}</h3>
                    <p className="text-sm text-muted-foreground">{selectedLocation.routerName}</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowDetailsModal(false)}
                  className="p-2 hover:bg-muted rounded-lg transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-4">
                {/* Status */}
                <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                  <span className="text-sm text-muted-foreground">Status</span>
                  <span className={`px-3 py-1 text-sm rounded-full border ${getStatusColor(selectedLocation.status)}`}>
                    {selectedLocation.status.toUpperCase()}
                  </span>
                </div>

                {/* Details */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-3 bg-muted/50 rounded-lg">
                    <p className="text-sm text-muted-foreground mb-1">Address</p>
                    <p className="text-sm font-medium text-foreground">{selectedLocation.address}</p>
                  </div>
                  <div className="p-3 bg-muted/50 rounded-lg">
                    <p className="text-sm text-muted-foreground mb-1">Router</p>
                    <p className="text-sm font-medium text-foreground">{selectedLocation.routerName}</p>
                  </div>
                  {selectedLocation.coordinates && (
                    <div className="p-3 bg-muted/50 rounded-lg col-span-2">
                      <p className="text-sm text-muted-foreground mb-1">Coordinates</p>
                      <p className="text-sm font-medium text-foreground">
                        {selectedLocation.coordinates.lat}, {selectedLocation.coordinates.lng}
                      </p>
                    </div>
                  )}
                </div>

                {/* Utilization */}
                <div className="border-t border-border pt-4">
                  <p className="text-sm font-medium text-foreground mb-3">Capacity</p>
                  <div className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Active Users</span>
                      <span className="text-foreground">{selectedLocation.totalUsers}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Maximum Capacity</span>
                      <span className="text-foreground">{selectedLocation.maxUsers}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Available Slots</span>
                      <span className="text-foreground">{selectedLocation.maxUsers - selectedLocation.totalUsers}</span>
                    </div>
                    <div>
                      <div className="h-2 bg-muted rounded-full overflow-hidden">
                        <div 
                          className={`h-full rounded-full transition-all ${getUtilizationColor(selectedLocation.totalUsers, selectedLocation.maxUsers)}`}
                          style={{ width: `${(selectedLocation.totalUsers / selectedLocation.maxUsers) * 100}%` }}
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex justify-end gap-3 pt-4">
                  <button
                    onClick={() => setShowDetailsModal(false)}
                    className="px-4 py-2 text-foreground hover:bg-muted rounded-lg transition-colors"
                  >
                    Close
                  </button>
                  <button className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors">
                    View Connected Users
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Delete Confirmation Modal */}
      <AnimatePresence>
        {showDeleteConfirm && selectedLocation && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
            onClick={() => setShowDeleteConfirm(false)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="glass rounded-xl p-6 max-w-md w-full"
            >
              <h3 className="text-xl font-semibold text-foreground mb-4">Delete Location</h3>
              <p className="text-muted-foreground mb-6">
                Are you sure you want to delete <span className="text-foreground font-medium">{selectedLocation.name}</span>? 
                This action cannot be undone.
              </p>
              <div className="flex justify-end gap-3">
                <button
                  onClick={() => setShowDeleteConfirm(false)}
                  className="px-4 py-2 text-foreground hover:bg-muted rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={confirmDelete}
                  className="px-4 py-2 bg-destructive text-destructive-foreground rounded-lg hover:bg-destructive/90 transition-colors"
                >
                  Delete
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
