import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Plus, 
  Search, 
  Eye, 
  Download, 
  Send, 
  CheckCircle, 
  XCircle,
  Clock,
  FileText,
  Printer,
  X
} from 'lucide-react';
import type { Invoice } from '../types';
import { formatCurrency, formatDate, getStatusColor } from '../lib/utils';

// Mock data
const mockInvoices: Invoice[] = [
  {
    id: '1',
    invoiceNumber: 'INV-001-ABC',
    customerId: '1',
    customerName: 'John Doe',
    planId: '1',
    planName: 'Premium 10Mbps',
    amount: 2500,
    tax: 0,
    total: 2500,
    status: 'paid',
    issueDate: '2024-06-01',
    dueDate: '2024-06-15',
    paidDate: '2024-06-10',
    paymentMethod: 'mpesa',
    mpesaTransactionId: 'MPESA123456',
  },
  {
    id: '2',
    invoiceNumber: 'INV-002-DEF',
    customerId: '2',
    customerName: 'Jane Smith',
    planId: '2',
    planName: 'Basic 5Mbps',
    amount: 1500,
    tax: 0,
    total: 1500,
    status: 'unpaid',
    issueDate: '2024-06-01',
    dueDate: '2024-06-15',
  },
  {
    id: '3',
    invoiceNumber: 'INV-003-GHI',
    customerId: '3',
    customerName: 'Mike Johnson',
    planId: '3',
    planName: 'Enterprise 20Mbps',
    amount: 5000,
    tax: 0,
    total: 5000,
    status: 'overdue',
    issueDate: '2024-05-01',
    dueDate: '2024-05-15',
  },
  {
    id: '4',
    invoiceNumber: 'INV-004-JKL',
    customerId: '4',
    customerName: 'Sarah Williams',
    planId: '2',
    planName: 'Basic 5Mbps',
    amount: 1500,
    tax: 0,
    total: 1500,
    status: 'paid',
    issueDate: '2024-06-01',
    dueDate: '2024-06-15',
    paidDate: '2024-06-05',
    paymentMethod: 'cash',
  },
  {
    id: '5',
    invoiceNumber: 'INV-005-MNO',
    customerId: '5',
    customerName: 'David Brown',
    planId: '1',
    planName: 'Premium 10Mbps',
    amount: 2500,
    tax: 0,
    total: 2500,
    status: 'unpaid',
    issueDate: '2024-06-01',
    dueDate: '2024-06-15',
  },
];

export default function Invoices() {
  const [invoices] = useState<Invoice[]>(mockInvoices);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [showViewModal, setShowViewModal] = useState(false);
  const [_showCreateModal, _setShowCreateModal] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);

  const filteredInvoices = invoices.filter(invoice => {
    const matchesSearch = 
      invoice.invoiceNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      invoice.customerName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      invoice.mpesaTransactionId?.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = filterStatus === 'all' || invoice.status === filterStatus;
    
    return matchesSearch && matchesStatus;
  });

  const handleView = (invoice: Invoice) => {
    setSelectedInvoice(invoice);
    setShowViewModal(true);
  };

  const getStatusIcon = (status: Invoice['status']) => {
    switch (status) {
      case 'paid':
        return <CheckCircle className="w-4 h-4 text-success" />;
      case 'unpaid':
        return <Clock className="w-4 h-4 text-warning" />;
      case 'overdue':
        return <XCircle className="w-4 h-4 text-destructive" />;
      default:
        return <FileText className="w-4 h-4 text-muted-foreground" />;
    }
  };

  const stats = {
    total: invoices.length,
    paid: invoices.filter(i => i.status === 'paid').length,
    unpaid: invoices.filter(i => i.status === 'unpaid').length,
    overdue: invoices.filter(i => i.status === 'overdue').length,
    totalAmount: invoices.reduce((sum, i) => sum + i.total, 0),
    paidAmount: invoices.filter(i => i.status === 'paid').reduce((sum, i) => sum + i.total, 0),
    unpaidAmount: invoices.filter(i => i.status !== 'paid').reduce((sum, i) => sum + i.total, 0),
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Invoices</h2>
          <p className="text-muted-foreground">Manage customer billing and payments</p>
        </div>
        <button
          onClick={() => {/* Create invoice modal to be implemented */}}
          className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
        >
          <Plus className="w-4 h-4" />
          Create Invoice
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="glass rounded-xl p-4">
          <p className="text-sm text-muted-foreground">Total Invoices</p>
          <p className="text-2xl font-bold text-foreground">{stats.total}</p>
          <p className="text-sm text-muted-foreground">{formatCurrency(stats.totalAmount)}</p>
        </div>
        <div className="glass rounded-xl p-4">
          <p className="text-sm text-muted-foreground">Paid</p>
          <p className="text-2xl font-bold text-success">{stats.paid}</p>
          <p className="text-sm text-success">{formatCurrency(stats.paidAmount)}</p>
        </div>
        <div className="glass rounded-xl p-4">
          <p className="text-sm text-muted-foreground">Unpaid</p>
          <p className="text-2xl font-bold text-warning">{stats.unpaid}</p>
          <p className="text-sm text-warning">{formatCurrency(stats.unpaidAmount)}</p>
        </div>
        <div className="glass rounded-xl p-4">
          <p className="text-sm text-muted-foreground">Overdue</p>
          <p className="text-2xl font-bold text-destructive">{stats.overdue}</p>
          <p className="text-sm text-destructive">
            {formatCurrency(invoices.filter(i => i.status === 'overdue').reduce((sum, i) => sum + i.total, 0))}
          </p>
        </div>
      </div>

      {/* Filters */}
      <div className="glass rounded-xl p-4">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search invoices..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-muted border border-border rounded-lg text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
            />
          </div>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-4 py-2 bg-muted border border-border rounded-lg text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
          >
            <option value="all">All Status</option>
            <option value="paid">Paid</option>
            <option value="unpaid">Unpaid</option>
            <option value="overdue">Overdue</option>
            <option value="cancelled">Cancelled</option>
          </select>
        </div>
      </div>

      {/* Invoices Table */}
      <div className="glass rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border bg-muted/50">
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Invoice #</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Customer</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Plan</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Amount</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Status</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Due Date</th>
                <th className="px-4 py-3 text-right text-sm font-medium text-muted-foreground">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredInvoices.map((invoice, index) => (
                <motion.tr
                  key={invoice.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="border-b border-border last:border-b-0 hover:bg-muted/30 transition-colors"
                >
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <FileText className="w-4 h-4 text-primary" />
                      <span className="font-medium text-foreground">{invoice.invoiceNumber}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className="text-sm text-foreground">{invoice.customerName}</span>
                  </td>
                  <td className="px-4 py-3">
                    <span className="text-sm text-foreground">{invoice.planName}</span>
                  </td>
                  <td className="px-4 py-3">
                    <span className="text-sm font-medium text-foreground">{formatCurrency(invoice.total)}</span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      {getStatusIcon(invoice.status)}
                      <span className={`px-2 py-1 text-xs rounded-full border ${getStatusColor(invoice.status)}`}>
                        {invoice.status}
                      </span>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`text-sm ${
                      invoice.status === 'overdue' ? 'text-destructive' : 'text-foreground'
                    }`}>
                      {formatDate(invoice.dueDate)}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => handleView(invoice)}
                        className="p-2 hover:bg-muted rounded-lg text-muted-foreground hover:text-foreground transition-colors"
                        title="View"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                      <button
                        className="p-2 hover:bg-muted rounded-lg text-muted-foreground hover:text-foreground transition-colors"
                        title="Download"
                      >
                        <Download className="w-4 h-4" />
                      </button>
                      {invoice.status !== 'paid' && (
                        <button
                          className="p-2 hover:bg-muted rounded-lg text-muted-foreground hover:text-foreground transition-colors"
                          title="Send Reminder"
                        >
                          <Send className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
        {filteredInvoices.length === 0 && (
          <div className="p-8 text-center text-muted-foreground">
            No invoices found matching your criteria.
          </div>
        )}
      </div>

      {/* View Invoice Modal */}
      <AnimatePresence>
        {showViewModal && selectedInvoice && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
            onClick={() => setShowViewModal(false)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="glass rounded-xl p-6 max-w-2xl w-full max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center">
                    <FileText className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-foreground">{selectedInvoice.invoiceNumber}</h3>
                    <p className="text-sm text-muted-foreground">Issued: {formatDate(selectedInvoice.issueDate)}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button className="p-2 hover:bg-muted rounded-lg text-muted-foreground hover:text-foreground transition-colors">
                    <Printer className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => setShowViewModal(false)}
                    className="p-2 hover:bg-muted rounded-lg transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>

              <div className="space-y-6">
                {/* Status Badge */}
                <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                  <span className="text-sm text-muted-foreground">Status</span>
                  <span className={`px-3 py-1 text-sm rounded-full border ${getStatusColor(selectedInvoice.status)}`}>
                    {selectedInvoice.status.toUpperCase()}
                  </span>
                </div>

                {/* Customer Info */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Billed To</p>
                    <p className="font-medium text-foreground">{selectedInvoice.customerName}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Service Plan</p>
                    <p className="font-medium text-foreground">{selectedInvoice.planName}</p>
                  </div>
                </div>

                {/* Invoice Details */}
                <div className="border-t border-border pt-4">
                  <table className="w-full">
                    <tbody>
                      <tr>
                        <td className="py-2 text-sm text-muted-foreground">Subtotal</td>
                        <td className="py-2 text-right text-sm text-foreground">{formatCurrency(selectedInvoice.amount)}</td>
                      </tr>
                      <tr>
                        <td className="py-2 text-sm text-muted-foreground">Tax</td>
                        <td className="py-2 text-right text-sm text-foreground">{formatCurrency(selectedInvoice.tax)}</td>
                      </tr>
                      <tr className="border-t border-border">
                        <td className="py-3 font-medium text-foreground">Total</td>
                        <td className="py-3 text-right font-bold text-lg text-foreground">{formatCurrency(selectedInvoice.total)}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                {/* Payment Info */}
                {selectedInvoice.status === 'paid' && (
                  <div className="border-t border-border pt-4">
                    <p className="text-sm font-medium text-foreground mb-2">Payment Information</p>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm text-muted-foreground">Payment Method</p>
                        <p className="text-sm text-foreground capitalize">{selectedInvoice.paymentMethod}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Paid Date</p>
                        <p className="text-sm text-foreground">{selectedInvoice.paidDate ? formatDate(selectedInvoice.paidDate) : 'N/A'}</p>
                      </div>
                      {selectedInvoice.mpesaTransactionId && (
                        <div className="col-span-2">
                          <p className="text-sm text-muted-foreground">M-Pesa Transaction ID</p>
                          <p className="text-sm text-foreground">{selectedInvoice.mpesaTransactionId}</p>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Actions */}
                <div className="flex justify-end gap-3 pt-4">
                  <button
                    onClick={() => setShowViewModal(false)}
                    className="px-4 py-2 text-foreground hover:bg-muted rounded-lg transition-colors"
                  >
                    Close
                  </button>
                  {selectedInvoice.status !== 'paid' && (
                    <button className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors">
                      Mark as Paid
                    </button>
                  )}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
