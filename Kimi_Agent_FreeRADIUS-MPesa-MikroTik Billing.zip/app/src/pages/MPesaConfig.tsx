import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Smartphone, 
  Key, 
  Shield, 
  Globe, 
  CheckCircle, 
  XCircle, 
  RefreshCw,
  Save,
  Eye,
  EyeOff,
  AlertTriangle,
} from 'lucide-react';
import type { MPesaConfig } from '../types';

// Mock data
const mockConfig: MPesaConfig = {
  id: '1',
  consumerKey: 'your_consumer_key_here',
  consumerSecret: 'your_consumer_secret_here',
  shortCode: '174379',
  passkey: 'bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919',
  environment: 'sandbox',
  callbackUrl: 'https://yourdomain.com/api/mpesa/callback',
  timeoutUrl: 'https://yourdomain.com/api/mpesa/timeout',
  resultUrl: 'https://yourdomain.com/api/mpesa/result',
  isActive: true,
};

export default function MPesaConfigPage() {
  const [config, setConfig] = useState<MPesaConfig>(mockConfig);
  const [showSecrets, setShowSecrets] = useState({
    consumerKey: false,
    consumerSecret: false,
    passkey: false,
  });
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<'success' | 'error' | null>(null);
  const [hasChanges, setHasChanges] = useState(false);

  const handleChange = (field: keyof MPesaConfig, value: string | boolean) => {
    setConfig(prev => ({ ...prev, [field]: value }));
    setHasChanges(true);
  };

  const handleSave = () => {
    // Simulate saving
    setTimeout(() => {
      setHasChanges(false);
    }, 500);
  };

  const handleTest = async () => {
    setIsTesting(true);
    setTestResult(null);
    
    // Simulate API test
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setIsTesting(false);
    setTestResult('success');
  };

  const toggleSecretVisibility = (field: keyof typeof showSecrets) => {
    setShowSecrets(prev => ({ ...prev, [field]: !prev[field] }));
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground">M-Pesa Configuration</h2>
          <p className="text-muted-foreground">Configure M-Pesa Daraja API integration</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={handleTest}
            disabled={isTesting}
            className="flex items-center gap-2 px-4 py-2 bg-muted text-foreground rounded-lg hover:bg-muted/80 transition-colors disabled:opacity-50"
          >
            {isTesting ? (
              <RefreshCw className="w-4 h-4 animate-spin" />
            ) : (
              <CheckCircle className="w-4 h-4" />
            )}
            Test Connection
          </button>
          <button
            onClick={handleSave}
            disabled={!hasChanges}
            className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors disabled:opacity-50"
          >
            <Save className="w-4 h-4" />
            Save Changes
          </button>
        </div>
      </div>

      {/* Test Result */}
      <AnimatePresence>
        {testResult && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className={`glass rounded-xl p-4 ${
              testResult === 'success' ? 'border-success/30' : 'border-destructive/30'
            }`}
          >
            <div className="flex items-center gap-3">
              {testResult === 'success' ? (
                <>
                  <CheckCircle className="w-5 h-5 text-success" />
                  <div>
                    <p className="font-medium text-success">Connection Successful</p>
                    <p className="text-sm text-muted-foreground">M-Pesa API is configured correctly and responding.</p>
                  </div>
                </>
              ) : (
                <>
                  <XCircle className="w-5 h-5 text-destructive" />
                  <div>
                    <p className="font-medium text-destructive">Connection Failed</p>
                    <p className="text-sm text-muted-foreground">Please check your credentials and try again.</p>
                  </div>
                </>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Configuration Form */}
      <div className="glass rounded-xl p-6 space-y-6">
        {/* Environment */}
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Environment</label>
          <div className="flex gap-4">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="radio"
                name="environment"
                checked={config.environment === 'sandbox'}
                onChange={() => handleChange('environment', 'sandbox')}
                className="w-4 h-4 text-primary"
              />
              <span className="text-foreground">Sandbox (Test)</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="radio"
                name="environment"
                checked={config.environment === 'production'}
                onChange={() => handleChange('environment', 'production')}
                className="w-4 h-4 text-primary"
              />
              <span className="text-foreground">Production</span>
            </label>
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            Use Sandbox for testing. Switch to Production for live transactions.
          </p>
        </div>

        {/* API Credentials */}
        <div className="border-t border-border pt-6">
          <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
            <Key className="w-5 h-5 text-primary" />
            API Credentials
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-1">Consumer Key</label>
              <div className="relative">
                <input
                  type={showSecrets.consumerKey ? 'text' : 'password'}
                  value={config.consumerKey}
                  onChange={(e) => handleChange('consumerKey', e.target.value)}
                  className="w-full pr-10 px-4 py-2 bg-muted border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                />
                <button
                  type="button"
                  onClick={() => toggleSecretVisibility('consumerKey')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  {showSecrets.consumerKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-foreground mb-1">Consumer Secret</label>
              <div className="relative">
                <input
                  type={showSecrets.consumerSecret ? 'text' : 'password'}
                  value={config.consumerSecret}
                  onChange={(e) => handleChange('consumerSecret', e.target.value)}
                  className="w-full pr-10 px-4 py-2 bg-muted border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                />
                <button
                  type="button"
                  onClick={() => toggleSecretVisibility('consumerSecret')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  {showSecrets.consumerSecret ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Shortcode & Passkey */}
        <div className="border-t border-border pt-6">
          <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
            <Shield className="w-5 h-5 text-secondary" />
            Business Details
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-1">Shortcode</label>
              <input
                type="text"
                value={config.shortCode}
                onChange={(e) => handleChange('shortCode', e.target.value)}
                className="w-full px-4 py-2 bg-muted border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
              />
              <p className="text-xs text-muted-foreground mt-1">Your M-Pesa business shortcode</p>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-foreground mb-1">Passkey</label>
              <div className="relative">
                <input
                  type={showSecrets.passkey ? 'text' : 'password'}
                  value={config.passkey}
                  onChange={(e) => handleChange('passkey', e.target.value)}
                  className="w-full pr-10 px-4 py-2 bg-muted border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                />
                <button
                  type="button"
                  onClick={() => toggleSecretVisibility('passkey')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  {showSecrets.passkey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              <p className="text-xs text-muted-foreground mt-1">Lipa na M-Pesa online passkey</p>
            </div>
          </div>
        </div>

        {/* Callback URLs */}
        <div className="border-t border-border pt-6">
          <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
            <Globe className="w-5 h-5 text-success" />
            Callback URLs
          </h3>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-1">Callback URL</label>
              <input
                type="url"
                value={config.callbackUrl}
                onChange={(e) => handleChange('callbackUrl', e.target.value)}
                className="w-full px-4 py-2 bg-muted border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
              />
              <p className="text-xs text-muted-foreground mt-1">URL to receive payment notifications</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-foreground mb-1">Timeout URL</label>
                <input
                  type="url"
                  value={config.timeoutUrl}
                  onChange={(e) => handleChange('timeoutUrl', e.target.value)}
                  className="w-full px-4 py-2 bg-muted border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-foreground mb-1">Result URL</label>
                <input
                  type="url"
                  value={config.resultUrl}
                  onChange={(e) => handleChange('resultUrl', e.target.value)}
                  className="w-full px-4 py-2 bg-muted border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Status */}
        <div className="border-t border-border pt-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold text-foreground flex items-center gap-2">
                <Smartphone className="w-5 h-5 text-warning" />
                Integration Status
              </h3>
              <p className="text-sm text-muted-foreground">Enable or disable M-Pesa payments</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={config.isActive}
                onChange={(e) => handleChange('isActive', e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-14 h-7 bg-muted peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary/30 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[4px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-6 after:w-6 after:transition-all peer-checked:bg-primary"></div>
            </label>
          </div>
        </div>
      </div>

      {/* Instructions */}
      <div className="glass rounded-xl p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-warning" />
          Setup Instructions
        </h3>
        <div className="space-y-3 text-sm text-muted-foreground">
          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
              <span className="text-xs text-primary font-medium">1</span>
            </div>
            <p>Register for an M-Pesa Daraja API account at <a href="https://developer.safaricom.co.ke" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">developer.safaricom.co.ke</a></p>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
              <span className="text-xs text-primary font-medium">2</span>
            </div>
            <p>Create a new app and obtain your Consumer Key and Consumer Secret</p>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
              <span className="text-xs text-primary font-medium">3</span>
            </div>
            <p>Get your Business Shortcode and Passkey from your M-Pesa provider</p>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
              <span className="text-xs text-primary font-medium">4</span>
            </div>
            <p>Configure the callback URLs to point to your server endpoints</p>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
              <span className="text-xs text-primary font-medium">5</span>
            </div>
            <p>Test the integration in Sandbox mode before switching to Production</p>
          </div>
        </div>
      </div>
    </div>
  );
}
