import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  DatabaseBackup,
  Download,
  Upload,
  FileSpreadsheet,
  FileJson,
  FileText,
  History,
  CheckCircle,
  Clock,
  Filter,
  Search,
  MoreVertical,
  Trash2,
  AlertTriangle,
  HardDrive,
  Cloud,
  Shield,
  Zap,
  Database,
  Users,
  CreditCard,
  Router
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer
} from 'recharts';

// Import/Export History
const dataOperations = [
  {
    id: '1',
    type: 'export',
    name: 'Customer Export - January 2024',
    format: 'csv',
    records: 1847,
    size: '2.4 MB',
    status: 'completed',
    createdBy: 'Admin',
    createdAt: '2024-01-29 14:30',
    expiresAt: '2024-02-05 14:30'
  },
  {
    id: '2',
    type: 'import',
    name: 'Bulk Customer Import',
    format: 'xlsx',
    records: 156,
    size: '850 KB',
    status: 'completed',
    createdBy: 'Manager',
    createdAt: '2024-01-29 11:15',
    expiresAt: null
  },
  {
    id: '3',
    type: 'export',
    name: 'Payment Report Q4 2023',
    format: 'xlsx',
    records: 5420,
    size: '4.2 MB',
    status: 'completed',
    createdBy: 'Admin',
    createdAt: '2024-01-28 16:45',
    expiresAt: '2024-02-04 16:45'
  },
  {
    id: '4',
    type: 'import',
    name: 'Router Configuration Import',
    format: 'json',
    records: 12,
    size: '45 KB',
    status: 'failed',
    createdBy: 'Admin',
    createdAt: '2024-01-28 10:20',
    expiresAt: null
  },
  {
    id: '5',
    type: 'export',
    name: 'Invoice Backup',
    format: 'csv',
    records: 3200,
    size: '5.8 MB',
    status: 'processing',
    createdBy: 'System',
    createdAt: '2024-01-29 15:00',
    expiresAt: '2024-02-05 15:00'
  }
];

// Backup Schedule
const backupSchedules = [
  {
    id: '1',
    name: 'Daily Database Backup',
    type: 'database',
    frequency: 'daily',
    time: '02:00 AM',
    retention: '30 days',
    lastRun: '2024-01-29 02:00',
    nextRun: '2024-01-30 02:00',
    status: 'active',
    destination: 'Cloud Storage'
  },
  {
    id: '2',
    name: 'Weekly Full Backup',
    type: 'full',
    frequency: 'weekly',
    time: 'Sunday 03:00 AM',
    retention: '12 weeks',
    lastRun: '2024-01-28 03:00',
    nextRun: '2024-02-04 03:00',
    status: 'active',
    destination: 'Local + Cloud'
  },
  {
    id: '3',
    name: 'Monthly Archive',
    type: 'archive',
    frequency: 'monthly',
    time: '1st 01:00 AM',
    retention: '2 years',
    lastRun: '2024-01-01 01:00',
    nextRun: '2024-02-01 01:00',
    status: 'active',
    destination: 'Cold Storage'
  }
];

// Storage Stats
const storageStats = {
  totalUsed: '45.2 GB',
  totalCapacity: '100 GB',
  percentage: 45,
  database: '12.5 GB',
  files: '28.3 GB',
  backups: '4.4 GB'
};

// Data Categories
const dataCategories = [
  { id: 'customers', name: 'Customers', records: 1847, size: '2.4 GB', icon: Users },
  { id: 'invoices', name: 'Invoices', records: 12450, size: '8.2 GB', icon: FileText },
  { id: 'payments', name: 'Payments', records: 9876, size: '1.8 GB', icon: CreditCard },
  { id: 'routers', name: 'Routers', records: 45, size: '156 MB', icon: Router },
  { id: 'sessions', name: 'PPPoE Sessions', records: 1847, size: '4.2 GB', icon: Database },
  { id: 'logs', name: 'System Logs', records: 2450000, size: '18.5 GB', icon: History },
];

// Import Templates
const importTemplates = [
  { id: '1', name: 'Customer Import', format: 'CSV/Excel', fields: 12, downloads: 456 },
  { id: '2', name: 'Router Import', format: 'JSON', fields: 8, downloads: 123 },
  { id: '3', name: 'Plan Import', format: 'CSV', fields: 6, downloads: 89 },
  { id: '4', name: 'Voucher Import', format: 'CSV', fields: 5, downloads: 234 },
];

// Storage Trend
const storageTrend = [
  { date: 'Jan 1', used: 38 },
  { date: 'Jan 5', used: 39 },
  { date: 'Jan 10', used: 40 },
  { date: 'Jan 15', used: 41 },
  { date: 'Jan 20', used: 43 },
  { date: 'Jan 25', used: 44 },
  { date: 'Jan 29', used: 45 },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 }
};

export default function DataCenter() {
  const [activeTab, setActiveTab] = useState('overview');
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [showBackupDialog, setShowBackupDialog] = useState(false);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return <Badge className="bg-green-100 text-green-700">Completed</Badge>;
      case 'failed':
        return <Badge className="bg-red-100 text-red-700">Failed</Badge>;
      case 'processing':
        return <Badge className="bg-blue-100 text-blue-700">Processing</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const getFileIcon = (format: string) => {
    switch (format) {
      case 'csv':
        return <FileSpreadsheet className="w-5 h-5 text-green-500" />;
      case 'xlsx':
        return <FileSpreadsheet className="w-5 h-5 text-blue-500" />;
      case 'json':
        return <FileJson className="w-5 h-5 text-yellow-500" />;
      default:
        return <FileText className="w-5 h-5 text-gray-500" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <DatabaseBackup className="w-8 h-8 text-primary" />
            Data Center
          </h1>
          <p className="text-muted-foreground mt-1">
            Import, export, and manage your data
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={() => setShowBackupDialog(true)}>
            <Database className="w-4 h-4 mr-2" />
            Backup Now
          </Button>
          <Button onClick={() => setShowImportDialog(true)}>
            <Upload className="w-4 h-4 mr-2" />
            Import Data
          </Button>
        </div>
      </div>

      {/* Storage Overview */}
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="grid grid-cols-1 lg:grid-cols-3 gap-4"
      >
        <motion.div variants={itemVariants} className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <HardDrive className="w-5 h-5" />
                Storage Usage
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between mb-4">
                <div>
                  <div className="text-3xl font-bold">{storageStats.totalUsed}</div>
                  <div className="text-sm text-muted-foreground">
                    of {storageStats.totalCapacity} used ({storageStats.percentage}%)
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-sm text-muted-foreground">Available</div>
                  <div className="text-xl font-semibold">
                    {(100 - parseFloat(storageStats.totalUsed)).toFixed(1)} GB
                  </div>
                </div>
              </div>
              <Progress value={storageStats.percentage} className="h-3 mb-6" />
              <div className="grid grid-cols-3 gap-4">
                <div className="p-4 bg-blue-50 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Database className="w-4 h-4 text-blue-600" />
                    <span className="text-sm text-blue-700">Database</span>
                  </div>
                  <div className="text-xl font-bold text-blue-700">{storageStats.database}</div>
                </div>
                <div className="p-4 bg-green-50 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <FileText className="w-4 h-4 text-green-600" />
                    <span className="text-sm text-green-700">Files</span>
                  </div>
                  <div className="text-xl font-bold text-green-700">{storageStats.files}</div>
                </div>
                <div className="p-4 bg-purple-50 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <DatabaseBackup className="w-4 h-4 text-purple-600" />
                    <span className="text-sm text-purple-700">Backups</span>
                  </div>
                  <div className="text-xl font-bold text-purple-700">{storageStats.backups}</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card className="h-full">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Cloud className="w-5 h-5" />
                Backup Status
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                <div className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <div>
                    <div className="font-medium text-green-700">Last Backup</div>
                    <div className="text-sm text-green-600">Today at 02:00 AM</div>
                  </div>
                </div>
              </div>
              <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                <div className="flex items-center gap-3">
                  <Clock className="w-5 h-5 text-blue-600" />
                  <div>
                    <div className="font-medium text-blue-700">Next Backup</div>
                    <div className="text-sm text-blue-600">Tomorrow at 02:00 AM</div>
                  </div>
                </div>
              </div>
              <div className="flex items-center justify-between p-3 bg-purple-50 rounded-lg">
                <div className="flex items-center gap-3">
                  <Shield className="w-5 h-5 text-purple-600" />
                  <div>
                    <div className="font-medium text-purple-700">Backup Health</div>
                    <div className="text-sm text-purple-600">All systems operational</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>

      {/* Main Content Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-5 lg:w-auto">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="operations">Operations</TabsTrigger>
          <TabsTrigger value="backups">Backups</TabsTrigger>
          <TabsTrigger value="categories">Data Categories</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Storage Trend */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <History className="w-5 h-5" />
                  Storage Growth
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={storageTrend}>
                      <defs>
                        <linearGradient id="storageGradient" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3}/>
                          <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Area
                        type="monotone"
                        dataKey="used"
                        stroke="#8b5cf6"
                        fillOpacity={1}
                        fill="url(#storageGradient)"
                        name="Usage %"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Recent Operations */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="w-5 h-5" />
                  Recent Operations
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {dataOperations.slice(0, 3).map((op) => (
                    <div key={op.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center gap-3">
                        {getFileIcon(op.format)}
                        <div>
                          <div className="font-medium text-sm">{op.name}</div>
                          <div className="text-xs text-muted-foreground">
                            {op.records.toLocaleString()} records • {op.size}
                          </div>
                        </div>
                      </div>
                      {getStatusBadge(op.status)}
                    </div>
                  ))}
                </div>
                <Button variant="outline" className="w-full mt-4" onClick={() => setActiveTab('operations')}>
                  View All Operations
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <Button variant="outline" className="h-auto py-4 flex flex-col items-center gap-2">
                  <Download className="w-6 h-6" />
                  <span>Export Customers</span>
                </Button>
                <Button variant="outline" className="h-auto py-4 flex flex-col items-center gap-2">
                  <Download className="w-6 h-6" />
                  <span>Export Invoices</span>
                </Button>
                <Button variant="outline" className="h-auto py-4 flex flex-col items-center gap-2">
                  <Upload className="w-6 h-6" />
                  <span>Import Data</span>
                </Button>
                <Button variant="outline" className="h-auto py-4 flex flex-col items-center gap-2">
                  <DatabaseBackup className="w-6 h-6" />
                  <span>Full Backup</span>
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="operations" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Import/Export History</CardTitle>
                <div className="flex items-center gap-2">
                  <div className="relative">
                    <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                    <Input placeholder="Search operations..." className="pl-9 w-64" />
                  </div>
                  <Button variant="outline" size="icon">
                    <Filter className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {dataOperations.map((op) => (
                  <div key={op.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center">
                        {getFileIcon(op.format)}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{op.name}</span>
                          <Badge variant={op.type === 'export' ? 'default' : 'secondary'}>
                            {op.type === 'export' ? 'Export' : 'Import'}
                          </Badge>
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {op.records.toLocaleString()} records • {op.size} • {op.createdBy}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {op.createdAt}
                          {op.expiresAt && ` • Expires: ${op.expiresAt}`}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      {getStatusBadge(op.status)}
                      {op.status === 'completed' && (
                        <Button variant="outline" size="sm">
                          <Download className="w-4 h-4 mr-2" />
                          Download
                        </Button>
                      )}
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreVertical className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>View Details</DropdownMenuItem>
                          <DropdownMenuItem>Retry</DropdownMenuItem>
                          <DropdownMenuItem className="text-red-600">
                            <Trash2 className="w-4 h-4 mr-2" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="backups" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Backup Schedules</CardTitle>
                <Button>
                  <Zap className="w-4 h-4 mr-2" />
                  Add Schedule
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {backupSchedules.map((schedule) => (
                  <div key={schedule.id} className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                          schedule.status === 'active' ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-600'
                        }`}>
                          <DatabaseBackup className="w-5 h-5" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-medium">{schedule.name}</span>
                            <Badge variant={schedule.status === 'active' ? 'default' : 'secondary'}>
                              {schedule.status}
                            </Badge>
                          </div>
                          <div className="text-sm text-muted-foreground">
                            {schedule.frequency} at {schedule.time} • Retention: {schedule.retention}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Switch checked={schedule.status === 'active'} />
                        <Button variant="ghost" size="icon">
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div>
                        <div className="text-muted-foreground">Last Run</div>
                        <div className="font-medium">{schedule.lastRun}</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">Next Run</div>
                        <div className="font-medium">{schedule.nextRun}</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">Destination</div>
                        <div className="font-medium">{schedule.destination}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="categories" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Data Categories</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {dataCategories.map((category) => (
                  <div key={category.id} className="p-4 border rounded-lg hover:bg-muted/50 transition-colors">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                        <category.icon className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <div className="font-medium">{category.name}</div>
                        <div className="text-sm text-muted-foreground">{category.size}</div>
                      </div>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">
                        {category.records.toLocaleString()} records
                      </span>
                      <div className="flex gap-2">
                        <Button variant="ghost" size="sm">
                          <Download className="w-4 h-4 mr-1" />
                          Export
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="templates" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Import Templates</CardTitle>
                <Button>
                  <Upload className="w-4 h-4 mr-2" />
                  Create Template
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {importTemplates.map((template) => (
                  <div key={template.id} className="p-4 border rounded-lg">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <div className="font-medium">{template.name}</div>
                        <div className="text-sm text-muted-foreground">
                          {template.format} • {template.fields} fields
                        </div>
                      </div>
                      {getFileIcon(template.format.toLowerCase())}
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">
                        {template.downloads} downloads
                      </span>
                      <Button variant="outline" size="sm">
                        <Download className="w-4 h-4 mr-2" />
                        Download
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Import Dialog */}
      <Dialog open={showImportDialog} onOpenChange={setShowImportDialog}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Import Data</DialogTitle>
            <DialogDescription>
              Upload a file to import data into the system
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="border-2 border-dashed border-muted rounded-lg p-8 text-center">
              <Upload className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
              <p className="text-muted-foreground mb-2">
                Drag and drop your file here, or click to browse
              </p>
              <p className="text-sm text-muted-foreground">
                Supports CSV, Excel, and JSON files up to 50MB
              </p>
              <Button variant="outline" className="mt-4">
                Browse Files
              </Button>
            </div>
            <div>
              <label className="text-sm font-medium">Import Type</label>
              <Select defaultValue="customers">
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="customers">Customers</SelectItem>
                  <SelectItem value="routers">Routers</SelectItem>
                  <SelectItem value="plans">Plans</SelectItem>
                  <SelectItem value="vouchers">Vouchers</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-2">
              <Switch id="validate" />
              <label htmlFor="validate" className="text-sm">
                Validate data before importing
              </label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowImportDialog(false)}>
              Cancel
            </Button>
            <Button onClick={() => setShowImportDialog(false)}>
              Start Import
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Backup Dialog */}
      <Dialog open={showBackupDialog} onOpenChange={setShowBackupDialog}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Create Backup</DialogTitle>
            <DialogDescription>
              Create a manual backup of your data
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <label className="text-sm font-medium">Backup Type</label>
              <Select defaultValue="full">
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="full">Full Backup (All Data)</SelectItem>
                  <SelectItem value="database">Database Only</SelectItem>
                  <SelectItem value="files">Files Only</SelectItem>
                  <SelectItem value="custom">Custom Selection</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium">Destination</label>
              <Select defaultValue="cloud">
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cloud">Cloud Storage</SelectItem>
                  <SelectItem value="local">Local Storage</SelectItem>
                  <SelectItem value="both">Both</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="p-4 bg-yellow-50 rounded-lg flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm text-yellow-700">
                Large backups may take several minutes to complete. You will be notified when the backup is ready.
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowBackupDialog(false)}>
              Cancel
            </Button>
            <Button onClick={() => setShowBackupDialog(false)}>
              <DatabaseBackup className="w-4 h-4 mr-2" />
              Start Backup
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
