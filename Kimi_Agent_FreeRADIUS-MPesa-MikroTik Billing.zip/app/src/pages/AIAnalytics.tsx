import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Brain,
  TrendingUp,
  AlertTriangle,
  Activity,
  Lightbulb,
  Target,
  BarChart3,
  PieChart,
  LineChart,
  Sparkles,
  RefreshCw,
  Download,
  Calendar
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart as RePieChart,
  Pie,
  Cell,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar
} from 'recharts';

// AI Insights Data
const aiInsights = [
  {
    id: '1',
    type: 'prediction',
    title: 'Revenue Forecast',
    description: 'Based on current trends, revenue is projected to increase by 18% next month. Consider expanding capacity in high-growth areas.',
    confidence: 92,
    impact: 'high',
    icon: TrendingUp,
    color: 'green'
  },
  {
    id: '2',
    type: 'anomaly',
    title: 'Unusual Churn Pattern',
    description: 'Premium plan customers in Zone C are churning 3x faster than average. Investigation recommended.',
    confidence: 87,
    impact: 'high',
    icon: AlertTriangle,
    color: 'red'
  },
  {
    id: '3',
    type: 'opportunity',
    title: 'Upsell Opportunity',
    description: '47 customers on Basic plan consistently exceed their data limits. Target for upgrade campaigns.',
    confidence: 95,
    impact: 'medium',
    icon: Target,
    color: 'blue'
  },
  {
    id: '4',
    type: 'optimization',
    title: 'Network Optimization',
    description: 'Peak usage patterns suggest bandwidth reallocation could improve QoS by 23% during 7-9 PM.',
    confidence: 89,
    impact: 'medium',
    icon: Lightbulb,
    color: 'yellow'
  }
];

// Predictive Analytics Data
const revenueForecast = [
  { month: 'Jan', actual: 450000, predicted: 445000 },
  { month: 'Feb', actual: 480000, predicted: 475000 },
  { month: 'Mar', actual: 520000, predicted: 515000 },
  { month: 'Apr', actual: 510000, predicted: 525000 },
  { month: 'May', actual: 580000, predicted: 575000 },
  { month: 'Jun', actual: 620000, predicted: 615000 },
  { month: 'Jul', actual: null, predicted: 680000 },
  { month: 'Aug', actual: null, predicted: 720000 },
  { month: 'Sep', actual: null, predicted: 750000 },
];

// Churn Risk Analysis
const churnRiskData = [
  { name: 'Low Risk', value: 1250, color: '#10b981' },
  { name: 'Medium Risk', value: 320, color: '#f59e0b' },
  { name: 'High Risk', value: 85, color: '#ef4444' },
  { name: 'Critical', value: 28, color: '#7c3aed' },
];

// Customer Segmentation
const segmentationData = [
  { subject: 'Data Usage', A: 120, B: 80, C: 40, fullMark: 150 },
  { subject: 'Payment History', A: 98, B: 90, C: 70, fullMark: 100 },
  { subject: 'Support Tickets', A: 20, B: 50, C: 80, fullMark: 100 },
  { subject: 'Tenure', A: 90, B: 70, C: 30, fullMark: 100 },
  { subject: 'Plan Value', A: 95, B: 60, C: 35, fullMark: 100 },
  { subject: 'Engagement', A: 85, B: 65, C: 45, fullMark: 100 },
];

// Growth Opportunities
const growthOpportunities = [
  {
    segment: 'Power Users',
    potentialRevenue: 125000,
    conversionRate: 34,
    customers: 156,
    action: 'Offer Premium Plans'
  },
  {
    segment: 'At-Risk Premium',
    potentialRevenue: 89000,
    conversionRate: 67,
    customers: 89,
    action: 'Retention Campaign'
  },
  {
    segment: 'Upgrade Candidates',
    potentialRevenue: 156000,
    conversionRate: 45,
    customers: 234,
    action: 'Targeted Upsell'
  },
  {
    segment: 'Win-Back',
    potentialRevenue: 67000,
    conversionRate: 23,
    customers: 178,
    action: 'Special Offers'
  }
];

// Anomaly Detection
const anomalies = [
  {
    id: '1',
    metric: 'Data Usage',
    expected: '450 GB/day',
    actual: '1,234 GB/day',
    deviation: '+174%',
    zone: 'Zone A - Tower 3',
    timestamp: '2024-01-29 14:30',
    status: 'investigating'
  },
  {
    id: '2',
    metric: 'Failed Payments',
    expected: '2-5%',
    actual: '18%',
    deviation: '+260%',
    zone: 'All Zones',
    timestamp: '2024-01-29 09:15',
    status: 'resolved'
  },
  {
    id: '3',
    metric: 'New Signups',
    expected: '25-30/day',
    actual: '3/day',
    deviation: '-88%',
    zone: 'Zone C',
    timestamp: '2024-01-28 16:00',
    status: 'open'
  }
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 }
};

export default function AIAnalytics() {
  const [timeRange, setTimeRange] = useState('30d');
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const handleRefresh = () => {
    setIsAnalyzing(true);
    setTimeout(() => setIsAnalyzing(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Brain className="w-8 h-8 text-primary" />
            AI Analytics
          </h1>
          <p className="text-muted-foreground mt-1">
            Machine learning insights and predictive analytics
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-32">
              <Calendar className="w-4 h-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7d">7 Days</SelectItem>
              <SelectItem value="30d">30 Days</SelectItem>
              <SelectItem value="90d">90 Days</SelectItem>
              <SelectItem value="1y">1 Year</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" onClick={handleRefresh} disabled={isAnalyzing}>
            <RefreshCw className={`w-4 h-4 mr-2 ${isAnalyzing ? 'animate-spin' : ''}`} />
            Analyze
          </Button>
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      {/* AI Status Banner */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="relative overflow-hidden rounded-xl bg-gradient-to-r from-violet-600 via-purple-600 to-indigo-600 p-6 text-white"
      >
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl" />
        <div className="relative flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-white/20 flex items-center justify-center">
              <Sparkles className="w-8 h-8" />
            </div>
            <div>
              <h2 className="text-2xl font-bold">AI Model Active</h2>
              <p className="text-white/80">Processing 1.2M data points • Last trained: 2 hours ago</p>
              <div className="flex items-center gap-4 mt-2">
                <Badge variant="secondary" className="bg-white/20 text-white">
                  Accuracy: 94.7%
                </Badge>
                <Badge variant="secondary" className="bg-white/20 text-white">
                  847 Predictions Today
                </Badge>
              </div>
            </div>
          </div>
          <div className="text-right hidden md:block">
            <div className="text-3xl font-bold">KES 2.4M</div>
            <div className="text-white/80">AI-Identified Opportunities</div>
          </div>
        </div>
      </motion.div>

      {/* AI Insights */}
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="grid grid-cols-1 md:grid-cols-2 gap-4"
      >
        {aiInsights.map((insight) => (
          <motion.div key={insight.id} variants={itemVariants}>
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-5">
                <div className="flex items-start gap-4">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                    insight.color === 'green' ? 'bg-green-100 text-green-600' :
                    insight.color === 'red' ? 'bg-red-100 text-red-600' :
                    insight.color === 'blue' ? 'bg-blue-100 text-blue-600' :
                    'bg-yellow-100 text-yellow-600'
                  }`}>
                    <insight.icon className="w-6 h-6" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-semibold">{insight.title}</h3>
                      <Badge variant={insight.impact === 'high' ? 'destructive' : 'secondary'}>
                        {insight.impact}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-3">{insight.description}</p>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-muted-foreground">AI Confidence:</span>
                      <Progress value={insight.confidence} className="w-24 h-2" />
                      <span className="text-xs font-medium">{insight.confidence}%</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </motion.div>

      {/* Main Analytics Tabs */}
      <Tabs defaultValue="forecast" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4 lg:w-auto">
          <TabsTrigger value="forecast">Revenue Forecast</TabsTrigger>
          <TabsTrigger value="churn">Churn Analysis</TabsTrigger>
          <TabsTrigger value="segments">Customer Segments</TabsTrigger>
          <TabsTrigger value="anomalies">Anomalies</TabsTrigger>
        </TabsList>

        <TabsContent value="forecast" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <LineChart className="w-5 h-5" />
                AI Revenue Forecast
              </CardTitle>
              <CardDescription>
                Machine learning predictions based on historical data and market trends
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={revenueForecast}>
                    <defs>
                      <linearGradient id="colorActual" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                      </linearGradient>
                      <linearGradient id="colorPredicted" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip formatter={(value) => `KES ${Number(value).toLocaleString()}`} />
                    <Area
                      type="monotone"
                      dataKey="actual"
                      stroke="#10b981"
                      fillOpacity={1}
                      fill="url(#colorActual)"
                      name="Actual Revenue"
                    />
                    <Area
                      type="monotone"
                      dataKey="predicted"
                      stroke="#8b5cf6"
                      strokeDasharray="5 5"
                      fillOpacity={1}
                      fill="url(#colorPredicted)"
                      name="AI Prediction"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
              <div className="grid grid-cols-3 gap-4 mt-6">
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">94.2%</div>
                  <div className="text-sm text-green-700">Prediction Accuracy</div>
                </div>
                <div className="text-center p-4 bg-purple-50 rounded-lg">
                  <div className="text-2xl font-bold text-purple-600">KES 750K</div>
                  <div className="text-sm text-purple-700">Projected Sept Revenue</div>
                </div>
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">+18%</div>
                  <div className="text-sm text-blue-700">Growth Forecast</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="churn" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <PieChart className="w-5 h-5" />
                  Churn Risk Distribution
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <RePieChart>
                      <Pie
                        data={churnRiskData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={100}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {churnRiskData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </RePieChart>
                  </ResponsiveContainer>
                </div>
                <div className="grid grid-cols-2 gap-2 mt-4">
                  {churnRiskData.map((item) => (
                    <div key={item.name} className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                      <span className="text-sm">{item.name}: {item.value}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Growth Opportunities</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {growthOpportunities.map((opp) => (
                  <div key={opp.segment} className="p-4 border rounded-lg hover:bg-muted/50 transition-colors">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium">{opp.segment}</span>
                      <Badge>{opp.action}</Badge>
                    </div>
                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div>
                        <div className="text-muted-foreground">Potential</div>
                        <div className="font-semibold">KES {opp.potentialRevenue.toLocaleString()}</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">Conversion</div>
                        <div className="font-semibold">{opp.conversionRate}%</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">Customers</div>
                        <div className="font-semibold">{opp.customers}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="segments" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5" />
                Customer Segmentation Analysis
              </CardTitle>
              <CardDescription>
                AI-powered clustering based on behavior patterns
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <RadarChart cx="50%" cy="50%" outerRadius="80%" data={segmentationData}>
                    <PolarGrid />
                    <PolarAngleAxis dataKey="subject" />
                    <PolarRadiusAxis />
                    <Radar
                      name="Premium Customers"
                      dataKey="A"
                      stroke="#8b5cf6"
                      fill="#8b5cf6"
                      fillOpacity={0.3}
                    />
                    <Radar
                      name="Standard Customers"
                      dataKey="B"
                      stroke="#10b981"
                      fill="#10b981"
                      fillOpacity={0.3}
                    />
                    <Radar
                      name="Basic Customers"
                      dataKey="C"
                      stroke="#f59e0b"
                      fill="#f59e0b"
                      fillOpacity={0.3}
                    />
                    <Tooltip />
                  </RadarChart>
                </ResponsiveContainer>
              </div>
              <div className="flex justify-center gap-6 mt-4">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded bg-violet-500/30 border border-violet-500" />
                  <span className="text-sm">Premium (245 customers)</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded bg-green-500/30 border border-green-500" />
                  <span className="text-sm">Standard (678 customers)</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded bg-yellow-500/30 border border-yellow-500" />
                  <span className="text-sm">Basic (892 customers)</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="anomalies" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5" />
                Detected Anomalies
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {anomalies.map((anomaly) => (
                  <div key={anomaly.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-start gap-4">
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                        anomaly.status === 'open' ? 'bg-red-100 text-red-600' :
                        anomaly.status === 'investigating' ? 'bg-yellow-100 text-yellow-600' :
                        'bg-green-100 text-green-600'
                      }`}>
                        <Activity className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{anomaly.metric}</span>
                          <Badge variant={anomaly.status === 'open' ? 'destructive' : 'secondary'}>
                            {anomaly.status}
                          </Badge>
                        </div>
                        <div className="text-sm text-muted-foreground mt-1">
                          Expected: {anomaly.expected} • Actual: {anomaly.actual}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {anomaly.zone} • {anomaly.timestamp}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className={`text-lg font-bold ${
                        anomaly.deviation.startsWith('+') ? 'text-red-600' : 'text-blue-600'
                      }`}>
                        {anomaly.deviation}
                      </div>
                      <div className="text-sm text-muted-foreground">deviation</div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Quick Stats */}
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="grid grid-cols-2 lg:grid-cols-4 gap-4"
      >
        {[
          { label: 'AI Predictions', value: '847', change: '+12%', icon: Brain },
          { label: 'Accuracy Rate', value: '94.7%', change: '+2.3%', icon: Target },
          { label: 'Anomalies Found', value: '23', change: '-5', icon: AlertTriangle },
          { label: 'Opportunities', value: 'KES 2.4M', change: '+18%', icon: TrendingUp },
        ].map((stat) => (
          <motion.div key={stat.label} variants={itemVariants}>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <stat.icon className="w-5 h-5 text-muted-foreground" />
                  <Badge variant="secondary" className="text-xs">
                    {stat.change}
                  </Badge>
                </div>
                <div className="mt-2">
                  <div className="text-2xl font-bold">{stat.value}</div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </motion.div>
    </div>
  );
}
