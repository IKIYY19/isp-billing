import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Gauge,
  TrendingUp,
  AlertTriangle,
  Download,
  Clock,
  Users,
  Router,
  BarChart3,
  PieChart,
  Activity,
  Zap,
  Settings,
  Filter,
  Search,
  MoreVertical,
  Ban,
  CheckCircle,
  RefreshCw,
  Calendar
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  PieChart as RePieChart,
  Pie,
  Cell,
  ReferenceLine
} from 'recharts';

// Usage Stats
const usageStats = {
  totalBandwidth: '850 Gbps',
  avgUtilization: 67,
  peakUtilization: 89,
  totalDataTransferred: '1.24 PB',
  activeSessions: 1847,
  throttledUsers: 23,
  suspendedUsers: 5
};

// Peak Hours Data
const peakHoursData = [
  { hour: '00:00', usage: 25, capacity: 100 },
  { hour: '02:00', usage: 18, capacity: 100 },
  { hour: '04:00', usage: 15, capacity: 100 },
  { hour: '06:00', usage: 35, capacity: 100 },
  { hour: '08:00', usage: 65, capacity: 100 },
  { hour: '10:00', usage: 55, capacity: 100 },
  { hour: '12:00', usage: 70, capacity: 100 },
  { hour: '14:00', usage: 60, capacity: 100 },
  { hour: '16:00', usage: 75, capacity: 100 },
  { hour: '18:00', usage: 85, capacity: 100 },
  { hour: '20:00', usage: 95, capacity: 100 },
  { hour: '22:00', usage: 70, capacity: 100 },
];

// Top Data Consumers
const topConsumers = [
  {
    id: '1',
    customer: 'ABC Enterprises Ltd',
    plan: 'Business Pro',
    dataLimit: 500,
    dataUsed: 487.5,
    percentage: 97.5,
    status: 'warning',
    lastActive: '2 min ago'
  },
  {
    id: '2',
    customer: 'Tech Solutions Kenya',
    plan: 'Business Unlimited',
    dataLimit: 1000,
    dataUsed: 892.3,
    percentage: 89.2,
    status: 'normal',
    lastActive: '5 min ago'
  },
  {
    id: '3',
    customer: 'Safari Hotel',
    plan: 'Hospitality Pro',
    dataLimit: 750,
    dataUsed: 712.8,
    percentage: 95.0,
    status: 'warning',
    lastActive: '1 min ago'
  },
  {
    id: '4',
    customer: 'Green Valley School',
    plan: 'Education Plus',
    dataLimit: 300,
    dataUsed: 285.6,
    percentage: 95.2,
    status: 'warning',
    lastActive: '15 min ago'
  },
  {
    id: '5',
    customer: 'Metro Cyber Cafe',
    plan: 'Business Basic',
    dataLimit: 200,
    dataUsed: 198.4,
    percentage: 99.2,
    status: 'critical',
    lastActive: 'Just now'
  }
];

// Bandwidth by Plan
const planBandwidthData = [
  { name: 'Basic', value: 15, color: '#3b82f6' },
  { name: 'Standard', value: 35, color: '#10b981' },
  { name: 'Premium', value: 30, color: '#8b5cf6' },
  { name: 'Business', value: 20, color: '#f59e0b' },
];

// FUP Violations
const fupViolations = [
  {
    id: '1',
    customer: 'John Kamau',
    violation: 'Exceeded daily limit (45GB/30GB)',
    action: 'Throttled to 2Mbps',
    timestamp: '2024-01-29 14:30',
    status: 'active'
  },
  {
    id: '2',
    customer: 'Sarah Wanjiku',
    violation: 'Exceeded monthly limit (320GB/250GB)',
    action: 'Throttled to 1Mbps',
    timestamp: '2024-01-29 12:15',
    status: 'active'
  },
  {
    id: '3',
    customer: 'Peter Ochieng',
    violation: 'Repeated FUP violations (5x this month)',
    action: 'Account suspended',
    timestamp: '2024-01-29 10:00',
    status: 'suspended'
  },
  {
    id: '4',
    customer: 'Mary Njeri',
    violation: 'Exceeded daily limit (38GB/30GB)',
    action: 'Throttled to 2Mbps',
    timestamp: '2024-01-28 22:45',
    status: 'lifted'
  }
];

// Usage Trends
const usageTrends = [
  { date: 'Week 1', download: 450, upload: 120 },
  { date: 'Week 2', download: 520, upload: 145 },
  { date: 'Week 3', download: 480, upload: 130 },
  { date: 'Week 4', download: 610, upload: 180 },
];

// Zone Usage
const zoneUsage = [
  { zone: 'Zone A - CBD', usage: 85, capacity: 100, customers: 450 },
  { zone: 'Zone B - Westlands', usage: 72, capacity: 100, customers: 380 },
  { zone: 'Zone C - Karen', usage: 45, capacity: 100, customers: 220 },
  { zone: 'Zone D - Eastleigh', usage: 91, capacity: 100, customers: 520 },
  { zone: 'Zone E - Lavington', usage: 58, capacity: 100, customers: 290 },
];

// FUP Rules
const fupRules = [
  {
    id: '1',
    name: 'Daily Limit Enforcement',
    plan: 'Basic 5Mbps',
    limit: '30GB/day',
    action: 'Throttle to 1Mbps',
    active: true
  },
  {
    id: '2',
    name: 'Monthly Cap Warning',
    plan: 'All Plans',
    limit: '80% of quota',
    action: 'Send warning SMS',
    active: true
  },
  {
    id: '3',
    name: 'Peak Hour Management',
    plan: 'All Plans',
    limit: '7PM - 11PM',
    action: 'Prioritize business traffic',
    active: true
  },
  {
    id: '4',
    name: 'Repeat Violator',
    plan: 'All Plans',
    limit: '5 violations/month',
    action: 'Suspend for 24hrs',
    active: false
  }
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 }
};

export default function UsageAnalytics() {
  const [timeRange, setTimeRange] = useState('24h');
  const [_selectedZone, _setSelectedZone] = useState('all');

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'normal':
        return <Badge className="bg-green-100 text-green-700">Normal</Badge>;
      case 'warning':
        return <Badge className="bg-yellow-100 text-yellow-700">Warning</Badge>;
      case 'critical':
        return <Badge className="bg-red-100 text-red-700">Critical</Badge>;
      case 'active':
        return <Badge className="bg-orange-100 text-orange-700">Throttled</Badge>;
      case 'suspended':
        return <Badge className="bg-red-100 text-red-700">Suspended</Badge>;
      case 'lifted':
        return <Badge className="bg-green-100 text-green-700">Lifted</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Gauge className="w-8 h-8 text-primary" />
            Usage Analytics & FUP
          </h1>
          <p className="text-muted-foreground mt-1">
            Monitor bandwidth usage and manage Fair Usage Policy
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-32">
              <Calendar className="w-4 h-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1h">1 Hour</SelectItem>
              <SelectItem value="24h">24 Hours</SelectItem>
              <SelectItem value="7d">7 Days</SelectItem>
              <SelectItem value="30d">30 Days</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline">
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="grid grid-cols-2 lg:grid-cols-4 gap-4"
      >
        {[
          { label: 'Avg Utilization', value: `${usageStats.avgUtilization}%`, icon: Activity, color: 'blue', trend: '+5%' },
          { label: 'Peak Usage', value: `${usageStats.peakUtilization}%`, icon: TrendingUp, color: 'purple', trend: '+12%' },
          { label: 'Data Transferred', value: usageStats.totalDataTransferred, icon: Download, color: 'green', trend: '+8%' },
          { label: 'Throttled Users', value: usageStats.throttledUsers.toString(), icon: AlertTriangle, color: 'orange', trend: '-3' },
        ].map((stat) => (
          <motion.div key={stat.label} variants={itemVariants}>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <stat.icon className={`w-5 h-5 text-${stat.color}-500`} />
                  <Badge variant="secondary" className="text-xs">
                    {stat.trend}
                  </Badge>
                </div>
                <div className="mt-2">
                  <div className="text-2xl font-bold">{stat.value}</div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </motion.div>

      {/* Main Content Tabs */}
      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="grid w-full grid-cols-5 lg:w-auto">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="consumers">Top Consumers</TabsTrigger>
          <TabsTrigger value="violations">FUP Violations</TabsTrigger>
          <TabsTrigger value="zones">Zone Analysis</TabsTrigger>
          <TabsTrigger value="rules">FUP Rules</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Peak Hours Chart */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="w-5 h-5" />
                  Peak Hours Analysis
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={peakHoursData}>
                      <defs>
                        <linearGradient id="usageGradient" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3}/>
                          <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="hour" />
                      <YAxis />
                      <Tooltip />
                      <ReferenceLine y={80} stroke="#ef4444" strokeDasharray="3 3" label="Critical" />
                      <Area
                        type="monotone"
                        dataKey="usage"
                        stroke="#8b5cf6"
                        fillOpacity={1}
                        fill="url(#usageGradient)"
                        name="Usage %"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
                <div className="grid grid-cols-3 gap-4 mt-4">
                  <div className="text-center p-3 bg-green-50 rounded-lg">
                    <div className="text-lg font-bold text-green-600">2-6 AM</div>
                    <div className="text-xs text-green-700">Off-Peak</div>
                  </div>
                  <div className="text-center p-3 bg-yellow-50 rounded-lg">
                    <div className="text-lg font-bold text-yellow-600">8 AM-6 PM</div>
                    <div className="text-xs text-yellow-700">Business Hours</div>
                  </div>
                  <div className="text-center p-3 bg-red-50 rounded-lg">
                    <div className="text-lg font-bold text-red-600">7-11 PM</div>
                    <div className="text-xs text-red-700">Peak Hours</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Bandwidth by Plan */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <PieChart className="w-5 h-5" />
                  Bandwidth by Plan
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <RePieChart>
                      <Pie
                        data={planBandwidthData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={100}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {planBandwidthData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </RePieChart>
                  </ResponsiveContainer>
                </div>
                <div className="grid grid-cols-2 gap-2 mt-4">
                  {planBandwidthData.map((item) => (
                    <div key={item.name} className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                      <span className="text-sm">{item.name}: {item.value}%</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Usage Trends */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5" />
                Weekly Usage Trends
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={usageTrends}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="download" fill="#3b82f6" name="Download (TB)" />
                    <Bar dataKey="upload" fill="#10b981" name="Upload (TB)" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="consumers" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Top Data Consumers</CardTitle>
                <div className="flex items-center gap-2">
                  <div className="relative">
                    <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                    <Input placeholder="Search customers..." className="pl-9 w-64" />
                  </div>
                  <Button variant="outline" size="icon">
                    <Filter className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {topConsumers.map((consumer) => (
                  <div key={consumer.id} className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                          <Users className="w-5 h-5 text-primary" />
                        </div>
                        <div>
                          <div className="font-medium">{consumer.customer}</div>
                          <div className="text-sm text-muted-foreground">{consumer.plan}</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {getStatusBadge(consumer.status)}
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreVertical className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem>View Details</DropdownMenuItem>
                            <DropdownMenuItem>Adjust Limit</DropdownMenuItem>
                            <DropdownMenuItem className="text-red-600">Throttle</DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">
                          {consumer.dataUsed} GB / {consumer.dataLimit} GB
                        </span>
                        <span className={`font-medium ${
                          consumer.percentage > 95 ? 'text-red-600' :
                          consumer.percentage > 80 ? 'text-yellow-600' :
                          'text-green-600'
                        }`}>
                          {consumer.percentage.toFixed(1)}%
                        </span>
                      </div>
                      <Progress
                        value={consumer.percentage}
                        className={`h-2 ${
                          consumer.percentage > 95 ? 'bg-red-100' :
                          consumer.percentage > 80 ? 'bg-yellow-100' :
                          'bg-green-100'
                        }`}
                      />
                      <div className="text-xs text-muted-foreground">
                        Last active: {consumer.lastActive}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="violations" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5" />
                  FUP Violations
                </CardTitle>
                <Badge variant="secondary">{fupViolations.length} Active</Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {fupViolations.map((violation) => (
                  <div key={violation.id} className="flex items-start justify-between p-4 border rounded-lg">
                    <div className="flex items-start gap-4">
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                        violation.status === 'suspended' ? 'bg-red-100 text-red-600' :
                        violation.status === 'active' ? 'bg-orange-100 text-orange-600' :
                        'bg-green-100 text-green-600'
                      }`}>
                        {violation.status === 'suspended' ? <Ban className="w-5 h-5" /> :
                         violation.status === 'active' ? <Zap className="w-5 h-5" /> :
                         <CheckCircle className="w-5 h-5" />}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{violation.customer}</span>
                          {getStatusBadge(violation.status)}
                        </div>
                        <div className="text-sm text-muted-foreground mt-1">{violation.violation}</div>
                        <div className="text-sm text-red-600 mt-1">Action: {violation.action}</div>
                        <div className="text-xs text-muted-foreground mt-1">{violation.timestamp}</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {violation.status !== 'lifted' && (
                        <>
                          <Button variant="outline" size="sm">Lift</Button>
                          <Button variant="outline" size="sm">Extend</Button>
                        </>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="zones" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Zone Usage Analysis</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {zoneUsage.map((zone) => (
                  <div key={zone.zone} className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                          <Router className="w-5 h-5 text-primary" />
                        </div>
                        <div>
                          <div className="font-medium">{zone.zone}</div>
                          <div className="text-sm text-muted-foreground">{zone.customers} customers</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className={`text-2xl font-bold ${
                          zone.usage > 90 ? 'text-red-600' :
                          zone.usage > 75 ? 'text-yellow-600' :
                          'text-green-600'
                        }`}>
                          {zone.usage}%
                        </div>
                        <div className="text-sm text-muted-foreground">utilization</div>
                      </div>
                    </div>
                    <Progress
                      value={zone.usage}
                      className="h-3"
                    />
                    <div className="flex items-center justify-between mt-2 text-sm">
                      <span className="text-muted-foreground">Capacity: {zone.capacity}%</span>
                      {zone.usage > 90 && (
                        <Badge variant="destructive">Overloaded</Badge>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="rules" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>FUP Rules Configuration</CardTitle>
                <Button>
                  <Zap className="w-4 h-4 mr-2" />
                  Add Rule
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {fupRules.map((rule) => (
                  <div key={rule.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-4">
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                        rule.active ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-600'
                      }`}>
                        <Settings className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{rule.name}</span>
                          <Badge variant={rule.active ? 'default' : 'secondary'}>
                            {rule.active ? 'Active' : 'Inactive'}
                          </Badge>
                        </div>
                        <div className="text-sm text-muted-foreground">
                          Plan: {rule.plan} • Limit: {rule.limit}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          Action: {rule.action}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Switch checked={rule.active} />
                      <Button variant="ghost" size="icon">
                        <MoreVertical className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
