import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  MessageCircle,
  Send,
  Users,
  Clock,
  CheckCircle,
  XCircle,
  RefreshCw,
  Settings,
  BarChart3,
  Zap,
  MoreVertical,
  Search,
  Filter,
  Download,
  Plus,
  Trash2,
  Edit,
  FileText
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar
} from 'recharts';

// WhatsApp Stats
const whatsappStats = {
  messagesSent: 12458,
  messagesDelivered: 11892,
  messagesRead: 10234,
  responseRate: 67,
  activeConversations: 234,
  templatesApproved: 12,
  apiStatus: 'connected',
  queueSize: 45
};

// Message History
const messageHistory = [
  {
    id: '1',
    customer: 'John Kamau',
    phone: '+254712345678',
    message: 'Your internet bill of KES 2,500 is due on 30th Jan. Pay via M-Pesa Paybill 123456.',
    type: 'template',
    status: 'delivered',
    sentAt: '2024-01-29 14:30',
    readAt: '2024-01-29 14:35'
  },
  {
    id: '2',
    customer: 'Sarah Wanjiku',
    phone: '+254723456789',
    message: 'Payment received! KES 3,000 credited to your account. Thank you!',
    type: 'automated',
    status: 'read',
    sentAt: '2024-01-29 13:15',
    readAt: '2024-01-29 13:20'
  },
  {
    id: '3',
    customer: 'Peter Ochieng',
    phone: '+254734567890',
    message: 'Your internet service has been suspended due to non-payment. Please contact support.',
    type: 'template',
    status: 'failed',
    sentAt: '2024-01-29 12:00',
    readAt: null
  },
  {
    id: '4',
    customer: 'Mary Njeri',
    phone: '+254745678901',
    message: 'Welcome to NetConnect ISP! Your account is now active. Login details sent via SMS.',
    type: 'template',
    status: 'read',
    sentAt: '2024-01-29 10:30',
    readAt: '2024-01-29 10:45'
  },
  {
    id: '5',
    customer: 'James Mwangi',
    phone: '+254756789012',
    message: 'Scheduled maintenance on 1st Feb 2-4 AM. Service may be intermittent.',
    type: 'broadcast',
    status: 'delivered',
    sentAt: '2024-01-29 09:00',
    readAt: null
  }
];

// Message Templates
const messageTemplates = [
  {
    id: '1',
    name: 'Payment Reminder',
    category: 'utility',
    language: 'en',
    status: 'approved',
    content: 'Your internet bill of {{1}} is due on {{2}}. Pay via M-Pesa Paybill {{3}}. Account: {{4}}',
    variables: 4,
    usage: 2450
  },
  {
    id: '2',
    name: 'Payment Confirmation',
    category: 'utility',
    language: 'en',
    status: 'approved',
    content: 'Payment received! {{1}} credited to your account. Thank you for choosing NetConnect!',
    variables: 1,
    usage: 1890
  },
  {
    id: '3',
    name: 'Welcome Message',
    category: 'marketing',
    language: 'en',
    status: 'approved',
    content: 'Welcome to NetConnect ISP, {{1}}! Your {{2}} plan is now active. Enjoy blazing fast internet!',
    variables: 2,
    usage: 567
  },
  {
    id: '4',
    name: 'Service Suspension',
    category: 'utility',
    language: 'en',
    status: 'approved',
    content: 'Your internet service has been suspended due to non-payment. Outstanding: {{1}}. Contact {{2}}',
    variables: 2,
    usage: 234
  },
  {
    id: '5',
    name: 'Promotional Offer',
    category: 'marketing',
    language: 'en',
    status: 'pending',
    content: 'Special offer! Upgrade to {{1}} and get {{2}} off for 3 months. Offer ends {{3}}!',
    variables: 3,
    usage: 0
  }
];

// Automation Rules
const automationRules = [
  {
    id: '1',
    name: 'Payment Reminder',
    trigger: '3 days before due date',
    template: 'Payment Reminder',
    active: true,
    sentCount: 2450,
    openRate: 78
  },
  {
    id: '2',
    name: 'Payment Confirmation',
    trigger: 'On payment received',
    template: 'Payment Confirmation',
    active: true,
    sentCount: 1890,
    openRate: 92
  },
  {
    id: '3',
    name: 'Welcome New Customer',
    trigger: 'On account activation',
    template: 'Welcome Message',
    active: true,
    sentCount: 567,
    openRate: 85
  },
  {
    id: '4',
    name: 'Service Suspension Notice',
    trigger: 'On account suspension',
    template: 'Service Suspension',
    active: false,
    sentCount: 234,
    openRate: 65
  }
];

// Analytics Data
const messageVolumeData = [
  { date: 'Mon', sent: 450, delivered: 420, read: 380 },
  { date: 'Tue', sent: 520, delivered: 490, read: 450 },
  { date: 'Wed', sent: 480, delivered: 460, read: 410 },
  { date: 'Thu', sent: 600, delivered: 580, read: 520 },
  { date: 'Fri', sent: 750, delivered: 720, read: 680 },
  { date: 'Sat', sent: 380, delivered: 360, read: 320 },
  { date: 'Sun', sent: 290, delivered: 280, read: 250 },
];

const templatePerformance = [
  { name: 'Payment Reminder', sent: 2450, delivered: 2380, read: 1980 },
  { name: 'Payment Conf', sent: 1890, delivered: 1860, read: 1750 },
  { name: 'Welcome', sent: 567, delivered: 560, read: 520 },
  { name: 'Suspension', sent: 234, delivered: 210, read: 165 },
];

// Chat Simulation
const chatMessages = [
  { id: '1', from: 'customer', text: 'Hi, I need help with my internet', time: '14:30' },
  { id: '2', from: 'bot', text: 'Hello! I\'m here to help. What seems to be the issue with your internet connection?', time: '14:30' },
  { id: '3', from: 'customer', text: 'It\'s very slow today', time: '14:31' },
  { id: '4', from: 'bot', text: 'I understand. Let me check your connection status. Your account shows normal usage. Have you tried restarting your router?', time: '14:31' },
  { id: '5', from: 'customer', text: 'Not yet, let me try', time: '14:32' },
  { id: '6', from: 'bot', text: 'Great! Please unplug your router for 30 seconds, then plug it back in. Let me know if that helps!', time: '14:32' },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 }
};

export default function WhatsAppIntegration() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [chatInput, setChatInput] = useState('');
  const [isConnected, setIsConnected] = useState(true);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'read':
        return <CheckCircle className="w-4 h-4 text-blue-500" />;
      case 'delivered':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'failed':
        return <XCircle className="w-4 h-4 text-red-500" />;
      default:
        return <Clock className="w-4 h-4 text-yellow-500" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'approved':
        return <Badge className="bg-green-100 text-green-700">Approved</Badge>;
      case 'pending':
        return <Badge className="bg-yellow-100 text-yellow-700">Pending</Badge>;
      case 'rejected':
        return <Badge className="bg-red-100 text-red-700">Rejected</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <MessageCircle className="w-8 h-8 text-green-500" />
            WhatsApp Integration
          </h1>
          <p className="text-muted-foreground mt-1">
            Connect with customers through WhatsApp Business API
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className={`flex items-center gap-2 px-3 py-1.5 rounded-full ${
            isConnected ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
          }`}>
            <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`} />
            <span className="text-sm font-medium">{isConnected ? 'Connected' : 'Disconnected'}</span>
          </div>
          <Button variant="outline" onClick={() => setIsConnected(!isConnected)}>
            <RefreshCw className="w-4 h-4 mr-2" />
            Reconnect
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="grid grid-cols-2 lg:grid-cols-4 gap-4"
      >
        {[
          { label: 'Messages Sent', value: whatsappStats.messagesSent.toLocaleString(), icon: Send, color: 'blue' },
          { label: 'Delivered', value: whatsappStats.messagesDelivered.toLocaleString(), icon: CheckCircle, color: 'green' },
          { label: 'Read Rate', value: `${Math.round((whatsappStats.messagesRead / whatsappStats.messagesDelivered) * 100)}%`, icon: Users, color: 'purple' },
          { label: 'Active Chats', value: whatsappStats.activeConversations.toString(), icon: MessageCircle, color: 'orange' },
        ].map((stat) => (
          <motion.div key={stat.label} variants={itemVariants}>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <stat.icon className={`w-5 h-5 text-${stat.color}-500`} />
                  <Badge variant="secondary" className="text-xs">+12%</Badge>
                </div>
                <div className="mt-2">
                  <div className="text-2xl font-bold">{stat.value}</div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </motion.div>

      {/* Main Content Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-5 lg:w-auto">
          <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
          <TabsTrigger value="messages">Messages</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
          <TabsTrigger value="automation">Automation</TabsTrigger>
          <TabsTrigger value="chatbot">Chatbot</TabsTrigger>
        </TabsList>

        <TabsContent value="dashboard" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Message Volume Chart */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="w-5 h-5" />
                  Message Volume (7 Days)
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={messageVolumeData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="sent" fill="#3b82f6" name="Sent" />
                      <Bar dataKey="delivered" fill="#10b981" name="Delivered" />
                      <Bar dataKey="read" fill="#8b5cf6" name="Read" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Template Performance */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="w-5 h-5" />
                  Template Performance
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={templatePerformance} layout="vertical">
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis type="number" />
                      <YAxis dataKey="name" type="category" width={100} />
                      <Tooltip />
                      <Bar dataKey="sent" fill="#3b82f6" name="Sent" />
                      <Bar dataKey="read" fill="#10b981" name="Read" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <Button variant="outline" className="h-auto py-4 flex flex-col items-center gap-2">
                  <Send className="w-6 h-6" />
                  <span>Send Message</span>
                </Button>
                <Button variant="outline" className="h-auto py-4 flex flex-col items-center gap-2">
                  <FileText className="w-6 h-6" />
                  <span>New Template</span>
                </Button>
                <Button variant="outline" className="h-auto py-4 flex flex-col items-center gap-2">
                  <Users className="w-6 h-6" />
                  <span>Broadcast</span>
                </Button>
                <Button variant="outline" className="h-auto py-4 flex flex-col items-center gap-2">
                  <Zap className="w-6 h-6" />
                  <span>Automation</span>
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="messages" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Message History</CardTitle>
                <div className="flex items-center gap-2">
                  <div className="relative">
                    <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                    <Input placeholder="Search messages..." className="pl-9 w-64" />
                  </div>
                  <Button variant="outline" size="icon">
                    <Filter className="w-4 h-4" />
                  </Button>
                  <Button variant="outline" size="icon">
                    <Download className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {messageHistory.map((msg) => (
                  <div key={msg.id} className="flex items-start gap-4 p-4 border rounded-lg hover:bg-muted/50 transition-colors">
                    <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0">
                      <MessageCircle className="w-5 h-5 text-green-600" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium">{msg.customer}</span>
                        <span className="text-sm text-muted-foreground">{msg.phone}</span>
                        <Badge variant="secondary">{msg.type}</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground line-clamp-2">{msg.message}</p>
                      <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                        <span>Sent: {msg.sentAt}</span>
                        {msg.readAt && <span>Read: {msg.readAt}</span>}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {getStatusIcon(msg.status)}
                      <span className="text-sm capitalize">{msg.status}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="templates" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Message Templates</CardTitle>
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Create Template
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {messageTemplates.map((template) => (
                  <div key={template.id} className="p-4 border rounded-lg">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{template.name}</span>
                          {getStatusBadge(template.status)}
                          <Badge variant="outline">{template.category}</Badge>
                        </div>
                        <div className="text-sm text-muted-foreground mt-1">
                          {template.variables} variables • Used {template.usage} times
                        </div>
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreVertical className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>
                            <Edit className="w-4 h-4 mr-2" />
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Send className="w-4 h-4 mr-2" />
                            Test
                          </DropdownMenuItem>
                          <DropdownMenuItem className="text-red-600">
                            <Trash2 className="w-4 h-4 mr-2" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                    <div className="p-3 bg-muted rounded-lg text-sm">
                      {template.content}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="automation" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Automation Rules</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {automationRules.map((rule) => (
                  <div key={rule.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-4">
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                        rule.active ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-600'
                      }`}>
                        <Zap className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{rule.name}</span>
                          <Badge variant={rule.active ? 'default' : 'secondary'}>
                            {rule.active ? 'Active' : 'Paused'}
                          </Badge>
                        </div>
                        <div className="text-sm text-muted-foreground">
                          Trigger: {rule.trigger} • Template: {rule.template}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          Sent: {rule.sentCount.toLocaleString()} • Open rate: {rule.openRate}%
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Switch checked={rule.active} />
                      <Button variant="ghost" size="icon">
                        <Edit className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="chatbot" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Chat Simulator */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageCircle className="w-5 h-5" />
                  Chat Simulator
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="border rounded-lg h-96 flex flex-col">
                  <div className="flex-1 p-4 space-y-4 overflow-y-auto">
                    {chatMessages.map((msg) => (
                      <div key={msg.id} className={`flex ${msg.from === 'customer' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-[80%] p-3 rounded-lg ${
                          msg.from === 'customer'
                            ? 'bg-green-500 text-white'
                            : 'bg-muted'
                        }`}>
                          <p className="text-sm">{msg.text}</p>
                          <span className={`text-xs ${msg.from === 'customer' ? 'text-green-100' : 'text-muted-foreground'}`}>
                            {msg.time}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="p-3 border-t flex gap-2">
                    <Input
                      placeholder="Type a message..."
                      value={chatInput}
                      onChange={(e) => setChatInput(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && setChatInput('')}
                    />
                    <Button size="icon" onClick={() => setChatInput('')}>
                      <Send className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Chatbot Settings */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="w-5 h-5" />
                  Chatbot Configuration
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <div className="font-medium">Auto-Reply</div>
                    <div className="text-sm text-muted-foreground">Automatically respond to common queries</div>
                  </div>
                  <Switch defaultChecked />
                </div>
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <div className="font-medium">Human Handoff</div>
                    <div className="text-sm text-muted-foreground">Transfer to agent when needed</div>
                  </div>
                  <Switch defaultChecked />
                </div>
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <div className="font-medium">Business Hours Only</div>
                    <div className="text-sm text-muted-foreground">Limit auto-replies to business hours</div>
                  </div>
                  <Switch />
                </div>
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <div className="font-medium">Typing Indicator</div>
                    <div className="text-sm text-muted-foreground">Show typing animation</div>
                  </div>
                  <Switch defaultChecked />
                </div>

                <div className="p-4 bg-muted rounded-lg">
                  <h4 className="font-medium mb-2">Quick Responses</h4>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span>Payment Issues</span>
                      <Badge variant="secondary">12 variations</Badge>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span>Technical Support</span>
                      <Badge variant="secondary">8 variations</Badge>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span>Plan Upgrades</span>
                      <Badge variant="secondary">5 variations</Badge>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
