import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Search, 
  Eye, 
  RefreshCw, 
  CheckCircle, 
  XCircle, 
  Clock,
  Smartphone,
  CreditCard,
  Banknote,
  ArrowRightLeft,
  X
} from 'lucide-react';
import type { Payment } from '../types';
import { formatCurrency, formatDateTime, getStatusColor } from '../lib/utils';

// Mock data
const mockPayments: Payment[] = [
  {
    id: '1',
    customerId: '1',
    customerName: 'John Doe',
    invoiceId: '1',
    transactionId: 'TXN123456',
    method: 'mpesa',
    amount: 2500,
    paymentMethod: 'mpesa',
    mpesaTransactionId: 'MPESA123456',
    mpesaPhoneNumber: '+254712345678',
    status: 'completed',
    createdAt: '2024-06-10T14:30:00',
    processedAt: '2024-06-10T14:32:00',
    notes: 'Monthly subscription payment',
  },
  {
    id: '2',
    customerId: '2',
    customerName: 'Jane Smith',
    invoiceId: '2',
    transactionId: 'TXN789012',
    method: 'mpesa',
    amount: 1500,
    paymentMethod: 'mpesa',
    mpesaTransactionId: 'MPESA789012',
    mpesaPhoneNumber: '+254723456789',
    status: 'pending',
    createdAt: '2024-06-15T09:15:00',
  },
  {
    id: '3',
    customerId: '3',
    customerName: 'Mike Johnson',
    invoiceId: '3',
    transactionId: 'TXN345678',
    method: 'cash',
    amount: 5000,
    paymentMethod: 'cash',
    status: 'completed',
    createdAt: '2024-06-05T16:45:00',
    processedAt: '2024-06-05T16:45:00',
    notes: 'Paid at office',
  },
  {
    id: '4',
    customerId: '4',
    customerName: 'Sarah Williams',
    invoiceId: '4',
    transactionId: 'TXN901234',
    method: 'bank',
    amount: 1500,
    paymentMethod: 'bank',
    status: 'completed',
    createdAt: '2024-06-05T10:20:00',
    processedAt: '2024-06-06T09:00:00',
    notes: 'Bank transfer',
  },
  {
    id: '5',
    customerId: '5',
    customerName: 'David Brown',
    invoiceId: '5',
    transactionId: 'TXN567890',
    method: 'mpesa',
    amount: 2500,
    paymentMethod: 'mpesa',
    status: 'failed',
    createdAt: '2024-06-14T11:30:00',
    notes: 'Insufficient funds',
  },
];

export default function Payments() {
  const [payments] = useState<Payment[]>(mockPayments);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterMethod, setFilterMethod] = useState<string>('all');
  const [showViewModal, setShowViewModal] = useState(false);
  const [selectedPayment, setSelectedPayment] = useState<Payment | null>(null);

  const filteredPayments = payments.filter(payment => {
    const matchesSearch = 
      payment.customerName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      payment.mpesaTransactionId?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      payment.mpesaPhoneNumber?.includes(searchQuery);
    
    const matchesStatus = filterStatus === 'all' || payment.status === filterStatus;
    const matchesMethod = filterMethod === 'all' || payment.paymentMethod === filterMethod;
    
    return matchesSearch && matchesStatus && matchesMethod;
  });

  const handleView = (payment: Payment) => {
    setSelectedPayment(payment);
    setShowViewModal(true);
  };

  const getPaymentMethodIcon = (method: Payment['paymentMethod']) => {
    switch (method) {
      case 'mpesa':
        return <Smartphone className="w-4 h-4 text-success" />;
      case 'cash':
        return <Banknote className="w-4 h-4 text-warning" />;
      case 'bank':
        return <CreditCard className="w-4 h-4 text-primary" />;
      default:
        return <CreditCard className="w-4 h-4 text-muted-foreground" />;
    }
  };

  const getStatusIcon = (status: Payment['status']) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-success" />;
      case 'pending':
        return <Clock className="w-4 h-4 text-warning" />;
      case 'failed':
        return <XCircle className="w-4 h-4 text-destructive" />;
      default:
        return <ArrowRightLeft className="w-4 h-4 text-muted-foreground" />;
    }
  };

  const stats = {
    total: payments.length,
    completed: payments.filter(p => p.status === 'completed').length,
    pending: payments.filter(p => p.status === 'pending').length,
    failed: payments.filter(p => p.status === 'failed').length,
    totalAmount: payments.filter(p => p.status === 'completed').reduce((sum, p) => sum + p.amount, 0),
    mpesaAmount: payments.filter(p => p.status === 'completed' && p.paymentMethod === 'mpesa').reduce((sum, p) => sum + p.amount, 0),
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Payments</h2>
          <p className="text-muted-foreground">Track and manage payment transactions</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors">
          <RefreshCw className="w-4 h-4" />
          Sync M-Pesa
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="glass rounded-xl p-4">
          <p className="text-sm text-muted-foreground">Total Payments</p>
          <p className="text-2xl font-bold text-foreground">{stats.total}</p>
          <p className="text-sm text-muted-foreground">{formatCurrency(stats.totalAmount)}</p>
        </div>
        <div className="glass rounded-xl p-4">
          <p className="text-sm text-muted-foreground">Completed</p>
          <p className="text-2xl font-bold text-success">{stats.completed}</p>
          <p className="text-sm text-success">Successfully processed</p>
        </div>
        <div className="glass rounded-xl p-4">
          <p className="text-sm text-muted-foreground">Pending</p>
          <p className="text-2xl font-bold text-warning">{stats.pending}</p>
          <p className="text-sm text-warning">Awaiting confirmation</p>
        </div>
        <div className="glass rounded-xl p-4">
          <p className="text-sm text-muted-foreground">M-Pesa Revenue</p>
          <p className="text-2xl font-bold text-primary">{formatCurrency(stats.mpesaAmount)}</p>
          <p className="text-sm text-primary">{Math.round((stats.mpesaAmount / stats.totalAmount) * 100)}% of total</p>
        </div>
      </div>

      {/* Filters */}
      <div className="glass rounded-xl p-4">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search payments..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-muted border border-border rounded-lg text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
            />
          </div>
          <div className="flex gap-2">
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="px-4 py-2 bg-muted border border-border rounded-lg text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
            >
              <option value="all">All Status</option>
              <option value="completed">Completed</option>
              <option value="pending">Pending</option>
              <option value="failed">Failed</option>
              <option value="refunded">Refunded</option>
            </select>
            <select
              value={filterMethod}
              onChange={(e) => setFilterMethod(e.target.value)}
              className="px-4 py-2 bg-muted border border-border rounded-lg text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
            >
              <option value="all">All Methods</option>
              <option value="mpesa">M-Pesa</option>
              <option value="cash">Cash</option>
              <option value="bank">Bank</option>
              <option value="other">Other</option>
            </select>
          </div>
        </div>
      </div>

      {/* Payments Table */}
      <div className="glass rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border bg-muted/50">
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Transaction ID</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Customer</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Amount</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Method</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Status</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Date</th>
                <th className="px-4 py-3 text-right text-sm font-medium text-muted-foreground">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredPayments.map((payment, index) => (
                <motion.tr
                  key={payment.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="border-b border-border last:border-b-0 hover:bg-muted/30 transition-colors"
                >
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <ArrowRightLeft className="w-4 h-4 text-primary" />
                      <span className="font-mono text-sm text-foreground">{payment.id}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className="text-sm text-foreground">{payment.customerName}</span>
                  </td>
                  <td className="px-4 py-3">
                    <span className="text-sm font-medium text-foreground">{formatCurrency(payment.amount)}</span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      {getPaymentMethodIcon(payment.paymentMethod)}
                      <span className="text-sm text-foreground capitalize">{payment.paymentMethod}</span>
                      {payment.mpesaPhoneNumber && (
                        <span className="text-xs text-muted-foreground">({payment.mpesaPhoneNumber})</span>
                      )}
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      {getStatusIcon(payment.status)}
                      <span className={`px-2 py-1 text-xs rounded-full border ${getStatusColor(payment.status)}`}>
                        {payment.status}
                      </span>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className="text-sm text-foreground">{formatDateTime(payment.createdAt)}</span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => handleView(payment)}
                        className="p-2 hover:bg-muted rounded-lg text-muted-foreground hover:text-foreground transition-colors"
                        title="View"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
        {filteredPayments.length === 0 && (
          <div className="p-8 text-center text-muted-foreground">
            No payments found matching your criteria.
          </div>
        )}
      </div>

      {/* View Payment Modal */}
      <AnimatePresence>
        {showViewModal && selectedPayment && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
            onClick={() => setShowViewModal(false)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="glass rounded-xl p-6 max-w-lg w-full"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-semibold text-foreground">Payment Details</h3>
                <button
                  onClick={() => setShowViewModal(false)}
                  className="p-2 hover:bg-muted rounded-lg transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-4">
                {/* Status */}
                <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                  <span className="text-sm text-muted-foreground">Status</span>
                  <div className="flex items-center gap-2">
                    {getStatusIcon(selectedPayment.status)}
                    <span className={`px-3 py-1 text-sm rounded-full border ${getStatusColor(selectedPayment.status)}`}>
                      {selectedPayment.status.toUpperCase()}
                    </span>
                  </div>
                </div>

                {/* Amount */}
                <div className="text-center py-4">
                  <p className="text-sm text-muted-foreground mb-1">Amount</p>
                  <p className="text-4xl font-bold text-foreground">{formatCurrency(selectedPayment.amount)}</p>
                </div>

                {/* Details */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-3 bg-muted/50 rounded-lg">
                    <p className="text-sm text-muted-foreground mb-1">Customer</p>
                    <p className="text-sm font-medium text-foreground">{selectedPayment.customerName}</p>
                  </div>
                  <div className="p-3 bg-muted/50 rounded-lg">
                    <p className="text-sm text-muted-foreground mb-1">Payment Method</p>
                    <div className="flex items-center gap-2">
                      {getPaymentMethodIcon(selectedPayment.paymentMethod)}
                      <p className="text-sm font-medium text-foreground capitalize">{selectedPayment.paymentMethod}</p>
                    </div>
                  </div>
                  <div className="p-3 bg-muted/50 rounded-lg">
                    <p className="text-sm text-muted-foreground mb-1">Transaction Date</p>
                    <p className="text-sm text-foreground">{formatDateTime(selectedPayment.createdAt)}</p>
                  </div>
                  {selectedPayment.processedAt && (
                    <div className="p-3 bg-muted/50 rounded-lg">
                      <p className="text-sm text-muted-foreground mb-1">Processed At</p>
                      <p className="text-sm text-foreground">{formatDateTime(selectedPayment.processedAt)}</p>
                    </div>
                  )}
                </div>

                {/* M-Pesa Details */}
                {selectedPayment.paymentMethod === 'mpesa' && (
                  <div className="border-t border-border pt-4">
                    <p className="text-sm font-medium text-foreground mb-2">M-Pesa Details</p>
                    <div className="space-y-2">
                      {selectedPayment.mpesaTransactionId && (
                        <div className="flex justify-between">
                          <span className="text-sm text-muted-foreground">Transaction ID</span>
                          <span className="text-sm font-mono text-foreground">{selectedPayment.mpesaTransactionId}</span>
                        </div>
                      )}
                      {selectedPayment.mpesaPhoneNumber && (
                        <div className="flex justify-between">
                          <span className="text-sm text-muted-foreground">Phone Number</span>
                          <span className="text-sm text-foreground">{selectedPayment.mpesaPhoneNumber}</span>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Notes */}
                {selectedPayment.notes && (
                  <div className="border-t border-border pt-4">
                    <p className="text-sm text-muted-foreground mb-1">Notes</p>
                    <p className="text-sm text-foreground">{selectedPayment.notes}</p>
                  </div>
                )}

                {/* Actions */}
                <div className="flex justify-end gap-3 pt-4">
                  <button
                    onClick={() => setShowViewModal(false)}
                    className="px-4 py-2 text-foreground hover:bg-muted rounded-lg transition-colors"
                  >
                    Close
                  </button>
                  {selectedPayment.status === 'pending' && (
                    <button className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors">
                      Verify Payment
                    </button>
                  )}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
