import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Users, 
  Plus, 
  Search,
  TrendingUp,
  CreditCard,
  UserCheck,
  DollarSign,
  Download,
  Edit2,
  Eye,
  Phone,
  Mail,
  MapPin
} from 'lucide-react';
import { formatCurrency, formatDate } from '../lib/utils';

interface Agent {
  id: string;
  name: string;
  email: string;
  phone: string;
  location: string;
  status: 'active' | 'inactive';
  commissionRate: number;
  totalSales: number;
  totalCommission: number;
  customersReferred: number;
  joinedDate: string;
  lastActive: string;
}

interface Commission {
  id: string;
  agentId: string;
  agentName: string;
  customerName: string;
  planName: string;
  saleAmount: number;
  commissionAmount: number;
  status: 'pending' | 'paid' | 'cancelled';
  createdAt: string;
  paidAt?: string;
}

const mockAgents: Agent[] = [
  {
    id: '1',
    name: 'Peter Kamau',
    email: 'peter@example.com',
    phone: '+254712345678',
    location: 'Nairobi CBD',
    status: 'active',
    commissionRate: 10,
    totalSales: 125000,
    totalCommission: 12500,
    customersReferred: 45,
    joinedDate: '2024-01-15',
    lastActive: '2024-06-15',
  },
  {
    id: '2',
    name: 'Mary Wanjiku',
    email: 'mary@example.com',
    phone: '+254723456789',
    location: 'Westlands',
    status: 'active',
    commissionRate: 12,
    totalSales: 180000,
    totalCommission: 21600,
    customersReferred: 62,
    joinedDate: '2023-11-20',
    lastActive: '2024-06-14',
  },
  {
    id: '3',
    name: 'James Ochieng',
    email: 'james@example.com',
    phone: '+254734567890',
    location: 'Kisumu',
    status: 'inactive',
    commissionRate: 8,
    totalSales: 45000,
    totalCommission: 3600,
    customersReferred: 15,
    joinedDate: '2024-03-01',
    lastActive: '2024-05-20',
  },
];

const mockCommissions: Commission[] = [
  {
    id: '1',
    agentId: '1',
    agentName: 'Peter Kamau',
    customerName: 'John Doe',
    planName: 'Premium 10Mbps',
    saleAmount: 2500,
    commissionAmount: 250,
    status: 'paid',
    createdAt: '2024-06-01',
    paidAt: '2024-06-05',
  },
  {
    id: '2',
    agentId: '2',
    agentName: 'Mary Wanjiku',
    customerName: 'Jane Smith',
    planName: 'Enterprise 20Mbps',
    saleAmount: 5000,
    commissionAmount: 600,
    status: 'pending',
    createdAt: '2024-06-10',
  },
  {
    id: '3',
    agentId: '1',
    agentName: 'Peter Kamau',
    customerName: 'David Brown',
    planName: 'Basic 5Mbps',
    saleAmount: 1500,
    commissionAmount: 150,
    status: 'pending',
    createdAt: '2024-06-12',
  },
];

const getStatusColor = (status: Agent['status']) => {
  switch (status) {
    case 'active': return 'bg-success/20 text-success';
    case 'inactive': return 'bg-muted text-muted-foreground';
  }
};

const getCommissionStatusColor = (status: Commission['status']) => {
  switch (status) {
    case 'paid': return 'bg-success/20 text-success';
    case 'pending': return 'bg-warning/20 text-warning';
    case 'cancelled': return 'bg-destructive/20 text-destructive';
  }
};

export default function Agents() {
  const [agents, _setAgents] = useState<Agent[]>(mockAgents);
  const [commissions] = useState<Commission[]>(mockCommissions);
  const [activeTab, setActiveTab] = useState<'agents' | 'commissions'>('agents');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [_showNewAgentModal, setShowNewAgentModal] = useState(false);
  const [selectedAgent, setSelectedAgent] = useState<Agent | null>(null);

  const filteredAgents = agents.filter(agent => {
    const matchesSearch = 
      agent.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      agent.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      agent.location.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = filterStatus === 'all' || agent.status === filterStatus;
    
    return matchesSearch && matchesStatus;
  });

  const stats = {
    totalAgents: agents.length,
    activeAgents: agents.filter(a => a.status === 'active').length,
    totalSales: agents.reduce((sum, a) => sum + a.totalSales, 0),
    totalCommissions: agents.reduce((sum, a) => sum + a.totalCommission, 0),
    pendingCommissions: commissions.filter(c => c.status === 'pending').reduce((sum, c) => sum + c.commissionAmount, 0),
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Agent Management</h2>
          <p className="text-muted-foreground">Manage sales agents and commissions</p>
        </div>
        <div className="flex gap-2">
          <button className="flex items-center gap-2 px-4 py-2 bg-muted text-foreground rounded-lg hover:bg-muted/80 transition-colors">
            <Download className="w-4 h-4" />
            Export
          </button>
          <button
            onClick={() => setShowNewAgentModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
          >
            <Plus className="w-4 h-4" />
            Add Agent
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary/20 rounded-lg flex items-center justify-center">
              <Users className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Total Agents</p>
              <p className="text-2xl font-bold text-foreground">{stats.totalAgents}</p>
            </div>
          </div>
        </div>
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-success/20 rounded-lg flex items-center justify-center">
              <UserCheck className="w-5 h-5 text-success" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Active Agents</p>
              <p className="text-2xl font-bold text-success">{stats.activeAgents}</p>
            </div>
          </div>
        </div>
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-secondary/20 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-secondary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Total Sales</p>
              <p className="text-2xl font-bold text-secondary">{formatCurrency(stats.totalSales)}</p>
            </div>
          </div>
        </div>
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-warning/20 rounded-lg flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-warning" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Commissions Paid</p>
              <p className="text-2xl font-bold text-warning">{formatCurrency(stats.totalCommissions)}</p>
            </div>
          </div>
        </div>
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary/20 rounded-lg flex items-center justify-center">
              <CreditCard className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Pending</p>
              <p className="text-2xl font-bold text-primary">{formatCurrency(stats.pendingCommissions)}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2">
        <button
          onClick={() => setActiveTab('agents')}
          className={`px-4 py-2 rounded-lg transition-colors ${
            activeTab === 'agents'
              ? 'bg-primary text-primary-foreground'
              : 'bg-muted text-foreground hover:bg-muted/80'
          }`}
        >
          Agents
        </button>
        <button
          onClick={() => setActiveTab('commissions')}
          className={`px-4 py-2 rounded-lg transition-colors ${
            activeTab === 'commissions'
              ? 'bg-primary text-primary-foreground'
              : 'bg-muted text-foreground hover:bg-muted/80'
          }`}
        >
          Commissions
        </button>
      </div>

      {activeTab === 'agents' && (
        <>
          {/* Filters */}
          <div className="glass rounded-xl p-4">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="Search agents..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 bg-muted border border-border rounded-lg text-sm"
                />
              </div>
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="px-4 py-2 bg-muted border border-border rounded-lg text-sm"
              >
                <option value="all">All Status</option>
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
              </select>
            </div>
          </div>

          {/* Agents Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredAgents.map((agent, index) => (
              <motion.div
                key={agent.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="glass rounded-xl p-5"
              >
                {/* Header */}
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center">
                      <span className="text-lg font-bold text-primary">{agent.name.charAt(0)}</span>
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground">{agent.name}</h3>
                      <span className={`px-2 py-0.5 rounded-full text-xs ${getStatusColor(agent.status)}`}>
                        {agent.status}
                      </span>
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <button 
                      onClick={() => setSelectedAgent(agent)}
                      className="p-2 hover:bg-muted rounded-lg text-muted-foreground"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                    <button className="p-2 hover:bg-muted rounded-lg text-muted-foreground">
                      <Edit2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Contact Info */}
                <div className="space-y-2 mb-4">
                  <div className="flex items-center gap-2 text-sm">
                    <Phone className="w-4 h-4 text-muted-foreground" />
                    <span className="text-foreground">{agent.phone}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Mail className="w-4 h-4 text-muted-foreground" />
                    <span className="text-foreground">{agent.email}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <MapPin className="w-4 h-4 text-muted-foreground" />
                    <span className="text-foreground">{agent.location}</span>
                  </div>
                </div>

                {/* Stats */}
                <div className="grid grid-cols-2 gap-3 mb-4">
                  <div className="p-3 bg-muted/50 rounded-lg text-center">
                    <p className="text-lg font-bold text-foreground">{agent.customersReferred}</p>
                    <p className="text-xs text-muted-foreground">Customers</p>
                  </div>
                  <div className="p-3 bg-muted/50 rounded-lg text-center">
                    <p className="text-lg font-bold text-primary">{agent.commissionRate}%</p>
                    <p className="text-xs text-muted-foreground">Commission</p>
                  </div>
                </div>

                {/* Financial Summary */}
                <div className="space-y-2 pt-4 border-t border-border">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Total Sales</span>
                    <span className="font-medium text-foreground">{formatCurrency(agent.totalSales)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Total Commission</span>
                    <span className="font-medium text-success">{formatCurrency(agent.totalCommission)}</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </>
      )}

      {activeTab === 'commissions' && (
        <div className="glass rounded-xl overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border bg-muted/50">
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Agent</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Customer</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Plan</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Sale Amount</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Commission</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Status</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Date</th>
              </tr>
            </thead>
            <tbody>
              {commissions.map((commission) => (
                <tr key={commission.id} className="border-b border-border last:border-b-0 hover:bg-muted/30">
                  <td className="px-4 py-3">
                    <span className="text-sm font-medium text-foreground">{commission.agentName}</span>
                  </td>
                  <td className="px-4 py-3">
                    <span className="text-sm text-foreground">{commission.customerName}</span>
                  </td>
                  <td className="px-4 py-3">
                    <span className="text-sm text-foreground">{commission.planName}</span>
                  </td>
                  <td className="px-4 py-3">
                    <span className="text-sm text-foreground">{formatCurrency(commission.saleAmount)}</span>
                  </td>
                  <td className="px-4 py-3">
                    <span className="text-sm font-medium text-success">{formatCurrency(commission.commissionAmount)}</span>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-1 rounded-full text-xs ${getCommissionStatusColor(commission.status)}`}>
                      {commission.status}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <span className="text-sm text-muted-foreground">{formatDate(commission.createdAt)}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Agent Detail Modal */}
      {selectedAgent && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
          onClick={() => setSelectedAgent(null)}
        >
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            onClick={(e) => e.stopPropagation()}
            className="glass rounded-xl p-6 max-w-lg w-full"
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-semibold text-foreground">Agent Details</h3>
              <button onClick={() => setSelectedAgent(null)} className="p-2 hover:bg-muted rounded-lg">
                <span className="text-2xl">&times;</span>
              </button>
            </div>
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center">
                  <span className="text-2xl font-bold text-primary">{selectedAgent.name.charAt(0)}</span>
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-foreground">{selectedAgent.name}</h4>
                  <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(selectedAgent.status)}`}>
                    {selectedAgent.status}
                  </span>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="p-3 bg-muted/50 rounded-lg">
                  <p className="text-sm text-muted-foreground">Phone</p>
                  <p className="text-sm font-medium text-foreground">{selectedAgent.phone}</p>
                </div>
                <div className="p-3 bg-muted/50 rounded-lg">
                  <p className="text-sm text-muted-foreground">Email</p>
                  <p className="text-sm text-foreground">{selectedAgent.email}</p>
                </div>
                <div className="p-3 bg-muted/50 rounded-lg">
                  <p className="text-sm text-muted-foreground">Location</p>
                  <p className="text-sm text-foreground">{selectedAgent.location}</p>
                </div>
                <div className="p-3 bg-muted/50 rounded-lg">
                  <p className="text-sm text-muted-foreground">Commission Rate</p>
                  <p className="text-sm font-medium text-primary">{selectedAgent.commissionRate}%</p>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="p-3 bg-muted/50 rounded-lg text-center">
                  <p className="text-xl font-bold text-foreground">{selectedAgent.customersReferred}</p>
                  <p className="text-xs text-muted-foreground">Customers</p>
                </div>
                <div className="p-3 bg-muted/50 rounded-lg text-center">
                  <p className="text-xl font-bold text-secondary">{formatCurrency(selectedAgent.totalSales)}</p>
                  <p className="text-xs text-muted-foreground">Total Sales</p>
                </div>
                <div className="p-3 bg-muted/50 rounded-lg text-center">
                  <p className="text-xl font-bold text-success">{formatCurrency(selectedAgent.totalCommission)}</p>
                  <p className="text-xs text-muted-foreground">Commission</p>
                </div>
              </div>

              <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                <span className="text-sm text-muted-foreground">Joined Date</span>
                <span className="text-sm text-foreground">{formatDate(selectedAgent.joinedDate)}</span>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </div>
  );
}
