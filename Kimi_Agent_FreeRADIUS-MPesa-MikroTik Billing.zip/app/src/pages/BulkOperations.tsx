import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Send, 
  FileText, 
  MessageSquare, 
  Users, 
  AlertCircle,
  Mail,
  Search,
  RefreshCw,
  X
} from 'lucide-react';

interface BulkOperation {
  id: string;
  type: 'sms' | 'email' | 'invoice';
  name: string;
  status: 'pending' | 'running' | 'completed' | 'failed';
  progress: number;
  total: number;
  processed: number;
  createdAt: string;
}

const mockOperations: BulkOperation[] = [
  { id: '1', type: 'sms', name: 'Payment Reminder - June', status: 'completed', progress: 100, total: 156, processed: 156, createdAt: '2024-06-15 10:30' },
  { id: '2', type: 'invoice', name: 'Monthly Invoice Generation', status: 'running', progress: 65, total: 200, processed: 130, createdAt: '2024-06-15 09:00' },
  { id: '3', type: 'email', name: 'Service Maintenance Notice', status: 'pending', progress: 0, total: 500, processed: 0, createdAt: '2024-06-15 11:00' },
];

const smsTemplates = [
  { id: '1', name: 'Payment Reminder', content: 'Dear {name}, your internet bill of KES {amount} is due on {dueDate}. Please pay to avoid disconnection. Pay via M-Pesa: {paybill}' },
  { id: '2', name: 'Welcome Message', content: 'Welcome to ISP Solutions, {name}! Your {plan} is now active. Username: {username}. Support: 0700123456' },
  { id: '3', name: 'Expiry Notice', content: 'Hi {name}, your internet service expires in {days} days. Renew now to avoid interruption. Paybill: 123456' },
  { id: '4', name: 'Maintenance Alert', content: 'Scheduled maintenance on {date} from {startTime} to {endTime}. Service may be interrupted. We apologize for inconvenience.' },
];

export default function BulkOperations() {
  const [activeTab, setActiveTab] = useState<'sms' | 'email' | 'invoice'>('sms');
  const [operations, setOperations] = useState<BulkOperation[]>(mockOperations);
  const [showNewOperation, setShowNewOperation] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState(smsTemplates[0]);
  const [message, setMessage] = useState(smsTemplates[0].content);
  const [filterStatus, setFilterStatus] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const handleSendBulkSMS = () => {
    const newOp: BulkOperation = {
      id: Date.now().toString(),
      type: 'sms',
      name: 'Bulk SMS Campaign',
      status: 'running',
      progress: 0,
      total: 156,
      processed: 0,
      createdAt: new Date().toLocaleString(),
    };
    setOperations([newOp, ...operations]);
    setShowNewOperation(false);
    
    // Simulate progress
    let progress = 0;
    const interval = setInterval(() => {
      progress += 10;
      setOperations(prev => prev.map(op => 
        op.id === newOp.id 
          ? { ...op, progress, processed: Math.floor((progress / 100) * op.total) }
          : op
      ));
      if (progress >= 100) {
        clearInterval(interval);
        setOperations(prev => prev.map(op => 
          op.id === newOp.id ? { ...op, status: 'completed' } : op
        ));
      }
    }, 500);
  };

  const getStatusColor = (status: BulkOperation['status']) => {
    switch (status) {
      case 'completed': return 'bg-success/20 text-success';
      case 'running': return 'bg-primary/20 text-primary';
      case 'pending': return 'bg-warning/20 text-warning';
      case 'failed': return 'bg-destructive/20 text-destructive';
    }
  };

  const getTypeIcon = (type: BulkOperation['type']) => {
    switch (type) {
      case 'sms': return <MessageSquare className="w-4 h-4" />;
      case 'email': return <Mail className="w-4 h-4" />;
      case 'invoice': return <FileText className="w-4 h-4" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Bulk Operations Center</h2>
          <p className="text-muted-foreground">Mass SMS, email campaigns, and batch invoicing</p>
        </div>
        <button
          onClick={() => setShowNewOperation(true)}
          className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
        >
          <Send className="w-4 h-4" />
          New Operation
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary/20 rounded-lg flex items-center justify-center">
              <MessageSquare className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">SMS Sent Today</p>
              <p className="text-2xl font-bold text-foreground">1,247</p>
            </div>
          </div>
        </div>
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-secondary/20 rounded-lg flex items-center justify-center">
              <Mail className="w-5 h-5 text-secondary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Emails Sent</p>
              <p className="text-2xl font-bold text-foreground">856</p>
            </div>
          </div>
        </div>
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-success/20 rounded-lg flex items-center justify-center">
              <FileText className="w-5 h-5 text-success" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Invoices Generated</p>
              <p className="text-2xl font-bold text-foreground">200</p>
            </div>
          </div>
        </div>
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-warning/20 rounded-lg flex items-center justify-center">
              <RefreshCw className="w-5 h-5 text-warning animate-spin" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Active Operations</p>
              <p className="text-2xl font-bold text-foreground">3</p>
            </div>
          </div>
        </div>
      </div>

      {/* Operations List */}
      <div className="glass rounded-xl overflow-hidden">
        <div className="p-4 border-b border-border flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search operations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-muted border border-border rounded-lg text-sm"
            />
          </div>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-4 py-2 bg-muted border border-border rounded-lg text-sm"
          >
            <option value="all">All Status</option>
            <option value="running">Running</option>
            <option value="completed">Completed</option>
            <option value="pending">Pending</option>
            <option value="failed">Failed</option>
          </select>
        </div>

        <div className="divide-y divide-border">
          {operations.map((op) => (
            <motion.div
              key={op.id}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="p-4 hover:bg-muted/30 transition-colors"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                    op.type === 'sms' ? 'bg-primary/20 text-primary' :
                    op.type === 'email' ? 'bg-secondary/20 text-secondary' :
                    'bg-success/20 text-success'
                  }`}>
                    {getTypeIcon(op.type)}
                  </div>
                  <div>
                    <h4 className="font-medium text-foreground">{op.name}</h4>
                    <p className="text-sm text-muted-foreground">{op.createdAt}</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(op.status)}`}>
                      {op.status}
                    </span>
                    <p className="text-sm text-muted-foreground mt-1">
                      {op.processed} / {op.total}
                    </p>
                  </div>
                </div>
              </div>
              {op.status === 'running' && (
                <div className="mt-3">
                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                    <motion.div
                      className="h-full bg-primary rounded-full"
                      initial={{ width: 0 }}
                      animate={{ width: `${op.progress}%` }}
                      transition={{ duration: 0.5 }}
                    />
                  </div>
                </div>
              )}
            </motion.div>
          ))}
        </div>
      </div>

      {/* New Operation Modal */}
      <AnimatePresence>
        {showNewOperation && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
            onClick={() => setShowNewOperation(false)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="glass rounded-xl p-6 max-w-2xl w-full max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-semibold text-foreground">New Bulk Operation</h3>
                <button onClick={() => setShowNewOperation(false)} className="p-2 hover:bg-muted rounded-lg">
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Tabs */}
              <div className="flex gap-2 mb-6">
                {(['sms', 'email', 'invoice'] as const).map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                      activeTab === tab 
                        ? 'bg-primary text-primary-foreground' 
                        : 'bg-muted text-foreground hover:bg-muted/80'
                    }`}
                  >
                    {tab === 'sms' && <MessageSquare className="w-4 h-4" />}
                    {tab === 'email' && <Mail className="w-4 h-4" />}
                    {tab === 'invoice' && <FileText className="w-4 h-4" />}
                    <span className="capitalize">{tab}</span>
                  </button>
                ))}
              </div>

              {activeTab === 'sms' && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">Select Template</label>
                    <select
                      value={selectedTemplate.id}
                      onChange={(e) => {
                        const template = smsTemplates.find(t => t.id === e.target.value);
                        if (template) {
                          setSelectedTemplate(template);
                          setMessage(template.content);
                        }
                      }}
                      className="w-full px-4 py-2 bg-muted border border-border rounded-lg"
                    >
                      {smsTemplates.map((t) => (
                        <option key={t.id} value={t.id}>{t.name}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">Message</label>
                    <textarea
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      rows={4}
                      className="w-full px-4 py-2 bg-muted border border-border rounded-lg"
                    />
                    <p className="text-xs text-muted-foreground mt-1">
                      {message.length} characters | {Math.ceil(message.length / 160)} SMS
                    </p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">Recipients</label>
                    <div className="flex gap-2 mb-2">
                      <button className="px-3 py-1 bg-muted rounded-full text-sm">All Customers</button>
                      <button className="px-3 py-1 bg-muted rounded-full text-sm">Active Only</button>
                      <button className="px-3 py-1 bg-muted rounded-full text-sm">Expired</button>
                      <button className="px-3 py-1 bg-muted rounded-full text-sm">Unpaid</button>
                    </div>
                    <div className="p-3 bg-muted/50 rounded-lg">
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Users className="w-4 h-4" />
                        <span>156 customers will receive this message</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex justify-end gap-3 pt-4">
                    <button
                      onClick={() => setShowNewOperation(false)}
                      className="px-4 py-2 text-foreground hover:bg-muted rounded-lg"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleSendBulkSMS}
                      className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 flex items-center gap-2"
                    >
                      <Send className="w-4 h-4" />
                      Send SMS
                    </button>
                  </div>
                </div>
              )}

              {activeTab === 'email' && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">Email Subject</label>
                    <input
                      type="text"
                      placeholder="Enter subject..."
                      className="w-full px-4 py-2 bg-muted border border-border rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">Email Body</label>
                    <textarea
                      rows={6}
                      placeholder="Enter email content..."
                      className="w-full px-4 py-2 bg-muted border border-border rounded-lg"
                    />
                  </div>
                  <div className="flex justify-end gap-3 pt-4">
                    <button
                      onClick={() => setShowNewOperation(false)}
                      className="px-4 py-2 text-foreground hover:bg-muted rounded-lg"
                    >
                      Cancel
                    </button>
                    <button className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 flex items-center gap-2">
                      <Mail className="w-4 h-4" />
                      Send Emails
                    </button>
                  </div>
                </div>
              )}

              {activeTab === 'invoice' && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">Invoice Period</label>
                    <select className="w-full px-4 py-2 bg-muted border border-border rounded-lg">
                      <option>June 2024</option>
                      <option>May 2024</option>
                      <option>Custom Range</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">Due Date</label>
                    <input
                      type="date"
                      className="w-full px-4 py-2 bg-muted border border-border rounded-lg"
                    />
                  </div>
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <AlertCircle className="w-5 h-5 text-warning" />
                      <p className="text-sm text-muted-foreground">
                        This will generate invoices for 200 active customers
                      </p>
                    </div>
                  </div>
                  <div className="flex justify-end gap-3 pt-4">
                    <button
                      onClick={() => setShowNewOperation(false)}
                      className="px-4 py-2 text-foreground hover:bg-muted rounded-lg"
                    >
                      Cancel
                    </button>
                    <button className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 flex items-center gap-2">
                      <FileText className="w-4 h-4" />
                      Generate Invoices
                    </button>
                  </div>
                </div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
