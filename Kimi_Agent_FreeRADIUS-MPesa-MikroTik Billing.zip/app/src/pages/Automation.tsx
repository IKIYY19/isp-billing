import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Zap, 
  Clock, 
  Calendar, 
  Bell, 
  Power, 
  CreditCard, 
  Mail, 
  MessageSquare,
  Plus,
  Edit2,
  Trash2,
  Play,
  Pause,
  History,
  CheckCircle,
  AlertTriangle
} from 'lucide-react';

interface Workflow {
  id: string;
  name: string;
  description: string;
  trigger: string;
  actions: string[];
  isActive: boolean;
  lastRun?: string;
  nextRun?: string;
  runCount: number;
}

const mockWorkflows: Workflow[] = [
  {
    id: '1',
    name: 'Auto-Suspend Expired Accounts',
    description: 'Automatically suspend accounts 7 days after expiry',
    trigger: 'Account expires + 7 days',
    actions: ['Suspend account', 'Send notification SMS', 'Send email'],
    isActive: true,
    lastRun: '2024-06-15 08:00',
    nextRun: '2024-06-16 08:00',
    runCount: 45,
  },
  {
    id: '2',
    name: 'Payment Reminder 3 Days Before',
    description: 'Send SMS and email 3 days before due date',
    trigger: '3 days before invoice due',
    actions: ['Send SMS reminder', 'Send email reminder'],
    isActive: true,
    lastRun: '2024-06-15 09:00',
    nextRun: '2024-06-16 09:00',
    runCount: 128,
  },
  {
    id: '3',
    name: 'Welcome New Customer',
    description: 'Send welcome message to new signups',
    trigger: 'New customer registered',
    actions: ['Send welcome SMS', 'Send email with credentials'],
    isActive: true,
    lastRun: '2024-06-15 14:30',
    runCount: 23,
  },
  {
    id: '4',
    name: 'Monthly Invoice Generation',
    description: 'Generate invoices on 1st of every month',
    trigger: '1st of month at 00:00',
    actions: ['Generate invoices', 'Send email notifications'],
    isActive: false,
    lastRun: '2024-06-01 00:00',
    nextRun: '2024-07-01 00:00',
    runCount: 6,
  },
];

const triggerOptions = [
  { value: 'expiry', label: 'Account Expiry', icon: Calendar },
  { value: 'payment', label: 'Payment Due', icon: CreditCard },
  { value: 'signup', label: 'New Signup', icon: CheckCircle },
  { value: 'schedule', label: 'Scheduled', icon: Clock },
];

const actionOptions = [
  { value: 'suspend', label: 'Suspend Account', icon: Power },
  { value: 'sms', label: 'Send SMS', icon: MessageSquare },
  { value: 'email', label: 'Send Email', icon: Mail },
  { value: 'notify', label: 'Send Notification', icon: Bell },
];

export default function Automation() {
  const [workflows, setWorkflows] = useState<Workflow[]>(mockWorkflows);
  const [showNewWorkflow, setShowNewWorkflow] = useState(false);
  const [_editingWorkflow, _setEditingWorkflow] = useState<Workflow | null>(null);

  const toggleWorkflow = (id: string) => {
    setWorkflows(prev => prev.map(w => 
      w.id === id ? { ...w, isActive: !w.isActive } : w
    ));
  };

  const deleteWorkflow = (id: string) => {
    setWorkflows(prev => prev.filter(w => w.id !== id));
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Automation Workflows</h2>
          <p className="text-muted-foreground">Automate repetitive tasks and notifications</p>
        </div>
        <button
          onClick={() => setShowNewWorkflow(true)}
          className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
        >
          <Plus className="w-4 h-4" />
          Create Workflow
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-success/20 rounded-lg flex items-center justify-center">
              <Zap className="w-5 h-5 text-success" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Active Workflows</p>
              <p className="text-2xl font-bold text-foreground">{workflows.filter(w => w.isActive).length}</p>
            </div>
          </div>
        </div>
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary/20 rounded-lg flex items-center justify-center">
              <History className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Total Executions</p>
              <p className="text-2xl font-bold text-foreground">{workflows.reduce((sum, w) => sum + w.runCount, 0)}</p>
            </div>
          </div>
        </div>
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-secondary/20 rounded-lg flex items-center justify-center">
              <Clock className="w-5 h-5 text-secondary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Time Saved</p>
              <p className="text-2xl font-bold text-foreground">48h</p>
            </div>
          </div>
        </div>
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-warning/20 rounded-lg flex items-center justify-center">
              <AlertTriangle className="w-5 h-5 text-warning" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Failed Runs</p>
              <p className="text-2xl font-bold text-foreground">2</p>
            </div>
          </div>
        </div>
      </div>

      {/* Workflows List */}
      <div className="space-y-4">
        {workflows.map((workflow, index) => (
          <motion.div
            key={workflow.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="glass rounded-xl p-5"
          >
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              <div className="flex items-start gap-4">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                  workflow.isActive ? 'bg-success/20' : 'bg-muted'
                }`}>
                  <Zap className={`w-6 h-6 ${workflow.isActive ? 'text-success' : 'text-muted-foreground'}`} />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground">{workflow.name}</h3>
                  <p className="text-sm text-muted-foreground">{workflow.description}</p>
                  <div className="flex flex-wrap gap-2 mt-2">
                    <span className="px-2 py-1 bg-muted rounded-full text-xs text-muted-foreground flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {workflow.trigger}
                    </span>
                    {workflow.actions.map((action, i) => (
                      <span key={i} className="px-2 py-1 bg-primary/10 rounded-full text-xs text-primary">
                        {action}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-6">
                <div className="text-right hidden md:block">
                  <p className="text-sm text-muted-foreground">Last Run</p>
                  <p className="text-sm text-foreground">{workflow.lastRun || 'Never'}</p>
                  {workflow.nextRun && (
                    <>
                      <p className="text-sm text-muted-foreground mt-1">Next Run</p>
                      <p className="text-sm text-primary">{workflow.nextRun}</p>
                    </>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {/* Edit workflow functionality to be implemented */}}
                    className="p-2 hover:bg-muted rounded-lg text-muted-foreground hover:text-foreground transition-colors"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => deleteWorkflow(workflow.id)}
                    className="p-2 hover:bg-destructive/10 rounded-lg text-muted-foreground hover:text-destructive transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => toggleWorkflow(workflow.id)}
                    className={`p-2 rounded-lg transition-colors ${
                      workflow.isActive 
                        ? 'bg-success/20 text-success hover:bg-success/30' 
                        : 'bg-muted text-muted-foreground hover:bg-muted/80'
                    }`}
                  >
                    {workflow.isActive ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            </div>

            {/* Execution Stats */}
            <div className="mt-4 pt-4 border-t border-border flex items-center gap-6">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-success" />
                <span className="text-sm text-muted-foreground">{workflow.runCount} successful runs</span>
              </div>
              <div className="flex items-center gap-2">
                <div className={`w-2 h-2 rounded-full ${workflow.isActive ? 'bg-success animate-pulse' : 'bg-muted'}`} />
                <span className="text-sm text-muted-foreground">{workflow.isActive ? 'Active' : 'Paused'}</span>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* New Workflow Modal */}
      {showNewWorkflow && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
          onClick={() => setShowNewWorkflow(false)}
        >
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            onClick={(e) => e.stopPropagation()}
            className="glass rounded-xl p-6 max-w-2xl w-full max-h-[90vh] overflow-y-auto"
          >
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-semibold text-foreground">Create Workflow</h3>
              <button onClick={() => setShowNewWorkflow(false)} className="p-2 hover:bg-muted rounded-lg">
                <span className="text-2xl">&times;</span>
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-foreground mb-1">Workflow Name</label>
                <input
                  type="text"
                  placeholder="e.g., Payment Reminder"
                  className="w-full px-4 py-2 bg-muted border border-border rounded-lg"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-1">Description</label>
                <textarea
                  placeholder="What does this workflow do?"
                  rows={2}
                  className="w-full px-4 py-2 bg-muted border border-border rounded-lg"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Trigger</label>
                <div className="grid grid-cols-2 gap-2">
                  {triggerOptions.map((trigger) => {
                    const Icon = trigger.icon;
                    return (
                      <button
                        key={trigger.value}
                        className="flex items-center gap-2 p-3 bg-muted rounded-lg hover:bg-muted/80 transition-colors text-left"
                      >
                        <Icon className="w-4 h-4 text-primary" />
                        <span className="text-sm">{trigger.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Actions</label>
                <div className="space-y-2">
                  {actionOptions.map((action) => {
                    const Icon = action.icon;
                    return (
                      <label key={action.value} className="flex items-center gap-3 p-3 bg-muted rounded-lg cursor-pointer hover:bg-muted/80 transition-colors">
                        <input type="checkbox" className="w-4 h-4 rounded border-border" />
                        <Icon className="w-4 h-4 text-secondary" />
                        <span className="text-sm">{action.label}</span>
                      </label>
                    );
                  })}
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4">
                <button
                  onClick={() => setShowNewWorkflow(false)}
                  className="px-4 py-2 text-foreground hover:bg-muted rounded-lg"
                >
                  Cancel
                </button>
                <button className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 flex items-center gap-2">
                  <Zap className="w-4 h-4" />
                  Create Workflow
                </button>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}

      {/* Tips Section */}
      <div className="glass rounded-xl p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
          <Zap className="w-5 h-5 text-warning" />
          Automation Tips
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 bg-muted/50 rounded-lg">
            <h4 className="font-medium text-foreground mb-2">Payment Reminders</h4>
            <p className="text-sm text-muted-foreground">
              Set up reminders 3 days before and on the due date to reduce late payments by up to 40%.
            </p>
          </div>
          <div className="p-4 bg-muted/50 rounded-lg">
            <h4 className="font-medium text-foreground mb-2">Auto-Suspend</h4>
            <p className="text-sm text-muted-foreground">
              Automatically suspend accounts after a grace period to encourage timely payments.
            </p>
          </div>
          <div className="p-4 bg-muted/50 rounded-lg">
            <h4 className="font-medium text-foreground mb-2">Welcome Series</h4>
            <p className="text-sm text-muted-foreground">
              Send a series of welcome messages to new customers to improve retention.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
