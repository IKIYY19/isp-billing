import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Network, 
  Power, 
  Clock, 
  ArrowUp, 
  ArrowDown,
  Search,
  X,
  Activity,
  ArrowUpDown
} from 'lucide-react';
import type { PPPoESession } from '../types';
import { formatBytes, formatDuration } from '../lib/utils';

// Mock data
const mockSessions: PPPoESession[] = [
  {
    id: '1',
    customerId: '1',
    username: 'john_doe',
    ipAddress: '192.168.1.100',
    macAddress: '00:1A:2B:3C:4D:5E',
    status: 'active',
    remoteIp: '10.0.0.5',
    service: 'pppoe-service-1',
    callerId: '00:1A:2B:3C:4D:5E',
    uptime: '86400',
    bytesIn: 1073741824,
    bytesOut: 536870912,
    packetsIn: 1250000,
    packetsOut: 890000,
    connectedSince: '2024-06-14T10:30:00',
  },
  {
    id: '2',
    customerId: '5',
    username: 'david_brown',
    ipAddress: '192.168.1.110',
    macAddress: '00:1A:2B:3C:4D:60',
    status: 'active',
    remoteIp: '10.0.0.8',
    service: 'pppoe-service-1',
    callerId: '00:1A:2B:3C:4D:60',
    uptime: '43200',
    bytesIn: 536870912,
    bytesOut: 268435456,
    packetsIn: 625000,
    packetsOut: 445000,
    connectedSince: '2024-06-14T22:30:00',
  },
  {
    id: '3',
    customerId: '6',
    username: 'emma_wilson',
    ipAddress: '192.168.1.115',
    macAddress: '00:1A:2B:3C:4D:65',
    status: 'active',
    remoteIp: '10.0.0.12',
    service: 'pppoe-service-2',
    callerId: '00:1A:2B:3C:4D:65',
    uptime: '172800',
    bytesIn: 2147483648,
    bytesOut: 1073741824,
    packetsIn: 2500000,
    packetsOut: 1780000,
    connectedSince: '2024-06-13T10:30:00',
  },
  {
    id: '4',
    customerId: '7',
    username: 'james_taylor',
    ipAddress: '192.168.1.120',
    macAddress: '00:1A:2B:3C:4D:70',
    status: 'active',
    remoteIp: '10.0.0.15',
    service: 'pppoe-service-1',
    callerId: '00:1A:2B:3C:4D:70',
    uptime: '21600',
    bytesIn: 268435456,
    bytesOut: 134217728,
    packetsIn: 312500,
    packetsOut: 222500,
    connectedSince: '2024-06-15T04:30:00',
  },
  {
    id: '5',
    customerId: '8',
    username: 'lisa_anderson',
    ipAddress: '192.168.1.125',
    macAddress: '00:1A:2B:3C:4D:75',
    status: 'active',
    remoteIp: '10.0.0.18',
    service: 'pppoe-service-2',
    callerId: '00:1A:2B:3C:4D:75',
    uptime: '691200',
    bytesIn: 4294967296,
    bytesOut: 2147483648,
    packetsIn: 5000000,
    packetsOut: 3560000,
    connectedSince: '2024-06-07T10:30:00',
  },
];

export default function PPPoESessions() {
  const [sessions, setSessions] = useState<PPPoESession[]>(mockSessions);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterService, setFilterService] = useState<string>('all');
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [selectedSession, setSelectedSession] = useState<PPPoESession | null>(null);

  const filteredSessions = sessions.filter(session => {
    const matchesSearch = 
      session.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
      session.ipAddress.includes(searchQuery) ||
      session.callerId.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesService = filterService === 'all' || session.service === filterService;
    
    return matchesSearch && matchesService;
  });

  const handleViewDetails = (session: PPPoESession) => {
    setSelectedSession(session);
    setShowDetailsModal(true);
  };

  const handleDisconnect = (sessionId: string) => {
    setSessions(prev => prev.filter(s => s.id !== sessionId));
  };

  const totalBandwidth = sessions.reduce((sum, s) => sum + s.bytesIn + s.bytesOut, 0);
  const avgUptime = sessions.reduce((sum, s) => sum + parseInt(s.uptime), 0) / sessions.length || 0;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground">PPPoE Sessions</h2>
          <p className="text-muted-foreground">Monitor active PPPoE connections</p>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary/20 rounded-lg flex items-center justify-center">
              <Network className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Active Sessions</p>
              <p className="text-2xl font-bold text-foreground">{sessions.length}</p>
            </div>
          </div>
        </div>
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-success/20 rounded-lg flex items-center justify-center">
              <ArrowUpDown className="w-5 h-5 text-success" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Total Bandwidth</p>
              <p className="text-2xl font-bold text-foreground">{formatBytes(totalBandwidth)}</p>
            </div>
          </div>
        </div>
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-secondary/20 rounded-lg flex items-center justify-center">
              <Clock className="w-5 h-5 text-secondary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Avg Uptime</p>
              <p className="text-2xl font-bold text-foreground">{formatDuration(avgUptime)}</p>
            </div>
          </div>
        </div>
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-warning/20 rounded-lg flex items-center justify-center">
              <Activity className="w-5 h-5 text-warning" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Avg Load</p>
              <p className="text-2xl font-bold text-foreground">42%</p>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="glass rounded-xl p-4">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search sessions..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-muted border border-border rounded-lg text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
            />
          </div>
          <select
            value={filterService}
            onChange={(e) => setFilterService(e.target.value)}
            className="px-4 py-2 bg-muted border border-border rounded-lg text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
          >
            <option value="all">All Services</option>
            <option value="pppoe-service-1">PPPoE Service 1</option>
            <option value="pppoe-service-2">PPPoE Service 2</option>
          </select>
        </div>
      </div>

      {/* Sessions Table */}
      <div className="glass rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border bg-muted/50">
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Username</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">IP Address</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Service</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Uptime</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Traffic</th>
                <th className="px-4 py-3 text-right text-sm font-medium text-muted-foreground">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredSessions.map((session, index) => (
                <motion.tr
                  key={session.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="border-b border-border last:border-b-0 hover:bg-muted/30 transition-colors"
                >
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
                        <span className="text-sm font-semibold text-primary">
                          {session.username.charAt(0).toUpperCase()}
                        </span>
                      </div>
                      <span className="font-medium text-foreground">{session.username}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-foreground">{session.ipAddress}</span>
                      </div>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <span>Remote: {session.remoteIp}</span>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className="text-sm text-foreground">{session.service}</span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-muted-foreground" />
                      <span className="text-sm text-foreground">{formatDuration(parseInt(session.uptime))}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <ArrowDown className="w-3 h-3 text-success" />
                        <span className="text-xs text-foreground">{formatBytes(session.bytesIn)}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <ArrowUp className="w-3 h-3 text-primary" />
                        <span className="text-xs text-foreground">{formatBytes(session.bytesOut)}</span>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => handleViewDetails(session)}
                        className="px-3 py-1.5 bg-muted text-foreground rounded-lg hover:bg-muted/80 transition-colors text-sm"
                      >
                        Details
                      </button>
                      <button
                        onClick={() => handleDisconnect(session.id)}
                        className="p-2 bg-destructive/10 text-destructive rounded-lg hover:bg-destructive/20 transition-colors"
                        title="Disconnect"
                      >
                        <Power className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
        {filteredSessions.length === 0 && (
          <div className="p-8 text-center text-muted-foreground">
            No active PPPoE sessions found.
          </div>
        )}
      </div>

      {/* Session Details Modal */}
      <AnimatePresence>
        {showDetailsModal && selectedSession && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
            onClick={() => setShowDetailsModal(false)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="glass rounded-xl p-6 max-w-lg w-full"
            >
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center">
                    <Network className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-foreground">{selectedSession.username}</h3>
                    <p className="text-sm text-muted-foreground">PPPoE Session</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowDetailsModal(false)}
                  className="p-2 hover:bg-muted rounded-lg transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-4">
                {/* Connection Info */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-3 bg-muted/50 rounded-lg">
                    <p className="text-sm text-muted-foreground mb-1">IP Address</p>
                    <p className="text-sm font-medium text-foreground">{selectedSession.ipAddress}</p>
                  </div>
                  <div className="p-3 bg-muted/50 rounded-lg">
                    <p className="text-sm text-muted-foreground mb-1">Remote IP</p>
                    <p className="text-sm font-medium text-foreground">{selectedSession.remoteIp}</p>
                  </div>
                  <div className="p-3 bg-muted/50 rounded-lg">
                    <p className="text-sm text-muted-foreground mb-1">Service</p>
                    <p className="text-sm font-medium text-foreground">{selectedSession.service}</p>
                  </div>
                  <div className="p-3 bg-muted/50 rounded-lg">
                    <p className="text-sm text-muted-foreground mb-1">Caller ID</p>
                    <p className="text-sm font-medium text-foreground font-mono">{selectedSession.callerId}</p>
                  </div>
                </div>

                {/* Uptime */}
                <div className="p-4 bg-muted/50 rounded-lg">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Clock className="w-5 h-5 text-secondary" />
                      <span className="text-sm text-muted-foreground">Uptime</span>
                    </div>
                    <span className="text-lg font-semibold text-foreground">
                      {formatDuration(parseInt(selectedSession.uptime))}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Connected since: {new Date(selectedSession.connectedSince).toLocaleString()}
                  </p>
                </div>

                {/* Traffic Stats */}
                <div className="border-t border-border pt-4">
                  <p className="text-sm font-medium text-foreground mb-3">Traffic Statistics</p>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-3 bg-muted/50 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <ArrowDown className="w-4 h-4 text-success" />
                        <span className="text-sm text-muted-foreground">Download</span>
                      </div>
                      <p className="text-lg font-semibold text-foreground">{formatBytes(selectedSession.bytesIn)}</p>
                      <p className="text-xs text-muted-foreground">{selectedSession.packetsIn.toLocaleString()} packets</p>
                    </div>
                    <div className="p-3 bg-muted/50 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <ArrowUp className="w-4 h-4 text-primary" />
                        <span className="text-sm text-muted-foreground">Upload</span>
                      </div>
                      <p className="text-lg font-semibold text-foreground">{formatBytes(selectedSession.bytesOut)}</p>
                      <p className="text-xs text-muted-foreground">{selectedSession.packetsOut.toLocaleString()} packets</p>
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex justify-end gap-3 pt-4">
                  <button
                    onClick={() => setShowDetailsModal(false)}
                    className="px-4 py-2 text-foreground hover:bg-muted rounded-lg transition-colors"
                  >
                    Close
                  </button>
                  <button 
                    onClick={() => {
                      handleDisconnect(selectedSession.id);
                      setShowDetailsModal(false);
                    }}
                    className="px-4 py-2 bg-destructive text-destructive-foreground rounded-lg hover:bg-destructive/90 transition-colors flex items-center gap-2"
                  >
                    <Power className="w-4 h-4" />
                    Disconnect
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
