import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  CreditCard, 
  FileText, 
  Activity, 
  Wifi, 
  Clock, 
  Calendar,
  ArrowUp,
  ArrowDown,
  Phone,
  Mail,
  CheckCircle,
  AlertCircle,
  LogOut,
  Download,
  MessageSquare,
  Zap
} from 'lucide-react';
import { 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar
} from 'recharts';
import { formatCurrency, formatDate } from '../lib/utils';

// Mock customer data
const customerData = {
  name: 'John Doe',
  username: 'john_doe',
  email: 'john@example.com',
  phone: '+254712345678',
  address: '123 Kimathi Street, Nairobi',
  plan: 'Premium 10Mbps',
  downloadSpeed: 10,
  uploadSpeed: 5,
  monthlyPrice: 2500,
  status: 'active',
  expiryDate: '2024-12-31',
  daysRemaining: 168,
  balance: 0,
  dataUsed: 450.5,
  dataLimit: 1000,
};

const usageData = [
  { day: 'Mon', download: 12.5, upload: 3.2 },
  { day: 'Tue', download: 15.8, upload: 4.1 },
  { day: 'Wed', download: 10.2, upload: 2.8 },
  { day: 'Thu', download: 18.5, upload: 5.2 },
  { day: 'Fri', download: 22.1, upload: 6.5 },
  { day: 'Sat', download: 28.3, upload: 8.1 },
  { day: 'Sun', download: 25.7, upload: 7.3 },
];

const invoices = [
  { id: 'INV-2024-156', date: '2024-06-01', amount: 2500, status: 'paid', paidDate: '2024-06-05' },
  { id: 'INV-2024-130', date: '2024-05-01', amount: 2500, status: 'paid', paidDate: '2024-05-03' },
  { id: 'INV-2024-105', date: '2024-04-01', amount: 2500, status: 'paid', paidDate: '2024-04-02' },
];

const payments = [
  { id: 'PAY-789', date: '2024-06-05', amount: 2500, method: 'M-Pesa', transactionId: 'MPESA123456' },
  { id: 'PAY-654', date: '2024-05-03', amount: 2500, method: 'M-Pesa', transactionId: 'MPESA789012' },
  { id: 'PAY-543', date: '2024-04-02', amount: 2500, method: 'Bank Transfer', transactionId: 'BT456789' },
];

const announcements = [
  { id: 1, title: 'Scheduled Maintenance', date: '2024-06-20', content: 'Network maintenance on June 20th from 2AM to 4AM. Service may be interrupted.' },
  { id: 2, title: 'New Plan Available', date: '2024-06-15', content: 'Upgrade to our new Ultra 50Mbps plan with unlimited data!' },
];

export default function CustomerPortal() {
  const [activeTab, setActiveTab] = useState<'overview' | 'usage' | 'invoices' | 'payments' | 'support'>('overview');
  const [_showPayModal, setShowPayModal] = useState(false);
  const [_showTicketModal, setShowTicketModal] = useState(false);

  const dataUsagePercent = (customerData.dataUsed / customerData.dataLimit) * 100;

  const TabButton = ({ id, label, icon: Icon }: { id: typeof activeTab; label: string; icon: any }) => (
    <button
      onClick={() => setActiveTab(id)}
      className={`flex items-center gap-2 px-4 py-3 rounded-lg transition-all ${
        activeTab === id 
          ? 'bg-primary text-primary-foreground' 
          : 'text-muted-foreground hover:bg-muted hover:text-foreground'
      }`}
    >
      <Icon className="w-5 h-5" />
      <span className="hidden md:inline">{label}</span>
    </button>
  );

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="glass-strong border-b border-border sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
                <Wifi className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="font-bold text-lg text-gradient">ISP Solutions</h1>
                <p className="text-xs text-muted-foreground">Customer Portal</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-success/10 rounded-full">
                <div className="w-2 h-2 rounded-full bg-success animate-pulse" />
                <span className="text-sm text-success">Online</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                  <span className="text-lg font-bold text-primary">{customerData.name.charAt(0)}</span>
                </div>
                <div className="hidden md:block">
                  <p className="text-sm font-medium text-foreground">{customerData.name}</p>
                  <p className="text-xs text-muted-foreground">{customerData.username}</p>
                </div>
              </div>
              <button className="p-2 hover:bg-muted rounded-lg text-muted-foreground">
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Sidebar */}
          <aside className="lg:w-64 flex-shrink-0">
            <div className="glass rounded-xl p-2 space-y-1 sticky top-24">
              <TabButton id="overview" label="Overview" icon={Activity} />
              <TabButton id="usage" label="Usage Statistics" icon={Zap} />
              <TabButton id="invoices" label="My Invoices" icon={FileText} />
              <TabButton id="payments" label="Payment History" icon={CreditCard} />
              <TabButton id="support" label="Support" icon={MessageSquare} />
            </div>

            {/* Quick Actions */}
            <div className="glass rounded-xl p-4 mt-4">
              <h3 className="text-sm font-medium text-foreground mb-3">Quick Actions</h3>
              <div className="space-y-2">
                <button 
                  onClick={() => setShowPayModal(true)}
                  className="w-full flex items-center gap-2 px-3 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
                >
                  <CreditCard className="w-4 h-4" />
                  Pay Now
                </button>
                <button 
                  onClick={() => setShowTicketModal(true)}
                  className="w-full flex items-center gap-2 px-3 py-2 bg-muted text-foreground rounded-lg hover:bg-muted/80 transition-colors"
                >
                  <MessageSquare className="w-4 h-4" />
                  Create Ticket
                </button>
              </div>
            </div>
          </aside>

          {/* Main Content */}
          <main className="flex-1">
            <AnimatePresence mode="wait">
              {activeTab === 'overview' && (
                <motion.div
                  key="overview"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="space-y-6"
                >
                  {/* Status Cards */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="glass rounded-xl p-5">
                      <div className="flex items-center gap-3 mb-3">
                        <div className="w-10 h-10 bg-success/20 rounded-lg flex items-center justify-center">
                          <CheckCircle className="w-5 h-5 text-success" />
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Account Status</p>
                          <p className="text-lg font-semibold text-success capitalize">{customerData.status}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Clock className="w-4 h-4" />
                        <span>{customerData.daysRemaining} days remaining</span>
                      </div>
                    </div>

                    <div className="glass rounded-xl p-5">
                      <div className="flex items-center gap-3 mb-3">
                        <div className="w-10 h-10 bg-primary/20 rounded-lg flex items-center justify-center">
                          <Wifi className="w-5 h-5 text-primary" />
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Current Plan</p>
                          <p className="text-lg font-semibold text-foreground">{customerData.plan}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <ArrowDown className="w-4 h-4" />
                        <span>{customerData.downloadSpeed} Mbps</span>
                        <ArrowUp className="w-4 h-4 ml-2" />
                        <span>{customerData.uploadSpeed} Mbps</span>
                      </div>
                    </div>

                    <div className="glass rounded-xl p-5">
                      <div className="flex items-center gap-3 mb-3">
                        <div className="w-10 h-10 bg-secondary/20 rounded-lg flex items-center justify-center">
                          <CreditCard className="w-5 h-5 text-secondary" />
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Monthly Bill</p>
                          <p className="text-lg font-semibold text-foreground">{formatCurrency(customerData.monthlyPrice)}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Calendar className="w-4 h-4" />
                        <span>Due: {formatDate(customerData.expiryDate)}</span>
                      </div>
                    </div>
                  </div>

                  {/* Data Usage */}
                  <div className="glass rounded-xl p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-lg font-semibold text-foreground flex items-center gap-2">
                        <Zap className="w-5 h-5 text-warning" />
                        Data Usage
                      </h3>
                      <span className="text-sm text-muted-foreground">
                        {customerData.dataUsed} GB / {customerData.dataLimit} GB
                      </span>
                    </div>
                    <div className="h-4 bg-muted rounded-full overflow-hidden mb-2">
                      <div 
                        className={`h-full rounded-full transition-all ${
                          dataUsagePercent > 80 ? 'bg-destructive' :
                          dataUsagePercent > 60 ? 'bg-warning' : 'bg-success'
                        }`}
                        style={{ width: `${dataUsagePercent}%` }}
                      />
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {dataUsagePercent.toFixed(1)}% used this month
                    </p>
                  </div>

                  {/* Announcements */}
                  <div className="glass rounded-xl p-6">
                    <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
                      <AlertCircle className="w-5 h-5 text-primary" />
                      Announcements
                    </h3>
                    <div className="space-y-3">
                      {announcements.map((announcement) => (
                        <div key={announcement.id} className="p-4 bg-muted/50 rounded-lg">
                          <div className="flex items-center justify-between mb-2">
                            <h4 className="font-medium text-foreground">{announcement.title}</h4>
                            <span className="text-xs text-muted-foreground">{announcement.date}</span>
                          </div>
                          <p className="text-sm text-muted-foreground">{announcement.content}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              )}

              {activeTab === 'usage' && (
                <motion.div
                  key="usage"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="space-y-6"
                >
                  <div className="glass rounded-xl p-6">
                    <h3 className="text-lg font-semibold text-foreground mb-4">Weekly Usage</h3>
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart data={usageData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="rgba(148, 163, 184, 0.1)" />
                        <XAxis dataKey="day" stroke="#94a3b8" />
                        <YAxis stroke="#94a3b8" />
                        <Tooltip 
                          contentStyle={{ 
                            backgroundColor: 'hsl(222 35% 8%)', 
                            border: '1px solid hsl(217 33% 17%)',
                            borderRadius: '8px',
                          }}
                        />
                        <Bar dataKey="download" fill="#6366f1" name="Download (GB)" radius={[4, 4, 0, 0]} />
                        <Bar dataKey="upload" fill="#06b6d4" name="Upload (GB)" radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="glass rounded-xl p-4 text-center">
                      <p className="text-2xl font-bold text-foreground">{customerData.dataUsed} GB</p>
                      <p className="text-sm text-muted-foreground">Total Used</p>
                    </div>
                    <div className="glass rounded-xl p-4 text-center">
                      <p className="text-2xl font-bold text-foreground">{customerData.dataLimit - customerData.dataUsed} GB</p>
                      <p className="text-sm text-muted-foreground">Remaining</p>
                    </div>
                    <div className="glass rounded-xl p-4 text-center">
                      <p className="text-2xl font-bold text-foreground">64.4 GB</p>
                      <p className="text-sm text-muted-foreground">Avg Daily</p>
                    </div>
                    <div className="glass rounded-xl p-4 text-center">
                      <p className="text-2xl font-bold text-foreground">12 Days</p>
                      <p className="text-sm text-muted-foreground">Cycle Reset</p>
                    </div>
                  </div>
                </motion.div>
              )}

              {activeTab === 'invoices' && (
                <motion.div
                  key="invoices"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="space-y-6"
                >
                  <div className="glass rounded-xl overflow-hidden">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-border bg-muted/50">
                          <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Invoice #</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Date</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Amount</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Status</th>
                          <th className="px-4 py-3 text-right text-sm font-medium text-muted-foreground">Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        {invoices.map((invoice) => (
                          <tr key={invoice.id} className="border-b border-border last:border-b-0 hover:bg-muted/30">
                            <td className="px-4 py-3 text-sm font-medium text-foreground">{invoice.id}</td>
                            <td className="px-4 py-3 text-sm text-muted-foreground">{invoice.date}</td>
                            <td className="px-4 py-3 text-sm text-foreground">{formatCurrency(invoice.amount)}</td>
                            <td className="px-4 py-3">
                              <span className="px-2 py-1 bg-success/20 text-success rounded-full text-xs">
                                {invoice.status}
                              </span>
                            </td>
                            <td className="px-4 py-3 text-right">
                              <button className="p-2 hover:bg-muted rounded-lg text-muted-foreground hover:text-foreground">
                                <Download className="w-4 h-4" />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </motion.div>
              )}

              {activeTab === 'payments' && (
                <motion.div
                  key="payments"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="space-y-6"
                >
                  <div className="glass rounded-xl overflow-hidden">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-border bg-muted/50">
                          <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Payment ID</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Date</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Amount</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Method</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Transaction ID</th>
                        </tr>
                      </thead>
                      <tbody>
                        {payments.map((payment) => (
                          <tr key={payment.id} className="border-b border-border last:border-b-0 hover:bg-muted/30">
                            <td className="px-4 py-3 text-sm font-medium text-foreground">{payment.id}</td>
                            <td className="px-4 py-3 text-sm text-muted-foreground">{payment.date}</td>
                            <td className="px-4 py-3 text-sm text-foreground">{formatCurrency(payment.amount)}</td>
                            <td className="px-4 py-3 text-sm text-foreground">{payment.method}</td>
                            <td className="px-4 py-3 text-sm font-mono text-muted-foreground">{payment.transactionId}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </motion.div>
              )}

              {activeTab === 'support' && (
                <motion.div
                  key="support"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="space-y-6"
                >
                  <div className="glass rounded-xl p-6">
                    <h3 className="text-lg font-semibold text-foreground mb-4">Contact Support</h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                      <div className="p-4 bg-muted/50 rounded-lg text-center">
                        <Phone className="w-8 h-8 text-primary mx-auto mb-2" />
                        <p className="font-medium text-foreground">Phone</p>
                        <p className="text-sm text-muted-foreground">0700 123 456</p>
                      </div>
                      <div className="p-4 bg-muted/50 rounded-lg text-center">
                        <Mail className="w-8 h-8 text-secondary mx-auto mb-2" />
                        <p className="font-medium text-foreground">Email</p>
                        <p className="text-sm text-muted-foreground">support@isp.com</p>
                      </div>
                      <div className="p-4 bg-muted/50 rounded-lg text-center">
                        <MessageSquare className="w-8 h-8 text-success mx-auto mb-2" />
                        <p className="font-medium text-foreground">WhatsApp</p>
                        <p className="text-sm text-muted-foreground">+254 700 123 456</p>
                      </div>
                    </div>
                    <button 
                      onClick={() => setShowTicketModal(true)}
                      className="w-full py-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
                    >
                      Create Support Ticket
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </main>
        </div>
      </div>
    </div>
  );
}
