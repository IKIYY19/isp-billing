import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Package, 
  Plus, 
  Search,
  Router,
  Wifi,
  Cable,
  Battery,
  AlertTriangle,
  Edit2,
  Trash2,
  BarChart3,
  Download
} from 'lucide-react';

interface InventoryItem {
  id: string;
  name: string;
  category: 'router' | 'access_point' | 'cable' | 'power_supply' | 'other';
  sku: string;
  quantity: number;
  minQuantity: number;
  unitCost: number;
  location: string;
  status: 'in_stock' | 'low_stock' | 'out_of_stock';
  supplier: string;
  lastRestocked: string;
  notes?: string;
}

const mockInventory: InventoryItem[] = [
  {
    id: '1',
    name: 'MikroTik RB2011UiAS-2HnD-IN',
    category: 'router',
    sku: 'MT-RB2011',
    quantity: 15,
    minQuantity: 5,
    unitCost: 12000,
    location: 'Main Warehouse',
    status: 'in_stock',
    supplier: 'TechWorld Kenya',
    lastRestocked: '2024-06-01',
    notes: 'Popular model for small offices',
  },
  {
    id: '2',
    name: 'Ubiquiti UniFi AP AC Lite',
    category: 'access_point',
    sku: 'UB-UAP-AC-LITE',
    quantity: 3,
    minQuantity: 5,
    unitCost: 8500,
    location: 'Main Warehouse',
    status: 'low_stock',
    supplier: 'Network Solutions Ltd',
    lastRestocked: '2024-05-15',
  },
  {
    id: '3',
    name: 'CAT6 Ethernet Cable (305m)',
    category: 'cable',
    sku: 'CAB-CAT6-305',
    quantity: 0,
    minQuantity: 2,
    unitCost: 8500,
    location: 'Storage B',
    status: 'out_of_stock',
    supplier: 'Cable Masters',
    lastRestocked: '2024-04-20',
  },
  {
    id: '4',
    name: '12V 2A Power Adapter',
    category: 'power_supply',
    sku: 'PS-12V2A',
    quantity: 45,
    minQuantity: 10,
    unitCost: 450,
    location: 'Main Warehouse',
    status: 'in_stock',
    supplier: 'PowerTech',
    lastRestocked: '2024-06-10',
  },
  {
    id: '5',
    name: 'MikroTik hAP ac²',
    category: 'router',
    sku: 'MT-HAP-AC2',
    quantity: 8,
    minQuantity: 5,
    unitCost: 9500,
    location: 'Main Warehouse',
    status: 'in_stock',
    supplier: 'TechWorld Kenya',
    lastRestocked: '2024-05-28',
  },
];

const getCategoryIcon = (category: InventoryItem['category']) => {
  switch (category) {
    case 'router': return <Router className="w-5 h-5" />;
    case 'access_point': return <Wifi className="w-5 h-5" />;
    case 'cable': return <Cable className="w-5 h-5" />;
    case 'power_supply': return <Battery className="w-5 h-5" />;
    default: return <Package className="w-5 h-5" />;
  }
};

const getStatusColor = (status: InventoryItem['status']) => {
  switch (status) {
    case 'in_stock': return 'bg-success/20 text-success';
    case 'low_stock': return 'bg-warning/20 text-warning';
    case 'out_of_stock': return 'bg-destructive/20 text-destructive';
  }
};

export default function Inventory() {
  const [inventory, _setInventory] = useState<InventoryItem[]>(mockInventory);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [_showNewItemModal, setShowNewItemModal] = useState(false);

  const filteredInventory = inventory.filter(item => {
    const matchesSearch = 
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.sku.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory = filterCategory === 'all' || item.category === filterCategory;
    const matchesStatus = filterStatus === 'all' || item.status === filterStatus;
    
    return matchesSearch && matchesCategory && matchesStatus;
  });

  const stats = {
    totalItems: inventory.length,
    totalValue: inventory.reduce((sum, item) => sum + (item.quantity * item.unitCost), 0),
    lowStock: inventory.filter(i => i.status === 'low_stock').length,
    outOfStock: inventory.filter(i => i.status === 'out_of_stock').length,
  };

  const categoryBreakdown = [
    { name: 'Routers', count: inventory.filter(i => i.category === 'router').reduce((sum, i) => sum + i.quantity, 0), icon: Router },
    { name: 'Access Points', count: inventory.filter(i => i.category === 'access_point').reduce((sum, i) => sum + i.quantity, 0), icon: Wifi },
    { name: 'Cables', count: inventory.filter(i => i.category === 'cable').reduce((sum, i) => sum + i.quantity, 0), icon: Cable },
    { name: 'Power Supplies', count: inventory.filter(i => i.category === 'power_supply').reduce((sum, i) => sum + i.quantity, 0), icon: Battery },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Inventory Management</h2>
          <p className="text-muted-foreground">Track equipment, stock levels, and suppliers</p>
        </div>
        <div className="flex gap-2">
          <button className="flex items-center gap-2 px-4 py-2 bg-muted text-foreground rounded-lg hover:bg-muted/80 transition-colors">
            <Download className="w-4 h-4" />
            Export
          </button>
          <button
            onClick={() => setShowNewItemModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
          >
            <Plus className="w-4 h-4" />
            Add Item
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary/20 rounded-lg flex items-center justify-center">
              <Package className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Total Items</p>
              <p className="text-2xl font-bold text-foreground">{stats.totalItems}</p>
            </div>
          </div>
        </div>
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-success/20 rounded-lg flex items-center justify-center">
              <BarChart3 className="w-5 h-5 text-success" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Inventory Value</p>
              <p className="text-2xl font-bold text-foreground">KES {stats.totalValue.toLocaleString()}</p>
            </div>
          </div>
        </div>
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-warning/20 rounded-lg flex items-center justify-center">
              <AlertTriangle className="w-5 h-5 text-warning" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Low Stock</p>
              <p className="text-2xl font-bold text-warning">{stats.lowStock}</p>
            </div>
          </div>
        </div>
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-destructive/20 rounded-lg flex items-center justify-center">
              <Package className="w-5 h-5 text-destructive" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Out of Stock</p>
              <p className="text-2xl font-bold text-destructive">{stats.outOfStock}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Category Breakdown */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {categoryBreakdown.map((category, index) => {
          const Icon = category.icon;
          return (
            <motion.div
              key={category.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="glass rounded-xl p-4"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-muted rounded-lg flex items-center justify-center">
                  <Icon className="w-5 h-5 text-muted-foreground" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">{category.name}</p>
                  <p className="text-xl font-bold text-foreground">{category.count}</p>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Filters */}
      <div className="glass rounded-xl p-4">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search inventory..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-muted border border-border rounded-lg text-sm"
            />
          </div>
          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="px-4 py-2 bg-muted border border-border rounded-lg text-sm"
          >
            <option value="all">All Categories</option>
            <option value="router">Routers</option>
            <option value="access_point">Access Points</option>
            <option value="cable">Cables</option>
            <option value="power_supply">Power Supplies</option>
            <option value="other">Other</option>
          </select>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-4 py-2 bg-muted border border-border rounded-lg text-sm"
          >
            <option value="all">All Status</option>
            <option value="in_stock">In Stock</option>
            <option value="low_stock">Low Stock</option>
            <option value="out_of_stock">Out of Stock</option>
          </select>
        </div>
      </div>

      {/* Inventory Table */}
      <div className="glass rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border bg-muted/50">
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Item</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">SKU</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Stock</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Status</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Location</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Unit Cost</th>
                <th className="px-4 py-3 text-right text-sm font-medium text-muted-foreground">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredInventory.map((item) => (
                <motion.tr
                  key={item.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="border-b border-border last:border-b-0 hover:bg-muted/30 transition-colors"
                >
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-muted rounded-lg flex items-center justify-center">
                        {getCategoryIcon(item.category)}
                      </div>
                      <div>
                        <p className="font-medium text-foreground">{item.name}</p>
                        <p className="text-xs text-muted-foreground capitalize">{item.category.replace('_', ' ')}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className="text-sm font-mono text-muted-foreground">{item.sku}</span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <span className={`text-sm font-medium ${
                        item.quantity <= item.minQuantity ? 'text-warning' : 'text-foreground'
                      }`}>
                        {item.quantity}
                      </span>
                      <span className="text-xs text-muted-foreground">/ {item.minQuantity} min</span>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(item.status)}`}>
                      {item.status.replace('_', ' ')}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <span className="text-sm text-foreground">{item.location}</span>
                  </td>
                  <td className="px-4 py-3">
                    <span className="text-sm text-foreground">KES {item.unitCost.toLocaleString()}</span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-end gap-2">
                      <button className="p-2 hover:bg-muted rounded-lg text-muted-foreground hover:text-foreground">
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button className="p-2 hover:bg-destructive/10 rounded-lg text-muted-foreground hover:text-destructive">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
        {filteredInventory.length === 0 && (
          <div className="p-8 text-center text-muted-foreground">
            No inventory items found.
          </div>
        )}
      </div>
    </div>
  );
}
