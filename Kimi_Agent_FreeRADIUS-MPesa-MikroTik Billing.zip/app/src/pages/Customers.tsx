import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Search, 
  Plus, 
  Edit2, 
  Trash2, 
  Eye,
  Wifi,
  Network,
  Phone,
  Mail,
  MapPin,
  CreditCard,
  X
} from 'lucide-react';
import type { Customer } from '../types';
import { formatCurrency, formatDate, getStatusColor } from '../lib/utils';

// Mock data
const mockCustomers: Customer[] = [
  {
    id: '1',
    username: 'john_doe',
    fullName: 'John Doe',
    email: 'john@example.com',
    phone: '+254712345678',
    address: '123 Kimathi Street, Nairobi',
    serviceType: 'pppoe',
    planId: '1',
    planName: 'Premium 10Mbps',
    status: 'active',
    expiryDate: '2024-12-31',
    createdAt: '2024-01-15',
    lastConnected: '2024-06-15T10:30:00',
    ipAddress: '192.168.1.100',
    macAddress: '00:1A:2B:3C:4D:5E',
    balance: 0,
  },
  {
    id: '2',
    username: 'jane_smith',
    fullName: 'Jane Smith',
    email: 'jane@example.com',
    phone: '+254723456789',
    address: '456 Moi Avenue, Mombasa',
    serviceType: 'hotspot',
    planId: '2',
    planName: 'Basic 5Mbps',
    status: 'active',
    expiryDate: '2024-12-31',
    createdAt: '2024-02-20',
    lastConnected: '2024-06-15T09:45:00',
    balance: 500,
  },
  {
    id: '3',
    username: 'mike_johnson',
    fullName: 'Mike Johnson',
    email: 'mike@example.com',
    phone: '+254734567890',
    address: '789 Oginga Odinga St, Kisumu',
    serviceType: 'pppoe',
    planId: '3',
    planName: 'Enterprise 20Mbps',
    status: 'expired',
    expiryDate: '2024-05-31',
    createdAt: '2023-11-10',
    lastConnected: '2024-05-30T18:20:00',
    ipAddress: '192.168.1.105',
    macAddress: '00:1A:2B:3C:4D:5F',
    balance: -2500,
  },
  {
    id: '4',
    username: 'sarah_williams',
    fullName: 'Sarah Williams',
    email: 'sarah@example.com',
    phone: '+254745678901',
    address: '321 Kenyatta Avenue, Nakuru',
    serviceType: 'hotspot',
    planId: '2',
    planName: 'Basic 5Mbps',
    status: 'suspended',
    expiryDate: '2024-06-30',
    createdAt: '2024-03-05',
    balance: -1500,
  },
  {
    id: '5',
    username: 'david_brown',
    fullName: 'David Brown',
    email: 'david@example.com',
    phone: '+254756789012',
    address: '654 Haile Selassie Ave, Nairobi',
    serviceType: 'pppoe',
    planId: '1',
    planName: 'Premium 10Mbps',
    status: 'active',
    expiryDate: '2024-12-31',
    createdAt: '2024-01-20',
    lastConnected: '2024-06-15T11:15:00',
    ipAddress: '192.168.1.110',
    macAddress: '00:1A:2B:3C:4D:60',
    balance: 1000,
  },
];

export default function Customers() {
  const [customers, setCustomers] = useState<Customer[]>(mockCustomers);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterService, setFilterService] = useState<string>('all');
  const [showViewModal, setShowViewModal] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  const filteredCustomers = customers.filter(customer => {
    const matchesSearch = 
      customer.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      customer.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
      customer.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      customer.phone.includes(searchQuery);
    
    const matchesStatus = filterStatus === 'all' || customer.status === filterStatus;
    const matchesService = filterService === 'all' || customer.serviceType === filterService;
    
    return matchesSearch && matchesStatus && matchesService;
  });

  const handleDelete = (customer: Customer) => {
    setSelectedCustomer(customer);
    setShowDeleteConfirm(true);
  };

  const confirmDelete = () => {
    if (selectedCustomer) {
      setCustomers(prev => prev.filter(c => c.id !== selectedCustomer.id));
      setShowDeleteConfirm(false);
      setSelectedCustomer(null);
    }
  };

  const handleView = (customer: Customer) => {
    setSelectedCustomer(customer);
    setShowViewModal(true);
  };

  const handleEdit = (_customer: Customer) => {
    // Edit functionality to be implemented
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Customers</h2>
          <p className="text-muted-foreground">Manage your PPPoE and Hotspot customers</p>
        </div>
        <button
          onClick={() => {/* Add customer modal to be implemented */}}
          className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
        >
          <Plus className="w-4 h-4" />
          Add Customer
        </button>
      </div>

      {/* Filters */}
      <div className="glass rounded-xl p-4">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search customers..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-muted border border-border rounded-lg text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
            />
          </div>
          <div className="flex gap-2">
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="px-4 py-2 bg-muted border border-border rounded-lg text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
            >
              <option value="all">All Status</option>
              <option value="active">Active</option>
              <option value="expired">Expired</option>
              <option value="suspended">Suspended</option>
              <option value="pending">Pending</option>
            </select>
            <select
              value={filterService}
              onChange={(e) => setFilterService(e.target.value)}
              className="px-4 py-2 bg-muted border border-border rounded-lg text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
            >
              <option value="all">All Services</option>
              <option value="pppoe">PPPoE</option>
              <option value="hotspot">Hotspot</option>
            </select>
          </div>
        </div>
      </div>

      {/* Customers Table */}
      <div className="glass rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border bg-muted/50">
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Customer</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Service</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Plan</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Status</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Expiry Date</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Balance</th>
                <th className="px-4 py-3 text-right text-sm font-medium text-muted-foreground">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredCustomers.map((customer, index) => (
                <motion.tr
                  key={customer.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="border-b border-border last:border-b-0 hover:bg-muted/30 transition-colors"
                >
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                        customer.serviceType === 'pppoe' ? 'bg-primary/20' : 'bg-secondary/20'
                      }`}>
                        <span className="text-sm font-semibold text-foreground">
                          {customer.fullName.charAt(0)}
                        </span>
                      </div>
                      <div>
                        <p className="font-medium text-foreground">{customer.fullName}</p>
                        <p className="text-sm text-muted-foreground">{customer.username}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      {customer.serviceType === 'pppoe' ? (
                        <Network className="w-4 h-4 text-primary" />
                      ) : (
                        <Wifi className="w-4 h-4 text-secondary" />
                      )}
                      <span className="text-sm text-foreground capitalize">{customer.serviceType}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className="text-sm text-foreground">{customer.planName}</span>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-1 text-xs rounded-full border ${getStatusColor(customer.status)}`}>
                      {customer.status}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <span className="text-sm text-foreground">{formatDate(customer.expiryDate)}</span>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`text-sm font-medium ${
                      customer.balance < 0 ? 'text-destructive' : 'text-success'
                    }`}>
                      {formatCurrency(customer.balance)}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => handleView(customer)}
                        className="p-2 hover:bg-muted rounded-lg text-muted-foreground hover:text-foreground transition-colors"
                        title="View"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleEdit(customer)}
                        className="p-2 hover:bg-muted rounded-lg text-muted-foreground hover:text-foreground transition-colors"
                        title="Edit"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(customer)}
                        className="p-2 hover:bg-destructive/10 rounded-lg text-muted-foreground hover:text-destructive transition-colors"
                        title="Delete"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
        {filteredCustomers.length === 0 && (
          <div className="p-8 text-center text-muted-foreground">
            No customers found matching your criteria.
          </div>
        )}
      </div>

      {/* View Customer Modal */}
      <AnimatePresence>
        {showViewModal && selectedCustomer && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
            onClick={() => setShowViewModal(false)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="glass rounded-xl p-6 max-w-lg w-full max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-semibold text-foreground">Customer Details</h3>
                <button
                  onClick={() => setShowViewModal(false)}
                  className="p-2 hover:bg-muted rounded-lg transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              
              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className={`w-16 h-16 rounded-full flex items-center justify-center ${
                    selectedCustomer.serviceType === 'pppoe' ? 'bg-primary/20' : 'bg-secondary/20'
                  }`}>
                    <span className="text-2xl font-bold text-foreground">
                      {selectedCustomer.fullName.charAt(0)}
                    </span>
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-foreground">{selectedCustomer.fullName}</h4>
                    <p className="text-muted-foreground">@{selectedCustomer.username}</p>
                    <span className={`inline-block mt-1 px-2 py-0.5 text-xs rounded-full border ${getStatusColor(selectedCustomer.status)}`}>
                      {selectedCustomer.status}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="p-3 bg-muted/50 rounded-lg">
                    <div className="flex items-center gap-2 text-muted-foreground mb-1">
                      <Mail className="w-4 h-4" />
                      <span className="text-sm">Email</span>
                    </div>
                    <p className="text-sm text-foreground">{selectedCustomer.email}</p>
                  </div>
                  <div className="p-3 bg-muted/50 rounded-lg">
                    <div className="flex items-center gap-2 text-muted-foreground mb-1">
                      <Phone className="w-4 h-4" />
                      <span className="text-sm">Phone</span>
                    </div>
                    <p className="text-sm text-foreground">{selectedCustomer.phone}</p>
                  </div>
                  <div className="p-3 bg-muted/50 rounded-lg">
                    <div className="flex items-center gap-2 text-muted-foreground mb-1">
                      <MapPin className="w-4 h-4" />
                      <span className="text-sm">Address</span>
                    </div>
                    <p className="text-sm text-foreground">{selectedCustomer.address}</p>
                  </div>
                  <div className="p-3 bg-muted/50 rounded-lg">
                    <div className="flex items-center gap-2 text-muted-foreground mb-1">
                      <CreditCard className="w-4 h-4" />
                      <span className="text-sm">Balance</span>
                    </div>
                    <p className={`text-sm font-medium ${selectedCustomer.balance < 0 ? 'text-destructive' : 'text-success'}`}>
                      {formatCurrency(selectedCustomer.balance)}
                    </p>
                  </div>
                </div>

                <div className="border-t border-border pt-4">
                  <h5 className="font-medium text-foreground mb-3">Service Information</h5>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Service Type</p>
                      <p className="text-sm text-foreground capitalize">{selectedCustomer.serviceType}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Plan</p>
                      <p className="text-sm text-foreground">{selectedCustomer.planName}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">IP Address</p>
                      <p className="text-sm text-foreground">{selectedCustomer.ipAddress || 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">MAC Address</p>
                      <p className="text-sm text-foreground">{selectedCustomer.macAddress || 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Created</p>
                      <p className="text-sm text-foreground">{formatDate(selectedCustomer.createdAt)}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Expiry</p>
                      <p className="text-sm text-foreground">{formatDate(selectedCustomer.expiryDate)}</p>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Delete Confirmation Modal */}
      <AnimatePresence>
        {showDeleteConfirm && selectedCustomer && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
            onClick={() => setShowDeleteConfirm(false)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="glass rounded-xl p-6 max-w-md w-full"
            >
              <h3 className="text-xl font-semibold text-foreground mb-4">Delete Customer</h3>
              <p className="text-muted-foreground mb-6">
                Are you sure you want to delete <span className="text-foreground font-medium">{selectedCustomer.fullName}</span>? 
                This action cannot be undone.
              </p>
              <div className="flex justify-end gap-3">
                <button
                  onClick={() => setShowDeleteConfirm(false)}
                  className="px-4 py-2 text-foreground hover:bg-muted rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={confirmDelete}
                  className="px-4 py-2 bg-destructive text-destructive-foreground rounded-lg hover:bg-destructive/90 transition-colors"
                >
                  Delete
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
