import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  phone?: string;
  role: 'admin' | 'manager' | 'staff' | 'technician';
  companyId?: string;
  avatar?: string;
}

export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
  expiresAt: number;
}

interface AuthState {
  user: User | null;
  tokens: AuthTokens | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
  authFlow: 'login' | 'register' | null;
  
  // Actions
  setUser: (user: User | null) => void;
  setTokens: (tokens: AuthTokens | null) => void;
  setLoading: (isLoading: boolean) => void;
  setError: (error: string | null) => void;
  setAuthFlow: (flow: 'login' | 'register' | null) => void;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  clearError: () => void;
}

// Mock user for demo
const mockUser: User = {
  id: '1',
  email: 'admin@ispbilling.com',
  firstName: 'Admin',
  lastName: 'User',
  phone: '+254712345678',
  role: 'admin',
  companyId: '1',
};

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      tokens: null,
      isAuthenticated: false,
      isLoading: false,
      error: null,
      authFlow: null,

      setUser: (user) => set({ user, isAuthenticated: !!user }),
      setTokens: (tokens) => set({ tokens }),
      setLoading: (isLoading) => set({ isLoading }),
      setError: (error) => set({ error }),
      setAuthFlow: (authFlow) => set({ authFlow }),

      login: async (email: string, password: string) => {
        set({ isLoading: true, error: null });
        
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        if (email === 'admin@ispbilling.com' && password === 'admin123') {
          set({
            user: mockUser,
            tokens: {
              accessToken: 'mock-token',
              refreshToken: 'mock-refresh',
              expiresAt: Date.now() + 3600000,
            },
            isAuthenticated: true,
            isLoading: false,
          });
        } else {
          set({
            error: 'Invalid email or password',
            isLoading: false,
          });
          throw new Error('Invalid credentials');
        }
      },

      logout: () => {
        set({
          user: null,
          tokens: null,
          isAuthenticated: false,
          error: null,
        });
      },

      clearError: () => set({ error: null }),
    }),
    {
      name: 'auth-storage',
      partialize: (state) => ({ user: state.user, tokens: state.tokens, isAuthenticated: state.isAuthenticated }),
    }
  )
);

export default useAuthStore;
