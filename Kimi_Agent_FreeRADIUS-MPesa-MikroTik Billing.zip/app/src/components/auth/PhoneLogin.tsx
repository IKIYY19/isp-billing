import { useState } from 'react';
import { useAuthStore } from '../../stores/authStore';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Loader2, Smartphone, ArrowLeft, CheckCircle } from 'lucide-react';

interface PhoneLoginProps {
  onBack?: () => void;
  onSuccess?: () => void;
}

export function PhoneLogin({ onBack, onSuccess }: PhoneLoginProps) {
  const [step, setStep] = useState<'phone' | 'otp'>('phone');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [otp, setOtp] = useState('');
  const [countdown, setCountdown] = useState(0);
  
  const {
    sendOTP,
    verifyOTP,
    isLoading,
    error,
    clearError,
    otpSent,
    otpTrackingId
  } = useAuthStore();

  const handleSendOTP = async (e: React.FormEvent) => {
    e.preventDefault();
    clearError();
    
    const response = await sendOTP(phoneNumber, 'login');
    
    if (response.success) {
      setStep('otp');
      setCountdown(60);
      startCountdown();
    }
  };

  const handleVerifyOTP = async (e: React.FormEvent) => {
    e.preventDefault();
    clearError();
    
    const response = await verifyOTP(otp, 'login');
    
    if (response.success) {
      onSuccess?.();
    }
  };

  const handleResendOTP = async () => {
    clearError();
    const response = await sendOTP(phoneNumber, 'login');
    
    if (response.success) {
      setCountdown(60);
      startCountdown();
    }
  };

  const startCountdown = () => {
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const formatPhoneNumber = (value: string) => {
    // Remove all non-numeric characters
    const cleaned = value.replace(/\D/g, '');
    
    // Format as Kenyan number if starts with 0 or 254
    if (cleaned.startsWith('0') && cleaned.length <= 10) {
      return cleaned;
    } else if (cleaned.startsWith('254') && cleaned.length <= 12) {
      return cleaned;
    }
    
    return cleaned.slice(0, 12);
  };

  if (step === 'otp') {
    return (
      <Card className="w-full max-w-md">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setStep('phone')}
              className="h-8 w-8"
            >
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <div>
              <CardTitle>Enter Verification Code</CardTitle>
              <CardDescription>
                Enter the 6-digit code sent to {phoneNumber}
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {error && (
            <Alert variant="destructive" className="mb-4">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          
          <form onSubmit={handleVerifyOTP} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="otp">Verification Code</Label>
              <Input
                id="otp"
                type="text"
                inputMode="numeric"
                pattern="[0-9]*"
                maxLength={6}
                placeholder="123456"
                value={otp}
                onChange={(e) => setOtp(e.target.value.replace(/\D/g, '').slice(0, 6))}
                className="text-center text-2xl tracking-widest"
                disabled={isLoading}
                autoFocus
              />
            </div>
            
            <Button
              type="submit"
              className="w-full"
              disabled={isLoading || otp.length !== 6}
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Verifying...
                </>
              ) : (
                'Verify & Login'
              )}
            </Button>
            
            <div className="text-center">
              {countdown > 0 ? (
                <p className="text-sm text-muted-foreground">
                  Resend code in {countdown}s
                </p>
              ) : (
                <Button
                  type="button"
                  variant="link"
                  onClick={handleResendOTP}
                  disabled={isLoading}
                >
                  Resend Code
                </Button>
              )}
            </div>
          </form>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        {onBack && (
          <Button
            variant="ghost"
            size="icon"
            onClick={onBack}
            className="absolute left-4 top-4 h-8 w-8"
          >
            <ArrowLeft className="h-4 w-4" />
          </Button>
        )}
        <div className="flex flex-col items-center text-center">
          <div className="mb-4 rounded-full bg-primary/10 p-3">
            <Smartphone className="h-6 w-6 text-primary" />
          </div>
          <CardTitle>Login with Phone</CardTitle>
          <CardDescription>
            Enter your phone number to receive a verification code
          </CardDescription>
        </div>
      </CardHeader>
      <CardContent>
        {error && (
          <Alert variant="destructive" className="mb-4">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}
        
        <form onSubmit={handleSendOTP} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="phone">Phone Number</Label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                +254
              </span>
              <Input
                id="phone"
                type="tel"
                inputMode="tel"
                placeholder="712345678"
                value={phoneNumber.startsWith('254') 
                  ? phoneNumber.slice(3) 
                  : phoneNumber.startsWith('0') 
                    ? phoneNumber.slice(1) 
                    : phoneNumber
                }
                onChange={(e) => {
                  const value = e.target.value.replace(/\D/g, '');
                  setPhoneNumber(value ? `254${value}` : '');
                }}
                className="pl-14"
                disabled={isLoading}
                maxLength={9}
              />
            </div>
            <p className="text-xs text-muted-foreground">
              Enter your number without the country code or leading zero
            </p>
          </div>
          
          <Button
            type="submit"
            className="w-full"
            disabled={isLoading || phoneNumber.length < 12}
          >
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Sending...
              </>
            ) : (
              'Send Verification Code'
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}

export default PhoneLogin;
