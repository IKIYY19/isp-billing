import { useEffect } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuthStore } from '../../stores/authStore';
import { Loader2 } from 'lucide-react';

interface ProtectedRouteProps {
  children: React.ReactNode;
  requiredRoles?: string | string[];
  requiredPermissions?: string | string[];
  fallback?: React.ReactNode;
}

export function ProtectedRoute({
  children,
  requiredRoles,
  requiredPermissions,
  fallback
}: ProtectedRouteProps) {
  const { isAuthenticated, user, isLoading, fetchProfile } = useAuthStore();
  const location = useLocation();

  useEffect(() => {
    // Try to fetch profile if we have a token but no user
    if (!user && isAuthenticated) {
      fetchProfile();
    }
  }, [user, isAuthenticated, fetchProfile]);

  // Show loading state
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  // Not authenticated - redirect to login
  if (!isAuthenticated) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // Check role requirements
  if (requiredRoles && user) {
    const roles = Array.isArray(requiredRoles) ? requiredRoles : [requiredRoles];
    const hasRole = roles.includes(user.role);

    if (!hasRole) {
      return fallback ? (
        <>{fallback}</>
      ) : (
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-2">Access Denied</h2>
            <p className="text-muted-foreground">
              You don't have permission to access this page.
            </p>
          </div>
        </div>
      );
    }
  }

  // Check permission requirements
  if (requiredPermissions && user) {
    const permissions = Array.isArray(requiredPermissions)
      ? requiredPermissions
      : [requiredPermissions];

    // Admin has all permissions
    if (user.role !== 'admin') {
      const userPermissions = user.permissions || [];
      const hasPermissions = permissions.every((p) => userPermissions.includes(p));

      if (!hasPermissions) {
        return fallback ? (
          <>{fallback}</>
        ) : (
          <div className="min-h-screen flex items-center justify-center">
            <div className="text-center">
              <h2 className="text-2xl font-bold mb-2">Access Denied</h2>
              <p className="text-muted-foreground">
                You don't have the required permissions.
              </p>
            </div>
          </div>
        );
      }
    }
  }

  // All checks passed - render children
  return <>{children}</>;
}

export default ProtectedRoute;
