import { useTheme, type ThemeType } from '../contexts/ThemeContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Palette, Moon, Sun, Check } from 'lucide-react';

export default function ThemeSettings() {
  const { currentTheme, setTheme, availableThemes, theme } = useTheme();

  const getThemeIcon = (themeId: ThemeType) => {
    switch (themeId) {
      case 'dark':
      case 'cyberpunk':
      case 'luxury':
        return <Moon className="w-4 h-4" />;
      default:
        return <Sun className="w-4 h-4" />;
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Palette className="w-5 h-5" />
          Theme Settings
        </CardTitle>
        <CardDescription>
          Customize the appearance of your ISP Billing System
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="p-4 rounded-lg border bg-card">
          <Label className="text-sm text-muted-foreground mb-2 block">Current Theme</Label>
          <div className="flex items-center gap-3">
            <div 
              className="w-12 h-12 rounded-lg flex items-center justify-center"
              style={{ 
                background: `linear-gradient(135deg, ${theme.colors.primary}, ${theme.colors.accent})` 
              }}
            >
              {getThemeIcon(currentTheme)}
            </div>
            <div>
              <p className="font-medium">{theme.name}</p>
              <p className="text-sm text-muted-foreground">{theme.description}</p>
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <Label>Select Theme</Label>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {availableThemes.map((t) => (
              <button
                key={t.id}
                onClick={() => setTheme(t.id)}
                className={`relative p-4 rounded-lg border-2 transition-all hover:scale-105 ${
                  currentTheme === t.id 
                    ? 'border-primary ring-2 ring-primary/20' 
                    : 'border-border hover:border-primary/50'
                }`}
              >
                <div 
                  className="w-full h-16 rounded-md mb-3 flex items-center justify-center"
                  style={{ 
                    background: `linear-gradient(135deg, ${t.colors.background}, ${t.colors.card})`,
                    border: `1px solid ${t.colors.border}`
                  }}
                >
                  <div 
                    className="w-8 h-8 rounded-full"
                    style={{ background: t.colors.primary }}
                  />
                </div>

                <div className="text-left">
                  <p className="font-medium text-sm">{t.name}</p>
                  <p className="text-xs text-muted-foreground line-clamp-1">{t.description}</p>
                </div>

                {currentTheme === t.id && (
                  <div className="absolute top-2 right-2 w-5 h-5 rounded-full bg-primary flex items-center justify-center">
                    <Check className="w-3 h-3 text-primary-foreground" />
                  </div>
                )}
              </button>
            ))}
          </div>
        </div>

        <div className="flex gap-2">
          <Button 
            variant="outline" 
            onClick={() => setTheme('default')}
            disabled={currentTheme === 'default'}
          >
            Reset to Default
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
