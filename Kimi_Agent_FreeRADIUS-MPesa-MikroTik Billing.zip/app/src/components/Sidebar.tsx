import {
  LayoutDashboard,
  Users,
  Package,
  FileText,
  CreditCard,
  Router,
  Wifi,
  Network,
  Database,
  Smartphone,
  BarChart3,
  Settings,
  ChevronLeft,
  ChevronRight,
  Activity,
  Send,
  Zap,
  History,
  HeadphonesIcon,
  Box,
  Ticket,
  UserPlus,
  Brain,
  MessageCircle,
  Gauge,
  DatabaseBackup,
  LifeBuoy,
  Server,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';

interface SidebarProps {
  currentPage: string;
  onPageChange: (page: string) => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
  userRole: string;
}

interface MenuItem {
  id: string;
  label: string;
  icon: React.ElementType;
  roles: string[];
}

const menuItems: MenuItem[] = [
  // Main
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, roles: ['admin', 'manager', 'staff', 'technician'] },
  
  // Customers
  { id: 'customers', label: 'Customers', icon: Users, roles: ['admin', 'manager', 'staff'] },
  { id: 'plans', label: 'Plans', icon: Package, roles: ['admin', 'manager'] },
  { id: 'invoices', label: 'Invoices', icon: FileText, roles: ['admin', 'manager', 'staff'] },
  { id: 'payments', label: 'Payments', icon: CreditCard, roles: ['admin', 'manager', 'staff'] },
  
  // Network Infrastructure
  { id: 'mikrotik', label: 'MikroTik', icon: Router, roles: ['admin', 'manager'] },
  { id: 'olt-management', label: 'OLT Management', icon: Server, roles: ['admin', 'manager'] },
  { id: 'hotspot', label: 'Hotspot', icon: Wifi, roles: ['admin', 'manager', 'staff'] },
  { id: 'pppoe', label: 'PPPoE', icon: Network, roles: ['admin', 'manager', 'staff'] },
  { id: 'usage-analytics', label: 'Usage Analytics', icon: Gauge, roles: ['admin', 'manager'] },
  { id: 'inventory', label: 'Inventory', icon: Box, roles: ['admin', 'manager'] },
  
  // Integrations
  { id: 'freeradius', label: 'FreeRADIUS', icon: Database, roles: ['admin', 'manager'] },
  { id: 'mpesa', label: 'M-Pesa', icon: Smartphone, roles: ['admin', 'manager'] },
  { id: 'whatsapp', label: 'WhatsApp', icon: MessageCircle, roles: ['admin', 'manager'] },
  
  // Management
  { id: 'vouchers', label: 'Vouchers', icon: Zap, roles: ['admin', 'manager', 'staff'] },
  { id: 'agents', label: 'Agents', icon: UserPlus, roles: ['admin', 'manager'] },
  { id: 'support-tickets', label: 'Support Tickets', icon: Ticket, roles: ['admin', 'manager', 'staff'] },
  { id: 'customer-portal', label: 'Customer Portal', icon: HeadphonesIcon, roles: ['admin', 'manager'] },
  
  // Analytics & Reports
  { id: 'reports', label: 'Reports', icon: BarChart3, roles: ['admin', 'manager'] },
  { id: 'ai-analytics', label: 'AI Analytics', icon: Brain, roles: ['admin', 'manager'] },
  { id: 'network-monitor', label: 'Network Monitor', icon: Activity, roles: ['admin', 'manager', 'technician'] },
  
  // Operations
  { id: 'bulk-operations', label: 'Bulk Operations', icon: Send, roles: ['admin', 'manager'] },
  { id: 'automation', label: 'Automation', icon: Zap, roles: ['admin', 'manager'] },
  { id: 'data-center', label: 'Data Center', icon: DatabaseBackup, roles: ['admin', 'manager'] },
  { id: 'audit-logs', label: 'Audit Logs', icon: History, roles: ['admin'] },
  
  // System
  { id: 'settings', label: 'Settings', icon: Settings, roles: ['admin', 'manager'] },
];

export default function Sidebar({
  currentPage,
  onPageChange,
  collapsed,
  onToggleCollapse,
  userRole,
}: SidebarProps) {
  const filteredMenuItems = menuItems.filter(item =>
    item.roles.includes(userRole)
  );

  return (
    <div
      className={cn(
        'fixed left-0 top-0 z-40 h-screen bg-card border-r transition-all duration-300',
        collapsed ? 'w-16' : 'w-64'
      )}
    >
      {/* Logo */}
      <div className="h-16 flex items-center justify-between px-4 border-b">
        {!collapsed && (
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
              <Wifi className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="font-bold text-lg">ISP Billing</span>
          </div>
        )}
        {collapsed && (
          <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center mx-auto">
            <Wifi className="w-5 h-5 text-primary-foreground" />
          </div>
        )}
        {!collapsed && (
          <Button
            variant="ghost"
            size="icon"
            onClick={onToggleCollapse}
            className="h-8 w-8"
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
        )}
      </div>

      {/* Collapse button when collapsed */}
      {collapsed && (
        <Button
          variant="ghost"
          size="icon"
          onClick={onToggleCollapse}
          className="absolute -right-3 top-20 h-6 w-6 rounded-full bg-primary text-primary-foreground shadow-md"
        >
          <ChevronRight className="h-3 w-3" />
        </Button>
      )}

      {/* Menu */}
      <ScrollArea className="h-[calc(100vh-4rem)]">
        <div className="p-2 space-y-1">
          {filteredMenuItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentPage === item.id;

            return (
              <button
                key={item.id}
                onClick={() => onPageChange(item.id)}
                className={cn(
                  'w-full flex items-center gap-3 px-3 py-2 rounded-lg transition-colors',
                  isActive
                    ? 'bg-primary text-primary-foreground'
                    : 'hover:bg-muted text-muted-foreground hover:text-foreground',
                  collapsed && 'justify-center px-2'
                )}
                title={collapsed ? item.label : undefined}
              >
                <Icon className="h-5 w-5 flex-shrink-0" />
                {!collapsed && <span className="text-sm font-medium">{item.label}</span>}
              </button>
            );
          })}
        </div>
      </ScrollArea>

      {/* Footer */}
      {!collapsed && (
        <div className="absolute bottom-0 left-0 right-0 p-4 border-t bg-card">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <LifeBuoy className="h-4 w-4" />
            <span>Need help? Contact support</span>
          </div>
        </div>
      )}
    </div>
  );
}
