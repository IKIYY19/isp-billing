import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Server, 
  Wifi, 
  Signal, 
  AlertTriangle, 
  CheckCircle, 
  XCircle,
  TrendingUp,
  TrendingDown,
  Activity,
  Brain,
  Zap,
  RefreshCw,
  MapPin,
  Router
} from 'lucide-react';
import { oltService } from '@/services/oltService';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend
} from 'recharts';

interface OLTDashboardStats {
  oltCount: number;
  totalPorts: number;
  totalONUs: number;
  onlineONUs: number;
  offlineONUs: number;
  activeAlarms: number;
  utilization: number;
}

interface OLTSummary {
  id: string;
  name: string;
  vendor: string;
  ipAddress: string;
  status: 'online' | 'offline';
  onuCount: number;
  onlineOnus: number;
  health: 'healthy' | 'degraded' | 'critical';
  location?: string;
}

export default function OLTDashboard() {
  const [stats, setStats] = useState<OLTDashboardStats>({
    oltCount: 0,
    totalPorts: 0,
    totalONUs: 0,
    onlineONUs: 0,
    offlineONUs: 0,
    activeAlarms: 0,
    utilization: 0
  });
  const [olts, setOLTs] = useState<OLTSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    fetchDashboardData();
    const interval = setInterval(fetchDashboardData, 60000);
    return () => clearInterval(interval);
  }, []);

  const fetchDashboardData = async () => {
    try {
      // Fetch all OLTs
      const oltsData = await oltService.getAllOLTs();
      const oltList = oltsData.olts || [];

      // Fetch status for each OLT
      const oltSummaries: OLTSummary[] = [];
      let totalONUs = 0;
      let onlineONUs = 0;
      let totalPorts = 0;
      let activeAlarms = 0;

      for (const olt of oltList) {
        try {
          const status = await oltService.getOLTStatus(olt.id);
          const ports = await oltService.getPONPorts(olt.id);
          const onus = await oltService.getONUs(olt.id);

          const oltONUs = onus.onus || [];
          const oltOnlineONUs = oltONUs.filter((o: any) => o.status === 'online').length;

          oltSummaries.push({
            id: olt.id,
            name: olt.name,
            vendor: olt.vendor,
            ipAddress: olt.ipAddress,
            status: status.connected ? 'online' : 'offline',
            onuCount: oltONUs.length,
            onlineOnus: oltOnlineONUs,
            health: status.health,
            location: olt.location
          });

          totalONUs += oltONUs.length;
          onlineONUs += oltOnlineONUs;
          totalPorts += ports.ports?.length || 0;
          activeAlarms += status.issues?.length || 0;
        } catch (e) {
          console.error(`Failed to fetch status for OLT ${olt.id}:`, e);
        }
      }

      setOLTs(oltSummaries);
      setStats({
        oltCount: oltList.length,
        totalPorts,
        totalONUs,
        onlineONUs,
        offlineONUs: totalONUs - onlineONUs,
        activeAlarms,
        utilization: totalONUs > 0 ? (onlineONUs / totalONUs) * 100 : 0
      });
    } catch (error) {
      console.error('Failed to fetch dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await fetchDashboardData();
    setRefreshing(false);
  };

  const getHealthColor = (health: string) => {
    switch (health) {
      case 'healthy': return 'bg-green-500';
      case 'degraded': return 'bg-yellow-500';
      case 'critical': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getVendorColor = (vendor: string) => {
    const colors: Record<string, string> = {
      huawei: '#ff0000',
      zte: '#0066cc',
      nokia: '#124191',
      fiberhome: '#00a651',
      generic: '#6b7280'
    };
    return colors[vendor.toLowerCase()] || colors.generic;
  };

  // Chart data
  const onuStatusData = [
    { name: 'Online', value: stats.onlineONUs, color: '#10b981' },
    { name: 'Offline', value: stats.offlineONUs, color: '#ef4444' }
  ];

  const vendorData = olts.reduce((acc: any[], olt) => {
    const existing = acc.find(v => v.name === olt.vendor);
    if (existing) {
      existing.count++;
    } else {
      acc.push({ name: olt.vendor, count: 1 });
    }
    return acc;
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">OLT Dashboard</h2>
          <p className="text-muted-foreground">Network-wide OLT overview and statistics</p>
        </div>
        <Button variant="outline" onClick={handleRefresh} disabled={refreshing}>
          <RefreshCw className={`w-4 h-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
          Refresh
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0 }}>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <Server className="w-5 h-5 text-blue-500" />
                <span className="text-sm text-muted-foreground">OLTs</span>
              </div>
              <p className="text-2xl font-bold mt-2">{stats.oltCount}</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <Signal className="w-5 h-5 text-purple-500" />
                <span className="text-sm text-muted-foreground">PON Ports</span>
              </div>
              <p className="text-2xl font-bold mt-2">{stats.totalPorts}</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <Wifi className="w-5 h-5 text-green-500" />
                <span className="text-sm text-muted-foreground">Total ONUs</span>
              </div>
              <p className="text-2xl font-bold mt-2">{stats.totalONUs}</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-green-500" />
                <span className="text-sm text-muted-foreground">Online</span>
              </div>
              <p className="text-2xl font-bold mt-2 text-green-600">{stats.onlineONUs}</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <XCircle className="w-5 h-5 text-red-500" />
                <span className="text-sm text-muted-foreground">Offline</span>
              </div>
              <p className="text-2xl font-bold mt-2 text-red-600">{stats.offlineONUs}</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25 }}>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-yellow-500" />
                <span className="text-sm text-muted-foreground">Alarms</span>
              </div>
              <p className="text-2xl font-bold mt-2 text-yellow-600">{stats.activeAlarms}</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <Activity className="w-5 h-5 text-blue-500" />
                <span className="text-sm text-muted-foreground">Utilization</span>
              </div>
              <p className="text-2xl font-bold mt-2">{stats.utilization.toFixed(1)}%</p>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Charts and OLT List */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* ONU Status Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">ONU Status Distribution</CardTitle>
          </CardHeader>
          <CardContent className="h-[250px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={onuStatusData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {onuStatusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Vendor Distribution */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Vendor Distribution</CardTitle>
          </CardHeader>
          <CardContent className="h-[250px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={vendorData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="count" fill="#3b82f6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Quick Stats */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Quick Stats</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-muted-foreground">Network Uptime</span>
                <span className="font-medium">99.9%</span>
              </div>
              <Progress value={99.9} className="h-2" />
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-muted-foreground">Average Signal Quality</span>
                <span className="font-medium">-18.5 dBm</span>
              </div>
              <Progress value={85} className="h-2" />
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-muted-foreground">Port Utilization</span>
                <span className="font-medium">{stats.utilization.toFixed(1)}%</span>
              </div>
              <Progress value={stats.utilization} className="h-2" />
            </div>
            <div className="pt-2 border-t">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Brain className="w-4 h-4 text-purple-500" />
                  <span className="text-sm">AI Optimizations</span>
                </div>
                <Badge variant="outline">Active</Badge>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Zap className="w-4 h-4 text-yellow-500" />
                <span className="text-sm">Self-Healing</span>
              </div>
              <Badge variant="outline">Enabled</Badge>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* OLT List */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Router className="w-5 h-5" />
            OLT Status Overview
          </CardTitle>
          <CardDescription>Real-time status of all OLTs in your network</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {olts.map((olt, index) => (
              <motion.div
                key={olt.id}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.05 }}
              >
                <Card className="hover:shadow-md transition-shadow cursor-pointer">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <div 
                          className="w-10 h-10 rounded-lg flex items-center justify-center text-white font-bold text-sm"
                          style={{ backgroundColor: getVendorColor(olt.vendor) }}
                        >
                          {olt.vendor.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <p className="font-medium">{olt.name}</p>
                          <p className="text-xs text-muted-foreground">{olt.vendor}</p>
                        </div>
                      </div>
                      <div className={`w-3 h-3 rounded-full ${getHealthColor(olt.health)}`} />
                    </div>

                    <div className="mt-4 space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground flex items-center gap-1">
                          <MapPin className="w-3 h-3" />
                          {olt.location || 'No location'}
                        </span>
                        <Badge variant={olt.status === 'online' ? 'default' : 'destructive'} className="text-xs">
                          {olt.status}
                        </Badge>
                      </div>

                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">{olt.ipAddress}</span>
                      </div>

                      <div className="pt-2 border-t">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-1 text-sm">
                            <Wifi className="w-4 h-4 text-green-500" />
                            <span>{olt.onlineOnus} / {olt.onuCount} ONUs</span>
                          </div>
                          <span className="text-xs text-muted-foreground">
                            {olt.onuCount > 0 ? ((olt.onlineOnus / olt.onuCount) * 100).toFixed(0) : 0}% online
                          </span>
                        </div>
                        <Progress 
                          value={olt.onuCount > 0 ? (olt.onlineOnus / olt.onuCount) * 100 : 0} 
                          className="mt-1 h-1.5"
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          {olts.length === 0 && (
            <div className="text-center py-12">
              <Server className="w-12 h-12 mx-auto text-muted-foreground" />
              <p className="mt-4 text-muted-foreground">No OLTs configured</p>
              <p className="text-sm text-muted-foreground">Add an OLT to get started</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
