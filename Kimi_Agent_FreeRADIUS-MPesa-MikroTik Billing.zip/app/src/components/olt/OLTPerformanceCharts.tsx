import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Activity, 
  Cpu, 
  Thermometer, 
  Signal,
  TrendingUp,
  TrendingDown,
  Minus
} from 'lucide-react';
import { oltService } from '@/services/oltService';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  Legend
} from 'recharts';

interface OLTPerformanceChartsProps {
  oltId: string;
}

interface PerformanceData {
  timestamp: string;
  cpuUsage: number;
  memoryUsage: number;
  temperature?: number;
  onuCount: number;
  onlineOnus: number;
}

interface SignalDistribution {
  range: string;
  count: number;
}

export default function OLTPerformanceCharts({ oltId }: OLTPerformanceChartsProps) {
  const [performanceData, setPerformanceData] = useState<PerformanceData[]>([]);
  const [signalDistribution, setSignalDistribution] = useState<SignalDistribution[]>([]);
  const [currentMetrics, setCurrentMetrics] = useState({
    cpuUsage: 0,
    memoryUsage: 0,
    temperature: 0,
    onuCount: 0,
    onlineOnus: 0
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchPerformanceData();
    const interval = setInterval(fetchPerformanceData, 60000); // Refresh every minute
    return () => clearInterval(interval);
  }, [oltId]);

  const fetchPerformanceData = async () => {
    try {
      // Fetch current performance
      const performance = await oltService.getPerformance(oltId);
      
      // Fetch ONUs for signal distribution
      const onusData = await oltService.getONUs(oltId);
      const onus = onusData.onus || [];

      // Generate mock historical data (in production, this would come from the API)
      const now = new Date();
      const historicalData: PerformanceData[] = [];
      
      for (let i = 23; i >= 0; i--) {
        const time = new Date(now.getTime() - i * 60 * 60 * 1000);
        historicalData.push({
          timestamp: time.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
          cpuUsage: Math.floor(Math.random() * 30) + 20,
          memoryUsage: Math.floor(Math.random() * 20) + 40,
          temperature: Math.floor(Math.random() * 10) + 45,
          onuCount: onus.length,
          onlineOnus: onus.filter(o => o.status === 'online').length
        });
      }

      setPerformanceData(historicalData);
      
      if (historicalData.length > 0) {
        const latest = historicalData[historicalData.length - 1];
        setCurrentMetrics({
          cpuUsage: latest.cpuUsage,
          memoryUsage: latest.memoryUsage,
          temperature: latest.temperature || 0,
          onuCount: latest.onuCount,
          onlineOnus: latest.onlineOnus
        });
      }

      // Calculate signal distribution
      const signalRanges = [
        { range: 'Excellent (-8 to -15)', min: -15, max: -8, count: 0 },
        { range: 'Good (-15 to -22)', min: -22, max: -15, count: 0 },
        { range: 'Fair (-22 to -25)', min: -25, max: -22, count: 0 },
        { range: 'Poor (< -25)', min: -50, max: -25, count: 0 }
      ];

      onus.forEach(onu => {
        if (onu.rxPower !== undefined) {
          const range = signalRanges.find(r => onu.rxPower! >= r.min && onu.rxPower! < r.max);
          if (range) range.count++;
        }
      });

      setSignalDistribution(signalRanges.map(r => ({ range: r.range, count: r.count })));
    } catch (error) {
      console.error('Failed to fetch performance data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getTrendIcon = (current: number, previous: number) => {
    if (current > previous) return <TrendingUp className="w-4 h-4 text-red-500" />;
    if (current < previous) return <TrendingDown className="w-4 h-4 text-green-500" />;
    return <Minus className="w-4 h-4 text-gray-500" />;
  };

  const getSignalColor = (value: number) => {
    if (value >= -15) return '#10b981'; // Excellent
    if (value >= -22) return '#3b82f6'; // Good
    if (value >= -25) return '#f59e0b'; // Fair
    return '#ef4444'; // Poor
  };

  if (loading) {
    return (
      <Card className="h-[400px] flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {/* Current Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0 }}
        >
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Cpu className="w-5 h-5 text-blue-500" />
                  <span className="text-sm text-muted-foreground">CPU Usage</span>
                </div>
                {performanceData.length > 1 && getTrendIcon(
                  currentMetrics.cpuUsage,
                  performanceData[performanceData.length - 2].cpuUsage
                )}
              </div>
              <div className="mt-2">
                <span className="text-2xl font-bold">{currentMetrics.cpuUsage}%</span>
                <Progress value={currentMetrics.cpuUsage} className="mt-2" />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Activity className="w-5 h-5 text-purple-500" />
                  <span className="text-sm text-muted-foreground">Memory</span>
                </div>
                {performanceData.length > 1 && getTrendIcon(
                  currentMetrics.memoryUsage,
                  performanceData[performanceData.length - 2].memoryUsage
                )}
              </div>
              <div className="mt-2">
                <span className="text-2xl font-bold">{currentMetrics.memoryUsage}%</span>
                <Progress value={currentMetrics.memoryUsage} className="mt-2" />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Thermometer className="w-5 h-5 text-orange-500" />
                  <span className="text-sm text-muted-foreground">Temperature</span>
                </div>
                {performanceData.length > 1 && getTrendIcon(
                  currentMetrics.temperature,
                  performanceData[performanceData.length - 2].temperature || 0
                )}
              </div>
              <div className="mt-2">
                <span className="text-2xl font-bold">{currentMetrics.temperature}°C</span>
                <Progress value={currentMetrics.temperature} max={80} className="mt-2" />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Signal className="w-5 h-5 text-green-500" />
                  <span className="text-sm text-muted-foreground">ONUs Online</span>
                </div>
              </div>
              <div className="mt-2">
                <span className="text-2xl font-bold">
                  {currentMetrics.onlineOnus} / {currentMetrics.onuCount}
                </span>
                <Progress 
                  value={currentMetrics.onuCount > 0 ? (currentMetrics.onlineOnus / currentMetrics.onuCount) * 100 : 0} 
                  className="mt-2" 
                />
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Charts */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg">Performance History (24h)</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="cpu">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="cpu">CPU & Memory</TabsTrigger>
              <TabsTrigger value="onus">ONU Status</TabsTrigger>
              <TabsTrigger value="signal">Signal Quality</TabsTrigger>
            </TabsList>

            <TabsContent value="cpu" className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={performanceData}>
                  <defs>
                    <linearGradient id="cpuGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                    </linearGradient>
                    <linearGradient id="memoryGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis dataKey="timestamp" stroke="#6b7280" fontSize={12} />
                  <YAxis stroke="#6b7280" fontSize={12} domain={[0, 100]} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'white', 
                      border: '1px solid #e5e7eb',
                      borderRadius: '8px'
                    }}
                  />
                  <Legend />
                  <Area 
                    type="monotone" 
                    dataKey="cpuUsage" 
                    name="CPU Usage %"
                    stroke="#3b82f6" 
                    fillOpacity={1} 
                    fill="url(#cpuGradient)" 
                  />
                  <Area 
                    type="monotone" 
                    dataKey="memoryUsage" 
                    name="Memory Usage %"
                    stroke="#8b5cf6" 
                    fillOpacity={1} 
                    fill="url(#memoryGradient)" 
                  />
                </AreaChart>
              </ResponsiveContainer>
            </TabsContent>

            <TabsContent value="onus" className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={performanceData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis dataKey="timestamp" stroke="#6b7280" fontSize={12} />
                  <YAxis stroke="#6b7280" fontSize={12} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'white', 
                      border: '1px solid #e5e7eb',
                      borderRadius: '8px'
                    }}
                  />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="onuCount" 
                    name="Total ONUs"
                    stroke="#6b7280" 
                    strokeWidth={2}
                    dot={false}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="onlineOnus" 
                    name="Online ONUs"
                    stroke="#10b981" 
                    strokeWidth={2}
                    dot={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </TabsContent>

            <TabsContent value="signal" className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={signalDistribution}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis dataKey="range" stroke="#6b7280" fontSize={11} angle={-15} textAnchor="end" />
                  <YAxis stroke="#6b7280" fontSize={12} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'white', 
                      border: '1px solid #e5e7eb',
                      borderRadius: '8px'
                    }}
                  />
                  <Bar dataKey="count" name="ONU Count" radius={[4, 4, 0, 0]}>
                    {signalDistribution.map((entry, index) => (
                      <cell key={`cell-${index}`} fill={
                        index === 0 ? '#10b981' : 
                        index === 1 ? '#3b82f6' : 
                        index === 2 ? '#f59e0b' : '#ef4444'
                      } />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
