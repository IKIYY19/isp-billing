import { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  Server, 
  Wifi, 
  Signal, 
  Router, 
  Zap,
  Maximize2,
  Minimize2,
  RefreshCw,
  Info
} from 'lucide-react';
import { oltService } from '@/services/oltService';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';

interface OLTNetworkTopologyProps {
  oltId: string;
  oltName: string;
}

interface TopologyNode {
  id: string;
  type: 'olt' | 'pon' | 'onu';
  name: string;
  status: 'online' | 'offline' | 'degraded';
  x: number;
  y: number;
  data?: any;
}

interface TopologyLink {
  source: string;
  target: string;
  status: 'online' | 'offline';
}

export default function OLTNetworkTopology({ oltId, oltName }: OLTNetworkTopologyProps) {
  const [nodes, setNodes] = useState<TopologyNode[]>([]);
  const [links, setLinks] = useState<TopologyLink[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedNode, setSelectedNode] = useState<TopologyNode | null>(null);
  const [zoom, setZoom] = useState(1);
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    fetchTopologyData();
  }, [oltId]);

  const fetchTopologyData = async () => {
    try {
      setLoading(true);
      
      // Fetch PON ports and ONUs
      const [portsData, onusData] = await Promise.all([
        oltService.getPONPorts(oltId),
        oltService.getONUs(oltId)
      ]);

      const ports = portsData.ports || [];
      const onus = onusData.onus || [];

      // Build topology
      const newNodes: TopologyNode[] = [];
      const newLinks: TopologyLink[] = [];

      // OLT node (center)
      newNodes.push({
        id: 'olt',
        type: 'olt',
        name: oltName,
        status: 'online',
        x: 400,
        y: 50
      });

      // PON port nodes
      const ponSpacing = 800 / (ports.length + 1);
      ports.forEach((port, index) => {
        const portId = `pon-${port.id}`;
        newNodes.push({
          id: portId,
          type: 'pon',
          name: `PON ${port.shelf}/${port.slot}/${port.portNumber}`,
          status: port.status,
          x: ponSpacing * (index + 1),
          y: 200,
          data: port
        });

        newLinks.push({
          source: 'olt',
          target: portId,
          status: port.status
        });

        // ONU nodes for this port
        const portOnus = onus.filter(o => o.ponPortId === port.id);
        const onuSpacing = ponSpacing / (portOnus.length + 1);
        
        portOnus.forEach((onu, onuIndex) => {
          const onuId = `onu-${onu.id}`;
          newNodes.push({
            id: onuId,
            type: 'onu',
            name: `ONU ${onu.onuId}`,
            status: onu.status === 'online' ? 'online' : 'offline',
            x: ponSpacing * (index + 1) - (ponSpacing / 2) + (onuSpacing * (onuIndex + 1)),
            y: 350,
            data: onu
          });

          newLinks.push({
            source: portId,
            target: onuId,
            status: onu.status === 'online' ? 'online' : 'offline'
          });
        });
      });

      setNodes(newNodes);
      setLinks(newLinks);
    } catch (error) {
      console.error('Failed to fetch topology:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleZoomIn = () => setZoom(prev => Math.min(prev + 0.2, 2));
  const handleZoomOut = () => setZoom(prev => Math.max(prev - 0.2, 0.5));

  const getNodeColor = (node: TopologyNode) => {
    switch (node.type) {
      case 'olt':
        return node.status === 'online' ? '#3b82f6' : '#ef4444';
      case 'pon':
        return node.status === 'online' ? '#10b981' : '#ef4444';
      case 'onu':
        return node.status === 'online' ? '#8b5cf6' : '#ef4444';
      default:
        return '#6b7280';
    }
  };

  const getNodeIcon = (type: string) => {
    switch (type) {
      case 'olt':
        return <Server className="w-6 h-6" />;
      case 'pon':
        return <Signal className="w-5 h-5" />;
      case 'onu':
        return <Wifi className="w-4 h-4" />;
      default:
        return <Router className="w-4 h-4" />;
    }
  };

  if (loading) {
    return (
      <Card className="h-[500px] flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <RefreshCw className="w-8 h-8 animate-spin text-primary" />
          <p className="text-muted-foreground">Loading network topology...</p>
        </div>
      </Card>
    );
  }

  return (
    <Card className="h-[500px]">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            <Router className="w-5 h-5" />
            Network Topology
          </CardTitle>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={handleZoomOut}>
              <Minimize2 className="w-4 h-4" />
            </Button>
            <span className="text-sm text-muted-foreground min-w-[50px] text-center">
              {Math.round(zoom * 100)}%
            </span>
            <Button variant="outline" size="sm" onClick={handleZoomIn}>
              <Maximize2 className="w-4 h-4" />
            </Button>
            <Button variant="outline" size="sm" onClick={fetchTopologyData}>
              <RefreshCw className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <div className="relative h-[420px] overflow-hidden bg-muted/30">
          <svg
            ref={svgRef}
            width="100%"
            height="100%"
            viewBox={`0 0 ${800 * zoom} ${400 * zoom}`}
            preserveAspectRatio="xMidYMid meet"
          >
            {/* Links */}
            {links.map((link, index) => (
              <motion.line
                key={`link-${index}`}
                x1={nodes.find(n => n.id === link.source)?.x || 0}
                y1={nodes.find(n => n.id === link.source)?.y || 0}
                x2={nodes.find(n => n.id === link.target)?.x || 0}
                y2={nodes.find(n => n.id === link.target)?.y || 0}
                stroke={link.status === 'online' ? '#10b981' : '#ef4444'}
                strokeWidth={2}
                strokeDasharray={link.status === 'offline' ? '5,5' : '0'}
                initial={{ pathLength: 0 }}
                animate={{ pathLength: 1 }}
                transition={{ duration: 0.5, delay: index * 0.05 }}
              />
            ))}

            {/* Nodes */}
            {nodes.map((node, index) => (
              <TooltipProvider key={node.id}>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <motion.g
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ duration: 0.3, delay: index * 0.05 }}
                      onClick={() => setSelectedNode(node)}
                      className="cursor-pointer"
                    >
                      <circle
                        cx={node.x}
                        cy={node.y}
                        r={node.type === 'olt' ? 25 : node.type === 'pon' ? 20 : 15}
                        fill={getNodeColor(node)}
                        stroke="white"
                        strokeWidth={2}
                        className="drop-shadow-md"
                      />
                      <foreignObject
                        x={node.x - (node.type === 'olt' ? 12 : node.type === 'pon' ? 10 : 8)}
                        y={node.y - (node.type === 'olt' ? 12 : node.type === 'pon' ? 10 : 8)}
                        width={node.type === 'olt' ? 24 : node.type === 'pon' ? 20 : 16}
                        height={node.type === 'olt' ? 24 : node.type === 'pon' ? 20 : 16}
                      >
                        <div className="flex items-center justify-center h-full text-white">
                          {getNodeIcon(node.type)}
                        </div>
                      </foreignObject>
                      
                      {/* Node label */}
                      <text
                        x={node.x}
                        y={node.y + (node.type === 'olt' ? 40 : node.type === 'pon' ? 35 : 30)}
                        textAnchor="middle"
                        className="text-xs fill-foreground font-medium"
                        style={{ fontSize: '10px' }}
                      >
                        {node.name}
                      </text>
                    </motion.g>
                  </TooltipTrigger>
                  <TooltipContent>
                    <div className="space-y-1">
                      <p className="font-medium">{node.name}</p>
                      <p className="text-xs text-muted-foreground capitalize">
                        Type: {node.type}
                      </p>
                      <p className="text-xs text-muted-foreground capitalize">
                        Status: {node.status}
                      </p>
                      {node.data?.serialNumber && (
                        <p className="text-xs text-muted-foreground">
                          SN: {node.data.serialNumber}
                        </p>
                      )}
                      {node.data?.rxPower !== undefined && (
                        <p className="text-xs text-muted-foreground">
                          Signal: {node.data.rxPower.toFixed(2)} dBm
                        </p>
                      )}
                    </div>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            ))}
          </svg>

          {/* Legend */}
          <div className="absolute bottom-4 left-4 bg-card/90 backdrop-blur-sm p-3 rounded-lg border shadow-sm">
            <p className="text-xs font-medium mb-2">Legend</p>
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-blue-500" />
                <span className="text-xs">OLT</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-green-500" />
                <span className="text-xs">PON Port</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-purple-500" />
                <span className="text-xs">ONU</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-red-500" />
                <span className="text-xs">Offline</span>
              </div>
            </div>
          </div>

          {/* Selected Node Info */}
          {selectedNode && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="absolute top-4 right-4 w-64 bg-card/95 backdrop-blur-sm p-4 rounded-lg border shadow-lg"
            >
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-medium">{selectedNode.name}</h4>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-6 w-6 p-0"
                  onClick={() => setSelectedNode(null)}
                >
                  ×
                </Button>
              </div>
              
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Type</span>
                  <Badge variant="outline" className="capitalize">
                    {selectedNode.type}
                  </Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Status</span>
                  <Badge 
                    className={selectedNode.status === 'online' ? 'bg-green-500' : 'bg-red-500'}
                  >
                    {selectedNode.status}
                  </Badge>
                </div>
                
                {selectedNode.data && (
                  <>
                    {selectedNode.data.serialNumber && (
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Serial</span>
                        <span className="font-mono text-xs">{selectedNode.data.serialNumber}</span>
                      </div>
                    )}
                    {selectedNode.data.macAddress && (
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">MAC</span>
                        <span className="font-mono text-xs">{selectedNode.data.macAddress}</span>
                      </div>
                    )}
                    {selectedNode.data.rxPower !== undefined && (
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Rx Power</span>
                        <span>{selectedNode.data.rxPower.toFixed(2)} dBm</span>
                      </div>
                    )}
                    {selectedNode.data.txPower !== undefined && (
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Tx Power</span>
                        <span>{selectedNode.data.txPower.toFixed(2)} dBm</span>
                      </div>
                    )}
                    {selectedNode.data.distance !== undefined && (
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Distance</span>
                        <span>{selectedNode.data.distance.toFixed(2)} km</span>
                      </div>
                    )}
                    {selectedNode.data.onuCount !== undefined && (
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">ONUs</span>
                        <span>{selectedNode.data.onuCount} / {selectedNode.data.maxOnus}</span>
                      </div>
                    )}
                    {selectedNode.data.customerName && (
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Customer</span>
                        <span>{selectedNode.data.customerName}</span>
                      </div>
                    )}
                  </>
                )}
              </div>
            </motion.div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
