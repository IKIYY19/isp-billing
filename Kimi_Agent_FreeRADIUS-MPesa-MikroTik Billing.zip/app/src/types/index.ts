// ============================================
// ISP Billing System - Centralized Type Definitions
// ============================================

// User & Authentication
export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  phone?: string;
  role: 'admin' | 'manager' | 'staff' | 'technician';
  companyId?: string;
  avatar?: string;
  permissions?: string[];
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  loginWithEmail: (email: string, password: string) => Promise<void>;
  loginWithPhone: (phone: string) => Promise<void>;
  verifyOTP: (phone: string, otp: string) => Promise<void>;
  registerWithEmail: (data: RegisterData) => Promise<void>;
  logout: () => void;
  forgotPassword: (email: string) => Promise<void>;
  handleOAuthCallback: (token: string) => Promise<void>;
  fetchProfile: () => Promise<void>;
  otpSent: boolean;
  otpTrackingId: string | null;
}

export interface RegisterData {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  phone?: string;
}

// Notifications
export interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  read: boolean;
  createdAt: string;
}

// Customer Management
export interface Customer {
  id: string;
  accountNumber: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  address?: string;
  city?: string;
  planId?: string;
  status: 'active' | 'inactive' | 'suspended' | 'terminated' | 'expired';
  balance: number;
  createdAt: string;
  updatedAt: string;
  // Extended fields for UI
  username?: string;
  fullName?: string;
  serviceType?: string;
  planName?: string;
  expiryDate?: string;
  ipAddress?: string;
  macAddress?: string;
  lastConnected?: string;
}

// Plans & Services
export interface Plan {
  id: string;
  name: string;
  description?: string;
  price: number;
  speed: string;
  type: 'pppoe' | 'hotspot' | 'fiber';
  status: 'active' | 'inactive';
  isActive?: boolean;
  createdAt?: string;
  dataLimit?: number;
  // Extended fields for UI
  serviceType?: string;
  downloadSpeed?: number;
  uploadSpeed?: number;
  duration?: number;
  durationUnit?: string;
}

// Invoicing
export interface Invoice {
  id: string;
  customerId: string;
  customerName?: string;
  planId?: string;
  planName?: string;
  invoiceNumber: string;
  amount: number;
  total?: number;
  tax?: number;
  balance: number;
  status: 'draft' | 'sent' | 'paid' | 'unpaid' | 'overdue' | 'cancelled';
  dueDate: string;
  issueDate?: string;
  paidDate?: string;
  paymentMethod?: string;
  mpesaTransactionId?: string;
  createdAt: string;
}

// Payments
export interface Payment {
  id: string;
  customerId: string;
  customerName?: string;
  invoiceId?: string;
  transactionId: string;
  amount: number;
  method: 'mpesa' | 'cash' | 'bank' | 'card';
  status: 'pending' | 'completed' | 'failed' | 'refunded';
  createdAt: string;
  // Extended fields for UI
  paymentMethod?: string;
  processedAt?: string;
  mpesaTransactionId?: string;
  mpesaPhoneNumber?: string;
  notes?: string;
}

// Dashboard & Analytics
export interface DashboardStats {
  totalCustomers: number;
  activeCustomers: number;
  monthlyRevenue: number;
  outstandingBalance: number;
  todayPayments: number;
  newCustomersThisMonth: number;
  // Extended fields
  totalRouters?: number;
  unpaidInvoices?: number;
  expiredCustomers?: number;
}

export interface RevenueData {
  month: string;
  revenue: number;
  expenses?: number;
  profit?: number;
}

export interface UserGrowthData {
  month: string;
  users: number;
}

// MikroTik Router Management
export interface MikrotikRouter {
  id: string;
  name: string;
  ipAddress: string;
  port: number;
  username: string;
  password?: string;
  apiPort: number;
  apiUseSsl: boolean;
  location?: string;
  description?: string;
  isActive: boolean;
  lastConnected?: string;
  version?: string;
  status?: 'online' | 'offline';
  // Extended fields for UI
  totalUsers?: number;
  cpuUsage?: number;
  memoryUsage?: number;
  uptime?: string;
}

// M-Pesa Configuration
export interface MPesaConfig {
  id?: string;
  consumerKey: string;
  consumerSecret: string;
  passkey: string;
  shortcode: string;
  shortCode?: string;
  environment: 'sandbox' | 'production';
  callbackUrl: string;
  timeoutUrl?: string;
  resultUrl?: string;
  isActive?: boolean;
}

// FreeRADIUS
export interface FreeRadiusUser {
  id: string;
  username: string;
  attribute: string;
  op: string;
  value: string;
  groupName?: string;
}

// Hotspot Management
export interface HotspotLocation {
  id: string;
  name: string;
  address: string;
  routerId: string;
  status: 'active' | 'inactive' | 'online' | 'offline' | 'maintenance';
  // Extended fields for UI
  routerName?: string;
  coordinates?: { lat: number; lng: number };
  totalUsers?: number;
  maxUsers?: number;
}

// PPPoE Sessions
export interface PPPoESession {
  id: string;
  username: string;
  ipAddress: string;
  macAddress: string;
  status: 'active' | 'inactive';
  uptime: string;
  bytesIn: number;
  bytesOut: number;
  // Extended fields for UI
  customerId?: string;
  customerName?: string;
  callerId?: string;
  service?: string;
  remoteIp?: string;
  connectedSince?: string;
  packetsIn?: number;
  packetsOut?: number;
}

// System Settings
export interface SystemSettings {
  companyName: string;
  companyEmail: string;
  companyPhone: string;
  companyAddress: string;
  currency: string;
  timezone: string;
  dateFormat: string;
  invoicePrefix: string;
  paymentTerms?: number;
  lateFeePercentage?: number;
  autoSuspendDays?: number;
  notificationEmail?: string;
  smtpHost?: string;
  smtpPort?: number;
  smtpUser?: string;
  smtpPassword?: string;
  smtpSecure?: boolean;
  // Extended fields
  taxRate: number;
  gracePeriod: number;
  reminderDays: number;
  autoSuspend: boolean;
}

// OLT Management
export interface OLT {
  id: string;
  name: string;
  vendor: string;
  model: string;
  ipAddress: string;
  port: number;
  protocol: string;
  username: string;
  password: string;
  enablePassword?: string;
  snmpCommunity?: string;
  snmpVersion?: string;
  location?: string;
  isActive: boolean;
  lastSeenAt?: string;
  firmwareVersion?: string;
}

export interface OLTStatus {
  oltId: string;
  name: string;
  vendor: string;
  model: string;
  ipAddress: string;
  connected: boolean;
  system?: {
    cpuUsage?: number;
    memoryUsage?: number;
    temperature?: number;
    uptime?: number;
  };
  ponPorts: number;
  onuCount: number;
  health: 'healthy' | 'degraded' | 'critical';
  issues: string[];
  lastUpdated: string;
}

export interface PONPort {
  id: string;
  oltId?: string;
  shelf?: number;
  slot?: number;
  portNumber: number;
  status: 'online' | 'offline';
  type: 'gpon' | 'xgpon' | 'xgspon' | 'epon' | string;
  onuCount: number;
  maxOnus: number;
  transmitPower?: number;
  receivePower?: number;
  temperature?: number;
  lastUpdated?: Date | string;
}

export interface ONU {
  id: string;
  oltId?: string;
  ponPortId?: string;
  onuId: number;
  serialNumber: string;
  macAddress: string;
  vendorId?: string;
  model?: string;
  firmwareVersion?: string;
  status: 'online' | 'offline' | 'los' | 'auth-fail' | 'config-fail';
  adminState: 'enabled' | 'disabled';
  authMode?: 'sn' | 'loid' | 'password';
  rxPower?: number;
  txPower?: number;
  oltRxPower?: number;
  distance?: number;
  temperature?: number;
  voltage?: number;
  customerId?: string;
  customerName?: string;
  description?: string;
  lastOnlineAt?: Date | string;
  offlineCount?: number;
  uptime?: number;
  createdAt?: Date | string;
  updatedAt?: Date | string;
}

export interface ONUProvisioningData {
  serialNumber: string;
  ponPortId: string;
  onuId?: number;
  customerId?: string;
  serviceProfile?: string;
  lineProfile?: string;
  description?: string;
  vlanConfig?: {
    vlanId: number;
    priority?: number;
  }[];
}

export interface AIOptimization {
  type: 'bandwidth' | 'maintenance' | 'upgrade' | 'anomaly';
  priority: 'high' | 'medium' | 'low';
  title: string;
  description: string;
  recommendation: string;
  affectedPorts?: string[];
  affectedONUs?: Array<{ id: string; serialNumber: string }>;
  metrics?: Record<string, any>;
}

export interface OLTAlarm {
  id: string;
  oltId: string;
  severity: 'critical' | 'major' | 'minor' | 'warning' | 'info';
  category: 'equipment' | 'environmental' | 'communication' | 'service';
  type: string;
  description: string;
  source: string;
  acknowledged: boolean;
  cleared: boolean;
  acknowledgedBy?: string;
  acknowledgedAt?: Date | string;
  clearedAt?: Date | string;
  createdAt: Date | string;
}

export interface OLTPerformance {
  oltId?: string;
  timestamp?: Date | string;
  cpuUsage: number;
  memoryUsage: number;
  temperature?: number;
  ponPorts?: Array<{
    portId: string;
    onuCount: number;
    onlineOnuCount?: number;
    offlineOnuCount?: number;
    rxPower?: number;
    txPower?: number;
    bandwidthUsage?: {
      upstream: number;
      downstream: number;
    };
  }>;
}

// Support Tickets
export interface SupportTicket {
  id: string;
  customerId: string;
  customerName?: string;
  subject: string;
  description: string;
  status: 'open' | 'in_progress' | 'resolved' | 'closed';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  category: string;
  assignedTo?: string;
  createdAt: string;
  updatedAt: string;
}

// Inventory
export interface InventoryItem {
  id: string;
  name: string;
  category: string;
  quantity: number;
  unitPrice: number;
  supplier?: string;
  serialNumber?: string;
  location?: string;
  status: 'available' | 'in_use' | 'damaged' | 'returned';
  createdAt: string;
}

// Vouchers
export interface Voucher {
  id: string;
  code: string;
  planId: string;
  planName?: string;
  duration: number;
  durationUnit: string;
  usedBy?: string;
  usedAt?: string;
  status: 'active' | 'used' | 'expired';
  createdAt: string;
  expiresAt: string;
}

// Agents
export interface Agent {
  id: string;
  name: string;
  email: string;
  phone: string;
  commissionRate: number;
  totalSales: number;
  totalCommission: number;
  status: 'active' | 'inactive';
  createdAt: string;
}

// Theme
export interface Theme {
  id: string;
  name: string;
  colors: {
    primary: string;
    secondary: string;
    accent: string;
    background: string;
    surface: string;
    text: string;
    textMuted: string;
    border: string;
    success: string;
    warning: string;
    error: string;
    info: string;
  };
}

// API Response Types
export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  message?: string;
  error?: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}
