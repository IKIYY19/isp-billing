import type { ReactNode } from 'react';
import { createContext, useContext, useState, useEffect } from 'react';

export type ThemeType = 
  | 'default'
  | 'dark'
  | 'ocean'
  | 'forest'
  | 'sunset'
  | 'cyberpunk'
  | 'minimal'
  | 'luxury';

interface ThemeColors {
  primary: string;
  secondary: string;
  accent: string;
  background: string;
  foreground: string;
  card: string;
  cardForeground: string;
  border: string;
  muted: string;
  mutedForeground: string;
  success: string;
  warning: string;
  destructive: string;
  info: string;
}

interface Theme {
  id: ThemeType;
  name: string;
  description: string;
  colors: ThemeColors;
  fontFamily?: string;
  borderRadius?: string;
}

export const themes: Record<ThemeType, Theme> = {
  default: {
    id: 'default',
    name: 'Default',
    description: 'Classic blue professional theme',
    colors: {
      primary: 'hsl(221 83% 53%)',
      secondary: 'hsl(215 20% 65%)',
      accent: 'hsl(262 83% 58%)',
      background: 'hsl(0 0% 100%)',
      foreground: 'hsl(222 47% 11%)',
      card: 'hsl(0 0% 100%)',
      cardForeground: 'hsl(222 47% 11%)',
      border: 'hsl(214 32% 91%)',
      muted: 'hsl(210 40% 96%)',
      mutedForeground: 'hsl(215 16% 47%)',
      success: 'hsl(142 76% 36%)',
      warning: 'hsl(38 92% 50%)',
      destructive: 'hsl(0 84% 60%)',
      info: 'hsl(199 89% 48%)'
    }
  },
  dark: {
    id: 'dark',
    name: 'Dark Mode',
    description: 'Sleek dark theme for night work',
    colors: {
      primary: 'hsl(217 91% 60%)',
      secondary: 'hsl(215 20% 45%)',
      accent: 'hsl(262 83% 68%)',
      background: 'hsl(224 71% 4%)',
      foreground: 'hsl(213 31% 91%)',
      card: 'hsl(224 71% 4%)',
      cardForeground: 'hsl(213 31% 91%)',
      border: 'hsl(216 34% 17%)',
      muted: 'hsl(223 47% 11%)',
      mutedForeground: 'hsl(215 20% 55%)',
      success: 'hsl(142 71% 45%)',
      warning: 'hsl(38 92% 50%)',
      destructive: 'hsl(0 62% 30%)',
      info: 'hsl(199 89% 48%)'
    }
  },
  ocean: {
    id: 'ocean',
    name: 'Ocean',
    description: 'Calming blue-green coastal theme',
    colors: {
      primary: 'hsl(188 94% 43%)',
      secondary: 'hsl(199 89% 48%)',
      accent: 'hsl(168 76% 42%)',
      background: 'hsl(200 50% 97%)',
      foreground: 'hsl(200 50% 15%)',
      card: 'hsl(0 0% 100%)',
      cardForeground: 'hsl(200 50% 15%)',
      border: 'hsl(190 40% 88%)',
      muted: 'hsl(195 40% 94%)',
      mutedForeground: 'hsl(200 30% 45%)',
      success: 'hsl(160 84% 39%)',
      warning: 'hsl(35 92% 50%)',
      destructive: 'hsl(0 72% 51%)',
      info: 'hsl(199 89% 48%)'
    }
  },
  forest: {
    id: 'forest',
    name: 'Forest',
    description: 'Natural green earthy theme',
    colors: {
      primary: 'hsl(142 76% 36%)',
      secondary: 'hsl(140 40% 45%)',
      accent: 'hsl(35 92% 50%)',
      background: 'hsl(80 20% 97%)',
      foreground: 'hsl(140 40% 10%)',
      card: 'hsl(0 0% 100%)',
      cardForeground: 'hsl(140 40% 10%)',
      border: 'hsl(120 30% 88%)',
      muted: 'hsl(100 25% 94%)',
      mutedForeground: 'hsl(140 20% 45%)',
      success: 'hsl(142 76% 36%)',
      warning: 'hsl(35 92% 50%)',
      destructive: 'hsl(0 84% 60%)',
      info: 'hsl(199 89% 48%)'
    }
  },
  sunset: {
    id: 'sunset',
    name: 'Sunset',
    description: 'Warm orange and purple gradient theme',
    colors: {
      primary: 'hsl(25 95% 53%)',
      secondary: 'hsl(280 60% 50%)',
      accent: 'hsl(340 82% 52%)',
      background: 'hsl(30 30% 97%)',
      foreground: 'hsl(25 40% 15%)',
      card: 'hsl(0 0% 100%)',
      cardForeground: 'hsl(25 40% 15%)',
      border: 'hsl(25 40% 88%)',
      muted: 'hsl(30 25% 94%)',
      mutedForeground: 'hsl(25 30% 45%)',
      success: 'hsl(142 76% 36%)',
      warning: 'hsl(38 92% 50%)',
      destructive: 'hsl(0 84% 60%)',
      info: 'hsl(199 89% 48%)'
    }
  },
  cyberpunk: {
    id: 'cyberpunk',
    name: 'Cyberpunk',
    description: 'Neon futuristic dark theme',
    colors: {
      primary: 'hsl(300 100% 50%)',
      secondary: 'hsl(180 100% 50%)',
      accent: 'hsl(60 100% 50%)',
      background: 'hsl(280 50% 5%)',
      foreground: 'hsl(0 0% 95%)',
      card: 'hsl(280 40% 8%)',
      cardForeground: 'hsl(0 0% 95%)',
      border: 'hsl(300 50% 25%)',
      muted: 'hsl(280 30% 12%)',
      mutedForeground: 'hsl(280 20% 60%)',
      success: 'hsl(120 100% 50%)',
      warning: 'hsl(60 100% 50%)',
      destructive: 'hsl(0 100% 60%)',
      info: 'hsl(180 100% 50%)'
    },
    fontFamily: 'monospace',
    borderRadius: '0px'
  },
  minimal: {
    id: 'minimal',
    name: 'Minimal',
    description: 'Clean grayscale minimalist theme',
    colors: {
      primary: 'hsl(0 0% 20%)',
      secondary: 'hsl(0 0% 60%)',
      accent: 'hsl(0 0% 40%)',
      background: 'hsl(0 0% 100%)',
      foreground: 'hsl(0 0% 10%)',
      card: 'hsl(0 0% 100%)',
      cardForeground: 'hsl(0 0% 10%)',
      border: 'hsl(0 0% 90%)',
      muted: 'hsl(0 0% 96%)',
      mutedForeground: 'hsl(0 0% 50%)',
      success: 'hsl(0 0% 30%)',
      warning: 'hsl(0 0% 50%)',
      destructive: 'hsl(0 0% 20%)',
      info: 'hsl(0 0% 40%)'
    },
    borderRadius: '2px'
  },
  luxury: {
    id: 'luxury',
    name: 'Luxury',
    description: 'Premium gold and dark theme',
    colors: {
      primary: 'hsl(45 90% 50%)',
      secondary: 'hsl(0 0% 30%)',
      accent: 'hsl(35 80% 45%)',
      background: 'hsl(0 0% 8%)',
      foreground: 'hsl(45 30% 95%)',
      card: 'hsl(0 0% 10%)',
      cardForeground: 'hsl(45 30% 95%)',
      border: 'hsl(45 30% 25%)',
      muted: 'hsl(0 0% 15%)',
      mutedForeground: 'hsl(45 20% 60%)',
      success: 'hsl(142 60% 40%)',
      warning: 'hsl(45 90% 50%)',
      destructive: 'hsl(0 70% 50%)',
      info: 'hsl(199 70% 50%)'
    }
  }
};

interface ThemeContextType {
  currentTheme: ThemeType;
  setTheme: (theme: ThemeType) => void;
  theme: Theme;
  availableThemes: Theme[];
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [currentTheme, setCurrentTheme] = useState<ThemeType>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('isp-billing-theme') as ThemeType;
      return saved && themes[saved] ? saved : 'default';
    }
    return 'default';
  });

  useEffect(() => {
    const theme = themes[currentTheme];
    const root = document.documentElement;

    Object.entries(theme.colors).forEach(([key, value]) => {
      const cssKey = key.replace(/([A-Z])/g, '-$1').toLowerCase();
      root.style.setProperty(`--${cssKey}`, value);
    });

    if (theme.fontFamily) {
      root.style.setProperty('--font-family', theme.fontFamily);
    } else {
      root.style.removeProperty('--font-family');
    }

    if (theme.borderRadius) {
      root.style.setProperty('--radius', theme.borderRadius);
    } else {
      root.style.removeProperty('--radius');
    }

    localStorage.setItem('isp-billing-theme', currentTheme);

    if (currentTheme === 'dark' || currentTheme === 'cyberpunk' || currentTheme === 'luxury') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [currentTheme]);

  const setTheme = (theme: ThemeType) => {
    if (themes[theme]) {
      setCurrentTheme(theme);
    }
  };

  return (
    <ThemeContext.Provider value={{
      currentTheme,
      setTheme,
      theme: themes[currentTheme],
      availableThemes: Object.values(themes)
    }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (context === undefined) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
}
