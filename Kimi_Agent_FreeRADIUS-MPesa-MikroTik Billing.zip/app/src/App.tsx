import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import LoginPage from './components/auth/LoginPage';
import Dashboard from './pages/Dashboard';
import Customers from './pages/Customers';
import Plans from './pages/Plans';
import Invoices from './pages/Invoices';
import Payments from './pages/Payments';
import MikrotikRouters from './pages/MikrotikRouters';
import HotspotLocations from './pages/HotspotLocations';
import PPPoESessions from './pages/PPPoESessions';
import FreeRadius from './pages/FreeRadius';
import MPesaConfig from './pages/MPesaConfig';
import Reports from './pages/Reports';
import Settings from './pages/Settings';
import NetworkMonitor from './pages/NetworkMonitor';
import BulkOperations from './pages/BulkOperations';
import Automation from './pages/Automation';
import AuditLogs from './pages/AuditLogs';
import CustomerPortal from './pages/CustomerPortal';
import SupportTickets from './pages/SupportTickets';
import Inventory from './pages/Inventory';
import Vouchers from './pages/Vouchers';
import Agents from './pages/Agents';
import AIAnalytics from './pages/AIAnalytics';
import WhatsAppIntegration from './pages/WhatsAppIntegration';
import UsageAnalytics from './pages/UsageAnalytics';
import DataCenter from './pages/DataCenter';
import OLTManagement from './pages/OLTManagement';
import type { User, Notification } from './types';

export type Page =
  | 'dashboard'
  | 'customers'
  | 'plans'
  | 'invoices'
  | 'payments'
  | 'mikrotik'
  | 'hotspot'
  | 'pppoe'
  | 'freeradius'
  | 'mpesa'
  | 'reports'
  | 'settings'
  | 'network-monitor'
  | 'bulk-operations'
  | 'automation'
  | 'audit-logs'
  | 'customer-portal'
  | 'support-tickets'
  | 'inventory'
  | 'vouchers'
  | 'agents'
  | 'ai-analytics'
  | 'whatsapp'
  | 'usage-analytics'
  | 'data-center'
  | 'olt-management';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentPage, setCurrentPage] = useState<Page>('dashboard');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check for existing session
    const savedUser = localStorage.getItem('currentUser');
    if (savedUser) {
      try {
        const user = JSON.parse(savedUser);
        setCurrentUser(user);
        setIsAuthenticated(true);
      } catch {
        localStorage.removeItem('currentUser');
      }
    }
    setIsLoading(false);

    // Load mock notifications
    setNotifications([
      {
        id: '1',
        title: 'Payment Received',
        message: 'M-Pesa payment of KES 2,500 received from John Doe',
        type: 'success',
        read: false,
        createdAt: new Date().toISOString(),
      },
      {
        id: '2',
        title: 'Router Offline',
        message: 'MikroTik router "Main Tower" is offline',
        type: 'error',
        read: false,
        createdAt: new Date(Date.now() - 3600000).toISOString(),
      },
      {
        id: '3',
        title: 'Account Expiring',
        message: '5 customer accounts will expire in the next 24 hours',
        type: 'warning',
        read: true,
        createdAt: new Date(Date.now() - 7200000).toISOString(),
      },
    ]);
  }, []);

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    setIsAuthenticated(true);
    localStorage.setItem('currentUser', JSON.stringify(user));
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setIsAuthenticated(false);
    localStorage.removeItem('currentUser');
  };

  const markNotificationAsRead = (id: string) => {
    setNotifications(prev => 
      prev.map(n => n.id === id ? { ...n, read: true } : n)
    );
  };

  const markAllNotificationsAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <Dashboard />;
      case 'customers':
        return <Customers />;
      case 'plans':
        return <Plans />;
      case 'invoices':
        return <Invoices />;
      case 'payments':
        return <Payments />;
      case 'mikrotik':
        return <MikrotikRouters />;
      case 'hotspot':
        return <HotspotLocations />;
      case 'pppoe':
        return <PPPoESessions />;
      case 'freeradius':
        return <FreeRadius />;
      case 'mpesa':
        return <MPesaConfig />;
      case 'reports':
        return <Reports />;
      case 'settings':
        return <Settings />;
      case 'network-monitor':
        return <NetworkMonitor />;
      case 'bulk-operations':
        return <BulkOperations />;
      case 'automation':
        return <Automation />;
      case 'audit-logs':
        return <AuditLogs />;
      case 'customer-portal':
        return <CustomerPortal />;
      case 'support-tickets':
        return <SupportTickets />;
      case 'inventory':
        return <Inventory />;
      case 'vouchers':
        return <Vouchers />;
      case 'agents':
        return <Agents />;
      case 'ai-analytics':
        return <AIAnalytics />;
      case 'whatsapp':
        return <WhatsAppIntegration />;
      case 'usage-analytics':
        return <UsageAnalytics />;
      case 'data-center':
        return <DataCenter />;
      case 'olt-management':
        return <OLTManagement />;
      default:
        return <Dashboard />;
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin" />
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <LoginPage onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-background flex">
      <Sidebar 
        currentPage={currentPage} 
        onPageChange={(page) => setCurrentPage(page as Page)}
        collapsed={isSidebarCollapsed}
        onToggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
        userRole={currentUser?.role || 'staff'}
      />
      
      <div className={`flex-1 flex flex-col transition-all duration-300 ${isSidebarCollapsed ? 'ml-16' : 'ml-64'}`}>
        <Header 
          currentPage={currentPage}
          onMenuToggle={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
          notifications={notifications}
          unreadCount={unreadCount}
          onMarkAsRead={markNotificationAsRead}
          onMarkAllAsRead={markAllNotificationsAsRead}
          currentUser={currentUser}
          onLogout={handleLogout}
        />
        
        <main className="flex-1 p-6 overflow-auto scrollbar-thin">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentPage}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
              className="h-full"
            >
              {renderPage()}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
}

export default App;
