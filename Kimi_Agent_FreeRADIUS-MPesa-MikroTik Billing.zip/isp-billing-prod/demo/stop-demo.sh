#!/bin/bash

# ISP Billing System - Stop Demo Environment

set -e

DEMO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}🛑 Stopping ISP Billing Demo Environment...${NC}"

# Stop backend
if [ -f "$DEMO_DIR/backend.pid" ]; then
    BACKEND_PID=$(cat "$DEMO_DIR/backend.pid")
    if kill -0 $BACKEND_PID 2>/dev/null; then
        kill $BACKEND_PID
        echo -e "${GREEN}✅ Backend stopped${NC}"
    fi
    rm -f "$DEMO_DIR/backend.pid"
fi

# Stop frontend
if [ -f "$DEMO_DIR/frontend.pid" ]; then
    FRONTEND_PID=$(cat "$DEMO_DIR/frontend.pid")
    if kill -0 $FRONTEND_PID 2>/dev/null; then
        kill $FRONTEND_PID
        echo -e "${GREEN}✅ Frontend stopped${NC}"
    fi
    rm -f "$DEMO_DIR/frontend.pid"
fi

# Stop containers
docker rm -f isp-billing-demo-db isp-billing-demo-redis 2>/dev/null || true
echo -e "${GREEN}✅ Database and Redis stopped${NC}"

echo ""
echo -e "${GREEN}🎉 Demo environment stopped successfully!${NC}"
