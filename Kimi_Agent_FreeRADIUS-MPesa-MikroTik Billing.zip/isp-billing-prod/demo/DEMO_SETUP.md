# ISP Billing System - Demo Environment Setup

This guide walks you through setting up a demo environment for showcasing the ISP Billing System to potential customers or stakeholders.

## Quick Start (5 minutes)

```bash
# 1. Clone and navigate to the project
cd /mnt/okcomputer/output/isp-billing-prod

# 2. Run the demo setup script
chmod +x demo/setup-demo.sh
./demo/setup-demo.sh

# 3. Access the demo
# Frontend: http://localhost:3001
# Backend API: http://localhost:3000/api/v1
# Admin: admin@demo.com / Demo@123
# Customer: customer@demo.com / Demo@123
```

## Demo Environment Features

### Pre-configured Data

The demo environment comes with:

- **10 Sample Customers** with realistic data
- **5 Internet Plans** (Residential & Business)
- **20 Sample Invoices** (paid, pending, overdue)
- **15 Sample Payments** across different methods
- **8 Support Tickets** in various states
- **3 Network Routers** with status
- **2 OLTs** with PON ports and ONUs

### Demo Accounts

| Role | Email | Password | Description |
|------|-------|----------|-------------|
| Super Admin | `admin@demo.com` | `Demo@123` | Full system access |
| Support Agent | `support@demo.com` | `Demo@123` | Support & customer management |
| Customer | `customer@demo.com` | `Demo@123` | Self-service portal |

### Demo Scenarios

#### 1. Customer Self-Service Portal
```
Login: customer@demo.com / Demo@123
```

**Features to showcase:**
- Dashboard with usage statistics
- View and pay invoices
- Create support tickets
- Update profile information
- View subscription details

#### 2. Admin Dashboard
```
Login: admin@demo.com / Demo@123
```

**Features to showcase:**
- Real-time network monitoring
- Customer management
- Invoice generation
- Payment processing
- Support ticket management
- Reports and analytics
- OLT management

#### 3. Payment Processing

**M-Pesa Demo:**
- Use phone number: `254712345678`
- Simulate payment success/failure
- View transaction history

**Bank Transfer Demo:**
- Pre-configured bank accounts
- Upload payment receipts
- Reconciliation workflow

## Demo Setup Script

The `setup-demo.sh` script performs:

1. **Environment Setup**
   - Creates demo `.env` file
   - Configures demo database
   - Sets up demo API keys

2. **Database Seeding**
   - Creates sample customers
   - Generates sample invoices
   - Adds sample payments
   - Creates support tickets
   - Configures network devices

3. **Service Startup**
   - Starts PostgreSQL with demo data
   - Starts Redis for caching
   - Starts backend API server
   - Starts frontend development server

4. **Demo Data Reset**
   - Provides option to reset data daily
   - Maintains demo account credentials

## Manual Demo Setup

If you prefer manual setup:

### 1. Database Setup

```bash
# Create demo database
docker run -d \
  --name isp-billing-demo-db \
  -e POSTGRES_DB=isp_billing_demo \
  -e POSTGRES_USER=demo \
  -e POSTGRES_PASSWORD=demo123 \
  -p 5433:5432 \
  postgres:15-alpine

# Run migrations
cd backend
npx prisma migrate dev --name demo_init
npx prisma db seed
```

### 2. Environment Configuration

Create `demo/.env.demo`:

```env
# Database
DATABASE_URL="postgresql://demo:demo123@localhost:5433/isp_billing_demo"

# Redis
REDIS_URL="redis://localhost:6380"

# JWT
JWT_SECRET="demo-secret-key-change-in-production"
JWT_EXPIRES_IN="24h"

# M-Pesa (Sandbox)
MPESA_CONSUMER_KEY="demo_consumer_key"
MPESA_CONSUMER_SECRET="demo_consumer_secret"
MPESA_PASSKEY="demo_passkey"
MPESA_SHORTCODE="174379"
MPESA_ENVIRONMENT="sandbox"

# Africa's Talking (Demo)
AT_API_KEY="demo_api_key"
AT_USERNAME="sandbox"

# Demo Mode
DEMO_MODE=true
DEMO_RESET_INTERVAL=86400
```

### 3. Start Services

```bash
# Terminal 1: Backend
cd backend
npm run start:dev

# Terminal 2: Frontend
cd frontend
npm run dev

# Terminal 3: Redis (if not running)
docker run -d --name isp-billing-demo-redis -p 6380:6379 redis:7-alpine
```

## Demo Data Customization

### Customize Sample Customers

Edit `demo/seed-data.js`:

```javascript
const demoCustomers = [
  {
    firstName: 'John',
    lastName: 'Doe',
    email: 'john.doe@example.com',
    phone: '254712345678',
    plan: 'Premium Home',
    // ...
  },
  // Add more customers
];
```

### Customize Plans

```javascript
const demoPlans = [
  {
    name: 'Basic Home',
    speed: { download: 5, upload: 2 },
    price: 1500,
    // ...
  },
  // Add more plans
];
```

## Demo Presentation Tips

### 1. Opening (2 minutes)
- Welcome and introduce the system
- Overview of key features
- Login to admin dashboard

### 2. Admin Dashboard Tour (5 minutes)
- Show real-time statistics
- Navigate through different sections
- Highlight key metrics

### 3. Customer Management (5 minutes)
- View customer list
- Show customer details
- Demonstrate search and filters
- Show customer usage

### 4. Billing & Payments (5 minutes)
- Show invoice list
- Generate a new invoice
- Process a payment (M-Pesa demo)
- Show payment history

### 5. Support System (3 minutes)
- Show ticket list
- Create a new ticket
- Respond to ticket
- Show knowledge base

### 6. Network Management (3 minutes)
- Show router status
- Show OLT management
- Show connected customers
- Demonstrate monitoring

### 7. Customer Portal (3 minutes)
- Login as customer
- Show dashboard
- Pay an invoice
- Create support ticket

### 8. Q&A (4 minutes)
- Answer questions
- Show additional features as requested
- Discuss pricing and implementation

## Demo Reset

To reset demo data:

```bash
# Automatic reset (runs daily at midnight)
cd demo
./reset-demo.sh

# Manual reset
cd backend
npx prisma db seed --force
```

## Troubleshooting

### Demo Not Loading
```bash
# Check if services are running
docker ps

# Check logs
docker logs isp-billing-demo-db
docker logs isp-billing-demo-redis

# Restart services
docker-compose -f demo/docker-compose.demo.yml restart
```

### Database Connection Issues
```bash
# Reset database
docker rm -f isp-billing-demo-db
./demo/setup-demo.sh
```

### Port Conflicts
```bash
# Check port usage
lsof -i :3000
lsof -i :3001
lsof -i :5433
lsof -i :6380

# Kill processes or change ports in .env
```

## Security Considerations

⚠️ **Important:** The demo environment is for demonstration purposes only.

- Use fake/demo data only
- Disable in production
- Regular data resets
- No real payment processing
- Sandbox API keys only

## Customization for Your Brand

### 1. Update Logo
Replace `frontend/public/logo.png` with your logo

### 2. Update Colors
Edit `frontend/src/constants/colors.ts`:

```typescript
export const Colors = {
  primary: {
    600: '#YOUR_BRAND_COLOR',
    // ...
  },
};
```

### 3. Update Company Info
Edit `frontend/src/constants/config.ts`:

```typescript
export const APP_CONFIG = {
  name: 'Your ISP Name',
  supportEmail: 'support@yourdomain.com',
  supportPhone: '+254...',
  // ...
};
```

## Support

For demo setup assistance:
- Email: support@yourdomain.com
- Documentation: https://docs.yourdomain.com
- Video Tutorials: https://youtube.com/yourchannel
