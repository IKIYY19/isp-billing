#!/bin/bash

# ISP Billing System - Demo Environment Setup Script
# This script sets up a complete demo environment for showcasing the system

set -e

echo "🚀 ISP Billing System - Demo Setup"
echo "==================================="
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
DEMO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$DEMO_DIR")"
DB_CONTAINER="isp-billing-demo-db"
REDIS_CONTAINER="isp-billing-demo-redis"
DB_PORT=5433
REDIS_PORT=6380

# Functions
print_status() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

# Check if Docker is installed
check_docker() {
    print_status "Checking Docker installation..."
    
    if ! command -v docker &> /dev/null; then
        print_error "Docker is not installed. Please install Docker first."
        exit 1
    fi
    
    if ! docker info &> /dev/null; then
        print_error "Docker daemon is not running. Please start Docker."
        exit 1
    fi
    
    print_success "Docker is ready"
}

# Check if Node.js is installed
check_node() {
    print_status "Checking Node.js installation..."
    
    if ! command -v node &> /dev/null; then
        print_error "Node.js is not installed. Please install Node.js 18+ first."
        exit 1
    fi
    
    NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
    if [ "$NODE_VERSION" -lt 18 ]; then
        print_error "Node.js version 18+ required. Current: $(node -v)"
        exit 1
    fi
    
    print_success "Node.js $(node -v) is ready"
}

# Stop existing containers
stop_existing() {
    print_status "Stopping existing demo containers..."
    
    docker rm -f $DB_CONTAINER $REDIS_CONTAINER 2>/dev/null || true
    
    print_success "Existing containers stopped"
}

# Start PostgreSQL container
start_database() {
    print_status "Starting PostgreSQL database..."
    
    docker run -d \
        --name $DB_CONTAINER \
        -e POSTGRES_DB=isp_billing_demo \
        -e POSTGRES_USER=demo \
        -e POSTGRES_PASSWORD=demo123 \
        -p $DB_PORT:5432 \
        -v "$DEMO_DIR/postgres-data:/var/lib/postgresql/data" \
        postgres:15-alpine \
        > /dev/null
    
    # Wait for database to be ready
    print_status "Waiting for database to be ready..."
    sleep 5
    
    until docker exec $DB_CONTAINER pg_isready -U demo > /dev/null 2>&1; do
        sleep 1
    done
    
    print_success "PostgreSQL is ready on port $DB_PORT"
}

# Start Redis container
start_redis() {
    print_status "Starting Redis cache..."
    
    docker run -d \
        --name $REDIS_CONTAINER \
        -p $REDIS_PORT:6379 \
        redis:7-alpine \
        > /dev/null
    
    print_success "Redis is ready on port $REDIS_PORT"
}

# Create demo environment file
create_env_file() {
    print_status "Creating demo environment configuration..."
    
    cat > "$PROJECT_ROOT/backend/.env.demo" << EOF
# Demo Environment Configuration
NODE_ENV=development
PORT=3000

# Database
DATABASE_URL="postgresql://demo:demo123@localhost:$DB_PORT/isp_billing_demo"

# Redis
REDIS_URL="redis://localhost:$REDIS_PORT"

# JWT
JWT_SECRET="demo-secret-key-not-for-production"
JWT_EXPIRES_IN="24h"
JWT_REFRESH_SECRET="demo-refresh-secret-key"
JWT_REFRESH_EXPIRES_IN="7d"

# CORS
CORS_ORIGIN="http://localhost:3001"

# M-Pesa (Sandbox)
MPESA_CONSUMER_KEY="demo_consumer_key"
MPESA_CONSUMER_SECRET="demo_consumer_secret"
MPESA_PASSKEY="demo_passkey"
MPESA_SHORTCODE="174379"
MPESA_ENVIRONMENT="sandbox"

# Africa's Talking (Demo)
AT_API_KEY="demo_api_key"
AT_USERNAME="sandbox"

# Email (Console output only)
SMTP_HOST="localhost"
SMTP_PORT=587
SMTP_USER="demo"
SMTP_PASS="demo"
EMAIL_FROM="demo@ispbilling.local"

# Demo Mode
DEMO_MODE=true
DEMO_RESET_INTERVAL=86400

# Logging
LOG_LEVEL="debug"
EOF
    
    print_success "Demo environment file created"
}

# Install dependencies
install_dependencies() {
    print_status "Installing backend dependencies..."
    
    cd "$PROJECT_ROOT/backend"
    
    if [ ! -d "node_modules" ]; then
        npm install
    fi
    
    print_success "Backend dependencies installed"
    
    print_status "Installing frontend dependencies..."
    
    cd "$PROJECT_ROOT/frontend"
    
    if [ ! -d "node_modules" ]; then
        npm install
    fi
    
    print_success "Frontend dependencies installed"
}

# Setup database
setup_database() {
    print_status "Setting up database schema..."
    
    cd "$PROJECT_ROOT/backend"
    
    # Copy demo env
    cp .env.demo .env
    
    # Generate Prisma client
    npx prisma generate
    
    # Run migrations
    npx prisma migrate dev --name demo_init --create-only 2>/dev/null || true
    npx prisma migrate deploy
    
    print_success "Database schema created"
}

# Seed demo data
seed_data() {
    print_status "Seeding demo data..."
    
    cd "$PROJECT_ROOT/backend"
    
    # Create seed script if it doesn't exist
    if [ ! -f "prisma/seed.ts" ]; then
        cat > "prisma/seed.ts" << 'EOF'
import { PrismaClient } from '@prisma/client';
import * as bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding demo data...');

  // Create demo admin user
  const adminPassword = await bcrypt.hash('Demo@123', 10);
  const admin = await prisma.user.upsert({
    where: { email: 'admin@demo.com' },
    update: {},
    create: {
      email: 'admin@demo.com',
      password: adminPassword,
      firstName: 'Demo',
      lastName: 'Admin',
      phone: '254700000001',
      role: 'admin',
      isActive: true,
      emailVerified: true,
      phoneVerified: true,
    },
  });
  console.log('✅ Admin user created:', admin.email);

  // Create demo support user
  const supportPassword = await bcrypt.hash('Demo@123', 10);
  const support = await prisma.user.upsert({
    where: { email: 'support@demo.com' },
    update: {},
    create: {
      email: 'support@demo.com',
      password: supportPassword,
      firstName: 'Support',
      lastName: 'Agent',
      phone: '254700000002',
      role: 'support',
      isActive: true,
      emailVerified: true,
      phoneVerified: true,
    },
  });
  console.log('✅ Support user created:', support.email);

  // Create demo customer user
  const customerPassword = await bcrypt.hash('Demo@123', 10);
  const customer = await prisma.user.upsert({
    where: { email: 'customer@demo.com' },
    update: {},
    create: {
      email: 'customer@demo.com',
      password: customerPassword,
      firstName: 'Demo',
      lastName: 'Customer',
      phone: '254712345678',
      role: 'customer',
      isActive: true,
      emailVerified: true,
      phoneVerified: true,
      address: '123 Demo Street',
      city: 'Nairobi',
      country: 'Kenya',
      accountNumber: 'ACC' + Date.now().toString().slice(-6),
    },
  });
  console.log('✅ Customer user created:', customer.email);

  // Create internet plans
  const plans = await Promise.all([
    prisma.plan.upsert({
      where: { id: 'plan-basic' },
      update: {},
      create: {
        id: 'plan-basic',
        name: 'Basic Home',
        description: '5 Mbps download, 2 Mbps upload - Perfect for browsing',
        speedDownload: 5,
        speedUpload: 2,
        price: 1500,
        currency: 'KES',
        billingCycle: 'monthly',
        isActive: true,
        category: 'residential',
      },
    }),
    prisma.plan.upsert({
      where: { id: 'plan-standard' },
      update: {},
      create: {
        id: 'plan-standard',
        name: 'Standard Home',
        description: '10 Mbps download, 5 Mbps upload - Great for streaming',
        speedDownload: 10,
        speedUpload: 5,
        price: 2500,
        currency: 'KES',
        billingCycle: 'monthly',
        isActive: true,
        category: 'residential',
        isPopular: true,
      },
    }),
    prisma.plan.upsert({
      where: { id: 'plan-premium' },
      update: {},
      create: {
        id: 'plan-premium',
        name: 'Premium Home',
        description: '20 Mbps download, 10 Mbps upload - For power users',
        speedDownload: 20,
        speedUpload: 10,
        price: 4500,
        currency: 'KES',
        billingCycle: 'monthly',
        isActive: true,
        category: 'residential',
      },
    }),
  ]);
  console.log('✅ Created', plans.length, 'plans');

  console.log('✅ Demo data seeded successfully!');
}

main()
  .catch((e) => {
    console.error('❌ Seeding error:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
EOF
    fi
    
    # Run seed
    npx prisma db seed
    
    print_success "Demo data seeded"
}

# Start backend server
start_backend() {
    print_status "Starting backend server..."
    
    cd "$PROJECT_ROOT/backend"
    
    # Start in background
    npm run start:dev > "$DEMO_DIR/backend.log" 2>&1 &
    BACKEND_PID=$!
    
    echo $BACKEND_PID > "$DEMO_DIR/backend.pid"
    
    # Wait for backend to be ready
    print_status "Waiting for backend to start..."
    sleep 5
    
    until curl -s http://localhost:3000/health > /dev/null 2>&1; do
        sleep 1
    done
    
    print_success "Backend server started (PID: $BACKEND_PID)"
}

# Start frontend server
start_frontend() {
    print_status "Starting frontend server..."
    
    cd "$PROJECT_ROOT/frontend"
    
    # Start in background
    npm run dev > "$DEMO_DIR/frontend.log" 2>&1 &
    FRONTEND_PID=$!
    
    echo $FRONTEND_PID > "$DEMO_DIR/frontend.pid"
    
    # Wait for frontend to be ready
    print_status "Waiting for frontend to start..."
    sleep 10
    
    print_success "Frontend server started (PID: $FRONTEND_PID)"
}

# Print access information
print_access_info() {
    echo ""
    echo "==================================="
    echo -e "${GREEN}🎉 Demo Environment Ready!${NC}"
    echo "==================================="
    echo ""
    echo -e "${BLUE}📱 Frontend:${NC} http://localhost:3001"
    echo -e "${BLUE}🔌 Backend API:${NC} http://localhost:3000/api/v1"
    echo -e "${BLUE}📊 API Docs:${NC} http://localhost:3000/api-docs"
    echo ""
    echo "Demo Accounts:"
    echo "  👤 Admin: admin@demo.com / Demo@123"
    echo "  🎧 Support: support@demo.com / Demo@123"
    echo "  🏠 Customer: customer@demo.com / Demo@123"
    echo ""
    echo "Useful Commands:"
    echo "  ./demo/stop-demo.sh    - Stop demo environment"
    echo "  ./demo/reset-demo.sh   - Reset demo data"
    echo "  tail -f demo/backend.log   - View backend logs"
    echo "  tail -f demo/frontend.log  - View frontend logs"
    echo ""
    echo -e "${YELLOW}⚠️  This is a demo environment. Do not use in production.${NC}"
    echo ""
}

# Main setup function
main() {
    print_status "Starting ISP Billing System demo setup..."
    
    # Pre-flight checks
    check_docker
    check_node
    
    # Setup infrastructure
    stop_existing
    start_database
    start_redis
    
    # Setup application
    create_env_file
    install_dependencies
    setup_database
    seed_data
    
    # Start services
    start_backend
    start_frontend
    
    # Print access info
    print_access_info
}

# Run main function
main "$@"
