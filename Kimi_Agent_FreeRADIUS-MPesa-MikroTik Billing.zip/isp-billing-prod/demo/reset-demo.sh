#!/bin/bash

# ISP Billing System - Reset Demo Data

set -e

DEMO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$DEMO_DIR")"

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${BLUE}🔄 Resetting ISP Billing Demo Data...${NC}"
echo ""

# Confirm reset
echo -e "${YELLOW}⚠️  This will reset all demo data to initial state.${NC}"
read -p "Are you sure? (y/N): " confirm

if [[ $confirm != [yY] && $confirm != [yY][eE][sS] ]]; then
    echo "Reset cancelled."
    exit 0
fi

cd "$PROJECT_ROOT/backend"

# Reset database
echo -e "${BLUE}Resetting database...${NC}"
npx prisma migrate reset --force

# Reseed data
echo -e "${BLUE}Reseeding demo data...${NC}"
npx prisma db seed

echo ""
echo -e "${GREEN}✅ Demo data reset successfully!${NC}"
echo ""
echo "Demo accounts:"
echo "  Admin: admin@demo.com / Demo@123"
echo "  Support: support@demo.com / Demo@123"
echo "  Customer: customer@demo.com / Demo@123"
