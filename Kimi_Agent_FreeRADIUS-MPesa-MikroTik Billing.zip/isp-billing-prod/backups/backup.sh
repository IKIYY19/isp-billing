#!/bin/sh
# ============================================
# ISP Billing System - Backup Script
# ============================================

set -e

# Configuration
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/backups"
DB_HOST="${DB_HOST:-postgres}"
DB_NAME="${DB_NAME:-isp_billing}"
DB_USER="${DB_USER:-isp_user}"
DB_PASSWORD="${DB_PASSWORD:-isp_password_2024}"
RETENTION_DAYS="${BACKUP_RETENTION_DAYS:-30}"
S3_BUCKET="${AWS_S3_BUCKET}"
AWS_REGION="${AWS_REGION:-us-east-1}"

# Colors (if terminal supports it)
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Logging functions
log() {
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] $1"
}

error() {
    echo "${RED}[ERROR]${NC} $1" >&2
}

success() {
    echo "${GREEN}[SUCCESS]${NC} $1"
}

warning() {
    echo "${YELLOW}[WARNING]${NC} $1"
}

# Create backup directory
mkdir -p "$BACKUP_DIR"

cd "$BACKUP_DIR"

log "Starting backup process..."

# ============================================
# 1. Database Backup
# ============================================
log "Backing up PostgreSQL database..."

export PGPASSWORD="$DB_PASSWORD"

if pg_dump -h "$DB_HOST" -U "$DB_USER" -d "$DB_NAME" -Fc > "db_$TIMESTAMP.dump" 2>/dev/null; then
    DB_SIZE=$(du -h "db_$TIMESTAMP.dump" | cut -f1)
    success "Database backup completed: db_$TIMESTAMP.dump ($DB_SIZE)"
else
    error "Database backup failed!"
    exit 1
fi

# ============================================
# 2. Create Full Backup Archive
# ============================================
log "Creating full backup archive..."

BACKUP_NAME="isp_billing_backup_$TIMESTAMP"
mkdir -p "$BACKUP_NAME"

# Move database backup
mv "db_$TIMESTAMP.dump" "$BACKUP_NAME/"

# Add metadata
cat > "$BACKUP_NAME/metadata.txt" << EOF
Backup Date: $(date)
Database: $DB_NAME
Host: $DB_HOST
Backup Type: Full
EOF

# Compress backup
tar -czf "${BACKUP_NAME}.tar.gz" "$BACKUP_NAME"
rm -rf "$BACKUP_NAME"

BACKUP_SIZE=$(du -h "${BACKUP_NAME}.tar.gz" | cut -f1)
success "Full backup created: ${BACKUP_NAME}.tar.gz ($BACKUP_SIZE)"

# ============================================
# 3. Upload to S3 (if configured)
# ============================================
if [ -n "$S3_BUCKET" ] && [ -n "$AWS_ACCESS_KEY_ID" ] && [ -n "$AWS_SECRET_ACCESS_KEY" ]; then
    log "Uploading backup to S3..."
    
    if aws s3 cp "${BACKUP_NAME}.tar.gz" "s3://${S3_BUCKET}/backups/" --region "$AWS_REGION"; then
        success "Backup uploaded to S3: s3://${S3_BUCKET}/backups/${BACKUP_NAME}.tar.gz"
    else
        warning "S3 upload failed, keeping local backup"
    fi
else
    log "S3 not configured, keeping local backup only"
fi

# ============================================
# 4. Cleanup Old Backups
# ============================================
log "Cleaning up old backups (retention: $RETENTION_DAYS days)..."

# Local cleanup
DELETED_COUNT=$(find "$BACKUP_DIR" -name "isp_billing_backup_*.tar.gz" -mtime +$RETENTION_DAYS | wc -l)
find "$BACKUP_DIR" -name "isp_billing_backup_*.tar.gz" -mtime +$RETENTION_DAYS -delete

if [ "$DELETED_COUNT" -gt 0 ]; then
    log "Deleted $DELETED_COUNT old local backups"
fi

# S3 cleanup (if configured)
if [ -n "$S3_BUCKET" ] && [ -n "$AWS_ACCESS_KEY_ID" ]; then
    log "Cleaning up old S3 backups..."
    
    # List and delete old backups from S3
    aws s3 ls "s3://${S3_BUCKET}/backups/" --region "$AWS_REGION" | \
    while read -r line; do
        FILE_DATE=$(echo "$line" | awk '{print $1}')
        FILE_NAME=$(echo "$line" | awk '{print $4}')
        
        # Calculate age in days
        FILE_AGE=$(( ( $(date +%s) - $(date -d "$FILE_DATE" +%s) ) / 86400 ))
        
        if [ "$FILE_AGE" -gt "$RETENTION_DAYS" ]; then
            aws s3 rm "s3://${S3_BUCKET}/backups/${FILE_NAME}" --region "$AWS_REGION"
            log "Deleted from S3: $FILE_NAME"
        fi
    done
fi

# ============================================
# 5. Send Notification (optional)
# ============================================
if [ -n "$WEBHOOK_URL" ]; then
    log "Sending notification..."
    
    curl -s -X POST "$WEBHOOK_URL" \
        -H "Content-Type: application/json" \
        -d "{
            \"text\": \"ISP Billing Backup Completed\",
            \"backup_name\": \"${BACKUP_NAME}.tar.gz\",
            \"size\": \"$BACKUP_SIZE\",
            \"timestamp\": \"$(date -Iseconds)\"
        }" || warning "Notification failed"
fi

# ============================================
# Summary
# ============================================
echo ""
echo "========================================"
echo "  Backup Summary"
echo "========================================"
echo "Backup File: ${BACKUP_NAME}.tar.gz"
echo "Size: $BACKUP_SIZE"
echo "Location: $BACKUP_DIR"
if [ -n "$S3_BUCKET" ]; then
    echo "S3: s3://${S3_BUCKET}/backups/"
fi
echo "Retention: $RETENTION_DAYS days"
echo "========================================"

success "Backup process completed successfully!"
