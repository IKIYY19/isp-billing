# ISP Billing System - Complete Deployment Guide

## 🎯 What You're Getting

A **production-ready ISP Billing System** with:

| Feature | Status |
|---------|--------|
| ✅ React Frontend | Complete with 25+ pages |
| ✅ Node.js Backend | Express + TypeScript API |
| ✅ PostgreSQL Database | Full schema with migrations |
| ✅ Redis Cache | Session & queue management |
| ✅ M-Pesa Integration | Daraja API for payments |
| ✅ OLT Management | Multi-vendor support (Huawei, ZTE, Nokia) |
| ✅ MikroTik Integration | Router monitoring & management |
| ✅ WhatsApp Integration | Business API notifications |
| ✅ SMS Notifications | Africa's Talking integration |
| ✅ Email Service | SMTP with templates |
| ✅ AI Customer Insights | Churn prediction, LTV analysis |
| ✅ Automated Billing | Monthly invoices, reminders |
| ✅ Monitoring | Prometheus + Grafana dashboards |
| ✅ Backups | Daily automated backups |
| ✅ SSL Certificates | Let's Encrypt auto-renewal |
| ✅ CI/CD Pipeline | GitHub Actions deployment |

---

## 🚀 Quick Deploy (5 Minutes)

### Prerequisites
- Ubuntu 22.04 LTS server
- 4GB RAM, 2 CPU cores
- Domain name (e.g., `billing.yourcompany.com`)
- Static IP address

### Step 1: Prepare Your Server

```bash
# SSH into your server
ssh root@your-server-ip

# Download deployment script
curl -fsSL https://raw.githubusercontent.com/yourusername/isp-billing/main/isp-billing-prod/scripts/deploy.sh -o deploy.sh
chmod +x deploy.sh

# Run deployment
./deploy.sh
```

### Step 2: Configure Environment

```bash
# Edit environment variables
nano /opt/isp-billing/docker/.env
```

Fill in your values:
```bash
# Required
DB_PASSWORD=your_secure_password
JWT_SECRET=$(openssl rand -base64 32)
DOMAIN=billing.yourcompany.com
EMAIL=admin@yourcompany.com

# M-Pesa (Get from https://developer.safaricom.co.ke/)
MPESA_CONSUMER_KEY=your_key
MPESA_CONSUMER_SECRET=your_secret
MPESA_PASSKEY=your_passkey

# Africa's Talking (Get from https://account.africastalking.com/)
AFRICASTALKING_API_KEY=your_key
AFRICASTALKING_USERNAME=your_username

# Email (Gmail SMTP)
SMTP_HOST=smtp.gmail.com
SMTP_USER=your-email@gmail.com
SMTP_PASS=your_app_password
```

### Step 3: Start Services

```bash
cd /opt/isp-billing/docker
docker-compose up -d
```

### Step 4: Setup SSL

```bash
/opt/isp-billing/scripts/setup-ssl.sh billing.yourcompany.com admin@yourcompany.com
```

### Step 5: Access Your System

| Service | URL |
|---------|-----|
| **Main App** | https://billing.yourcompany.com |
| **API Docs** | https://billing.yourcompany.com/api/docs |
| **Grafana** | http://your-server-ip:3002 |
| **Prometheus** | http://your-server-ip:9090 |

---

## 📁 Project Structure

```
isp-billing-prod/
├── docker/
│   ├── docker-compose.yml          # Main orchestration
│   ├── frontend.Dockerfile         # Frontend build
│   ├── backend.Dockerfile          # Backend build
│   └── .env.example                # Config template
│
├── nginx/
│   ├── nginx.conf                  # Main nginx config
│   └── conf.d/
│       └── default.conf            # Site config
│
├── monitoring/
│   ├── prometheus.yml              # Metrics collection
│   └── grafana/
│       ├── dashboards/             # Pre-built dashboards
│       └── datasources/            # Data source config
│
├── backups/
│   ├── Dockerfile                  # Backup service
│   └── backup.sh                   # Backup script
│
├── scripts/
│   ├── deploy.sh                   # Main deployment
│   └── setup-ssl.sh                # SSL setup
│
└── .github/workflows/
    ├── ci-cd.yml                   # CI/CD pipeline
    └── nightly-backup.yml          # Automated backups
```

---

## 🔧 Management Commands

### View Logs
```bash
# All services
docker-compose -f /opt/isp-billing/docker/docker-compose.yml logs -f

# Specific service
docker logs -f isp-backend
docker logs -f isp-frontend
```

### Restart Services
```bash
# Restart all
docker-compose -f /opt/isp-billing/docker/docker-compose.yml restart

# Restart specific service
docker restart isp-backend
```

### Update Application
```bash
# Pull latest and redeploy
/opt/isp-billing/scripts/deploy.sh update
```

### Manual Backup
```bash
/opt/isp-billing/backup.sh
```

### Database Access
```bash
# Connect to PostgreSQL
docker exec -it isp-postgres psql -U isp_user -d isp_billing

# Run migrations
docker-compose -f /opt/isp-billing/docker/docker-compose.yml exec backend npm run migrate
```

---

## 📊 Monitoring

### Grafana Dashboard
- **URL**: http://your-server-ip:3002
- **Default Login**: admin / admin (change on first login)

### Pre-built Dashboards
1. **System Overview** - CPU, Memory, Disk usage
2. **Application Metrics** - Request rate, response time
3. **Database Metrics** - Connections, query performance
4. **Business Metrics** - Revenue, customers, payments

### Alerts Setup
```bash
# Edit alert rules
nano /opt/isp-billing/monitoring/prometheus-alerts.yml
```

Example alerts:
- High CPU usage (>80%)
- Low disk space (<20%)
- Database down
- Payment failures

---

## 💰 M-Pesa Integration

### 1. Get API Credentials
1. Go to https://developer.safaricom.co.ke/
2. Create an account
3. Create a new app
4. Get Consumer Key and Secret
5. Generate Passkey

### 2. Configure Callback URL
```bash
# In your M-Pesa app settings
Callback URL: https://billing.yourcompany.com/api/payments/mpesa/callback
```

### 3. Test Payment
```bash
curl -X POST https://billing.yourcompany.com/api/payments \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "customerId": "1",
    "amount": 100,
    "method": "mpesa",
    "mpesaPhoneNumber": "254712345678"
  }'
```

---

## 📱 WhatsApp Integration

### 1. Setup WhatsApp Business API
1. Go to https://business.facebook.com/
2. Create a Business account
3. Add WhatsApp channel
4. Get Phone Number ID and API Key

### 2. Configure Webhook
```bash
# In WhatsApp Business settings
Webhook URL: https://billing.yourcompany.com/api/webhooks/whatsapp
Verify Token: your_verify_token
```

### 3. Test Message
```bash
curl -X POST https://billing.yourcompany.com/api/notifications/send \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "customerId": "1",
    "type": "payment_reminder",
    "channels": ["whatsapp"]
  }'
```

---

## 📧 Email Configuration

### Gmail SMTP
```bash
# In .env file
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASS=your_app_password  # Generate at https://myaccount.google.com/apppasswords
```

### Test Email
```bash
curl -X POST https://billing.yourcompany.com/api/notifications/send \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "customerId": "1",
    "type": "welcome",
    "channels": ["email"]
  }'
```

---

## 🔒 Security Checklist

- [ ] Change default passwords
- [ ] Enable firewall (ufw)
- [ ] Setup fail2ban
- [ ] Configure SSL certificates
- [ ] Enable 2FA for admin accounts
- [ ] Regular security updates
- [ ] Backup encryption
- [ ] API rate limiting enabled

### Enable Firewall
```bash
ufw allow 22/tcp    # SSH
ufw allow 80/tcp    # HTTP
ufw allow 443/tcp   # HTTPS
ufw enable
```

### Install fail2ban
```bash
apt install fail2ban
systemctl enable fail2ban
systemctl start fail2ban
```

---

## 🐛 Troubleshooting

### Services Won't Start
```bash
# Check logs
docker-compose -f /opt/isp-billing/docker/docker-compose.yml logs

# Check disk space
df -h

# Restart Docker
systemctl restart docker
```

### Database Connection Failed
```bash
# Check PostgreSQL status
docker exec isp-postgres pg_isready -U isp_user

# Reset database (WARNING: Data loss!)
docker-compose -f /opt/isp-billing/docker/docker-compose.yml down -v
docker-compose -f /opt/isp-billing/docker/docker-compose.yml up -d
```

### SSL Certificate Issues
```bash
# Check certificate status
ssl-status your-domain.com

# Renew manually
certbot renew --force-renewal

# Test renewal
certbot renew --dry-run
```

### M-Pesa Callback Not Working
```bash
# Check if URL is accessible
curl -I https://billing.yourcompany.com/api/payments/mpesa/callback

# Check firewall
curl ifconfig.me  # Get public IP
# Whitelist this IP in M-Pesa dashboard
```

---

## 📈 Scaling

### Vertical Scaling
```bash
# Upgrade server specs (more RAM/CPU)
# Docker automatically uses available resources
```

### Horizontal Scaling
```bash
# Add more backend instances
docker-compose -f /opt/isp-billing/docker/docker-compose.yml up -d --scale backend=3
```

### Database Scaling
```bash
# Setup read replicas
# Use connection pooling (PgBouncer)
```

---

## 📞 Support

| Resource | Link |
|----------|------|
| Documentation | https://docs.isp-billing.com |
| API Reference | https://api.isp-billing.com/docs |
| GitHub Issues | https://github.com/yourusername/isp-billing/issues |
| Email Support | support@isp-billing.com |

---

## 🎉 You're Ready!

Your ISP Billing System is now running. Start adding customers, configuring plans, and managing your network!

**Next Steps:**
1. Add your first customer
2. Create internet plans
3. Configure M-Pesa for payments
4. Add your MikroTik routers
5. Setup OLTs for fiber customers
6. Customize email templates
7. Configure backup schedule

**Happy Billing! 🚀**
