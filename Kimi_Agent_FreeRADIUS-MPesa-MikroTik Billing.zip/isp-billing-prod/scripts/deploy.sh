#!/bin/bash
# ============================================
# ISP Billing System - Automated Deployment Script
# ============================================

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
PROJECT_NAME="isp-billing"
PROJECT_DIR="/opt/${PROJECT_NAME}"
BACKUP_DIR="/opt/backups/${PROJECT_NAME}"
LOG_FILE="/var/log/${PROJECT_NAME}-deploy.log"

# Functions
log() {
    echo -e "${BLUE}[$(date +'%Y-%m-%d %H:%M:%S')]${NC} $1" | tee -a "$LOG_FILE"
}

error() {
    echo -e "${RED}[ERROR]${NC} $1" | tee -a "$LOG_FILE"
    exit 1
}

success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1" | tee -a "$LOG_FILE"
}

warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1" | tee -a "$LOG_FILE"
}

# Check if running as root
check_root() {
    if [[ $EUID -ne 0 ]]; then
        error "This script must be run as root"
    fi
}

# Install dependencies
install_dependencies() {
    log "Installing dependencies..."
    
    apt-get update
    apt-get install -y \
        apt-transport-https \
        ca-certificates \
        curl \
        gnupg \
        lsb-release \
        git \
        nginx \
        certbot \
        python3-certbot-nginx \
        htop \
        vim \
        unzip \
        jq
    
    # Install Docker
    if ! command -v docker &> /dev/null; then
        log "Installing Docker..."
        curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg
        echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | tee /etc/apt/sources.list.d/docker.list > /dev/null
        apt-get update
        apt-get install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
    fi
    
    # Install Docker Compose
    if ! command -v docker-compose &> /dev/null; then
        log "Installing Docker Compose..."
        curl -L "https://github.com/docker/compose/releases/download/v2.23.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
        chmod +x /usr/local/bin/docker-compose
    fi
    
    success "Dependencies installed"
}

# Setup project directory
setup_project() {
    log "Setting up project directory..."
    
    mkdir -p "$PROJECT_DIR"
    mkdir -p "$BACKUP_DIR"
    mkdir -p "/var/log/${PROJECT_NAME}"
    
    # Create backup script
    cat > "$PROJECT_DIR/backup.sh" << 'BACKUP_EOF'
#!/bin/bash
BACKUP_DIR="/opt/backups/isp-billing"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
mkdir -p "$BACKUP_DIR"

# Backup database
docker exec isp-postgres pg_dump -U isp_user isp_billing > "$BACKUP_DIR/db_$TIMESTAMP.sql"

# Backup uploads
docker cp isp-backend:/app/uploads "$BACKUP_DIR/uploads_$TIMESTAMP"

# Compress backup
tar -czf "$BACKUP_DIR/backup_$TIMESTAMP.tar.gz" -C "$BACKUP_DIR" "db_$TIMESTAMP.sql" "uploads_$TIMESTAMP"

# Remove old backups (keep 30 days)
find "$BACKUP_DIR" -name "backup_*.tar.gz" -mtime +30 -delete
find "$BACKUP_DIR" -name "db_*.sql" -mtime +30 -delete
find "$BACKUP_DIR" -name "uploads_*" -mtime +30 -delete

# Upload to S3 if configured
if [ -n "$AWS_S3_BUCKET" ]; then
    aws s3 cp "$BACKUP_DIR/backup_$TIMESTAMP.tar.gz" "s3://$AWS_S3_BUCKET/backups/"
fi

echo "Backup completed: backup_$TIMESTAMP.tar.gz"
BACKUP_EOF
    chmod +x "$PROJECT_DIR/backup.sh"
    
    # Setup cron for daily backups
    (crontab -l 2>/dev/null; echo "0 2 * * * $PROJECT_DIR/backup.sh >> /var/log/isp-billing-backup.log 2>&1") | crontab -
    
    success "Project directory setup complete"
}

# Clone and setup application
setup_application() {
    log "Setting up application..."
    
    cd "$PROJECT_DIR"
    
    # If git repo exists, pull latest
    if [ -d ".git" ]; then
        git pull origin main
    else
        # Copy from local directory or clone
        log "Please ensure your application files are in $PROJECT_DIR"
    fi
    
    # Create environment file if not exists
    if [ ! -f ".env" ]; then
        cp docker/.env.example .env
        warning "Please edit .env file with your configuration"
    fi
    
    success "Application setup complete"
}

# Build and start services
start_services() {
    log "Building and starting services..."
    
    cd "$PROJECT_DIR"
    
    # Pull latest images
    docker-compose -f docker/docker-compose.yml pull
    
    # Build and start
    docker-compose -f docker/docker-compose.yml up -d --build
    
    # Wait for services to be ready
    log "Waiting for services to be ready..."
    sleep 30
    
    # Check health
    if docker-compose -f docker/docker-compose.yml ps | grep -q "unhealthy"; then
        warning "Some services are unhealthy. Check logs with: docker-compose -f docker/docker-compose.yml logs"
    fi
    
    success "Services started successfully"
}

# Setup SSL certificate
setup_ssl() {
    log "Setting up SSL certificate..."
    
    # Get domain from .env
    DOMAIN=$(grep "DOMAIN=" "$PROJECT_DIR/.env" | cut -d'=' -f2 || echo "")
    EMAIL=$(grep "EMAIL=" "$PROJECT_DIR/.env" | cut -d'=' -f2 || echo "")
    
    if [ -z "$DOMAIN" ] || [ "$DOMAIN" = "your-domain.com" ]; then
        warning "Domain not configured. Skipping SSL setup."
        warning "Please set DOMAIN in .env and run: certbot --nginx -d your-domain.com"
        return
    fi
    
    # Obtain SSL certificate
    certbot --nginx -d "$DOMAIN" --non-interactive --agree-tos -m "$EMAIL" || warning "SSL setup failed"
    
    # Setup auto-renewal
    (crontab -l 2>/dev/null; echo "0 12 * * * /usr/bin/certbot renew --quiet") | crontab -
    
    success "SSL certificate configured"
}

# Setup monitoring
setup_monitoring() {
    log "Setting up monitoring..."
    
    # Create Prometheus config
    mkdir -p "$PROJECT_DIR/monitoring/prometheus"
    
    cat > "$PROJECT_DIR/monitoring/prometheus.yml" << 'PROM_EOF'
global:
  scrape_interval: 15s
  evaluation_interval: 15s

alerting:
  alertmanagers:
    - static_configs:
        - targets: []

rule_files: []

scrape_configs:
  - job_name: 'prometheus'
    static_configs:
      - targets: ['localhost:9090']

  - job_name: 'node-exporter'
    static_configs:
      - targets: ['node-exporter:9100']

  - job_name: 'backend'
    static_configs:
      - targets: ['backend:3000']
    metrics_path: /metrics

  - job_name: 'postgres'
    static_configs:
      - targets: ['postgres-exporter:9187']

  - job_name: 'redis'
    static_configs:
      - targets: ['redis-exporter:9121']
PROM_EOF
    
    success "Monitoring configured"
}

# Display status
display_status() {
    echo ""
    echo "========================================"
    echo "  ISP Billing System - Deployment Complete"
    echo "========================================"
    echo ""
    echo "Services:"
    docker-compose -f "$PROJECT_DIR/docker/docker-compose.yml" ps
    echo ""
    echo "Access Points:"
    echo "  - Main App:     http://localhost or https://your-domain.com"
    echo "  - API:          http://localhost/api"
    echo "  - Grafana:      http://localhost:3002"
    echo "  - Prometheus:   http://localhost:9090"
    echo ""
    echo "Useful Commands:"
    echo "  - View logs:    docker-compose -f $PROJECT_DIR/docker/docker-compose.yml logs -f"
    echo "  - Restart:      docker-compose -f $PROJECT_DIR/docker/docker-compose.yml restart"
    echo "  - Backup:       $PROJECT_DIR/backup.sh"
    echo "  - Update:       cd $PROJECT_DIR && git pull && docker-compose -f docker/docker-compose.yml up -d --build"
    echo ""
    echo "========================================"
}

# Main deployment function
deploy() {
    log "Starting ISP Billing System deployment..."
    
    check_root
    install_dependencies
    setup_project
    setup_application
    start_services
    setup_ssl
    setup_monitoring
    display_status
    
    success "Deployment completed successfully!"
}

# Update function
update() {
    log "Updating ISP Billing System..."
    
    cd "$PROJECT_DIR"
    
    # Backup first
    "$PROJECT_DIR/backup.sh"
    
    # Pull latest code
    git pull origin main
    
    # Rebuild and restart
    docker-compose -f docker/docker-compose.yml down
    docker-compose -f docker/docker-compose.yml up -d --build
    
    success "Update completed!"
}

# Rollback function
rollback() {
    log "Rolling back to previous version..."
    
    cd "$PROJECT_DIR"
    
    # Get previous commit
    git log --oneline -5
    read -p "Enter commit hash to rollback to: " commit
    
    git checkout "$commit"
    docker-compose -f docker/docker-compose.yml up -d --build
    
    success "Rollback completed!"
}

# Show help
show_help() {
    echo "ISP Billing System - Deployment Script"
    echo ""
    echo "Usage: $0 [command]"
    echo ""
    echo "Commands:"
    echo "  deploy    - Full deployment (first time setup)"
    echo "  update    - Update to latest version"
    echo "  rollback  - Rollback to previous version"
    echo "  backup    - Run backup manually"
    echo "  logs      - View service logs"
    echo "  status    - Show service status"
    echo "  help      - Show this help message"
}

# Main
case "${1:-deploy}" in
    deploy)
        deploy
        ;;
    update)
        update
        ;;
    rollback)
        rollback
        ;;
    backup)
        "$PROJECT_DIR/backup.sh"
        ;;
    logs)
        docker-compose -f "$PROJECT_DIR/docker/docker-compose.yml" logs -f
        ;;
    status)
        docker-compose -f "$PROJECT_DIR/docker/docker-compose.yml" ps
        ;;
    help)
        show_help
        ;;
    *)
        echo "Unknown command: $1"
        show_help
        exit 1
        ;;
esac
