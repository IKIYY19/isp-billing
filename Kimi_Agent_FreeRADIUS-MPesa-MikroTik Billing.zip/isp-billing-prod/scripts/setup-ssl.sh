#!/bin/bash
# ============================================
# ISP Billing System - SSL Certificate Setup
# ============================================

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log() {
    echo -e "${BLUE}[$(date +'%Y-%m-%d %H:%M:%S')]${NC} $1"
}

error() {
    echo -e "${RED}[ERROR]${NC} $1" >&2
    exit 1
}

success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

# Check if running as root
if [[ $EUID -ne 0 ]]; then
    error "This script must be run as root"
fi

# Get domain from user or environment
DOMAIN="${1:-${DOMAIN}}"
EMAIL="${2:-${EMAIL}}"

if [ -z "$DOMAIN" ]; then
    read -p "Enter your domain name (e.g., billing.yourcompany.com): " DOMAIN
fi

if [ -z "$EMAIL" ]; then
    read -p "Enter your email address for SSL notifications: " EMAIL
fi

log "Setting up SSL certificate for $DOMAIN"

# ============================================
# 1. Install Certbot
# ============================================
log "Installing Certbot..."

if ! command -v certbot &> /dev/null; then
    apt-get update
    apt-get install -y certbot python3-certbot-nginx
fi

# ============================================
# 2. Create Nginx Configuration
# ============================================
log "Creating Nginx configuration..."

NGINX_CONF="/etc/nginx/sites-available/$DOMAIN"
NGINX_ENABLED="/etc/nginx/sites-enabled/$DOMAIN"

mkdir -p /etc/nginx/ssl
mkdir -p /var/www/certbot

cat > "$NGINX_CONF" << EOF
# HTTP - Redirect to HTTPS
server {
    listen 80;
    server_name $DOMAIN;
    
    # Let's Encrypt challenge
    location /.well-known/acme-challenge/ {
        root /var/www/certbot;
    }
    
    location / {
        return 301 https://\$host\$request_uri;
    }
}

# HTTPS Server
server {
    listen 443 ssl http2;
    server_name $DOMAIN;

    # SSL Certificates
    ssl_certificate /etc/letsencrypt/live/$DOMAIN/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/$DOMAIN/privkey.pem;
    
    # SSL Configuration
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384;
    ssl_prefer_server_ciphers off;
    ssl_session_cache shared:SSL:10m;
    ssl_session_timeout 1d;
    ssl_stapling on;
    ssl_stapling_verify on;
    
    # Security Headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;
    add_header Content-Security-Policy "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline';" always;

    # Frontend - React App
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
        
        # Cache static assets
        location ~* \\.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)\$ {
            proxy_pass http://localhost:3000;
            expires 1y;
            add_header Cache-Control "public, immutable";
        }
    }

    # Backend API
    location /api/ {
        proxy_pass http://localhost:3001/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
        
        # Timeouts
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }

    # WebSocket support
    location /ws/ {
        proxy_pass http://localhost:3001/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }

    # Health check
    location /health {
        access_log off;
        return 200 "healthy\\n";
        add_header Content-Type text/plain;
    }
}
EOF

# Enable site
ln -sf "$NGINX_CONF" "$NGINX_ENABLED"

# Test Nginx configuration
nginx -t || error "Nginx configuration test failed"

# Reload Nginx
systemctl reload nginx

# ============================================
# 3. Obtain SSL Certificate
# ============================================
log "Obtaining SSL certificate from Let's Encrypt..."

certbot certonly \
    --nginx \
    -d "$DOMAIN" \
    --non-interactive \
    --agree-tos \
    -m "$EMAIL" \
    --redirect \
    --hsts \
    --staple-ocsp \
    || error "Failed to obtain SSL certificate"

success "SSL certificate obtained successfully!"

# ============================================
# 4. Setup Auto-Renewal
# ============================================
log "Setting up auto-renewal..."

# Create renewal hook
cat > /etc/letsencrypt/renewal-hooks/deploy/reload-nginx.sh << 'HOOK_EOF'
#!/bin/bash
# Reload Nginx after certificate renewal
systemctl reload nginx
echo "$(date): Nginx reloaded after certificate renewal" >> /var/log/letsencrypt-renewal.log
HOOK_EOF

chmod +x /etc/letsencrypt/renewal-hooks/deploy/reload-nginx.sh

# Add cron job for renewal (runs twice daily)
if ! crontab -l 2>/dev/null | grep -q "certbot renew"; then
    (crontab -l 2>/dev/null; echo "0 0,12 * * * certbot renew --quiet --deploy-hook '/etc/letsencrypt/renewal-hooks/deploy/reload-nginx.sh'") | crontab -
    log "Auto-renewal cron job added"
fi

# Test renewal
certbot renew --dry-run || warning "Certbot renewal test failed"

# ============================================
# 5. Create SSL Status Script
# ============================================
log "Creating SSL status script..."

cat > /usr/local/bin/ssl-status << 'STATUS_EOF'
#!/bin/bash
# Check SSL certificate status

DOMAIN="${1:-$(hostname -f)}"

echo "========================================"
echo "  SSL Certificate Status"
echo "========================================"
echo "Domain: $DOMAIN"
echo ""

# Check certificate info
if [ -f "/etc/letsencrypt/live/$DOMAIN/fullchain.pem" ]; then
    echo "Certificate Path: /etc/letsencrypt/live/$DOMAIN/fullchain.pem"
    echo ""
    
    # Get expiry date
    EXPIRY=$(openssl x509 -in "/etc/letsencrypt/live/$DOMAIN/fullchain.pem" -noout -dates | grep notAfter | cut -d= -f2)
    EXPIRY_EPOCH=$(date -d "$EXPIRY" +%s)
    CURRENT_EPOCH=$(date +%s)
    DAYS_LEFT=$(( (EXPIRY_EPOCH - CURRENT_EPOCH) / 86400 ))
    
    echo "Expiry Date: $EXPIRY"
    echo "Days Left: $DAYS_LEFT"
    echo ""
    
    if [ $DAYS_LEFT -lt 7 ]; then
        echo "⚠️  WARNING: Certificate expires in less than 7 days!"
    elif [ $DAYS_LEFT -lt 30 ]; then
        echo "⚠️  Certificate expires in less than 30 days"
    else
        echo "✅ Certificate is valid"
    fi
    
    echo ""
    echo "Certificate Details:"
    openssl x509 -in "/etc/letsencrypt/live/$DOMAIN/fullchain.pem" -noout -subject -issuer
else
    echo "❌ Certificate not found for $DOMAIN"
    exit 1
fi

echo ""
echo "========================================"
STATUS_EOF

chmod +x /usr/local/bin/ssl-status

# ============================================
# Summary
# ============================================
echo ""
echo "========================================"
echo "  SSL Setup Complete!"
echo "========================================"
echo ""
echo "Domain: $DOMAIN"
echo "Email: $EMAIL"
echo ""
echo "Certificate Location:"
echo "  - Full Chain: /etc/letsencrypt/live/$DOMAIN/fullchain.pem"
echo "  - Private Key: /etc/letsencrypt/live/$DOMAIN/privkey.pem"
echo ""
echo "Useful Commands:"
echo "  - Check status: ssl-status $DOMAIN"
echo "  - Renew manually: certbot renew --force-renewal"
echo "  - Test config: nginx -t"
echo "  - Reload nginx: systemctl reload nginx"
echo ""
echo "Auto-renewal is configured via cron."
echo "========================================"

success "SSL setup completed!"
