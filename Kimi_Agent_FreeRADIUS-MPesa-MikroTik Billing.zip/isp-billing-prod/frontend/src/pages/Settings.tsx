import { useState } from 'react'
import { Save, Bell, Shield, CreditCard, Wifi, Mail, Smartphone, MessageSquare } from 'lucide-react'

export default function Settings() {
  const [activeTab, setActiveTab] = useState('general')

  const tabs = [
    { id: 'general', label: 'General', icon: Shield },
    { id: 'notifications', label: 'Notifications', icon: Bell },
    { id: 'payments', label: 'Payments', icon: CreditCard },
    { id: 'network', label: 'Network', icon: Wifi }
  ]

  return (
    <div>
      <div className="header">
        <h1>Settings</h1>
        <button className="btn btn-primary">
          <Save size={18} style={{ marginRight: '0.5rem' }} />
          Save Changes
        </button>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '200px 1fr', gap: '1.5rem' }}>
        <div className="section" style={{ padding: '1rem' }}>
          {tabs.map(tab => (
            <div
              key={tab.id}
              className={`nav-item ${activeTab === tab.id ? 'active' : ''}`}
              onClick={() => setActiveTab(tab.id)}
              style={{ marginBottom: '0.5rem' }}
            >
              <tab.icon size={18} />
              {tab.label}
            </div>
          ))}
        </div>

        <div className="section" style={{ padding: '1.5rem' }}>
          {activeTab === 'general' && (
            <div>
              <h3 style={{ marginBottom: '1.5rem' }}>General Settings</h3>
              <div style={{ display: 'grid', gap: '1.5rem' }}>
                <div className="form-group">
                  <label>Company Name</label>
                  <input type="text" defaultValue="My ISP Company" />
                </div>
                <div className="form-group">
                  <label>Contact Email</label>
                  <input type="email" defaultValue="admin@myisp.com" />
                </div>
                <div className="form-group">
                  <label>Contact Phone</label>
                  <input type="tel" defaultValue="+254712345678" />
                </div>
                <div className="form-group">
                  <label>Physical Address</label>
                  <input type="text" defaultValue="Nairobi, Kenya" />
                </div>
                <div className="form-group">
                  <label>Currency</label>
                  <select defaultValue="KES">
                    <option value="KES">Kenyan Shilling (KES)</option>
                    <option value="USD">US Dollar (USD)</option>
                    <option value="EUR">Euro (EUR)</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'notifications' && (
            <div>
              <h3 style={{ marginBottom: '1.5rem' }}>Notification Settings</h3>
              
              <div style={{ marginBottom: '2rem' }}>
                <h4 style={{ marginBottom: '1rem', color: '#64748b' }}>Email Notifications</h4>
                <div style={{ display: 'grid', gap: '1rem' }}>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', cursor: 'pointer' }}>
                    <input type="checkbox" defaultChecked />
                    <span>Invoice generated</span>
                  </label>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', cursor: 'pointer' }}>
                    <input type="checkbox" defaultChecked />
                    <span>Payment received</span>
                  </label>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', cursor: 'pointer' }}>
                    <input type="checkbox" defaultChecked />
                    <span>Payment overdue reminder</span>
                  </label>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', cursor: 'pointer' }}>
                    <input type="checkbox" />
                    <span>Service suspension</span>
                  </label>
                </div>
              </div>

              <div style={{ marginBottom: '2rem' }}>
                <h4 style={{ marginBottom: '1rem', color: '#64748b' }}>SMS Notifications</h4>
                <div style={{ display: 'grid', gap: '1rem' }}>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', cursor: 'pointer' }}>
                    <input type="checkbox" defaultChecked />
                    <span>Payment reminders</span>
                  </label>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', cursor: 'pointer' }}>
                    <input type="checkbox" defaultChecked />
                    <span>Service alerts</span>
                  </label>
                </div>
              </div>

              <div>
                <h4 style={{ marginBottom: '1rem', color: '#64748b' }}>Integration Settings</h4>
                <div className="form-group">
                  <label>Africa's Talking API Key</label>
                  <input type="password" placeholder="Enter API key" />
                </div>
                <div className="form-group">
                  <label>WhatsApp Business API Key</label>
                  <input type="password" placeholder="Enter API key" />
                </div>
              </div>
            </div>
          )}

          {activeTab === 'payments' && (
            <div>
              <h3 style={{ marginBottom: '1.5rem' }}>Payment Settings</h3>
              
              <div style={{ marginBottom: '2rem' }}>
                <h4 style={{ marginBottom: '1rem', color: '#64748b' }}>M-Pesa Configuration</h4>
                <div className="form-group">
                  <label>Consumer Key</label>
                  <input type="text" placeholder="Enter consumer key" />
                </div>
                <div className="form-group">
                  <label>Consumer Secret</label>
                  <input type="password" placeholder="Enter consumer secret" />
                </div>
                <div className="form-group">
                  <label>Passkey</label>
                  <input type="password" placeholder="Enter passkey" />
                </div>
                <div className="form-group">
                  <label>Shortcode</label>
                  <input type="text" placeholder="174379" />
                </div>
                <div className="form-group">
                  <label>Environment</label>
                  <select defaultValue="sandbox">
                    <option value="sandbox">Sandbox</option>
                    <option value="production">Production</option>
                  </select>
                </div>
              </div>

              <div>
                <h4 style={{ marginBottom: '1rem', color: '#64748b' }}>Invoice Settings</h4>
                <div className="form-group">
                  <label>Invoice Due Days</label>
                  <input type="number" defaultValue="14" />
                </div>
                <div className="form-group">
                  <label>Late Fee (%)</label>
                  <input type="number" defaultValue="5" />
                </div>
                <div className="form-group">
                  <label>Auto-suspend After (days)</label>
                  <input type="number" defaultValue="7" />
                </div>
              </div>
            </div>
          )}

          {activeTab === 'network' && (
            <div>
              <h3 style={{ marginBottom: '1.5rem' }}>Network Settings</h3>
              
              <div style={{ marginBottom: '2rem' }}>
                <h4 style={{ marginBottom: '1rem', color: '#64748b' }}>MikroTik Settings</h4>
                <div className="form-group">
                  <label>Default Username</label>
                  <input type="text" defaultValue="admin" />
                </div>
                <div className="form-group">
                  <label>Default Password</label>
                  <input type="password" placeholder="Enter password" />
                </div>
                <div className="form-group">
                  <label>API Port</label>
                  <input type="number" defaultValue="8728" />
                </div>
              </div>

              <div>
                <h4 style={{ marginBottom: '1rem', color: '#64748b' }}>OLT Settings</h4>
                <div className="form-group">
                  <label>Default SNMP Community</label>
                  <input type="text" defaultValue="public" />
                </div>
                <div className="form-group">
                  <label>Auto-discovery Interval (minutes)</label>
                  <input type="number" defaultValue="30" />
                </div>
                <div className="form-group">
                  <label>Signal Threshold (dBm)</label>
                  <input type="number" defaultValue="-27" />
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
