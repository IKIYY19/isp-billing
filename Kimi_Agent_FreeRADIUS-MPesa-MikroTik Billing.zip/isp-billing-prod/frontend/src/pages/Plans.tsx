import { useState } from 'react'
import { Plus, Edit2, Trash2, Wifi, Check } from 'lucide-react'

interface Plan {
  id: string
  name: string
  speed: string
  price: number
  dataCap: string
  type: 'residential' | 'business'
  features: string[]
}

export default function Plans() {
  const [plans, setPlans] = useState<Plan[]>([
    { 
      id: '1', 
      name: 'Basic', 
      speed: '5Mbps', 
      price: 1500, 
      dataCap: '100GB', 
      type: 'residential',
      features: ['5Mbps Download', '2Mbps Upload', '100GB Data', 'Email Support']
    },
    { 
      id: '2', 
      name: 'Standard', 
      speed: '10Mbps', 
      price: 2500, 
      dataCap: '500GB', 
      type: 'residential',
      features: ['10Mbps Download', '5Mbps Upload', '500GB Data', 'Priority Support']
    },
    { 
      id: '3', 
      name: 'Premium', 
      speed: '20Mbps', 
      price: 4000, 
      dataCap: 'Unlimited', 
      type: 'residential',
      features: ['20Mbps Download', '10Mbps Upload', 'Unlimited Data', '24/7 Support', 'Static IP']
    },
    { 
      id: '4', 
      name: 'Business Basic', 
      speed: '50Mbps', 
      price: 10000, 
      dataCap: 'Unlimited', 
      type: 'business',
      features: ['50Mbps Download', '25Mbps Upload', 'Unlimited Data', 'SLA Guarantee', 'Static IP', 'Priority Support']
    },
    { 
      id: '5', 
      name: 'Business Pro', 
      speed: '100Mbps', 
      price: 20000, 
      dataCap: 'Unlimited', 
      type: 'business',
      features: ['100Mbps Download', '50Mbps Upload', 'Unlimited Data', 'SLA Guarantee', 'Static IP Block', 'Dedicated Support', 'DDoS Protection']
    }
  ])

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-KE', {
      style: 'currency',
      currency: 'KES'
    }).format(amount)
  }

  return (
    <div>
      <div className="header">
        <h1>Internet Plans</h1>
        <button className="btn btn-primary">
          <Plus size={18} style={{ marginRight: '0.5rem' }} />
          Add Plan
        </button>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '1.5rem' }}>
        {plans.map(plan => (
          <div 
            key={plan.id} 
            style={{ 
              background: '#1e293b', 
              borderRadius: '0.75rem', 
              border: '1px solid #334155',
              padding: '1.5rem',
              position: 'relative'
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '1rem' }}>
              <div>
                <span style={{ 
                  fontSize: '0.75rem', 
                  textTransform: 'uppercase', 
                  padding: '0.25rem 0.5rem', 
                  borderRadius: '0.25rem',
                  background: plan.type === 'business' ? 'rgba(59, 130, 246, 0.2)' : 'rgba(34, 197, 94, 0.2)',
                  color: plan.type === 'business' ? '#3b82f6' : '#22c55e'
                }}>
                  {plan.type}
                </span>
                <h3 style={{ marginTop: '0.5rem', fontSize: '1.25rem' }}>{plan.name}</h3>
              </div>
              <div style={{ display: 'flex', gap: '0.5rem' }}>
                <button style={{ background: 'none', border: 'none', color: '#94a3b8', cursor: 'pointer' }}>
                  <Edit2 size={18} />
                </button>
                <button style={{ background: 'none', border: 'none', color: '#94a3b8', cursor: 'pointer' }}>
                  <Trash2 size={18} />
                </button>
              </div>
            </div>

            <div style={{ textAlign: 'center', marginBottom: '1.5rem' }}>
              <div style={{ fontSize: '2.5rem', fontWeight: 'bold', color: '#3b82f6' }}>
                {formatCurrency(plan.price)}
              </div>
              <div style={{ color: '#64748b' }}>per month</div>
            </div>

            <div style={{ 
              display: 'flex', 
              alignItems: 'center', 
              justifyContent: 'center', 
              gap: '0.5rem',
              padding: '0.75rem',
              background: '#0f172a',
              borderRadius: '0.5rem',
              marginBottom: '1.5rem'
            }}>
              <Wifi size={20} style={{ color: '#22c55e' }} />
              <span style={{ fontSize: '1.125rem', fontWeight: 600 }}>{plan.speed}</span>
              <span style={{ color: '#64748b' }}>|</span>
              <span style={{ color: '#64748b' }}>{plan.dataCap}</span>
            </div>

            <ul style={{ listStyle: 'none', marginBottom: '1.5rem' }}>
              {plan.features.map((feature, index) => (
                <li 
                  key={index} 
                  style={{ 
                    display: 'flex', 
                    alignItems: 'center', 
                    gap: '0.5rem',
                    padding: '0.5rem 0',
                    borderBottom: index < plan.features.length - 1 ? '1px solid #334155' : 'none'
                  }}
                >
                  <Check size={16} style={{ color: '#22c55e' }} />
                  <span style={{ fontSize: '0.875rem' }}>{feature}</span>
                </li>
              ))}
            </ul>

            <button className="btn btn-primary" style={{ width: '100%' }}>
              Edit Plan
            </button>
          </div>
        ))}
      </div>
    </div>
  )
}
