import { useState } from 'react'
import { Plus, Zap, Activity, Settings } from 'lucide-react'

interface OLT {
  id: string
  name: string
  ip: string
  vendor: string
  model: string
  status: 'online' | 'offline'
  ponPorts: number
  activeOnus: number
  totalOnus: number
}

interface PONPort {
  id: string
  status: 'active' | 'inactive'
  onus: number
  rxPower: string
}

interface ONU {
  id: string
  serial: string
  status: 'online' | 'offline'
  rxPower: string
  txPower: string
  customer: string
}

export default function OLTs() {
  const [olts, setOlts] = useState<OLT[]>([
    { 
      id: '1', 
      name: 'Huawei OLT 1', 
      ip: '10.0.1.1', 
      vendor: 'huawei', 
      model: 'MA5608T',
      status: 'online',
      ponPorts: 8,
      activeOnus: 124,
      totalOnus: 128
    },
    { 
      id: '2', 
      name: 'ZTE OLT 1', 
      ip: '10.0.1.2', 
      vendor: 'zte', 
      model: 'C320',
      status: 'online',
      ponPorts: 16,
      activeOnus: 189,
      totalOnus: 256
    }
  ])

  const [selectedOLT, setSelectedOLT] = useState<string | null>(null)

  const [ponPorts] = useState<PONPort[]>([
    { id: 'PON0/1/1', status: 'active', onus: 16, rxPower: '-15.2dBm' },
    { id: 'PON0/1/2', status: 'active', onus: 14, rxPower: '-18.5dBm' },
    { id: 'PON0/1/3', status: 'inactive', onus: 0, rxPower: '-' },
    { id: 'PON0/1/4', status: 'active', onus: 18, rxPower: '-16.8dBm' }
  ])

  const [onus] = useState<ONU[]>([
    { id: 'ONU001', serial: 'HWTC12345678', status: 'online', rxPower: '-20.5dBm', txPower: '2.5dBm', customer: 'John Doe' },
    { id: 'ONU002', serial: 'HWTC87654321', status: 'online', rxPower: '-22.1dBm', txPower: '2.3dBm', customer: 'Jane Smith' },
    { id: 'ONU003', serial: 'HWTC11112222', status: 'offline', rxPower: '-', txPower: '-', customer: 'Bob Wilson' }
  ])

  return (
    <div>
      <div className="header">
        <h1>OLT Management</h1>
        <button className="btn btn-primary">
          <Plus size={18} style={{ marginRight: '0.5rem' }} />
          Add OLT
        </button>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '1.5rem', marginBottom: '2rem' }}>
        {olts.map(olt => (
          <div 
            key={olt.id} 
            style={{ 
              background: '#1e293b', 
              borderRadius: '0.75rem', 
              border: selectedOLT === olt.id ? '2px solid #3b82f6' : '1px solid #334155',
              padding: '1.5rem',
              cursor: 'pointer'
            }}
            onClick={() => setSelectedOLT(olt.id)}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '1rem' }}>
              <div>
                <h3 style={{ fontSize: '1.125rem' }}>{olt.name}</h3>
                <div style={{ fontSize: '0.875rem', color: '#64748b' }}>{olt.model} • {olt.ip}</div>
              </div>
              <span className={`status ${olt.status}`}>
                {olt.status}
              </span>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.5rem' }}>
              <span style={{ 
                textTransform: 'uppercase', 
                fontSize: '0.75rem', 
                fontWeight: 600,
                padding: '0.25rem 0.5rem',
                background: 'rgba(59, 130, 246, 0.2)',
                color: '#3b82f6',
                borderRadius: '0.25rem'
              }}>
                {olt.vendor}
              </span>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '1rem', marginTop: '1rem' }}>
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: '1.5rem', fontWeight: 'bold' }}>{olt.ponPorts}</div>
                <div style={{ fontSize: '0.75rem', color: '#64748b' }}>PON Ports</div>
              </div>
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#22c55e' }}>{olt.activeOnus}</div>
                <div style={{ fontSize: '0.75rem', color: '#64748b' }}>Active ONUs</div>
              </div>
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: '1.5rem', fontWeight: 'bold' }}>{olt.totalOnus}</div>
                <div style={{ fontSize: '0.75rem', color: '#64748b' }}>Total Capacity</div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {selectedOLT && (
        <>
          <div className="section" style={{ marginBottom: '1.5rem' }}>
            <div className="section-header">
              <h3 className="section-title">PON Ports</h3>
              <button className="btn">
                <Settings size={16} style={{ marginRight: '0.5rem' }} />
                Configure
              </button>
            </div>
            <div style={{ padding: '1.5rem', display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem' }}>
              {ponPorts.map(port => (
                <div 
                  key={port.id}
                  style={{ 
                    background: '#0f172a', 
                    padding: '1rem', 
                    borderRadius: '0.5rem',
                    border: port.status === 'active' ? '1px solid #22c55e' : '1px solid #334155'
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.5rem' }}>
                    <span style={{ fontWeight: 600 }}>{port.id}</span>
                    <span className={`status ${port.status}`}>
                      {port.status}
                    </span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.875rem', color: '#64748b' }}>
                    <span>{port.onus} ONUs</span>
                    <span>{port.rxPower}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="section">
            <div className="section-header">
              <h3 className="section-title">Connected ONUs</h3>
              <button className="btn btn-primary">
                <Plus size={16} style={{ marginRight: '0.5rem' }} />
                Provision ONU
              </button>
            </div>
            <div className="table-container">
              <table>
                <thead>
                  <tr>
                    <th>ONU ID</th>
                    <th>Serial Number</th>
                    <th>Customer</th>
                    <th>Status</th>
                    <th>RX Power</th>
                    <th>TX Power</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {onus.map(onu => (
                    <tr key={onu.id}>
                      <td>{onu.id}</td>
                      <td>{onu.serial}</td>
                      <td>{onu.customer}</td>
                      <td>
                        <span className={`status ${onu.status}`}>
                          {onu.status}
                        </span>
                      </td>
                      <td>{onu.rxPower}</td>
                      <td>{onu.txPower}</td>
                      <td>
                        <button className="btn" style={{ padding: '0.25rem 0.75rem', fontSize: '0.75rem' }}>
                          Manage
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  )
}
