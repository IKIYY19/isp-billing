import { useState } from 'react'
import { Plus, RefreshCw, Power, Users } from 'lucide-react'

interface Router {
  id: string
  name: string
  ip: string
  model: string
  status: 'online' | 'offline'
  type: string
  customers: number
  cpuUsage: number
  memoryUsage: number
  uptime: string
}

export default function Routers() {
  const [routers, setRouters] = useState<Router[]>([
    { 
      id: '1', 
      name: 'MikroTik Main', 
      ip: '192.168.1.1', 
      model: 'RB3011', 
      status: 'online', 
      type: 'mikrotik', 
      customers: 45,
      cpuUsage: 35,
      memoryUsage: 62,
      uptime: '45d 12h 30m'
    },
    { 
      id: '2', 
      name: 'MikroTik Backup', 
      ip: '192.168.1.2', 
      model: 'RB2011', 
      status: 'online', 
      type: 'mikrotik', 
      customers: 23,
      cpuUsage: 28,
      memoryUsage: 45,
      uptime: '30d 8h 15m'
    },
    { 
      id: '3', 
      name: 'Hotspot Router', 
      ip: '192.168.2.1', 
      model: 'hAP ac', 
      status: 'offline', 
      type: 'mikrotik', 
      customers: 0,
      cpuUsage: 0,
      memoryUsage: 0,
      uptime: '-'
    }
  ])

  return (
    <div>
      <div className="header">
        <h1>Routers</h1>
        <button className="btn btn-primary">
          <Plus size={18} style={{ marginRight: '0.5rem' }} />
          Add Router
        </button>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(350px, 1fr))', gap: '1.5rem' }}>
        {routers.map(router => (
          <div 
            key={router.id} 
            style={{ 
              background: '#1e293b', 
              borderRadius: '0.75rem', 
              border: '1px solid #334155',
              padding: '1.5rem'
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '1rem' }}>
              <div>
                <h3 style={{ fontSize: '1.125rem' }}>{router.name}</h3>
                <div style={{ fontSize: '0.875rem', color: '#64748b' }}>{router.model} • {router.ip}</div>
              </div>
              <span className={`status ${router.status}`}>
                {router.status}
              </span>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '1rem', marginBottom: '1rem' }}>
              <div style={{ background: '#0f172a', padding: '0.75rem', borderRadius: '0.5rem' }}>
                <div style={{ fontSize: '0.75rem', color: '#64748b', marginBottom: '0.25rem' }}>CPU Usage</div>
                <div style={{ fontSize: '1.25rem', fontWeight: 600 }}>{router.cpuUsage}%</div>
                <div style={{ 
                  height: '4px', 
                  background: '#334155', 
                  borderRadius: '2px', 
                  marginTop: '0.5rem',
                  overflow: 'hidden'
                }}>
                  <div style={{ 
                    width: `${router.cpuUsage}%`, 
                    height: '100%', 
                    background: router.cpuUsage > 80 ? '#ef4444' : '#22c55e',
                    borderRadius: '2px'
                  }} />
                </div>
              </div>
              <div style={{ background: '#0f172a', padding: '0.75rem', borderRadius: '0.5rem' }}>
                <div style={{ fontSize: '0.75rem', color: '#64748b', marginBottom: '0.25rem' }}>Memory</div>
                <div style={{ fontSize: '1.25rem', fontWeight: 600 }}>{router.memoryUsage}%</div>
                <div style={{ 
                  height: '4px', 
                  background: '#334155', 
                  borderRadius: '2px', 
                  marginTop: '0.5rem',
                  overflow: 'hidden'
                }}>
                  <div style={{ 
                    width: `${router.memoryUsage}%`, 
                    height: '100%', 
                    background: router.memoryUsage > 80 ? '#ef4444' : '#3b82f6',
                    borderRadius: '2px'
                  }} />
                </div>
              </div>
            </div>

            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <Users size={16} style={{ color: '#64748b' }} />
                <span>{router.customers} customers</span>
              </div>
              <div style={{ fontSize: '0.875rem', color: '#64748b' }}>
                Uptime: {router.uptime}
              </div>
            </div>

            <div style={{ display: 'flex', gap: '0.5rem' }}>
              <button className="btn" style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem' }}>
                <RefreshCw size={16} />
                Reboot
              </button>
              <button className="btn" style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem' }}>
                <Power size={16} />
                {router.status === 'online' ? 'Disable' : 'Enable'}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
