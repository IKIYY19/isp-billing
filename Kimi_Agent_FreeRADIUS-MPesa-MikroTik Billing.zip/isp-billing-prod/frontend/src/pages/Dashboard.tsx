import { useState, useEffect } from 'react'
import { 
  Users, Receipt, CreditCard, Router, 
  TrendingUp, TrendingDown, AlertCircle 
} from 'lucide-react'

interface DashboardStats {
  totalCustomers: number
  activeCustomers: number
  monthlyRevenue: number
  pendingInvoices: number
  activeSessions: number
  totalBandwidth: string
}

interface RecentPayment {
  id: string
  customer: string
  amount: number
  date: string
  method: string
}

interface Alert {
  type: 'warning' | 'error'
  message: string
  time: string
}

export default function Dashboard() {
  const [stats, setStats] = useState<DashboardStats>({
    totalCustomers: 312,
    activeCustomers: 298,
    monthlyRevenue: 784500,
    pendingInvoices: 45000,
    activeSessions: 245,
    totalBandwidth: '2.5 Gbps'
  })

  const [recentPayments, setRecentPayments] = useState<RecentPayment[]>([
    { id: 'PAY001', customer: 'John Doe', amount: 2500, date: '2024-02-03', method: 'M-Pesa' },
    { id: 'PAY002', customer: 'Jane Smith', amount: 1500, date: '2024-02-03', method: 'Bank' },
    { id: 'PAY003', customer: 'Bob Wilson', amount: 4000, date: '2024-02-02', method: 'M-Pesa' },
    { id: 'PAY004', customer: 'Alice Brown', amount: 2500, date: '2024-02-02', method: 'M-Pesa' }
  ])

  const [alerts, setAlerts] = useState<Alert[]>([
    { type: 'warning', message: 'Router MikroTik Backup high CPU usage (85%)', time: '5 min ago' },
    { type: 'error', message: 'OLT Huawei OLT 1 PON port 3 offline', time: '15 min ago' },
    { type: 'warning', message: '5 invoices overdue for more than 30 days', time: '1 hour ago' }
  ])

  useEffect(() => {
    // In production, fetch from API
    // fetch('/api/reports/dashboard').then(r => r.json()).then(setStats)
  }, [])

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-KE', {
      style: 'currency',
      currency: 'KES'
    }).format(amount)
  }

  const statCards = [
    { 
      title: 'Total Customers', 
      value: stats.totalCustomers.toString(), 
      change: '+12%',
      changeType: 'positive' as const,
      icon: Users 
    },
    { 
      title: 'Monthly Revenue', 
      value: formatCurrency(stats.monthlyRevenue), 
      change: '+8.5%',
      changeType: 'positive' as const,
      icon: CreditCard 
    },
    { 
      title: 'Pending Invoices', 
      value: formatCurrency(stats.pendingInvoices), 
      change: '-2.3%',
      changeType: 'positive' as const,
      icon: Receipt 
    },
    { 
      title: 'Active Sessions', 
      value: stats.activeSessions.toString(), 
      change: '+5%',
      changeType: 'positive' as const,
      icon: Router 
    }
  ]

  return (
    <div>
      <div className="header">
        <h1>Dashboard</h1>
        <div style={{ color: '#64748b' }}>
          {new Date().toLocaleDateString('en-KE', { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
          })}
        </div>
      </div>

      <div className="stats-grid">
        {statCards.map((card, index) => (
          <div key={index} className="stat-card">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <div>
                <h3>{card.title}</h3>
                <div className="stat-value">{card.value}</div>
                <div className={`stat-change ${card.changeType}`}>
                  {card.changeType === 'positive' ? <TrendingUp size={14} style={{ display: 'inline' }} /> : <TrendingDown size={14} style={{ display: 'inline' }} />}
                  {' '}{card.change} from last month
                </div>
              </div>
              <div style={{ 
                background: 'rgba(59, 130, 246, 0.2)', 
                padding: '0.75rem', 
                borderRadius: '0.5rem',
                color: '#3b82f6'
              }}>
                <card.icon size={24} />
              </div>
            </div>
          </div>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
        <div className="section">
          <div className="section-header">
            <h3 className="section-title">Recent Payments</h3>
            <button className="btn btn-primary">View All</button>
          </div>
          <div className="table-container">
            <table>
              <thead>
                <tr>
                  <th>Customer</th>
                  <th>Amount</th>
                  <th>Method</th>
                  <th>Date</th>
                </tr>
              </thead>
              <tbody>
                {recentPayments.map(payment => (
                  <tr key={payment.id}>
                    <td>{payment.customer}</td>
                    <td>{formatCurrency(payment.amount)}</td>
                    <td>
                      <span className={`status ${payment.method === 'M-Pesa' ? 'active' : 'pending'}`}>
                        {payment.method}
                      </span>
                    </td>
                    <td>{payment.date}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="section">
          <div className="section-header">
            <h3 className="section-title">System Alerts</h3>
            <button className="btn btn-primary">View All</button>
          </div>
          <div>
            {alerts.map((alert, index) => (
              <div key={index} className="alert">
                <div className={`alert-icon ${alert.type}`}>
                  <AlertCircle size={18} />
                </div>
                <div className="alert-content">
                  <div className="alert-title">{alert.message}</div>
                  <div className="alert-time">{alert.time}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
