import { useState } from 'react'
import { Plus, Search, Filter, MoreVertical, Phone, Mail } from 'lucide-react'

interface Customer {
  id: string
  name: string
  email: string
  phone: string
  status: 'active' | 'suspended' | 'pending'
  plan: string
  balance: number
}

export default function Customers() {
  const [customers, setCustomers] = useState<Customer[]>([
    { id: '1', name: 'John Doe', email: 'john@example.com', phone: '+254712345678', status: 'active', plan: 'Premium 10Mbps', balance: 0 },
    { id: '2', name: 'Jane Smith', email: 'jane@example.com', phone: '+254723456789', status: 'active', plan: 'Basic 5Mbps', balance: 0 },
    { id: '3', name: 'Bob Wilson', email: 'bob@example.com', phone: '+254734567890', status: 'suspended', plan: 'Standard 8Mbps', balance: 2500 },
    { id: '4', name: 'Alice Brown', email: 'alice@example.com', phone: '+254745678901', status: 'active', plan: 'Premium 10Mbps', balance: 0 },
    { id: '5', name: 'Charlie Davis', email: 'charlie@example.com', phone: '+254756789012', status: 'pending', plan: 'Basic 5Mbps', balance: 1500 }
  ])

  const [searchTerm, setSearchTerm] = useState('')

  const filteredCustomers = customers.filter(c => 
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.phone.includes(searchTerm)
  )

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-KE', {
      style: 'currency',
      currency: 'KES'
    }).format(amount)
  }

  return (
    <div>
      <div className="header">
        <h1>Customers</h1>
        <button className="btn btn-primary">
          <Plus size={18} style={{ marginRight: '0.5rem' }} />
          Add Customer
        </button>
      </div>

      <div className="section">
        <div className="section-header">
          <div style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}>
            <div style={{ position: 'relative' }}>
              <Search size={18} style={{ position: 'absolute', left: '0.75rem', top: '50%', transform: 'translateY(-50%)', color: '#64748b' }} />
              <input
                type="text"
                placeholder="Search customers..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                style={{
                  padding: '0.5rem 1rem 0.5rem 2.5rem',
                  border: '1px solid #334155',
                  borderRadius: '0.5rem',
                  background: '#0f172a',
                  color: '#e2e8f0',
                  width: '300px'
                }}
              />
            </div>
            <button className="btn" style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <Filter size={18} />
              Filter
            </button>
          </div>
        </div>
        <div className="table-container">
          <table>
            <thead>
              <tr>
                <th>Customer</th>
                <th>Contact</th>
                <th>Plan</th>
                <th>Status</th>
                <th>Balance</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredCustomers.map(customer => (
                <tr key={customer.id}>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                      <div style={{ 
                        width: '40px', 
                        height: '40px', 
                        borderRadius: '50%', 
                        background: '#3b82f6',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontWeight: 'bold'
                      }}>
                        {customer.name.charAt(0)}
                      </div>
                      <div>
                        <div style={{ fontWeight: 500 }}>{customer.name}</div>
                        <div style={{ fontSize: '0.75rem', color: '#64748b' }}>ID: {customer.id}</div>
                      </div>
                    </div>
                  </td>
                  <td>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.25rem' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.875rem' }}>
                        <Mail size={14} />
                        {customer.email}
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.875rem', color: '#64748b' }}>
                        <Phone size={14} />
                        {customer.phone}
                      </div>
                    </div>
                  </td>
                  <td>{customer.plan}</td>
                  <td>
                    <span className={`status ${customer.status}`}>
                      {customer.status}
                    </span>
                  </td>
                  <td style={{ color: customer.balance > 0 ? '#ef4444' : '#22c55e' }}>
                    {formatCurrency(customer.balance)}
                  </td>
                  <td>
                    <button style={{ background: 'none', border: 'none', color: '#94a3b8', cursor: 'pointer' }}>
                      <MoreVertical size={18} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
