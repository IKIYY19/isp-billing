import { useState } from 'react'
import { TrendingUp, Users, CreditCard, Activity } from 'lucide-react'

export default function Reports() {
  const [dateRange, setDateRange] = useState('30days')

  const revenueData = [
    { month: 'Jan', amount: 650000 },
    { month: 'Feb', amount: 720000 },
    { month: 'Mar', amount: 680000 },
    { month: 'Apr', amount: 750000 },
    { month: 'May', amount: 784500 },
    { month: 'Jun', amount: 820000 }
  ]

  const customerGrowth = [
    { month: 'Jan', new: 25, churned: 5 },
    { month: 'Feb', new: 32, churned: 3 },
    { month: 'Mar', new: 28, churned: 4 },
    { month: 'Apr', new: 35, churned: 2 },
    { month: 'May', new: 40, churned: 5 },
    { month: 'Jun', new: 38, churned: 3 }
  ]

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-KE', {
      style: 'currency',
      currency: 'KES',
      maximumFractionDigits: 0
    }).format(amount)
  }

  return (
    <div>
      <div className="header">
        <h1>Reports & Analytics</h1>
        <select 
          value={dateRange} 
          onChange={(e) => setDateRange(e.target.value)}
          style={{
            padding: '0.5rem 1rem',
            border: '1px solid #334155',
            borderRadius: '0.5rem',
            background: '#1e293b',
            color: '#e2e8f0'
          }}
        >
          <option value="7days">Last 7 Days</option>
          <option value="30days">Last 30 Days</option>
          <option value="90days">Last 90 Days</option>
          <option value="1year">Last Year</option>
        </select>
      </div>

      <div className="stats-grid">
        <div className="stat-card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <div>
              <h3>Total Revenue</h3>
              <div className="stat-value">{formatCurrency(784500)}</div>
              <div className="stat-change positive">
                <TrendingUp size={14} style={{ display: 'inline' }} /> +12.5% from last month
              </div>
            </div>
            <div style={{ background: 'rgba(34, 197, 94, 0.2)', padding: '0.75rem', borderRadius: '0.5rem', color: '#22c55e' }}>
              <CreditCard size={24} />
            </div>
          </div>
        </div>
        <div className="stat-card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <div>
              <h3>New Customers</h3>
              <div className="stat-value">38</div>
              <div className="stat-change positive">
                <TrendingUp size={14} style={{ display: 'inline' }} /> +18% from last month
              </div>
            </div>
            <div style={{ background: 'rgba(59, 130, 246, 0.2)', padding: '0.75rem', borderRadius: '0.5rem', color: '#3b82f6' }}>
              <Users size={24} />
            </div>
          </div>
        </div>
        <div className="stat-card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <div>
              <h3>Churn Rate</h3>
              <div className="stat-value">1.2%</div>
              <div className="stat-change positive">
                <TrendingUp size={14} style={{ display: 'inline' }} /> -0.3% from last month
              </div>
            </div>
            <div style={{ background: 'rgba(234, 179, 8, 0.2)', padding: '0.75rem', borderRadius: '0.5rem', color: '#eab308' }}>
              <Activity size={24} />
            </div>
          </div>
        </div>
        <div className="stat-card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <div>
              <h3>Avg Revenue/User</h3>
              <div className="stat-value">{formatCurrency(2514)}</div>
              <div className="stat-change positive">
                <TrendingUp size={14} style={{ display: 'inline' }} /> +5.2% from last month
              </div>
            </div>
            <div style={{ background: 'rgba(168, 85, 247, 0.2)', padding: '0.75rem', borderRadius: '0.5rem', color: '#a855f7' }}>
              <TrendingUp size={24} />
            </div>
          </div>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
        <div className="section">
          <div className="section-header">
            <h3 className="section-title">Revenue Trend</h3>
          </div>
          <div style={{ padding: '1.5rem' }}>
            <div style={{ display: 'flex', alignItems: 'flex-end', gap: '0.5rem', height: '200px' }}>
              {revenueData.map((data, index) => (
                <div key={index} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                  <div 
                    style={{ 
                      width: '100%', 
                      background: '#3b82f6', 
                      borderRadius: '4px 4px 0 0',
                      height: `${(data.amount / 900000) * 180}px`
                    }} 
                  />
                  <div style={{ fontSize: '0.75rem', color: '#64748b', marginTop: '0.5rem' }}>{data.month}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="section">
          <div className="section-header">
            <h3 className="section-title">Customer Growth</h3>
          </div>
          <div style={{ padding: '1.5rem' }}>
            <div style={{ display: 'flex', alignItems: 'flex-end', gap: '0.5rem', height: '200px' }}>
              {customerGrowth.map((data, index) => (
                <div key={index} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                  <div style={{ display: 'flex', width: '100%', gap: '2px' }}>
                    <div 
                      style={{ 
                        flex: 1,
                        background: '#22c55e', 
                        borderRadius: '4px 4px 0 0',
                        height: `${(data.new / 50) * 180}px`
                      }} 
                    />
                    <div 
                      style={{ 
                        flex: 1,
                        background: '#ef4444', 
                        borderRadius: '4px 4px 0 0',
                        height: `${(data.churned / 50) * 180}px`
                      }} 
                    />
                  </div>
                  <div style={{ fontSize: '0.75rem', color: '#64748b', marginTop: '0.5rem' }}>{data.month}</div>
                </div>
              ))}
            </div>
            <div style={{ display: 'flex', justifyContent: 'center', gap: '2rem', marginTop: '1rem' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <div style={{ width: '12px', height: '12px', background: '#22c55e', borderRadius: '2px' }} />
                <span style={{ fontSize: '0.875rem' }}>New</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <div style={{ width: '12px', height: '12px', background: '#ef4444', borderRadius: '2px' }} />
                <span style={{ fontSize: '0.875rem' }}>Churned</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="section" style={{ marginTop: '1.5rem' }}>
        <div className="section-header">
          <h3 className="section-title">Revenue by Plan</h3>
        </div>
        <div className="table-container">
          <table>
            <thead>
              <tr>
                <th>Plan</th>
                <th>Customers</th>
                <th>Monthly Revenue</th>
                <th>% of Total</th>
                <th>Growth</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Basic (5Mbps)</td>
                <td>120</td>
                <td>{formatCurrency(180000)}</td>
                <td>23%</td>
                <td style={{ color: '#22c55e' }}>+5%</td>
              </tr>
              <tr>
                <td>Standard (10Mbps)</td>
                <td>145</td>
                <td>{formatCurrency(362500)}</td>
                <td>46%</td>
                <td style={{ color: '#22c55e' }}>+12%</td>
              </tr>
              <tr>
                <td>Premium (20Mbps)</td>
                <td>47</td>
                <td>{formatCurrency(188000)}</td>
                <td>24%</td>
                <td style={{ color: '#22c55e' }}>+8%</td>
              </tr>
              <tr>
                <td>Business Plans</td>
                <td>12</td>
                <td>{formatCurrency(54000)}</td>
                <td>7%</td>
                <td style={{ color: '#22c55e' }}>+15%</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
