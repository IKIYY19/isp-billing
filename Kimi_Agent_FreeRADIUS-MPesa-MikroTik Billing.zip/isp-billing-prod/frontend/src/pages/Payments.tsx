import { useState } from 'react'
import { CreditCard, Smartphone, Building2, CheckCircle } from 'lucide-react'

interface Payment {
  id: string
  invoiceId: string
  customer: string
  amount: number
  method: 'mpesa' | 'bank' | 'cash'
  transactionId: string
  status: 'completed' | 'pending' | 'failed'
  date: string
}

export default function Payments() {
  const [payments, setPayments] = useState<Payment[]>([
    { id: 'PAY001', invoiceId: 'INV001', customer: 'John Doe', amount: 2500, method: 'mpesa', transactionId: 'MPESA123', status: 'completed', date: '2024-02-10' },
    { id: 'PAY002', invoiceId: 'INV002', customer: 'Jane Smith', amount: 1500, method: 'bank', transactionId: 'BANK456', status: 'pending', date: '2024-02-15' },
    { id: 'PAY003', invoiceId: 'INV004', customer: 'Alice Brown', amount: 2500, method: 'mpesa', transactionId: 'MPESA789', status: 'completed', date: '2024-02-08' },
    { id: 'PAY004', invoiceId: 'INV005', customer: 'Charlie Davis', amount: 1500, method: 'cash', transactionId: 'CASH001', status: 'completed', date: '2024-02-12' }
  ])

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-KE', {
      style: 'currency',
      currency: 'KES'
    }).format(amount)
  }

  const getMethodIcon = (method: string) => {
    switch (method) {
      case 'mpesa': return <Smartphone size={18} />
      case 'bank': return <Building2 size={18} />
      default: return <CreditCard size={18} />
    }
  }

  return (
    <div>
      <div className="header">
        <h1>Payments</h1>
        <button className="btn btn-primary">Record Payment</button>
      </div>

      <div className="section">
        <div className="section-header">
          <h3 className="section-title">Payment Methods</h3>
        </div>
        <div style={{ padding: '1.5rem', display: 'flex', gap: '1rem' }}>
          <div style={{ 
            flex: 1, 
            padding: '1.5rem', 
            background: '#0f172a', 
            borderRadius: '0.5rem',
            border: '1px solid #334155'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '1rem' }}>
              <div style={{ color: '#22c55e' }}><Smartphone size={24} /></div>
              <div>
                <div style={{ fontWeight: 600 }}>M-Pesa</div>
                <div style={{ fontSize: '0.875rem', color: '#64748b' }}>Mobile money payments</div>
              </div>
            </div>
            <div style={{ fontSize: '1.5rem', fontWeight: 'bold' }}>KES 125,000</div>
            <div style={{ fontSize: '0.875rem', color: '#22c55e' }}>85% of total</div>
          </div>
          <div style={{ 
            flex: 1, 
            padding: '1.5rem', 
            background: '#0f172a', 
            borderRadius: '0.5rem',
            border: '1px solid #334155'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '1rem' }}>
              <div style={{ color: '#3b82f6' }}><Building2 size={24} /></div>
              <div>
                <div style={{ fontWeight: 600 }}>Bank Transfer</div>
                <div style={{ fontSize: '0.875rem', color: '#64748b' }}>Direct bank deposits</div>
              </div>
            </div>
            <div style={{ fontSize: '1.5rem', fontWeight: 'bold' }}>KES 45,000</div>
            <div style={{ fontSize: '0.875rem', color: '#3b82f6' }}>12% of total</div>
          </div>
          <div style={{ 
            flex: 1, 
            padding: '1.5rem', 
            background: '#0f172a', 
            borderRadius: '0.5rem',
            border: '1px solid #334155'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '1rem' }}>
              <div style={{ color: '#eab308' }}><CreditCard size={24} /></div>
              <div>
                <div style={{ fontWeight: 600 }}>Cash</div>
                <div style={{ fontSize: '0.875rem', color: '#64748b' }}>In-person payments</div>
              </div>
            </div>
            <div style={{ fontSize: '1.5rem', fontWeight: 'bold' }}>KES 12,000</div>
            <div style={{ fontSize: '0.875rem', color: '#eab308' }}>3% of total</div>
          </div>
        </div>
      </div>

      <div className="section">
        <div className="section-header">
          <h3 className="section-title">Recent Transactions</h3>
        </div>
        <div className="table-container">
          <table>
            <thead>
              <tr>
                <th>Transaction ID</th>
                <th>Customer</th>
                <th>Invoice</th>
                <th>Amount</th>
                <th>Method</th>
                <th>Status</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              {payments.map(payment => (
                <tr key={payment.id}>
                  <td>{payment.transactionId}</td>
                  <td>{payment.customer}</td>
                  <td>{payment.invoiceId}</td>
                  <td>{formatCurrency(payment.amount)}</td>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                      {getMethodIcon(payment.method)}
                      {payment.method.toUpperCase()}
                    </div>
                  </td>
                  <td>
                    <span className={`status ${payment.status}`}>
                      {payment.status}
                    </span>
                  </td>
                  <td>{payment.date}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
