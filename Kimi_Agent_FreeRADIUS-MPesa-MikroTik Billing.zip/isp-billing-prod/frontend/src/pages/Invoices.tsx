import { useState } from 'react'
import { Plus, Search, Download, Send } from 'lucide-react'

interface Invoice {
  id: string
  customer: string
  amount: number
  status: 'paid' | 'pending' | 'overdue'
  dueDate: string
  paidDate: string | null
}

export default function Invoices() {
  const [invoices, setInvoices] = useState<Invoice[]>([
    { id: 'INV001', customer: 'John Doe', amount: 2500, status: 'paid', dueDate: '2024-02-15', paidDate: '2024-02-10' },
    { id: 'INV002', customer: 'Jane Smith', amount: 1500, status: 'pending', dueDate: '2024-02-20', paidDate: null },
    { id: 'INV003', customer: 'Bob Wilson', amount: 2000, status: 'overdue', dueDate: '2024-01-30', paidDate: null },
    { id: 'INV004', customer: 'Alice Brown', amount: 2500, status: 'paid', dueDate: '2024-02-10', paidDate: '2024-02-08' },
    { id: 'INV005', customer: 'Charlie Davis', amount: 1500, status: 'pending', dueDate: '2024-02-25', paidDate: null }
  ])

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-KE', {
      style: 'currency',
      currency: 'KES'
    }).format(amount)
  }

  const totalPaid = invoices.filter(i => i.status === 'paid').reduce((sum, i) => sum + i.amount, 0)
  const totalPending = invoices.filter(i => i.status === 'pending').reduce((sum, i) => sum + i.amount, 0)
  const totalOverdue = invoices.filter(i => i.status === 'overdue').reduce((sum, i) => sum + i.amount, 0)

  return (
    <div>
      <div className="header">
        <h1>Invoices</h1>
        <button className="btn btn-primary">
          <Plus size={18} style={{ marginRight: '0.5rem' }} />
          Create Invoice
        </button>
      </div>

      <div className="stats-grid" style={{ gridTemplateColumns: 'repeat(3, 1fr)' }}>
        <div className="stat-card">
          <h3>Paid</h3>
          <div className="stat-value" style={{ color: '#22c55e' }}>{formatCurrency(totalPaid)}</div>
        </div>
        <div className="stat-card">
          <h3>Pending</h3>
          <div className="stat-value" style={{ color: '#eab308' }}>{formatCurrency(totalPending)}</div>
        </div>
        <div className="stat-card">
          <h3>Overdue</h3>
          <div className="stat-value" style={{ color: '#ef4444' }}>{formatCurrency(totalOverdue)}</div>
        </div>
      </div>

      <div className="section">
        <div className="section-header">
          <div style={{ display: 'flex', gap: '1rem' }}>
            <button className="btn" style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <Download size={18} />
              Export
            </button>
            <button className="btn" style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <Send size={18} />
              Send Reminders
            </button>
          </div>
        </div>
        <div className="table-container">
          <table>
            <thead>
              <tr>
                <th>Invoice #</th>
                <th>Customer</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Due Date</th>
                <th>Paid Date</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {invoices.map(invoice => (
                <tr key={invoice.id}>
                  <td>{invoice.id}</td>
                  <td>{invoice.customer}</td>
                  <td>{formatCurrency(invoice.amount)}</td>
                  <td>
                    <span className={`status ${invoice.status}`}>
                      {invoice.status}
                    </span>
                  </td>
                  <td>{invoice.dueDate}</td>
                  <td>{invoice.paidDate || '-'}</td>
                  <td>
                    <button className="btn" style={{ padding: '0.25rem 0.75rem', fontSize: '0.75rem' }}>
                      View
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
