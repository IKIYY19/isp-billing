import { useState, useEffect } from 'react'
import { 
  LayoutDashboard, Users, Receipt, CreditCard, 
  Router, Server, BarChart3, Settings, LogOut,
  Wifi, AlertCircle, TrendingUp, TrendingDown,
  CheckCircle, XCircle, Clock
} from 'lucide-react'
import Dashboard from './pages/Dashboard'
import Customers from './pages/Customers'
import Invoices from './pages/Invoices'
import Payments from './pages/Payments'
import Plans from './pages/Plans'
import Routers from './pages/Routers'
import OLTs from './pages/OLTs'
import Reports from './pages/Reports'
import SettingsPage from './pages/Settings'
import Login from './pages/Login'

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [activeTab, setActiveTab] = useState('dashboard')

  useEffect(() => {
    const token = localStorage.getItem('token')
    if (token) setIsLoggedIn(true)
  }, [])

  const handleLogin = () => {
    setIsLoggedIn(true)
  }

  const handleLogout = () => {
    localStorage.removeItem('token')
    setIsLoggedIn(false)
  }

  if (!isLoggedIn) {
    return <Login onLogin={handleLogin} />
  }

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'customers', label: 'Customers', icon: Users },
    { id: 'invoices', label: 'Invoices', icon: Receipt },
    { id: 'payments', label: 'Payments', icon: CreditCard },
    { id: 'plans', label: 'Plans', icon: Wifi },
    { id: 'routers', label: 'Routers', icon: Router },
    { id: 'olts', label: 'OLTs', icon: Server },
    { id: 'reports', label: 'Reports', icon: BarChart3 },
    { id: 'settings', label: 'Settings', icon: Settings },
  ]

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard': return <Dashboard />
      case 'customers': return <Customers />
      case 'invoices': return <Invoices />
      case 'payments': return <Payments />
      case 'plans': return <Plans />
      case 'routers': return <Routers />
      case 'olts': return <OLTs />
      case 'reports': return <Reports />
      case 'settings': return <SettingsPage />
      default: return <Dashboard />
    }
  }

  return (
    <div className="dashboard">
      <aside className="sidebar">
        <div className="logo">
          <Wifi size={28} />
          ISP Billing
        </div>
        <nav>
          {navItems.map(item => (
            <div
              key={item.id}
              className={`nav-item ${activeTab === item.id ? 'active' : ''}`}
              onClick={() => setActiveTab(item.id)}
            >
              <item.icon size={20} />
              {item.label}
            </div>
          ))}
        </nav>
        <div style={{ marginTop: 'auto', paddingTop: '2rem' }}>
          <div className="nav-item" onClick={handleLogout}>
            <LogOut size={20} />
            Logout
          </div>
        </div>
      </aside>
      <main className="main-content">
        {renderContent()}
      </main>
    </div>
  )
}

export default App
