import React, { useEffect } from 'react';
import { StatusBar, LogBox } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { PaperProvider } from 'react-native-paper';
import Toast from 'react-native-toast-message';

import { AppNavigator } from '@/navigation';
import { Colors } from '@/constants/colors';

// Ignore specific warnings
LogBox.ignoreLogs([
  'Non-serializable values were found in the navigation state',
  'ViewPropTypes will be removed from React Native',
]);

// Main App Component
const App: React.FC = () => {
  useEffect(() => {
    // App initialization logic
    // - Check for updates
    // - Initialize push notifications
    // - Set up analytics
    // - Load initial data
  }, []);

  return (
    <SafeAreaProvider>
      <PaperProvider>
        <StatusBar
          barStyle="dark-content"
          backgroundColor={Colors.light.background}
        />
        <AppNavigator />
        <Toast />
      </PaperProvider>
    </SafeAreaProvider>
  );
};

export default App;
