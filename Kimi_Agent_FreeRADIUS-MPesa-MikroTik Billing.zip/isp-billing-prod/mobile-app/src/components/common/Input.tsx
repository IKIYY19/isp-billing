import React, { useState, forwardRef } from 'react';
import {
  TextInput,
  View,
  Text,
  StyleSheet,
  TextInputProps,
  ViewStyle,
  TextStyle,
  TouchableOpacity,
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { Colors } from '@/constants/colors';

// Input props interface
interface InputProps extends TextInputProps {
  label?: string;
  error?: string;
  helper?: string;
  icon?: string;
  iconRight?: string;
  onIconPress?: () => void;
  onIconRightPress?: () => void;
  containerStyle?: ViewStyle;
  labelStyle?: TextStyle;
  inputStyle?: TextStyle;
  errorStyle?: TextStyle;
  secureTextEntry?: boolean;
}

// Input component
export const Input = forwardRef<TextInput, InputProps>(
  (
    {
      label,
      error,
      helper,
      icon,
      iconRight,
      onIconPress,
      onIconRightPress,
      containerStyle,
      labelStyle,
      inputStyle,
      errorStyle,
      secureTextEntry,
      ...textInputProps
    },
    ref
  ) => {
    const [isFocused, setIsFocused] = useState(false);
    const [isPasswordVisible, setIsPasswordVisible] = useState(!secureTextEntry);

    const togglePasswordVisibility = () => {
      setIsPasswordVisible(!isPasswordVisible);
    };

    return (
      <View style={[styles.container, containerStyle]}>
        {label && (
          <Text style={[styles.label, labelStyle]}>
            {label}
          </Text>
        )}
        
        <View
          style={[
            styles.inputContainer,
            isFocused && styles.inputContainerFocused,
            error && styles.inputContainerError,
          ]}
        >
          {icon && (
            <TouchableOpacity
              onPress={onIconPress}
              disabled={!onIconPress}
              style={styles.iconLeft}
            >
              <Icon
                name={icon}
                size={20}
                color={error ? Colors.error : isFocused ? Colors.primary[600] : Colors.gray[400]}
              />
            </TouchableOpacity>
          )}
          
          <TextInput
            ref={ref}
            style={[
              styles.input,
              icon && styles.inputWithIcon,
              (iconRight || secureTextEntry) && styles.inputWithRightIcon,
              inputStyle,
            ]}
            placeholderTextColor={Colors.gray[400]}
            onFocus={() => setIsFocused(true)}
            onBlur={() => setIsFocused(false)}
            secureTextEntry={secureTextEntry && !isPasswordVisible}
            {...textInputProps}
          />
          
          {secureTextEntry && (
            <TouchableOpacity
              onPress={togglePasswordVisibility}
              style={styles.iconRight}
            >
              <Icon
                name={isPasswordVisible ? 'eye-off' : 'eye'}
                size={20}
                color={Colors.gray[400]}
              />
            </TouchableOpacity>
          )}
          
          {iconRight && !secureTextEntry && (
            <TouchableOpacity
              onPress={onIconRightPress}
              disabled={!onIconRightPress}
              style={styles.iconRight}
            >
              <Icon
                name={iconRight}
                size={20}
                color={error ? Colors.error : isFocused ? Colors.primary[600] : Colors.gray[400]}
              />
            </TouchableOpacity>
          )}
        </View>
        
        {error ? (
          <Text style={[styles.error, errorStyle]}>{error}</Text>
        ) : helper ? (
          <Text style={styles.helper}>{helper}</Text>
        ) : null}
      </View>
    );
  }
);

// Styles
const styles = StyleSheet.create({
  container: {
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    fontWeight: '500',
    color: Colors.gray[700],
    marginBottom: 8,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.gray[300],
    borderRadius: 12,
    backgroundColor: Colors.light.background,
    minHeight: 48,
  },
  inputContainerFocused: {
    borderColor: Colors.primary[600],
    borderWidth: 2,
  },
  inputContainerError: {
    borderColor: Colors.error,
    borderWidth: 2,
  },
  input: {
    flex: 1,
    fontSize: 16,
    color: Colors.gray[900],
    paddingVertical: 12,
    paddingHorizontal: 16,
  },
  inputWithIcon: {
    paddingLeft: 8,
  },
  inputWithRightIcon: {
    paddingRight: 8,
  },
  iconLeft: {
    paddingLeft: 16,
  },
  iconRight: {
    paddingRight: 16,
  },
  error: {
    fontSize: 12,
    color: Colors.error,
    marginTop: 4,
  },
  helper: {
    fontSize: 12,
    color: Colors.gray[500],
    marginTop: 4,
  },
});

export default Input;
