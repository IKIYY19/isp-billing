import React, { useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  RefreshControl,
  TouchableOpacity,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { Colors } from '@/constants/colors';
import { Card, StatCard, Button } from '@/components/common';
import { useAuth, useDashboard } from '@/hooks';

// Dashboard screen component
export const DashboardScreen: React.FC = () => {
  const navigation = useNavigation();
  const { user, fullName, isAdmin } = useAuth();
  const {
    stats,
    revenueChange,
    customerChange,
    criticalAlertsCount,
    warningAlertsCount,
    isLoading,
    error,
    formatCurrency,
    formatNumber,
    formatPercentage,
    refreshAll,
    fetchStats,
  } = useDashboard();

  // Load dashboard data
  useEffect(() => {
    fetchStats();
  }, [fetchStats]);

  // Handle refresh
  const onRefresh = useCallback(() => {
    refreshAll();
  }, [refreshAll]);

  // Quick action items
  const quickActions = [
    {
      icon: 'account-plus',
      label: 'New Customer',
      onPress: () => navigation.navigate('Customers', { screen: 'AddCustomer' } as never),
      color: Colors.primary[600],
    },
    {
      icon: 'file-document-plus',
      label: 'New Invoice',
      onPress: () => navigation.navigate('Invoices', { screen: 'CreateInvoice' } as never),
      color: Colors.secondary[600],
    },
    {
      icon: 'cash-plus',
      label: 'Record Payment',
      onPress: () => navigation.navigate('Payments', { screen: 'RecordPayment' } as never),
      color: Colors.accent.orange,
    },
    {
      icon: 'ticket-account',
      label: 'New Ticket',
      onPress: () => navigation.navigate('Support', { screen: 'CreateTicket' } as never),
      color: Colors.accent.purple,
    },
  ];

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.greeting}>Good Morning,</Text>
          <Text style={styles.userName}>{fullName}</Text>
        </View>
        <TouchableOpacity
          style={styles.notificationButton}
          onPress={() => navigation.navigate('Notifications' as never)}
        >
          <Icon name="bell-outline" size={24} color={Colors.gray[700]} />
          {(criticalAlertsCount + warningAlertsCount) > 0 && (
            <View style={styles.notificationBadge}>
              <Text style={styles.notificationBadgeText}>
                {criticalAlertsCount + warningAlertsCount}
              </Text>
            </View>
          )}
        </TouchableOpacity>
      </View>

      <ScrollView
        contentContainerStyle={styles.scrollContent}
        refreshControl={
          <RefreshControl refreshing={isLoading} onRefresh={onRefresh} />
        }
      >
        {/* Stats Grid */}
        {stats && (
          <View style={styles.statsGrid}>
            <StatCard
              title="Total Revenue"
              value={formatCurrency(stats.revenueThisMonth)}
              subtitle="This month"
              icon="cash-multiple"
              iconColor={Colors.success}
              iconBackgroundColor={Colors.secondary[100]}
              trend={revenueChange >= 0 ? 'up' : 'down'}
              trendValue={`${formatPercentage(Math.abs(revenueChange))} vs last month`}
            />
            
            <StatCard
              title="Active Customers"
              value={formatNumber(stats.activeCustomers)}
              subtitle={`${formatNumber(stats.newCustomersToday)} new today`}
              icon="account-group"
              iconColor={Colors.primary[600]}
              iconBackgroundColor={Colors.primary[100]}
              trend={customerChange >= 0 ? 'up' : 'down'}
              trendValue={`${formatPercentage(Math.abs(customerChange))} vs last month`}
            />
            
            <StatCard
              title="Pending Invoices"
              value={formatNumber(stats.pendingInvoices)}
              subtitle={`${formatNumber(stats.overdueInvoices)} overdue`}
              icon="file-document-outline"
              iconColor={Colors.warning}
              iconBackgroundColor={`${Colors.warning}20`}
            />
            
            <StatCard
              title="Network Uptime"
              value={formatPercentage(stats.networkUptime)}
              subtitle="Last 30 days"
              icon="wifi"
              iconColor={Colors.success}
              iconBackgroundColor={Colors.secondary[100]}
            />
          </View>
        )}

        {/* Quick Actions */}
        <Card title="Quick Actions" padding="small">
          <View style={styles.quickActionsGrid}>
            {quickActions.map((action, index) => (
              <TouchableOpacity
                key={index}
                style={styles.quickActionItem}
                onPress={action.onPress}
              >
                <View
                  style={[
                    styles.quickActionIcon,
                    { backgroundColor: `${action.color}20` },
                  ]}
                >
                  <Icon name={action.icon} size={24} color={action.color} />
                </View>
                <Text style={styles.quickActionLabel}>{action.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </Card>

        {/* Recent Activity */}
        <Card
          title="Recent Activity"
          headerRight={
            <TouchableOpacity onPress={() => navigation.navigate('Activity' as never)}>
              <Text style={styles.viewAllText}>View All</Text>
            </TouchableOpacity>
          }
        >
          <View style={styles.activityList}>
            {/* Sample activities - would be populated from API */}
            <ActivityItem
              icon="cash-check"
              iconColor={Colors.success}
              title="Payment Received"
              description="John Doe paid KSh 2,500"
              time="2 min ago"
            />
            <ActivityItem
              icon="account-plus"
              iconColor={Colors.primary[600]}
              title="New Customer"
              description="Jane Smith registered"
              time="15 min ago"
            />
            <ActivityItem
              icon="alert-circle"
              iconColor={Colors.warning}
              title="Ticket Created"
              description="Slow internet connection reported"
              time="1 hour ago"
            />
            <ActivityItem
              icon="file-document"
              iconColor={Colors.accent.purple}
              title="Invoice Generated"
              description="Monthly invoice for #INV-2024-001"
              time="2 hours ago"
            />
          </View>
        </Card>

        {/* Alerts */}
        {(criticalAlertsCount > 0 || warningAlertsCount > 0) && (
          <Card title="Alerts" style={styles.alertsCard}>
            {criticalAlertsCount > 0 && (
              <AlertItem
                severity="critical"
                message={`${criticalAlertsCount} critical alert${criticalAlertsCount > 1 ? 's' : ''} require attention`}
              />
            )}
            {warningAlertsCount > 0 && (
              <AlertItem
                severity="warning"
                message={`${warningAlertsCount} warning${warningAlertsCount > 1 ? 's' : ''}`}
              />
            )}
          </Card>
        )}
      </ScrollView>
    </SafeAreaView>
  );
};

// Activity item component
interface ActivityItemProps {
  icon: string;
  iconColor: string;
  title: string;
  description: string;
  time: string;
}

const ActivityItem: React.FC<ActivityItemProps> = ({
  icon,
  iconColor,
  title,
  description,
  time,
}) => (
  <View style={styles.activityItem}>
    <View style={[styles.activityIcon, { backgroundColor: `${iconColor}20` }]}>
      <Icon name={icon} size={20} color={iconColor} />
    </View>
    <View style={styles.activityContent}>
      <Text style={styles.activityTitle}>{title}</Text>
      <Text style={styles.activityDescription}>{description}</Text>
    </View>
    <Text style={styles.activityTime}>{time}</Text>
  </View>
);

// Alert item component
interface AlertItemProps {
  severity: 'critical' | 'warning' | 'info';
  message: string;
}

const AlertItem: React.FC<AlertItemProps> = ({ severity, message }) => {
  const getSeverityColor = () => {
    switch (severity) {
      case 'critical':
        return Colors.error;
      case 'warning':
        return Colors.warning;
      case 'info':
        return Colors.info;
      default:
        return Colors.gray[500];
    }
  };

  const getSeverityIcon = () => {
    switch (severity) {
      case 'critical':
        return 'alert-circle';
      case 'warning':
        return 'alert';
      case 'info':
        return 'information';
      default:
        return 'information';
    }
  };

  return (
    <View style={styles.alertItem}>
      <Icon
        name={getSeverityIcon()}
        size={20}
        color={getSeverityColor()}
      />
      <Text style={[styles.alertMessage, { color: getSeverityColor() }]}>
        {message}
      </Text>
    </View>
  );
};

// Styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.gray[50],
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: Colors.light.background,
  },
  greeting: {
    fontSize: 14,
    color: Colors.gray[500],
  },
  userName: {
    fontSize: 20,
    fontWeight: '700',
    color: Colors.gray[900],
  },
  notificationButton: {
    position: 'relative',
    padding: 8,
  },
  notificationBadge: {
    position: 'absolute',
    top: 4,
    right: 4,
    backgroundColor: Colors.error,
    borderRadius: 10,
    minWidth: 18,
    height: 18,
    justifyContent: 'center',
    alignItems: 'center',
  },
  notificationBadgeText: {
    color: Colors.light.background,
    fontSize: 10,
    fontWeight: '600',
  },
  scrollContent: {
    padding: 16,
  },
  statsGrid: {
    gap: 12,
    marginBottom: 16,
  },
  quickActionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  quickActionItem: {
    width: '23%',
    alignItems: 'center',
    paddingVertical: 8,
  },
  quickActionIcon: {
    width: 48,
    height: 48,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  quickActionLabel: {
    fontSize: 12,
    color: Colors.gray[600],
    textAlign: 'center',
  },
  viewAllText: {
    fontSize: 14,
    color: Colors.primary[600],
    fontWeight: '500',
  },
  activityList: {
    gap: 16,
  },
  activityItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  activityIcon: {
    width: 40,
    height: 40,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  activityContent: {
    flex: 1,
  },
  activityTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: Colors.gray[900],
  },
  activityDescription: {
    fontSize: 12,
    color: Colors.gray[500],
    marginTop: 2,
  },
  activityTime: {
    fontSize: 12,
    color: Colors.gray[400],
  },
  alertsCard: {
    backgroundColor: Colors.error + '10',
  },
  alertItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
  },
  alertMessage: {
    fontSize: 14,
    marginLeft: 12,
    flex: 1,
  },
});

export default DashboardScreen;
