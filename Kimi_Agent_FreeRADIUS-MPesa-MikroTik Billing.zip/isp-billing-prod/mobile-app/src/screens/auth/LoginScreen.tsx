import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  TouchableOpacity,
  Image,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { Formik } from 'formik';
import * as Yup from 'yup';
import { Colors } from '@/constants/colors';
import { Button, Input } from '@/components/common';
import { useAuth } from '@/hooks';
import { LoginCredentials } from '@/types';

// Validation schema
const loginSchema = Yup.object().shape({
  email: Yup.string()
    .email('Invalid email address')
    .when('loginMethod', {
      is: 'email',
      then: (schema) => schema.required('Email is required'),
    }),
  phone: Yup.string()
    .matches(/^254[0-9]{9}$/, 'Phone must be in format 254XXXXXXXXX')
    .when('loginMethod', {
      is: 'phone',
      then: (schema) => schema.required('Phone number is required'),
    }),
  password: Yup.string()
    .min(8, 'Password must be at least 8 characters')
    .required('Password is required'),
});

// Login screen component
export const LoginScreen: React.FC = () => {
  const navigation = useNavigation();
  const { login, loginWithGoogle, requestOTP, isLoading, error, clearError } = useAuth();
  const [loginMethod, setLoginMethod] = useState<'email' | 'phone'>('email');
  const [showOTP, setShowOTP] = useState(false);
  const [otpPhone, setOtpPhone] = useState('');

  // Handle login
  const handleLogin = useCallback(async (values: LoginCredentials) => {
    try {
      clearError();
      await login(values);
      // Navigation will be handled by auth navigator
    } catch (err: any) {
      Alert.alert('Login Failed', err.message || 'Please check your credentials and try again');
    }
  }, [login, clearError]);

  // Handle Google login
  const handleGoogleLogin = useCallback(async () => {
    try {
      clearError();
      // In real implementation, use Google Sign-In
      // const { idToken } = await GoogleSignin.signIn();
      // await loginWithGoogle(idToken);
      Alert.alert('Coming Soon', 'Google login will be available soon');
    } catch (err: any) {
      Alert.alert('Login Failed', err.message);
    }
  }, [loginWithGoogle, clearError]);

  // Handle OTP request
  const handleRequestOTP = useCallback(async (phone: string) => {
    try {
      clearError();
      await requestOTP(phone);
      setOtpPhone(phone);
      setShowOTP(true);
      Alert.alert('OTP Sent', 'Please check your phone for the verification code');
    } catch (err: any) {
      Alert.alert('Failed', err.message);
    }
  }, [requestOTP, clearError]);

  return (
    <SafeAreaView style={styles.container}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.keyboardView}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
        >
          {/* Logo */}
          <View style={styles.logoContainer}>
            <View style={styles.logo}>
              <Text style={styles.logoText}>ISP</Text>
            </View>
            <Text style={styles.title}>Welcome Back</Text>
            <Text style={styles.subtitle}>Sign in to your account</Text>
          </View>

          {/* Login Method Toggle */}
          <View style={styles.methodToggle}>
            <TouchableOpacity
              style={[
                styles.methodButton,
                loginMethod === 'email' && styles.methodButtonActive,
              ]}
              onPress={() => setLoginMethod('email')}
            >
              <Text
                style={[
                  styles.methodButtonText,
                  loginMethod === 'email' && styles.methodButtonTextActive,
                ]}
              >
                Email
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                styles.methodButton,
                loginMethod === 'phone' && styles.methodButtonActive,
              ]}
              onPress={() => setLoginMethod('phone')}
            >
              <Text
                style={[
                  styles.methodButtonText,
                  loginMethod === 'phone' && styles.methodButtonTextActive,
                ]}
              >
                Phone
              </Text>
            </TouchableOpacity>
          </View>

          {/* Login Form */}
          <Formik
            initialValues={{
              email: '',
              phone: '',
              password: '',
              loginMethod,
            }}
            validationSchema={loginSchema}
            onSubmit={handleLogin}
          >
            {({
              handleChange,
              handleBlur,
              handleSubmit,
              values,
              errors,
              touched,
            }) => (
              <View style={styles.form}>
                {loginMethod === 'email' ? (
                  <Input
                    label="Email Address"
                    placeholder="Enter your email"
                    keyboardType="email-address"
                    autoCapitalize="none"
                    icon="email-outline"
                    value={values.email}
                    onChangeText={handleChange('email')}
                    onBlur={handleBlur('email')}
                    error={touched.email && errors.email ? errors.email : undefined}
                  />
                ) : (
                  <Input
                    label="Phone Number"
                    placeholder="254XXXXXXXXX"
                    keyboardType="phone-pad"
                    icon="phone-outline"
                    value={values.phone}
                    onChangeText={handleChange('phone')}
                    onBlur={handleBlur('phone')}
                    error={touched.phone && errors.phone ? errors.phone : undefined}
                    helper="Enter number in format 254XXXXXXXXX"
                  />
                )}

                <Input
                  label="Password"
                  placeholder="Enter your password"
                  secureTextEntry
                  icon="lock-outline"
                  value={values.password}
                  onChangeText={handleChange('password')}
                  onBlur={handleBlur('password')}
                  error={touched.password && errors.password ? errors.password : undefined}
                />

                <TouchableOpacity
                  style={styles.forgotPassword}
                  onPress={() => navigation.navigate('ForgotPassword' as never)}
                >
                  <Text style={styles.forgotPasswordText}>Forgot Password?</Text>
                </TouchableOpacity>

                <Button
                  title="Sign In"
                  onPress={handleSubmit as any}
                  loading={isLoading}
                  fullWidth
                  size="large"
                />

                {loginMethod === 'phone' && (
                  <Button
                    title="Sign in with OTP"
                    variant="outline"
                    onPress={() => handleRequestOTP(values.phone)}
                    disabled={!values.phone || values.phone.length < 12}
                    fullWidth
                    style={styles.otpButton}
                  />
                )}
              </View>
            )}
          </Formik>

          {/* Divider */}
          <View style={styles.divider}>
            <View style={styles.dividerLine} />
            <Text style={styles.dividerText}>OR</Text>
            <View style={styles.dividerLine} />
          </View>

          {/* Social Login */}
          <Button
            title="Continue with Google"
            variant="outline"
            onPress={handleGoogleLogin}
            fullWidth
            icon={<View style={styles.googleIcon} />}
          />

          {/* Register Link */}
          <View style={styles.registerContainer}>
            <Text style={styles.registerText}>Don't have an account?</Text>
            <TouchableOpacity onPress={() => navigation.navigate('Register' as never)}>
              <Text style={styles.registerLink}>Sign Up</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

// Styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.light.background,
  },
  keyboardView: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    padding: 24,
  },
  logoContainer: {
    alignItems: 'center',
    marginTop: 40,
    marginBottom: 32,
  },
  logo: {
    width: 80,
    height: 80,
    borderRadius: 20,
    backgroundColor: Colors.primary[600],
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  logoText: {
    fontSize: 28,
    fontWeight: '700',
    color: Colors.light.background,
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: Colors.gray[900],
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: Colors.gray[500],
  },
  methodToggle: {
    flexDirection: 'row',
    backgroundColor: Colors.gray[100],
    borderRadius: 12,
    padding: 4,
    marginBottom: 24,
  },
  methodButton: {
    flex: 1,
    paddingVertical: 10,
    alignItems: 'center',
    borderRadius: 8,
  },
  methodButtonActive: {
    backgroundColor: Colors.light.background,
    shadowColor: Colors.light.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  methodButtonText: {
    fontSize: 14,
    fontWeight: '500',
    color: Colors.gray[500],
  },
  methodButtonTextActive: {
    color: Colors.primary[600],
  },
  form: {
    marginBottom: 24,
  },
  forgotPassword: {
    alignSelf: 'flex-end',
    marginBottom: 24,
  },
  forgotPasswordText: {
    fontSize: 14,
    color: Colors.primary[600],
    fontWeight: '500',
  },
  otpButton: {
    marginTop: 12,
  },
  divider: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 24,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: Colors.gray[200],
  },
  dividerText: {
    fontSize: 14,
    color: Colors.gray[400],
    marginHorizontal: 16,
  },
  googleIcon: {
    width: 20,
    height: 20,
    backgroundColor: Colors.gray[400],
    borderRadius: 10,
  },
  registerContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 24,
  },
  registerText: {
    fontSize: 14,
    color: Colors.gray[500],
  },
  registerLink: {
    fontSize: 14,
    color: Colors.primary[600],
    fontWeight: '600',
    marginLeft: 4,
  },
});

export default LoginScreen;
