import { useCallback, useEffect } from 'react';
import { useDashboardStore } from '@/store';

// Dashboard hook for components
export const useDashboard = () => {
  const {
    stats,
    revenueChart,
    customerGrowthChart,
    usageChart,
    planDistributionChart,
    paymentMethodsChart,
    recentActivities,
    alerts,
    networkStatus,
    customerDashboard,
    isLoading,
    error,
    fetchStats,
    fetchRevenueChart,
    fetchCustomerGrowthChart,
    fetchUsageChart,
    fetchPlanDistributionChart,
    fetchPaymentMethodsChart,
    fetchRecentActivities,
    fetchAlerts,
    fetchNetworkStatus,
    fetchCustomerDashboard,
    fetchCustomerUsage,
    refreshAll,
    clearError,
  } = useDashboardStore();

  // Format currency
  const formatCurrency = useCallback((amount: number): string => {
    return new Intl.NumberFormat('en-KE', {
      style: 'currency',
      currency: 'KES',
    }).format(amount);
  }, []);

  // Format number
  const formatNumber = useCallback((num: number): string => {
    return new Intl.NumberFormat('en-KE').format(num);
  }, []);

  // Format percentage
  const formatPercentage = useCallback((value: number): string => {
    return `${value.toFixed(1)}%`;
  }, []);

  // Format bytes
  const formatBytes = useCallback((bytes: number): string => {
    if (bytes === 0) return '0 B';
    
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return `${parseFloat((bytes / Math.pow(k, i)).toFixed(2))} ${sizes[i]}`;
  }, []);

  // Get revenue change percentage
  const getRevenueChange = useCallback((): number => {
    if (!revenueChart || revenueChart.datasets.length === 0) return 0;
    
    const data = revenueChart.datasets[0].data;
    if (data.length < 2) return 0;
    
    const current = data[data.length - 1];
    const previous = data[data.length - 2];
    
    if (previous === 0) return 0;
    
    return ((current - previous) / previous) * 100;
  }, [revenueChart]);

  // Get customer change percentage
  const getCustomerChange = useCallback((): number => {
    if (!customerGrowthChart || customerGrowthChart.datasets.length === 0) return 0;
    
    const data = customerGrowthChart.datasets[0].data;
    if (data.length < 2) return 0;
    
    const current = data[data.length - 1];
    const previous = data[data.length - 2];
    
    if (previous === 0) return 0;
    
    return ((current - previous) / previous) * 100;
  }, [customerGrowthChart]);

  // Get critical alerts count
  const getCriticalAlertsCount = useCallback((): number => {
    return alerts.filter((alert) => alert.severity === 'critical').length;
  }, [alerts]);

  // Get warning alerts count
  const getWarningAlertsCount = useCallback((): number => {
    return alerts.filter((alert) => alert.severity === 'warning').length;
  }, [alerts]);

  // Load dashboard data on mount
  useEffect(() => {
    if (!stats) {
      fetchStats();
    }
  }, [stats, fetchStats]);

  return {
    // State
    stats,
    revenueChart,
    customerGrowthChart,
    usageChart,
    planDistributionChart,
    paymentMethodsChart,
    recentActivities,
    alerts,
    networkStatus,
    customerDashboard,
    isLoading,
    error,
    
    // Computed
    revenueChange: getRevenueChange(),
    customerChange: getCustomerChange(),
    criticalAlertsCount: getCriticalAlertsCount(),
    warningAlertsCount: getWarningAlertsCount(),
    
    // Formatters
    formatCurrency,
    formatNumber,
    formatPercentage,
    formatBytes,
    
    // Actions
    fetchStats,
    fetchRevenueChart,
    fetchCustomerGrowthChart,
    fetchUsageChart,
    fetchPlanDistributionChart,
    fetchPaymentMethodsChart,
    fetchRecentActivities,
    fetchAlerts,
    fetchNetworkStatus,
    fetchCustomerDashboard,
    fetchCustomerUsage,
    refreshAll,
    clearError,
  };
};

export default useDashboard;
