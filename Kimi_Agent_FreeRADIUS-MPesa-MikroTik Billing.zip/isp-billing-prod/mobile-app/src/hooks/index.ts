// Hooks exports
export { useAuth } from './useAuth';
export { useDashboard } from './useDashboard';

// Re-export for convenience
export * from './useAuth';
export * from './useDashboard';
