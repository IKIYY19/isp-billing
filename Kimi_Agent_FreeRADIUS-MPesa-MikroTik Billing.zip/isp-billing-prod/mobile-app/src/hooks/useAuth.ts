import { useCallback, useEffect } from 'react';
import { useAuthStore } from '@/store';
import { LoginCredentials, RegisterData, OTPVerification, User } from '@/types';

// Auth hook for components
export const useAuth = () => {
  const {
    user,
    tokens,
    isAuthenticated,
    isLoading,
    error,
    login,
    register,
    loginWithGoogle,
    requestOTP,
    verifyOTP,
    logout,
    refreshUser,
    updateProfile,
    changePassword,
    clearError,
    setLoading,
  } = useAuthStore();

  // Check if user has specific role
  const hasRole = useCallback(
    (roles: string | string[]): boolean => {
      if (!user) return false;
      
      const roleArray = Array.isArray(roles) ? roles : [roles];
      return roleArray.includes(user.role);
    },
    [user]
  );

  // Check if user is admin
  const isAdmin = useCallback((): boolean => {
    return hasRole(['admin']);
  }, [hasRole]);

  // Check if user is agent
  const isAgent = useCallback((): boolean => {
    return hasRole(['admin', 'agent', 'support']);
  }, [hasRole]);

  // Get user full name
  const getFullName = useCallback((): string => {
    if (!user) return '';
    return `${user.firstName} ${user.lastName}`.trim();
  }, [user]);

  // Get user initials
  const getInitials = useCallback((): string => {
    if (!user) return '';
    return `${user.firstName[0]}${user.lastName[0]}`.toUpperCase();
  }, [user]);

  // Refresh user on mount if authenticated
  useEffect(() => {
    if (isAuthenticated && !user) {
      refreshUser();
    }
  }, [isAuthenticated, user, refreshUser]);

  return {
    // State
    user,
    tokens,
    isAuthenticated,
    isLoading,
    error,
    
    // Computed
    isAdmin: isAdmin(),
    isAgent: isAgent(),
    fullName: getFullName(),
    initials: getInitials(),
    
    // Actions
    login,
    register,
    loginWithGoogle,
    requestOTP,
    verifyOTP,
    logout,
    refreshUser,
    updateProfile,
    changePassword,
    clearError,
    setLoading,
    hasRole,
  };
};

export default useAuth;
