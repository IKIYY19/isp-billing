// User Types
export interface User {
  id: string;
  email: string;
  phone: string;
  firstName: string;
  lastName: string;
  role: 'customer' | 'admin' | 'agent' | 'support';
  avatar?: string;
  isActive: boolean;
  emailVerified: boolean;
  phoneVerified: boolean;
  createdAt: string;
  updatedAt: string;
  lastLoginAt?: string;
}

export interface Customer extends User {
  accountNumber: string;
  address: string;
  city: string;
  country: string;
  postalCode?: string;
  coordinates?: {
    latitude: number;
    longitude: number;
  };
  idNumber?: string;
  dateOfBirth?: string;
  emergencyContact?: {
    name: string;
    phone: string;
    relationship: string;
  };
  referralCode?: string;
  referredBy?: string;
  notes?: string;
  tags: string[];
  customFields: Record<string, any>;
}

// Authentication Types
export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
  tokenType: 'Bearer';
}

export interface LoginCredentials {
  email?: string;
  phone?: string;
  password: string;
}

export interface RegisterData {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  password: string;
  address: string;
  city: string;
  country: string;
}

export interface OTPVerification {
  phone: string;
  code: string;
}

// Subscription & Plan Types
export interface Plan {
  id: string;
  name: string;
  description: string;
  speed: {
    download: number;
    upload: number;
    unit: 'Mbps' | 'Gbps';
  };
  dataLimit?: {
    amount: number;
    unit: 'GB' | 'TB';
    type: 'unlimited' | 'capped' | 'fair_use';
  };
  price: number;
  currency: string;
  billingCycle: 'monthly' | 'quarterly' | 'semi-annual' | 'annual';
  features: string[];
  isActive: boolean;
  isPopular?: boolean;
  category: 'residential' | 'business' | 'enterprise';
  createdAt: string;
  updatedAt: string;
}

export interface Subscription {
  id: string;
  customerId: string;
  planId: string;
  plan: Plan;
  status: 'active' | 'suspended' | 'cancelled' | 'expired' | 'pending';
  startDate: string;
  endDate: string;
  nextBillingDate: string;
  autoRenew: boolean;
  ipAddress?: string;
  pppoeUsername?: string;
  pppoePassword?: string;
  routerId?: string;
  oltId?: string;
  ponPort?: number;
  onuSerial?: string;
  installationDate?: string;
  cancellationDate?: string;
  cancellationReason?: string;
  createdAt: string;
  updatedAt: string;
}

// Invoice Types
export interface Invoice {
  id: string;
  invoiceNumber: string;
  customerId: string;
  customer?: Customer;
  subscriptionId?: string;
  subscription?: Subscription;
  items: InvoiceItem[];
  subtotal: number;
  taxAmount: number;
  discountAmount: number;
  total: number;
  amountPaid: number;
  balanceDue: number;
  currency: string;
  status: 'draft' | 'sent' | 'paid' | 'partial' | 'overdue' | 'cancelled';
  issueDate: string;
  dueDate: string;
  paidDate?: string;
  notes?: string;
  terms?: string;
  createdAt: string;
  updatedAt: string;
}

export interface InvoiceItem {
  id: string;
  description: string;
  quantity: number;
  unitPrice: number;
  total: number;
  type: 'subscription' | 'installation' | 'equipment' | 'service' | 'late_fee' | 'other';
}

// Payment Types
export interface Payment {
  id: string;
  transactionId: string;
  customerId: string;
  customer?: Customer;
  invoiceId?: string;
  invoice?: Invoice;
  amount: number;
  currency: string;
  method: 'mpesa' | 'bank_transfer' | 'cash' | 'card' | 'cheque' | 'wallet';
  status: 'pending' | 'completed' | 'failed' | 'refunded' | 'cancelled';
  mpesaDetails?: {
    phoneNumber: string;
    merchantRequestId: string;
    checkoutRequestId: string;
    resultCode?: number;
    resultDesc?: string;
  };
  bankDetails?: {
    accountNumber: string;
    bankName: string;
    reference: string;
  };
  cardDetails?: {
    last4: string;
    brand: string;
  };
  notes?: string;
  processedAt?: string;
  createdAt: string;
  updatedAt: string;
}

// Usage Types
export interface UsageRecord {
  id: string;
  customerId: string;
  subscriptionId: string;
  date: string;
  downloadBytes: number;
  uploadBytes: number;
  totalBytes: number;
  sessionDuration: number;
  ipAddress: string;
  macAddress?: string;
}

export interface UsageSummary {
  customerId: string;
  period: 'daily' | 'weekly' | 'monthly';
  startDate: string;
  endDate: string;
  totalDownload: number;
  totalUpload: number;
  totalUsage: number;
  averageDaily: number;
  peakUsageTime?: string;
}

// Ticket Types
export interface SupportTicket {
  id: string;
  ticketNumber: string;
  customerId: string;
  customer?: Customer;
  subject: string;
  description: string;
  category: 'technical' | 'billing' | 'sales' | 'general';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  status: 'open' | 'in_progress' | 'waiting_customer' | 'resolved' | 'closed';
  assignedTo?: string;
  assignedToUser?: User;
  attachments: string[];
  messages: TicketMessage[];
  resolution?: string;
  satisfactionRating?: number;
  satisfactionComment?: string;
  createdAt: string;
  updatedAt: string;
  resolvedAt?: string;
  closedAt?: string;
}

export interface TicketMessage {
  id: string;
  ticketId: string;
  senderId: string;
  senderType: 'customer' | 'agent' | 'system';
  message: string;
  isInternal: boolean;
  attachments: string[];
  createdAt: string;
}

// Network Device Types
export interface Router {
  id: string;
  name: string;
  ipAddress: string;
  port: number;
  username: string;
  password?: string;
  apiPort?: number;
  model?: string;
  osVersion?: string;
  location?: string;
  coordinates?: {
    latitude: number;
    longitude: number;
  };
  isActive: boolean;
  lastSeenAt?: string;
  status: 'online' | 'offline' | 'unknown';
  connectedCustomers: number;
  totalCustomers: number;
  createdAt: string;
  updatedAt: string;
}

export interface OLT {
  id: string;
  name: string;
  vendor: 'huawei' | 'zte' | 'nokia' | 'fiberhome' | 'other';
  model: string;
  ipAddress: string;
  port: number;
  username: string;
  password?: string;
  snmpCommunity?: string;
  location: string;
  coordinates?: {
    latitude: number;
    longitude: number;
  };
  isActive: boolean;
  status: 'online' | 'offline' | 'unknown';
  lastSeenAt?: string;
  totalPonPorts: number;
  activePonPorts: number;
  totalOnus: number;
  activeOnus: number;
  createdAt: string;
  updatedAt: string;
}

export interface PonPort {
  id: string;
  oltId: string;
  portNumber: number;
  status: 'active' | 'inactive' | 'error';
  totalOnus: number;
  activeOnus: number;
  opticalPower?: number;
  createdAt: string;
  updatedAt: string;
}

export interface ONU {
  id: string;
  oltId: string;
  ponPortId: string;
  serialNumber: string;
  name?: string;
  customerId?: string;
  status: 'online' | 'offline' | 'unknown' | 'error';
  opticalPowerRx?: number;
  opticalPowerTx?: number;
  distance?: number;
  lastSeenAt?: string;
  provisionedAt?: string;
  createdAt: string;
  updatedAt: string;
}

// Notification Types
export interface Notification {
  id: string;
  userId: string;
  type: 'payment' | 'invoice' | 'ticket' | 'system' | 'promotion' | 'usage';
  title: string;
  message: string;
  data?: Record<string, any>;
  isRead: boolean;
  sentVia: ('push' | 'sms' | 'email' | 'whatsapp')[];
  createdAt: string;
  readAt?: string;
}

// Dashboard Types
export interface DashboardStats {
  totalCustomers: number;
  activeCustomers: number;
  newCustomersToday: number;
  totalRevenue: number;
  revenueThisMonth: number;
  pendingInvoices: number;
  overdueInvoices: number;
  openTickets: number;
  networkUptime: number;
  averageSpeed: number;
  dataUsageToday: number;
}

export interface ChartData {
  labels: string[];
  datasets: {
    label: string;
    data: number[];
    color?: string;
  }[];
}

// API Response Types
export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
    details?: any;
  };
  meta?: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}

export interface PaginatedResponse<T> {
  data: T[];
  meta: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
    hasNextPage: boolean;
    hasPrevPage: boolean;
  };
}

// App State Types
export interface AppState {
  isLoading: boolean;
  isAuthenticated: boolean;
  user: User | null;
  tokens: AuthTokens | null;
  settings: AppSettings;
  unreadNotifications: number;
}

export interface AppSettings {
  language: string;
  theme: 'light' | 'dark' | 'system';
  notifications: {
    push: boolean;
    email: boolean;
    sms: boolean;
  };
  biometricAuth: boolean;
}

// Form Types
export interface ProfileFormData {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  country: string;
  postalCode?: string;
}

export interface TicketFormData {
  subject: string;
  description: string;
  category: SupportTicket['category'];
  priority: SupportTicket['priority'];
  attachments?: string[];
}

export interface PaymentFormData {
  amount: number;
  method: Payment['method'];
  phoneNumber?: string;
  invoiceId?: string;
}
