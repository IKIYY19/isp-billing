import React, { useEffect, useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { ActivityIndicator, View, StyleSheet } from 'react-native';

import { Colors } from '@/constants/colors';
import { useAuth } from '@/hooks';
import { LoginScreen, DashboardScreen } from '@/screens';

// Create navigators
const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

// Auth Navigator
const AuthNavigator: React.FC = () => (
  <Stack.Navigator
    screenOptions={{
      headerShown: false,
      cardStyle: { backgroundColor: Colors.light.background },
    }}
  >
    <Stack.Screen name="Login" component={LoginScreen} />
    {/* Add Register, ForgotPassword, OTP screens here */}
  </Stack.Navigator>
);

// Main Tab Navigator
const MainTabNavigator: React.FC = () => (
  <Tab.Navigator
    screenOptions={({ route }) => ({
      tabBarIcon: ({ focused, color, size }) => {
        let iconName: string;

        switch (route.name) {
          case 'Home':
            iconName = focused ? 'home' : 'home-outline';
            break;
          case 'Customers':
            iconName = focused ? 'account-group' : 'account-group-outline';
            break;
          case 'Invoices':
            iconName = focused ? 'file-document' : 'file-document-outline';
            break;
          case 'Payments':
            iconName = focused ? 'cash' : 'cash-outline';
            break;
          case 'Support':
            iconName = focused ? 'headset' : 'headset-outline';
            break;
          case 'More':
            iconName = focused ? 'dots-horizontal' : 'dots-horizontal';
            break;
          default:
            iconName = 'help-circle-outline';
        }

        return <Icon name={iconName} size={size} color={color} />;
      },
      tabBarActiveTintColor: Colors.primary[600],
      tabBarInactiveTintColor: Colors.gray[400],
      tabBarStyle: {
        backgroundColor: Colors.light.background,
        borderTopWidth: 1,
        borderTopColor: Colors.gray[200],
        paddingBottom: 8,
        paddingTop: 8,
        height: 64,
      },
      tabBarLabelStyle: {
        fontSize: 12,
        fontWeight: '500',
      },
      headerShown: false,
    })}
  >
    <Tab.Screen name="Home" component={DashboardScreen} />
    <Tab.Screen name="Customers" component={PlaceholderScreen} />
    <Tab.Screen name="Invoices" component={PlaceholderScreen} />
    <Tab.Screen name="Payments" component={PlaceholderScreen} />
    <Tab.Screen name="Support" component={PlaceholderScreen} />
    <Tab.Screen name="More" component={PlaceholderScreen} />
  </Tab.Navigator>
);

// Placeholder screen for development
const PlaceholderScreen: React.FC<{ route: any }> = ({ route }) => (
  <View style={styles.placeholder}>
    <Icon name="construction" size={64} color={Colors.gray[300]} />
    <Text style={styles.placeholderText}>{route.name} Screen</Text>
    <Text style={styles.placeholderSubtext}>Coming Soon</Text>
  </View>
);

// Import Text for placeholder
import { Text } from 'react-native';

// Main App Navigator
export const AppNavigator: React.FC = () => {
  const { isAuthenticated, isLoading } = useAuth();
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    // Simulate app initialization
    const timer = setTimeout(() => {
      setIsReady(true);
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  // Show loading screen while initializing
  if (!isReady || isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={Colors.primary[600]} />
      </View>
    );
  }

  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        {isAuthenticated ? (
          <Stack.Screen name="Main" component={MainTabNavigator} />
        ) : (
          <Stack.Screen name="Auth" component={AuthNavigator} />
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
};

// Styles
const styles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.light.background,
  },
  placeholder: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.gray[50],
  },
  placeholderText: {
    fontSize: 24,
    fontWeight: '600',
    color: Colors.gray[700],
    marginTop: 16,
  },
  placeholderSubtext: {
    fontSize: 16,
    color: Colors.gray[400],
    marginTop: 8,
  },
});

export default AppNavigator;
