import { create } from 'zustand';
import { DashboardStats, ChartData, UsageSummary } from '@/types';
import { dashboardApi } from '@/services/api';

// Dashboard State Interface
interface DashboardState {
  // State
  stats: DashboardStats | null;
  revenueChart: ChartData | null;
  customerGrowthChart: ChartData | null;
  usageChart: ChartData | null;
  planDistributionChart: ChartData | null;
  paymentMethodsChart: ChartData | null;
  recentActivities: any[];
  alerts: any[];
  networkStatus: {
    online: number;
    offline: number;
    total: number;
    uptime: number;
  } | null;
  customerDashboard: {
    subscription: any;
    usage: UsageSummary | null;
    upcomingInvoice: any;
    recentPayments: any[];
    notifications: any[];
  } | null;
  isLoading: boolean;
  error: string | null;
  
  // Actions
  fetchStats: () => Promise<void>;
  fetchRevenueChart: (period?: 'week' | 'month' | 'quarter' | 'year') => Promise<void>;
  fetchCustomerGrowthChart: (period?: 'week' | 'month' | 'quarter' | 'year') => Promise<void>;
  fetchUsageChart: (period?: 'day' | 'week' | 'month') => Promise<void>;
  fetchPlanDistributionChart: () => Promise<void>;
  fetchPaymentMethodsChart: (period?: 'week' | 'month' | 'quarter' | 'year') => Promise<void>;
  fetchRecentActivities: (limit?: number) => Promise<void>;
  fetchAlerts: () => Promise<void>;
  fetchNetworkStatus: () => Promise<void>;
  fetchCustomerDashboard: () => Promise<void>;
  fetchCustomerUsage: (period?: 'daily' | 'weekly' | 'monthly') => Promise<void>;
  refreshAll: () => Promise<void>;
  clearError: () => void;
}

// Create dashboard store
export const useDashboardStore = create<DashboardState>((set, get) => ({
  // Initial state
  stats: null,
  revenueChart: null,
  customerGrowthChart: null,
  usageChart: null,
  planDistributionChart: null,
  paymentMethodsChart: null,
  recentActivities: [],
  alerts: [],
  networkStatus: null,
  customerDashboard: null,
  isLoading: false,
  error: null,

  // Fetch dashboard stats
  fetchStats: async () => {
    set({ isLoading: true, error: null });
    
    try {
      const stats = await dashboardApi.getStats();
      set({ stats, isLoading: false });
    } catch (error: any) {
      set({
        isLoading: false,
        error: error.message || 'Failed to fetch stats',
      });
    }
  },

  // Fetch revenue chart
  fetchRevenueChart: async (period = 'month') => {
    set({ isLoading: true, error: null });
    
    try {
      const revenueChart = await dashboardApi.getRevenueChart(period);
      set({ revenueChart, isLoading: false });
    } catch (error: any) {
      set({
        isLoading: false,
        error: error.message || 'Failed to fetch revenue chart',
      });
    }
  },

  // Fetch customer growth chart
  fetchCustomerGrowthChart: async (period = 'month') => {
    set({ isLoading: true, error: null });
    
    try {
      const customerGrowthChart = await dashboardApi.getCustomerGrowthChart(period);
      set({ customerGrowthChart, isLoading: false });
    } catch (error: any) {
      set({
        isLoading: false,
        error: error.message || 'Failed to fetch customer growth chart',
      });
    }
  },

  // Fetch usage chart
  fetchUsageChart: async (period = 'week') => {
    set({ isLoading: true, error: null });
    
    try {
      const usageChart = await dashboardApi.getUsageChart(period);
      set({ usageChart, isLoading: false });
    } catch (error: any) {
      set({
        isLoading: false,
        error: error.message || 'Failed to fetch usage chart',
      });
    }
  },

  // Fetch plan distribution chart
  fetchPlanDistributionChart: async () => {
    set({ isLoading: true, error: null });
    
    try {
      const planDistributionChart = await dashboardApi.getPlanDistributionChart();
      set({ planDistributionChart, isLoading: false });
    } catch (error: any) {
      set({
        isLoading: false,
        error: error.message || 'Failed to fetch plan distribution',
      });
    }
  },

  // Fetch payment methods chart
  fetchPaymentMethodsChart: async (period = 'month') => {
    set({ isLoading: true, error: null });
    
    try {
      const paymentMethodsChart = await dashboardApi.getPaymentMethodsChart(period);
      set({ paymentMethodsChart, isLoading: false });
    } catch (error: any) {
      set({
        isLoading: false,
        error: error.message || 'Failed to fetch payment methods chart',
      });
    }
  },

  // Fetch recent activities
  fetchRecentActivities: async (limit = 10) => {
    try {
      const recentActivities = await dashboardApi.getRecentActivities(limit);
      set({ recentActivities });
    } catch (error: any) {
      console.error('Failed to fetch recent activities:', error);
    }
  },

  // Fetch alerts
  fetchAlerts: async () => {
    try {
      const alerts = await dashboardApi.getAlerts();
      set({ alerts });
    } catch (error: any) {
      console.error('Failed to fetch alerts:', error);
    }
  },

  // Fetch network status
  fetchNetworkStatus: async () => {
    try {
      const networkStatus = await dashboardApi.getNetworkStatus();
      set({ networkStatus });
    } catch (error: any) {
      console.error('Failed to fetch network status:', error);
    }
  },

  // Fetch customer dashboard
  fetchCustomerDashboard: async () => {
    set({ isLoading: true, error: null });
    
    try {
      const customerDashboard = await dashboardApi.getCustomerDashboard();
      set({ customerDashboard, isLoading: false });
    } catch (error: any) {
      set({
        isLoading: false,
        error: error.message || 'Failed to fetch customer dashboard',
      });
    }
  },

  // Fetch customer usage
  fetchCustomerUsage: async (period = 'monthly') => {
    try {
      const usage = await dashboardApi.getCustomerUsage(period);
      set((state) => ({
        customerDashboard: state.customerDashboard
          ? { ...state.customerDashboard, usage }
          : null,
      }));
    } catch (error: any) {
      console.error('Failed to fetch customer usage:', error);
    }
  },

  // Refresh all dashboard data
  refreshAll: async () => {
    set({ isLoading: true, error: null });
    
    try {
      await Promise.all([
        get().fetchStats(),
        get().fetchRevenueChart(),
        get().fetchCustomerGrowthChart(),
        get().fetchUsageChart(),
        get().fetchPlanDistributionChart(),
        get().fetchPaymentMethodsChart(),
        get().fetchRecentActivities(),
        get().fetchAlerts(),
        get().fetchNetworkStatus(),
      ]);
      
      set({ isLoading: false });
    } catch (error: any) {
      set({
        isLoading: false,
        error: error.message || 'Failed to refresh dashboard',
      });
    }
  },

  // Clear error
  clearError: () => {
    set({ error: null });
  },
}));

export default useDashboardStore;
