import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { User, AuthTokens, LoginCredentials, RegisterData, OTPVerification } from '@/types';
import { authApi } from '@/services/api';

// Auth State Interface
interface AuthState {
  // State
  user: User | null;
  tokens: AuthTokens | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
  
  // Actions
  login: (credentials: LoginCredentials) => Promise<void>;
  register: (data: RegisterData) => Promise<void>;
  loginWithGoogle: (idToken: string) => Promise<void>;
  requestOTP: (phone: string) => Promise<{ message: string; expiresIn: number }>;
  verifyOTP: (data: OTPVerification) => Promise<void>;
  logout: () => Promise<void>;
  refreshUser: () => Promise<void>;
  updateProfile: (data: Partial<User>) => Promise<void>;
  changePassword: (oldPassword: string, newPassword: string) => Promise<void>;
  clearError: () => void;
  setLoading: (loading: boolean) => void;
}

// Create auth store with persistence
export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      // Initial state
      user: null,
      tokens: null,
      isAuthenticated: false,
      isLoading: false,
      error: null,

      // Login action
      login: async (credentials) => {
        set({ isLoading: true, error: null });
        
        try {
          const { user, tokens } = await authApi.login(credentials);
          
          set({
            user,
            tokens,
            isAuthenticated: true,
            isLoading: false,
            error: null,
          });
        } catch (error: any) {
          set({
            isLoading: false,
            error: error.message || 'Login failed',
          });
          throw error;
        }
      },

      // Register action
      register: async (data) => {
        set({ isLoading: true, error: null });
        
        try {
          const { user, tokens } = await authApi.register(data);
          
          set({
            user,
            tokens,
            isAuthenticated: true,
            isLoading: false,
            error: null,
          });
        } catch (error: any) {
          set({
            isLoading: false,
            error: error.message || 'Registration failed',
          });
          throw error;
        }
      },

      // Google login action
      loginWithGoogle: async (idToken) => {
        set({ isLoading: true, error: null });
        
        try {
          const { user, tokens } = await authApi.loginWithGoogle(idToken);
          
          set({
            user,
            tokens,
            isAuthenticated: true,
            isLoading: false,
            error: null,
          });
        } catch (error: any) {
          set({
            isLoading: false,
            error: error.message || 'Google login failed',
          });
          throw error;
        }
      },

      // Request OTP action
      requestOTP: async (phone) => {
        set({ isLoading: true, error: null });
        
        try {
          const result = await authApi.requestOTP(phone);
          set({ isLoading: false, error: null });
          return result;
        } catch (error: any) {
          set({
            isLoading: false,
            error: error.message || 'Failed to send OTP',
          });
          throw error;
        }
      },

      // Verify OTP action
      verifyOTP: async (data) => {
        set({ isLoading: true, error: null });
        
        try {
          const { user, tokens } = await authApi.verifyOTP(data);
          
          set({
            user,
            tokens,
            isAuthenticated: true,
            isLoading: false,
            error: null,
          });
        } catch (error: any) {
          set({
            isLoading: false,
            error: error.message || 'OTP verification failed',
          });
          throw error;
        }
      },

      // Logout action
      logout: async () => {
        set({ isLoading: true });
        
        try {
          await authApi.logout();
        } catch (error) {
          console.error('Logout error:', error);
        } finally {
          set({
            user: null,
            tokens: null,
            isAuthenticated: false,
            isLoading: false,
            error: null,
          });
        }
      },

      // Refresh user data
      refreshUser: async () => {
        try {
          const user = await authApi.getCurrentUser();
          set({ user });
        } catch (error: any) {
          console.error('Refresh user error:', error);
          
          // If unauthorized, logout
          if (error.response?.status === 401) {
            await get().logout();
          }
        }
      },

      // Update profile
      updateProfile: async (data) => {
        set({ isLoading: true, error: null });
        
        try {
          const user = await authApi.updateProfile(data);
          set({ user, isLoading: false, error: null });
        } catch (error: any) {
          set({
            isLoading: false,
            error: error.message || 'Failed to update profile',
          });
          throw error;
        }
      },

      // Change password
      changePassword: async (oldPassword, newPassword) => {
        set({ isLoading: true, error: null });
        
        try {
          await authApi.changePassword(oldPassword, newPassword);
          set({ isLoading: false, error: null });
        } catch (error: any) {
          set({
            isLoading: false,
            error: error.message || 'Failed to change password',
          });
          throw error;
        }
      },

      // Clear error
      clearError: () => {
        set({ error: null });
      },

      // Set loading state
      setLoading: (loading) => {
        set({ isLoading: loading });
      },
    }),
    {
      name: 'auth-storage',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({
        user: state.user,
        tokens: state.tokens,
        isAuthenticated: state.isAuthenticated,
      }),
    }
  )
);

export default useAuthStore;
