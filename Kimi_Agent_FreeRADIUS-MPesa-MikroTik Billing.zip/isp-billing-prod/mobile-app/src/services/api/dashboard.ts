import { api } from './client';
import { DashboardStats, ChartData, ApiResponse, UsageSummary } from '@/types';

// Dashboard API endpoints
export const dashboardApi = {
  // Get dashboard statistics
  getStats: async (): Promise<DashboardStats> => {
    const response = await api.get<ApiResponse<DashboardStats>>('/dashboard/stats');
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to get dashboard stats');
    }
    
    return response.data;
  },

  // Get revenue chart data
  getRevenueChart: async (
    period: 'week' | 'month' | 'quarter' | 'year' = 'month'
  ): Promise<ChartData> => {
    const response = await api.get<ApiResponse<ChartData>>(
      `/dashboard/charts/revenue?period=${period}`
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to get revenue chart');
    }
    
    return response.data;
  },

  // Get customer growth chart data
  getCustomerGrowthChart: async (
    period: 'week' | 'month' | 'quarter' | 'year' = 'month'
  ): Promise<ChartData> => {
    const response = await api.get<ApiResponse<ChartData>>(
      `/dashboard/charts/customers?period=${period}`
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to get customer growth chart');
    }
    
    return response.data;
  },

  // Get usage chart data
  getUsageChart: async (
    period: 'day' | 'week' | 'month' = 'week'
  ): Promise<ChartData> => {
    const response = await api.get<ApiResponse<ChartData>>(
      `/dashboard/charts/usage?period=${period}`
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to get usage chart');
    }
    
    return response.data;
  },

  // Get plan distribution chart
  getPlanDistributionChart: async (): Promise<ChartData> => {
    const response = await api.get<ApiResponse<ChartData>>(
      '/dashboard/charts/plan-distribution'
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to get plan distribution');
    }
    
    return response.data;
  },

  // Get payment methods chart
  getPaymentMethodsChart: async (
    period: 'week' | 'month' | 'quarter' | 'year' = 'month'
  ): Promise<ChartData> => {
    const response = await api.get<ApiResponse<ChartData>>(
      `/dashboard/charts/payment-methods?period=${period}`
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to get payment methods chart');
    }
    
    return response.data;
  },

  // Get recent activities
  getRecentActivities: async (limit: number = 10): Promise<any[]> => {
    const response = await api.get<ApiResponse<any[]>>(
      `/dashboard/activities?limit=${limit}`
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to get recent activities');
    }
    
    return response.data;
  },

  // Get alerts and notifications
  getAlerts: async (): Promise<any[]> => {
    const response = await api.get<ApiResponse<any[]>>('/dashboard/alerts');
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to get alerts');
    }
    
    return response.data;
  },

  // Get network status
  getNetworkStatus: async (): Promise<{
    online: number;
    offline: number;
    total: number;
    uptime: number;
  }> => {
    const response = await api.get<ApiResponse<{
      online: number;
      offline: number;
      total: number;
      uptime: number;
    }>>('/dashboard/network-status');
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to get network status');
    }
    
    return response.data;
  },

  // Get customer dashboard data (for customer app)
  getCustomerDashboard: async (): Promise<{
    subscription: any;
    usage: UsageSummary;
    upcomingInvoice: any;
    recentPayments: any[];
    notifications: any[];
  }> => {
    const response = await api.get<ApiResponse<{
      subscription: any;
      usage: UsageSummary;
      upcomingInvoice: any;
      recentPayments: any[];
      notifications: any[];
    }>>('/dashboard/customer');
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to get customer dashboard');
    }
    
    return response.data;
  },

  // Get usage summary for customer
  getCustomerUsage: async (
    period: 'daily' | 'weekly' | 'monthly' = 'monthly'
  ): Promise<UsageSummary> => {
    const response = await api.get<ApiResponse<UsageSummary>>(
      `/dashboard/usage?period=${period}`
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to get usage data');
    }
    
    return response.data;
  },
};

export default dashboardApi;
