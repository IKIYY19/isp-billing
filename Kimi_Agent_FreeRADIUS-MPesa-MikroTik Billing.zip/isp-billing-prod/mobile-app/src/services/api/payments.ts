import { api } from './client';
import { 
  Payment, 
  PaginatedResponse, 
  ApiResponse 
} from '@/types';

// Payment API endpoints
export const paymentsApi = {
  // Get all payments
  getAll: async (params?: {
    page?: number;
    limit?: number;
    search?: string;
    status?: string;
    method?: string;
    customerId?: string;
    startDate?: string;
    endDate?: string;
    sortBy?: string;
    sortOrder?: 'asc' | 'desc';
  }): Promise<PaginatedResponse<Payment>> => {
    const queryParams = new URLSearchParams();
    
    if (params) {
      Object.entries(params).forEach(([key, value]) => {
        if (value !== undefined) {
          queryParams.append(key, String(value));
        }
      });
    }
    
    const response = await api.get<ApiResponse<PaginatedResponse<Payment>>>(
      `/payments?${queryParams.toString()}`
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to get payments');
    }
    
    return response.data;
  },

  // Get payment by ID
  getById: async (id: string): Promise<Payment> => {
    const response = await api.get<ApiResponse<Payment>>(`/payments/${id}`);
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to get payment');
    }
    
    return response.data;
  },

  // Get payment by transaction ID
  getByTransactionId: async (transactionId: string): Promise<Payment> => {
    const response = await api.get<ApiResponse<Payment>>(
      `/payments/transaction/${transactionId}`
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Payment not found');
    }
    
    return response.data;
  },

  // Create M-Pesa payment (STK Push)
  createMpesaPayment: async (data: {
    amount: number;
    phoneNumber: string;
    invoiceId?: string;
    accountReference?: string;
  }): Promise<{
    merchantRequestId: string;
    checkoutRequestId: string;
    customerMessage: string;
  }> => {
    const response = await api.post<ApiResponse<{
      merchantRequestId: string;
      checkoutRequestId: string;
      customerMessage: string;
    }>>('/payments/mpesa/stk-push', data);
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to initiate M-Pesa payment');
    }
    
    return response.data;
  },

  // Check M-Pesa payment status
  checkMpesaStatus: async (checkoutRequestId: string): Promise<{
    status: 'pending' | 'completed' | 'failed';
    resultCode?: number;
    resultDesc?: string;
    payment?: Payment;
  }> => {
    const response = await api.get<ApiResponse<{
      status: 'pending' | 'completed' | 'failed';
      resultCode?: number;
      resultDesc?: string;
      payment?: Payment;
    }>>(`/payments/mpesa/status/${checkoutRequestId}`);
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to check payment status');
    }
    
    return response.data;
  },

  // Create bank transfer payment
  createBankTransfer: async (data: {
    amount: number;
    invoiceId?: string;
    bankName: string;
    accountNumber: string;
    reference: string;
    notes?: string;
  }): Promise<Payment> => {
    const response = await api.post<ApiResponse<Payment>>(
      '/payments/bank-transfer',
      data
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to create bank transfer');
    }
    
    return response.data;
  },

  // Create cash payment (admin only)
  createCashPayment: async (data: {
    amount: number;
    customerId: string;
    invoiceId?: string;
    notes?: string;
  }): Promise<Payment> => {
    const response = await api.post<ApiResponse<Payment>>('/payments/cash', data);
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to create cash payment');
    }
    
    return response.data;
  },

  // Refund payment
  refund: async (
    id: string,
    data: {
      amount?: number;
      reason: string;
    }
  ): Promise<Payment> => {
    const response = await api.post<ApiResponse<Payment>>(
      `/payments/${id}/refund`,
      data
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to refund payment');
    }
    
    return response.data;
  },

  // Get payment receipt
  getReceipt: async (id: string): Promise<Blob> => {
    const response = await apiClient.get(`/payments/${id}/receipt`, {
      responseType: 'blob',
    });
    
    return response.data;
  },

  // Download receipt
  downloadReceipt: async (id: string): Promise<{ blob: Blob; filename: string }> => {
    const response = await apiClient.get(`/payments/${id}/receipt/download`, {
      responseType: 'blob',
    });
    
    const contentDisposition = response.headers['content-disposition'];
    const filename = contentDisposition
      ? contentDisposition.split('filename=')[1]?.replace(/"/g, '')
      : `receipt-${id}.pdf`;
    
    return { blob: response.data, filename };
  },

  // Get payment statistics
  getStats: async (params?: {
    startDate?: string;
    endDate?: string;
  }): Promise<{
    total: number;
    completed: number;
    pending: number;
    failed: number;
    refunded: number;
    totalAmount: number;
    byMethod: Record<string, { count: number; amount: number }>;
  }> => {
    const queryParams = new URLSearchParams();
    
    if (params) {
      Object.entries(params).forEach(([key, value]) => {
        if (value !== undefined) {
          queryParams.append(key, String(value));
        }
      });
    }
    
    const response = await api.get<ApiResponse<{
      total: number;
      completed: number;
      pending: number;
      failed: number;
      refunded: number;
      totalAmount: number;
      byMethod: Record<string, { count: number; amount: number }>;
    }>>(`/payments/stats?${queryParams.toString()}`);
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to get payment stats');
    }
    
    return response.data;
  },

  // Get M-Pesa configuration
  getMpesaConfig: async (): Promise<{
    paybillNumber: string;
    accountNumber: string;
    stkPushEnabled: boolean;
    c2bEnabled: boolean;
  }> => {
    const response = await api.get<ApiResponse<{
      paybillNumber: string;
      accountNumber: string;
      stkPushEnabled: boolean;
      c2bEnabled: boolean;
    }>>('/payments/mpesa/config');
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to get M-Pesa config');
    }
    
    return response.data;
  },

  // Reconcile payments
  reconcile: async (params?: {
    startDate?: string;
    endDate?: string;
    method?: string;
  }): Promise<{
    reconciled: number;
    unmatched: number;
    totalAmount: number;
  }> => {
    const queryParams = new URLSearchParams();
    
    if (params) {
      Object.entries(params).forEach(([key, value]) => {
        if (value !== undefined) {
          queryParams.append(key, String(value));
        }
      });
    }
    
    const response = await api.post<ApiResponse<{
      reconciled: number;
      unmatched: number;
      totalAmount: number;
    }>>(`/payments/reconcile?${queryParams.toString()}`);
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to reconcile payments');
    }
    
    return response.data;
  },
};

export default paymentsApi;
