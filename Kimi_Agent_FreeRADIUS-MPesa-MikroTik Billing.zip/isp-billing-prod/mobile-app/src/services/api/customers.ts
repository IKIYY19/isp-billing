import { api } from './client';
import { 
  Customer, 
  PaginatedResponse, 
  ApiResponse,
  Subscription,
  Invoice,
  Payment,
  SupportTicket 
} from '@/types';

// Customer API endpoints
export const customersApi = {
  // Get all customers (admin only)
  getAll: async (params?: {
    page?: number;
    limit?: number;
    search?: string;
    status?: string;
    plan?: string;
    sortBy?: string;
    sortOrder?: 'asc' | 'desc';
  }): Promise<PaginatedResponse<Customer>> => {
    const queryParams = new URLSearchParams();
    
    if (params) {
      Object.entries(params).forEach(([key, value]) => {
        if (value !== undefined) {
          queryParams.append(key, String(value));
        }
      });
    }
    
    const response = await api.get<ApiResponse<PaginatedResponse<Customer>>>(
      `/customers?${queryParams.toString()}`
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to get customers');
    }
    
    return response.data;
  },

  // Get customer by ID
  getById: async (id: string): Promise<Customer> => {
    const response = await api.get<ApiResponse<Customer>>(`/customers/${id}`);
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to get customer');
    }
    
    return response.data;
  },

  // Get customer by account number
  getByAccountNumber: async (accountNumber: string): Promise<Customer> => {
    const response = await api.get<ApiResponse<Customer>>(
      `/customers/account/${accountNumber}`
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Customer not found');
    }
    
    return response.data;
  },

  // Create new customer
  create: async (data: Partial<Customer>): Promise<Customer> => {
    const response = await api.post<ApiResponse<Customer>>('/customers', data);
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to create customer');
    }
    
    return response.data;
  },

  // Update customer
  update: async (id: string, data: Partial<Customer>): Promise<Customer> => {
    const response = await api.patch<ApiResponse<Customer>>(
      `/customers/${id}`,
      data
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to update customer');
    }
    
    return response.data;
  },

  // Delete customer
  delete: async (id: string): Promise<void> => {
    const response = await api.delete<ApiResponse<void>>(`/customers/${id}`);
    
    if (!response.success) {
      throw new Error(response.error?.message || 'Failed to delete customer');
    }
  },

  // Get customer subscriptions
  getSubscriptions: async (customerId: string): Promise<Subscription[]> => {
    const response = await api.get<ApiResponse<Subscription[]>>(
      `/customers/${customerId}/subscriptions`
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to get subscriptions');
    }
    
    return response.data;
  },

  // Get customer invoices
  getInvoices: async (
    customerId: string,
    params?: { page?: number; limit?: number; status?: string }
  ): Promise<PaginatedResponse<Invoice>> => {
    const queryParams = new URLSearchParams();
    
    if (params) {
      Object.entries(params).forEach(([key, value]) => {
        if (value !== undefined) {
          queryParams.append(key, String(value));
        }
      });
    }
    
    const response = await api.get<ApiResponse<PaginatedResponse<Invoice>>>(
      `/customers/${customerId}/invoices?${queryParams.toString()}`
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to get invoices');
    }
    
    return response.data;
  },

  // Get customer payments
  getPayments: async (
    customerId: string,
    params?: { page?: number; limit?: number }
  ): Promise<PaginatedResponse<Payment>> => {
    const queryParams = new URLSearchParams();
    
    if (params) {
      Object.entries(params).forEach(([key, value]) => {
        if (value !== undefined) {
          queryParams.append(key, String(value));
        }
      });
    }
    
    const response = await api.get<ApiResponse<PaginatedResponse<Payment>>>(
      `/customers/${customerId}/payments?${queryParams.toString()}`
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to get payments');
    }
    
    return response.data;
  },

  // Get customer tickets
  getTickets: async (
    customerId: string,
    params?: { page?: number; limit?: number; status?: string }
  ): Promise<PaginatedResponse<SupportTicket>> => {
    const queryParams = new URLSearchParams();
    
    if (params) {
      Object.entries(params).forEach(([key, value]) => {
        if (value !== undefined) {
          queryParams.append(key, String(value));
        }
      });
    }
    
    const response = await api.get<ApiResponse<PaginatedResponse<SupportTicket>>>(
      `/customers/${customerId}/tickets?${queryParams.toString()}`
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to get tickets');
    }
    
    return response.data;
  },

  // Get customer usage
  getUsage: async (
    customerId: string,
    params?: { startDate?: string; endDate?: string }
  ): Promise<any> => {
    const queryParams = new URLSearchParams();
    
    if (params) {
      Object.entries(params).forEach(([key, value]) => {
        if (value !== undefined) {
          queryParams.append(key, String(value));
        }
      });
    }
    
    const response = await api.get<ApiResponse<any>>(
      `/customers/${customerId}/usage?${queryParams.toString()}`
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to get usage');
    }
    
    return response.data;
  },

  // Suspend customer
  suspend: async (id: string, reason?: string): Promise<Customer> => {
    const response = await api.post<ApiResponse<Customer>>(
      `/customers/${id}/suspend`,
      { reason }
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to suspend customer');
    }
    
    return response.data;
  },

  // Activate customer
  activate: async (id: string): Promise<Customer> => {
    const response = await api.post<ApiResponse<Customer>>(
      `/customers/${id}/activate`
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to activate customer');
    }
    
    return response.data;
  },

  // Bulk operations
  bulkUpdate: async (ids: string[], data: Partial<Customer>): Promise<void> => {
    const response = await api.post<ApiResponse<void>>('/customers/bulk/update', {
      ids,
      data,
    });
    
    if (!response.success) {
      throw new Error(response.error?.message || 'Failed to update customers');
    }
  },

  bulkDelete: async (ids: string[]): Promise<void> => {
    const response = await api.post<ApiResponse<void>>('/customers/bulk/delete', {
      ids,
    });
    
    if (!response.success) {
      throw new Error(response.error?.message || 'Failed to delete customers');
    }
  },

  bulkSuspend: async (ids: string[], reason?: string): Promise<void> => {
    const response = await api.post<ApiResponse<void>>('/customers/bulk/suspend', {
      ids,
      reason,
    });
    
    if (!response.success) {
      throw new Error(response.error?.message || 'Failed to suspend customers');
    }
  },

  // Export customers
  export: async (format: 'csv' | 'excel' | 'pdf' = 'csv'): Promise<Blob> => {
    const response = await apiClient.get(`/customers/export?format=${format}`, {
      responseType: 'blob',
    });
    
    return response.data;
  },

  // Import customers
  import: async (file: File): Promise<{ imported: number; failed: number; errors: string[] }> => {
    const formData = new FormData();
    formData.append('file', file);
    
    const response = await api.post<ApiResponse<{
      imported: number;
      failed: number;
      errors: string[];
    }>>('/customers/import', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to import customers');
    }
    
    return response.data;
  },
};

export default customersApi;
