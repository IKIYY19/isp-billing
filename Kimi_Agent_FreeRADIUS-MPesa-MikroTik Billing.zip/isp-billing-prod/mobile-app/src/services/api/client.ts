import axios, { 
  AxiosInstance, 
  AxiosRequestConfig, 
  AxiosResponse, 
  AxiosError 
} from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getBaseUrl, STORAGE_KEYS, API_CONFIG } from '@/constants/config';
import { AuthTokens } from '@/types';

// Create axios instance
const apiClient: AxiosInstance = axios.create({
  baseURL: getBaseUrl(),
  timeout: API_CONFIG.TIMEOUT,
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
  },
});

// Request interceptor
apiClient.interceptors.request.use(
  async (config: AxiosRequestConfig): Promise<AxiosRequestConfig> => {
    try {
      // Get access token
      const token = await AsyncStorage.getItem(STORAGE_KEYS.ACCESS_TOKEN);
      
      if (token && config.headers) {
        config.headers.Authorization = `Bearer ${token}`;
      }
      
      // Add request timestamp for debugging
      config.headers = config.headers || {};
      config.headers['X-Request-Time'] = new Date().toISOString();
      
      return config;
    } catch (error) {
      console.error('Request interceptor error:', error);
      return config;
    }
  },
  (error: AxiosError) => {
    console.error('Request error:', error);
    return Promise.reject(error);
  }
);

// Response interceptor
apiClient.interceptors.response.use(
  (response: AxiosResponse): AxiosResponse => {
    // Add response timestamp
    response.config.headers = response.config.headers || {};
    response.config.headers['X-Response-Time'] = new Date().toISOString();
    
    return response;
  },
  async (error: AxiosError) => {
    const originalRequest = error.config as AxiosRequestConfig & { _retry?: boolean };
    
    // Handle 401 Unauthorized
    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;
      
      try {
        // Try to refresh token
        const refreshToken = await AsyncStorage.getItem(STORAGE_KEYS.REFRESH_TOKEN);
        
        if (refreshToken) {
          const response = await axios.post(`${getBaseUrl()}/auth/refresh`, {
            refreshToken,
          });
          
          const { accessToken, refreshToken: newRefreshToken } = response.data.data as AuthTokens;
          
          // Save new tokens
          await AsyncStorage.setItem(STORAGE_KEYS.ACCESS_TOKEN, accessToken);
          await AsyncStorage.setItem(STORAGE_KEYS.REFRESH_TOKEN, newRefreshToken);
          
          // Retry original request
          if (originalRequest.headers) {
            originalRequest.headers.Authorization = `Bearer ${accessToken}`;
          }
          
          return apiClient(originalRequest);
        }
      } catch (refreshError) {
        // Refresh failed, clear tokens and redirect to login
        await AsyncStorage.multiRemove([
          STORAGE_KEYS.ACCESS_TOKEN,
          STORAGE_KEYS.REFRESH_TOKEN,
          STORAGE_KEYS.USER_DATA,
        ]);
        
        // Emit logout event (handled by auth context)
        // This will be caught by the app navigator
        return Promise.reject(refreshError);
      }
    }
    
    // Handle network errors
    if (!error.response) {
      console.error('Network error:', error.message);
      return Promise.reject({
        ...error,
        message: 'Network error. Please check your connection.',
      });
    }
    
    // Handle other errors
    return Promise.reject(error);
  }
);

// API response wrapper
export const handleResponse = <T>(response: AxiosResponse): T => {
  return response.data;
};

// API error handler
export const handleError = (error: AxiosError): never => {
  if (error.response) {
    // Server returned error response
    const data = error.response.data as any;
    throw new Error(data?.error?.message || data?.message || 'An error occurred');
  } else if (error.request) {
    // Request made but no response
    throw new Error('No response from server. Please try again.');
  } else {
    // Error in request setup
    throw new Error(error.message || 'An unexpected error occurred');
  }
};

// Generic API methods
export const api = {
  get: async <T>(url: string, config?: AxiosRequestConfig): Promise<T> => {
    try {
      const response = await apiClient.get<T>(url, config);
      return handleResponse(response);
    } catch (error) {
      handleError(error as AxiosError);
      throw error;
    }
  },

  post: async <T>(url: string, data?: any, config?: AxiosRequestConfig): Promise<T> => {
    try {
      const response = await apiClient.post<T>(url, data, config);
      return handleResponse(response);
    } catch (error) {
      handleError(error as AxiosError);
      throw error;
    }
  },

  put: async <T>(url: string, data?: any, config?: AxiosRequestConfig): Promise<T> => {
    try {
      const response = await apiClient.put<T>(url, data, config);
      return handleResponse(response);
    } catch (error) {
      handleError(error as AxiosError);
      throw error;
    }
  },

  patch: async <T>(url: string, data?: any, config?: AxiosRequestConfig): Promise<T> => {
    try {
      const response = await apiClient.patch<T>(url, data, config);
      return handleResponse(response);
    } catch (error) {
      handleError(error as AxiosError);
      throw error;
    }
  },

  delete: async <T>(url: string, config?: AxiosRequestConfig): Promise<T> => {
    try {
      const response = await apiClient.delete<T>(url, config);
      return handleResponse(response);
    } catch (error) {
      handleError(error as AxiosError);
      throw error;
    }
  },
};

export default apiClient;
