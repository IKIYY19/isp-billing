import { api } from './client';
import { 
  Invoice, 
  PaginatedResponse, 
  ApiResponse,
  Payment 
} from '@/types';

// Invoice API endpoints
export const invoicesApi = {
  // Get all invoices
  getAll: async (params?: {
    page?: number;
    limit?: number;
    search?: string;
    status?: string;
    customerId?: string;
    startDate?: string;
    endDate?: string;
    sortBy?: string;
    sortOrder?: 'asc' | 'desc';
  }): Promise<PaginatedResponse<Invoice>> => {
    const queryParams = new URLSearchParams();
    
    if (params) {
      Object.entries(params).forEach(([key, value]) => {
        if (value !== undefined) {
          queryParams.append(key, String(value));
        }
      });
    }
    
    const response = await api.get<ApiResponse<PaginatedResponse<Invoice>>>(
      `/invoices?${queryParams.toString()}`
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to get invoices');
    }
    
    return response.data;
  },

  // Get invoice by ID
  getById: async (id: string): Promise<Invoice> => {
    const response = await api.get<ApiResponse<Invoice>>(`/invoices/${id}`);
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to get invoice');
    }
    
    return response.data;
  },

  // Get invoice by number
  getByNumber: async (invoiceNumber: string): Promise<Invoice> => {
    const response = await api.get<ApiResponse<Invoice>>(
      `/invoices/number/${invoiceNumber}`
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Invoice not found');
    }
    
    return response.data;
  },

  // Create new invoice
  create: async (data: Partial<Invoice>): Promise<Invoice> => {
    const response = await api.post<ApiResponse<Invoice>>('/invoices', data);
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to create invoice');
    }
    
    return response.data;
  },

  // Update invoice
  update: async (id: string, data: Partial<Invoice>): Promise<Invoice> => {
    const response = await api.patch<ApiResponse<Invoice>>(
      `/invoices/${id}`,
      data
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to update invoice');
    }
    
    return response.data;
  },

  // Delete invoice
  delete: async (id: string): Promise<void> => {
    const response = await api.delete<ApiResponse<void>>(`/invoices/${id}`);
    
    if (!response.success) {
      throw new Error(response.error?.message || 'Failed to delete invoice');
    }
  },

  // Send invoice to customer
  send: async (id: string, method: 'email' | 'sms' | 'whatsapp' = 'email'): Promise<void> => {
    const response = await api.post<ApiResponse<void>>(
      `/invoices/${id}/send`,
      { method }
    );
    
    if (!response.success) {
      throw new Error(response.error?.message || 'Failed to send invoice');
    }
  },

  // Mark invoice as paid
  markAsPaid: async (
    id: string,
    paymentData: {
      amount: number;
      method: string;
      transactionId?: string;
      notes?: string;
    }
  ): Promise<Payment> => {
    const response = await api.post<ApiResponse<Payment>>(
      `/invoices/${id}/pay`,
      paymentData
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to mark invoice as paid');
    }
    
    return response.data;
  },

  // Void invoice
  void: async (id: string, reason?: string): Promise<Invoice> => {
    const response = await api.post<ApiResponse<Invoice>>(
      `/invoices/${id}/void`,
      { reason }
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to void invoice');
    }
    
    return response.data;
  },

  // Get invoice PDF
  getPdf: async (id: string): Promise<Blob> => {
    const response = await apiClient.get(`/invoices/${id}/pdf`, {
      responseType: 'blob',
    });
    
    return response.data;
  },

  // Download invoice
  download: async (id: string): Promise<{ blob: Blob; filename: string }> => {
    const response = await apiClient.get(`/invoices/${id}/download`, {
      responseType: 'blob',
    });
    
    const contentDisposition = response.headers['content-disposition'];
    const filename = contentDisposition
      ? contentDisposition.split('filename=')[1]?.replace(/"/g, '')
      : `invoice-${id}.pdf`;
    
    return { blob: response.data, filename };
  },

  // Get overdue invoices
  getOverdue: async (params?: {
    page?: number;
    limit?: number;
    days?: number;
  }): Promise<PaginatedResponse<Invoice>> => {
    const queryParams = new URLSearchParams();
    
    if (params) {
      Object.entries(params).forEach(([key, value]) => {
        if (value !== undefined) {
          queryParams.append(key, String(value));
        }
      });
    }
    
    const response = await api.get<ApiResponse<PaginatedResponse<Invoice>>>(
      `/invoices/overdue?${queryParams.toString()}`
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to get overdue invoices');
    }
    
    return response.data;
  },

  // Get upcoming invoices
  getUpcoming: async (params?: {
    page?: number;
    limit?: number;
    days?: number;
  }): Promise<PaginatedResponse<Invoice>> => {
    const queryParams = new URLSearchParams();
    
    if (params) {
      Object.entries(params).forEach(([key, value]) => {
        if (value !== undefined) {
          queryParams.append(key, String(value));
        }
      });
    }
    
    const response = await api.get<ApiResponse<PaginatedResponse<Invoice>>>(
      `/invoices/upcoming?${queryParams.toString()}`
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to get upcoming invoices');
    }
    
    return response.data;
  },

  // Generate recurring invoices
  generateRecurring: async (): Promise<{
    generated: number;
    failed: number;
    invoices: Invoice[];
  }> => {
    const response = await api.post<ApiResponse<{
      generated: number;
      failed: number;
      invoices: Invoice[];
    }>>('/invoices/generate-recurring');
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to generate invoices');
    }
    
    return response.data;
  },

  // Bulk operations
  bulkSend: async (ids: string[], method: 'email' | 'sms' | 'whatsapp' = 'email'): Promise<void> => {
    const response = await api.post<ApiResponse<void>>('/invoices/bulk/send', {
      ids,
      method,
    });
    
    if (!response.success) {
      throw new Error(response.error?.message || 'Failed to send invoices');
    }
  },

  bulkDelete: async (ids: string[]): Promise<void> => {
    const response = await api.post<ApiResponse<void>>('/invoices/bulk/delete', {
      ids,
    });
    
    if (!response.success) {
      throw new Error(response.error?.message || 'Failed to delete invoices');
    }
  },

  // Get invoice statistics
  getStats: async (params?: {
    startDate?: string;
    endDate?: string;
  }): Promise<{
    total: number;
    paid: number;
    unpaid: number;
    overdue: number;
    totalAmount: number;
    paidAmount: number;
    unpaidAmount: number;
    overdueAmount: number;
  }> => {
    const queryParams = new URLSearchParams();
    
    if (params) {
      Object.entries(params).forEach(([key, value]) => {
        if (value !== undefined) {
          queryParams.append(key, String(value));
        }
      });
    }
    
    const response = await api.get<ApiResponse<{
      total: number;
      paid: number;
      unpaid: number;
      overdue: number;
      totalAmount: number;
      paidAmount: number;
      unpaidAmount: number;
      overdueAmount: number;
    }>>(`/invoices/stats?${queryParams.toString()}`);
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to get invoice stats');
    }
    
    return response.data;
  },
};

export default invoicesApi;
