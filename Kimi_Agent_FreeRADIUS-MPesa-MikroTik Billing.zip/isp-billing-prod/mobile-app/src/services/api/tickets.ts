import { api } from './client';
import { 
  SupportTicket, 
  TicketMessage,
  PaginatedResponse, 
  ApiResponse 
} from '@/types';

// Tickets API endpoints
export const ticketsApi = {
  // Get all tickets
  getAll: async (params?: {
    page?: number;
    limit?: number;
    search?: string;
    status?: string;
    priority?: string;
    category?: string;
    customerId?: string;
    assignedTo?: string;
    sortBy?: string;
    sortOrder?: 'asc' | 'desc';
  }): Promise<PaginatedResponse<SupportTicket>> => {
    const queryParams = new URLSearchParams();
    
    if (params) {
      Object.entries(params).forEach(([key, value]) => {
        if (value !== undefined) {
          queryParams.append(key, String(value));
        }
      });
    }
    
    const response = await api.get<ApiResponse<PaginatedResponse<SupportTicket>>>(
      `/tickets?${queryParams.toString()}`
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to get tickets');
    }
    
    return response.data;
  },

  // Get ticket by ID
  getById: async (id: string): Promise<SupportTicket> => {
    const response = await api.get<ApiResponse<SupportTicket>>(`/tickets/${id}`);
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to get ticket');
    }
    
    return response.data;
  },

  // Get ticket by number
  getByNumber: async (ticketNumber: string): Promise<SupportTicket> => {
    const response = await api.get<ApiResponse<SupportTicket>>(
      `/tickets/number/${ticketNumber}`
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Ticket not found');
    }
    
    return response.data;
  },

  // Create new ticket
  create: async (data: {
    subject: string;
    description: string;
    category: string;
    priority?: string;
    attachments?: string[];
  }): Promise<SupportTicket> => {
    const response = await api.post<ApiResponse<SupportTicket>>('/tickets', data);
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to create ticket');
    }
    
    return response.data;
  },

  // Update ticket
  update: async (id: string, data: Partial<SupportTicket>): Promise<SupportTicket> => {
    const response = await api.patch<ApiResponse<SupportTicket>>(
      `/tickets/${id}`,
      data
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to update ticket');
    }
    
    return response.data;
  },

  // Add message to ticket
  addMessage: async (
    id: string,
    data: {
      message: string;
      isInternal?: boolean;
      attachments?: string[];
    }
  ): Promise<TicketMessage> => {
    const response = await api.post<ApiResponse<TicketMessage>>(
      `/tickets/${id}/messages`,
      data
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to add message');
    }
    
    return response.data;
  },

  // Assign ticket
  assign: async (id: string, userId: string): Promise<SupportTicket> => {
    const response = await api.post<ApiResponse<SupportTicket>>(
      `/tickets/${id}/assign`,
      { userId }
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to assign ticket');
    }
    
    return response.data;
  },

  // Change ticket status
  changeStatus: async (
    id: string,
    status: string,
    notes?: string
  ): Promise<SupportTicket> => {
    const response = await api.post<ApiResponse<SupportTicket>>(
      `/tickets/${id}/status`,
      { status, notes }
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to change status');
    }
    
    return response.data;
  },

  // Resolve ticket
  resolve: async (
    id: string,
    resolution: string
  ): Promise<SupportTicket> => {
    const response = await api.post<ApiResponse<SupportTicket>>(
      `/tickets/${id}/resolve`,
      { resolution }
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to resolve ticket');
    }
    
    return response.data;
  },

  // Close ticket
  close: async (id: string): Promise<SupportTicket> => {
    const response = await api.post<ApiResponse<SupportTicket>>(
      `/tickets/${id}/close`
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to close ticket');
    }
    
    return response.data;
  },

  // Reopen ticket
  reopen: async (id: string, reason?: string): Promise<SupportTicket> => {
    const response = await api.post<ApiResponse<SupportTicket>>(
      `/tickets/${id}/reopen`,
      { reason }
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to reopen ticket');
    }
    
    return response.data;
  },

  // Add satisfaction rating
  addRating: async (
    id: string,
    rating: number,
    comment?: string
  ): Promise<SupportTicket> => {
    const response = await api.post<ApiResponse<SupportTicket>>(
      `/tickets/${id}/rating`,
      { rating, comment }
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to add rating');
    }
    
    return response.data;
  },

  // Get my tickets (for customer)
  getMyTickets: async (params?: {
    page?: number;
    limit?: number;
    status?: string;
  }): Promise<PaginatedResponse<SupportTicket>> => {
    const queryParams = new URLSearchParams();
    
    if (params) {
      Object.entries(params).forEach(([key, value]) => {
        if (value !== undefined) {
          queryParams.append(key, String(value));
        }
      });
    }
    
    const response = await api.get<ApiResponse<PaginatedResponse<SupportTicket>>>(
      `/tickets/my-tickets?${queryParams.toString()}`
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to get tickets');
    }
    
    return response.data;
  },

  // Get assigned tickets (for agents)
  getAssignedTickets: async (params?: {
    page?: number;
    limit?: number;
    status?: string;
  }): Promise<PaginatedResponse<SupportTicket>> => {
    const queryParams = new URLSearchParams();
    
    if (params) {
      Object.entries(params).forEach(([key, value]) => {
        if (value !== undefined) {
          queryParams.append(key, String(value));
        }
      });
    }
    
    const response = await api.get<ApiResponse<PaginatedResponse<SupportTicket>>>(
      `/tickets/assigned?${queryParams.toString()}`
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to get assigned tickets');
    }
    
    return response.data;
  },

  // Get ticket statistics
  getStats: async (): Promise<{
    total: number;
    open: number;
    inProgress: number;
    waitingCustomer: number;
    resolved: number;
    closed: number;
    byPriority: Record<string, number>;
    byCategory: Record<string, number>;
    avgResolutionTime: number;
    satisfactionRate: number;
  }> => {
    const response = await api.get<ApiResponse<{
      total: number;
      open: number;
      inProgress: number;
      waitingCustomer: number;
      resolved: number;
      closed: number;
      byPriority: Record<string, number>;
      byCategory: Record<string, number>;
      avgResolutionTime: number;
      satisfactionRate: number;
    }>>('/tickets/stats');
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to get ticket stats');
    }
    
    return response.data;
  },

  // Upload attachment
  uploadAttachment: async (
    ticketId: string,
    file: FormData
  ): Promise<{ url: string; filename: string }> => {
    const response = await api.post<ApiResponse<{ url: string; filename: string }>>(
      `/tickets/${ticketId}/attachments`,
      file,
      {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      }
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to upload attachment');
    }
    
    return response.data;
  },

  // Delete attachment
  deleteAttachment: async (ticketId: string, filename: string): Promise<void> => {
    const response = await api.delete<ApiResponse<void>>(
      `/tickets/${ticketId}/attachments/${filename}`
    );
    
    if (!response.success) {
      throw new Error(response.error?.message || 'Failed to delete attachment');
    }
  },

  // Bulk operations
  bulkAssign: async (ids: string[], userId: string): Promise<void> => {
    const response = await api.post<ApiResponse<void>>('/tickets/bulk/assign', {
      ids,
      userId,
    });
    
    if (!response.success) {
      throw new Error(response.error?.message || 'Failed to assign tickets');
    }
  },

  bulkChangeStatus: async (ids: string[], status: string): Promise<void> => {
    const response = await api.post<ApiResponse<void>>('/tickets/bulk/status', {
      ids,
      status,
    });
    
    if (!response.success) {
      throw new Error(response.error?.message || 'Failed to change ticket status');
    }
  },

  bulkDelete: async (ids: string[]): Promise<void> => {
    const response = await api.post<ApiResponse<void>>('/tickets/bulk/delete', {
      ids,
    });
    
    if (!response.success) {
      throw new Error(response.error?.message || 'Failed to delete tickets');
    }
  },
};

export default ticketsApi;
