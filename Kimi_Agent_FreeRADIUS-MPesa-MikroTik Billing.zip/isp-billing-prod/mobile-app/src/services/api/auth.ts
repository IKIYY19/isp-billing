import apiClient, { api } from './client';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { STORAGE_KEYS } from '@/constants/config';
import { 
  User, 
  AuthTokens, 
  LoginCredentials, 
  RegisterData, 
  OTPVerification,
  ApiResponse 
} from '@/types';

// Auth API endpoints
export const authApi = {
  // Login with email/password
  login: async (credentials: LoginCredentials): Promise<{ user: User; tokens: AuthTokens }> => {
    const response = await api.post<ApiResponse<{ user: User; tokens: AuthTokens }>>(
      '/auth/login',
      credentials
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Login failed');
    }
    
    // Save tokens
    await AsyncStorage.setItem(STORAGE_KEYS.ACCESS_TOKEN, response.data.tokens.accessToken);
    await AsyncStorage.setItem(STORAGE_KEYS.REFRESH_TOKEN, response.data.tokens.refreshToken);
    await AsyncStorage.setItem(STORAGE_KEYS.USER_DATA, JSON.stringify(response.data.user));
    
    return response.data;
  },

  // Register new account
  register: async (data: RegisterData): Promise<{ user: User; tokens: AuthTokens }> => {
    const response = await api.post<ApiResponse<{ user: User; tokens: AuthTokens }>>(
      '/auth/register',
      data
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Registration failed');
    }
    
    // Save tokens
    await AsyncStorage.setItem(STORAGE_KEYS.ACCESS_TOKEN, response.data.tokens.accessToken);
    await AsyncStorage.setItem(STORAGE_KEYS.REFRESH_TOKEN, response.data.tokens.refreshToken);
    await AsyncStorage.setItem(STORAGE_KEYS.USER_DATA, JSON.stringify(response.data.user));
    
    return response.data;
  },

  // Login with Google OAuth
  loginWithGoogle: async (idToken: string): Promise<{ user: User; tokens: AuthTokens }> => {
    const response = await api.post<ApiResponse<{ user: User; tokens: AuthTokens }>>(
      '/auth/google',
      { idToken }
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Google login failed');
    }
    
    // Save tokens
    await AsyncStorage.setItem(STORAGE_KEYS.ACCESS_TOKEN, response.data.tokens.accessToken);
    await AsyncStorage.setItem(STORAGE_KEYS.REFRESH_TOKEN, response.data.tokens.refreshToken);
    await AsyncStorage.setItem(STORAGE_KEYS.USER_DATA, JSON.stringify(response.data.user));
    
    return response.data;
  },

  // Request OTP for phone verification
  requestOTP: async (phone: string): Promise<{ message: string; expiresIn: number }> => {
    const response = await api.post<ApiResponse<{ message: string; expiresIn: number }>>(
      '/auth/otp/request',
      { phone }
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to send OTP');
    }
    
    return response.data;
  },

  // Verify OTP
  verifyOTP: async (data: OTPVerification): Promise<{ user: User; tokens: AuthTokens }> => {
    const response = await api.post<ApiResponse<{ user: User; tokens: AuthTokens }>>(
      '/auth/otp/verify',
      data
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'OTP verification failed');
    }
    
    // Save tokens
    await AsyncStorage.setItem(STORAGE_KEYS.ACCESS_TOKEN, response.data.tokens.accessToken);
    await AsyncStorage.setItem(STORAGE_KEYS.REFRESH_TOKEN, response.data.tokens.refreshToken);
    await AsyncStorage.setItem(STORAGE_KEYS.USER_DATA, JSON.stringify(response.data.user));
    
    return response.data;
  },

  // Get current user
  getCurrentUser: async (): Promise<User> => {
    const response = await api.get<ApiResponse<User>>('/auth/me');
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to get user');
    }
    
    // Update stored user data
    await AsyncStorage.setItem(STORAGE_KEYS.USER_DATA, JSON.stringify(response.data));
    
    return response.data;
  },

  // Update user profile
  updateProfile: async (data: Partial<User>): Promise<User> => {
    const response = await api.patch<ApiResponse<User>>('/auth/profile', data);
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to update profile');
    }
    
    // Update stored user data
    await AsyncStorage.setItem(STORAGE_KEYS.USER_DATA, JSON.stringify(response.data));
    
    return response.data;
  },

  // Change password
  changePassword: async (oldPassword: string, newPassword: string): Promise<void> => {
    const response = await api.post<ApiResponse<void>>('/auth/change-password', {
      oldPassword,
      newPassword,
    });
    
    if (!response.success) {
      throw new Error(response.error?.message || 'Failed to change password');
    }
  },

  // Request password reset
  forgotPassword: async (email: string): Promise<{ message: string }> => {
    const response = await api.post<ApiResponse<{ message: string }>>(
      '/auth/forgot-password',
      { email }
    );
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Failed to send reset email');
    }
    
    return response.data;
  },

  // Reset password with token
  resetPassword: async (token: string, newPassword: string): Promise<void> => {
    const response = await api.post<ApiResponse<void>>('/auth/reset-password', {
      token,
      newPassword,
    });
    
    if (!response.success) {
      throw new Error(response.error?.message || 'Failed to reset password');
    }
  },

  // Logout
  logout: async (): Promise<void> => {
    try {
      // Call logout endpoint
      await api.post('/auth/logout');
    } catch (error) {
      console.error('Logout API error:', error);
    } finally {
      // Clear stored data regardless of API response
      await AsyncStorage.multiRemove([
        STORAGE_KEYS.ACCESS_TOKEN,
        STORAGE_KEYS.REFRESH_TOKEN,
        STORAGE_KEYS.USER_DATA,
      ]);
    }
  },

  // Refresh token
  refreshToken: async (): Promise<AuthTokens> => {
    const refreshToken = await AsyncStorage.getItem(STORAGE_KEYS.REFRESH_TOKEN);
    
    if (!refreshToken) {
      throw new Error('No refresh token available');
    }
    
    const response = await api.post<ApiResponse<AuthTokens>>('/auth/refresh', {
      refreshToken,
    });
    
    if (!response.success || !response.data) {
      throw new Error(response.error?.message || 'Token refresh failed');
    }
    
    // Save new tokens
    await AsyncStorage.setItem(STORAGE_KEYS.ACCESS_TOKEN, response.data.accessToken);
    await AsyncStorage.setItem(STORAGE_KEYS.REFRESH_TOKEN, response.data.refreshToken);
    
    return response.data;
  },

  // Check if user is authenticated
  isAuthenticated: async (): Promise<boolean> => {
    const token = await AsyncStorage.getItem(STORAGE_KEYS.ACCESS_TOKEN);
    return !!token;
  },

  // Get stored user
  getStoredUser: async (): Promise<User | null> => {
    const userData = await AsyncStorage.getItem(STORAGE_KEYS.USER_DATA);
    return userData ? JSON.parse(userData) : null;
  },
};

export default authApi;
