import { Platform } from 'react-native';

// API Configuration
export const API_CONFIG = {
  // Development
  DEV_BASE_URL: 'http://localhost:3000/api/v1',
  
  // Production - Update with your domain
  PROD_BASE_URL: 'https://api.yourdomain.com/api/v1',
  
  // Timeout settings
  TIMEOUT: 30000,
  
  // Retry settings
  MAX_RETRIES: 3,
  RETRY_DELAY: 1000,
  
  // Pagination
  DEFAULT_PAGE_SIZE: 20,
  MAX_PAGE_SIZE: 100,
};

// Get current API URL
export const getBaseUrl = (): string => {
  if (__DEV__) {
    // For Android emulator, use 10.0.2.2 instead of localhost
    if (Platform.OS === 'android') {
      return 'http://10.0.2.2:3000/api/v1';
    }
    return API_CONFIG.DEV_BASE_URL;
  }
  return API_CONFIG.PROD_BASE_URL;
};

// App Configuration
export const APP_CONFIG = {
  name: 'ISP Billing',
  version: '1.0.0',
  buildNumber: '1',
  bundleId: Platform.OS === 'ios' 
    ? 'com.yourcompany.ispbilling' 
    : 'com.yourcompany.ispbilling',
  
  // Support
  supportEmail: 'support@yourdomain.com',
  supportPhone: '+254700000000',
  
  // Social
  website: 'https://yourdomain.com',
  facebook: 'https://facebook.com/yourpage',
  twitter: 'https://twitter.com/yourhandle',
  
  // Legal
  termsUrl: 'https://yourdomain.com/terms',
  privacyUrl: 'https://yourdomain.com/privacy',
};

// Storage Keys
export const STORAGE_KEYS = {
  // Auth
  ACCESS_TOKEN: '@auth/access_token',
  REFRESH_TOKEN: '@auth/refresh_token',
  USER_DATA: '@auth/user_data',
  
  // Settings
  APP_SETTINGS: '@app/settings',
  LANGUAGE: '@app/language',
  THEME: '@app/theme',
  
  // Notifications
  FCM_TOKEN: '@notifications/fcm_token',
  NOTIFICATIONS_ENABLED: '@notifications/enabled',
  
  // Cache
  DASHBOARD_CACHE: '@cache/dashboard',
  CUSTOMERS_CACHE: '@cache/customers',
  INVOICES_CACHE: '@cache/invoices',
  PLANS_CACHE: '@cache/plans',
  
  // Biometric
  BIOMETRIC_ENABLED: '@biometric/enabled',
};

// Feature Flags
export const FEATURES = {
  // Authentication
  BIOMETRIC_AUTH: true,
  SOCIAL_LOGIN: true,
  PHONE_OTP: true,
  
  // Payments
  MPESA_ENABLED: true,
  CARD_PAYMENTS: false,
  BANK_TRANSFER: true,
  
  // Notifications
  PUSH_NOTIFICATIONS: true,
  SMS_NOTIFICATIONS: true,
  WHATSAPP_NOTIFICATIONS: true,
  EMAIL_NOTIFICATIONS: true,
  
  // Features
  TICKET_SYSTEM: true,
  USAGE_TRACKING: true,
  NETWORK_MAP: true,
  REFERRAL_PROGRAM: true,
  
  // Admin Features
  NETWORK_MONITORING: true,
  OLT_MANAGEMENT: true,
  REPORTS: true,
  BULK_OPERATIONS: true,
};

// Date/Time Formats
export const DATE_FORMATS = {
  DISPLAY_DATE: 'MMM dd, yyyy',
  DISPLAY_DATETIME: 'MMM dd, yyyy HH:mm',
  DISPLAY_TIME: 'HH:mm',
  API_DATE: 'yyyy-MM-dd',
  API_DATETIME: "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
};

// Currency Configuration
export const CURRENCY = {
  code: 'KES',
  symbol: 'KSh',
  name: 'Kenyan Shilling',
  decimalPlaces: 2,
};

// Network Status
export const NETWORK_STATUS = {
  ONLINE: 'online',
  OFFLINE: 'offline',
  UNKNOWN: 'unknown',
};

// Subscription Status
export const SUBSCRIPTION_STATUS = {
  ACTIVE: 'active',
  SUSPENDED: 'suspended',
  CANCELLED: 'cancelled',
  EXPIRED: 'expired',
  PENDING: 'pending',
};

// Invoice Status
export const INVOICE_STATUS = {
  DRAFT: 'draft',
  SENT: 'sent',
  PAID: 'paid',
  PARTIAL: 'partial',
  OVERDUE: 'overdue',
  CANCELLED: 'cancelled',
};

// Payment Methods
export const PAYMENT_METHODS = {
  MPESA: 'mpesa',
  BANK_TRANSFER: 'bank_transfer',
  CASH: 'cash',
  CARD: 'card',
  CHEQUE: 'cheque',
  WALLET: 'wallet',
};

// Ticket Categories
export const TICKET_CATEGORIES = {
  TECHNICAL: 'technical',
  BILLING: 'billing',
  SALES: 'sales',
  GENERAL: 'general',
};

// Ticket Priorities
export const TICKET_PRIORITIES = {
  LOW: 'low',
  MEDIUM: 'medium',
  HIGH: 'high',
  URGENT: 'urgent',
};

// Ticket Status
export const TICKET_STATUS = {
  OPEN: 'open',
  IN_PROGRESS: 'in_progress',
  WAITING_CUSTOMER: 'waiting_customer',
  RESOLVED: 'resolved',
  CLOSED: 'closed',
};

// OLT Vendors
export const OLT_VENDORS = {
  HUAWEI: 'huawei',
  ZTE: 'zte',
  NOKIA: 'nokia',
  FIBERHOME: 'fiberhome',
  OTHER: 'other',
};

// Animation Durations
export const ANIMATION = {
  FAST: 150,
  NORMAL: 300,
  SLOW: 500,
};

// Validation Rules
export const VALIDATION = {
  PASSWORD_MIN_LENGTH: 8,
  PHONE_REGEX: /^\+?[1-9]\d{1,14}$/,
  EMAIL_REGEX: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
  MPESA_REGEX: /^254[0-9]{9}$/,
};

// Rate Limiting
export const RATE_LIMITS = {
  LOGIN_ATTEMPTS: 5,
  LOGIN_WINDOW: 15 * 60 * 1000, // 15 minutes
  OTP_REQUESTS: 3,
  OTP_WINDOW: 60 * 60 * 1000, // 1 hour
};

export default {
  API_CONFIG,
  getBaseUrl,
  APP_CONFIG,
  STORAGE_KEYS,
  FEATURES,
  DATE_FORMATS,
  CURRENCY,
  NETWORK_STATUS,
  SUBSCRIPTION_STATUS,
  INVOICE_STATUS,
  PAYMENT_METHODS,
  TICKET_CATEGORIES,
  TICKET_PRIORITIES,
  TICKET_STATUS,
  OLT_VENDORS,
  ANIMATION,
  VALIDATION,
  RATE_LIMITS,
};
