export const Colors = {
  // Primary Brand Colors
  primary: {
    50: '#EEF2FF',
    100: '#E0E7FF',
    200: '#C7D2FE',
    300: '#A5B4FC',
    400: '#818CF8',
    500: '#6366F1',
    600: '#4F46E5',
    700: '#4338CA',
    800: '#3730A3',
    900: '#312E81',
  },

  // Secondary Colors
  secondary: {
    50: '#F0FDF4',
    100: '#DCFCE7',
    200: '#BBF7D0',
    300: '#86EFAC',
    400: '#4ADE80',
    500: '#22C55E',
    600: '#16A34A',
    700: '#15803D',
    800: '#166534',
    900: '#14532D',
  },

  // Accent Colors
  accent: {
    orange: '#F97316',
    yellow: '#EAB308',
    pink: '#EC4899',
    purple: '#A855F7',
    cyan: '#06B6D4',
  },

  // Semantic Colors
  success: '#22C55E',
  warning: '#F59E0B',
  error: '#EF4444',
  info: '#3B82F6',

  // Neutral Colors
  gray: {
    50: '#F9FAFB',
    100: '#F3F4F6',
    200: '#E5E7EB',
    300: '#D1D5DB',
    400: '#9CA3AF',
    500: '#6B7280',
    600: '#4B5563',
    700: '#374151',
    800: '#1F2937',
    900: '#111827',
  },

  // Light Theme
  light: {
    background: '#FFFFFF',
    surface: '#F9FAFB',
    surfaceVariant: '#F3F4F6',
    primary: '#4F46E5',
    primaryContainer: '#EEF2FF',
    secondary: '#22C55E',
    secondaryContainer: '#F0FDF4',
    onBackground: '#111827',
    onSurface: '#374151',
    onSurfaceVariant: '#6B7280',
    border: '#E5E7EB',
    divider: '#F3F4F6',
    shadow: 'rgba(0, 0, 0, 0.1)',
  },

  // Dark Theme
  dark: {
    background: '#111827',
    surface: '#1F2937',
    surfaceVariant: '#374151',
    primary: '#818CF8',
    primaryContainer: '#312E81',
    secondary: '#4ADE80',
    secondaryContainer: '#14532D',
    onBackground: '#F9FAFB',
    onSurface: '#E5E7EB',
    onSurfaceVariant: '#9CA3AF',
    border: '#374151',
    divider: '#374151',
    shadow: 'rgba(0, 0, 0, 0.3)',
  },

  // Status Colors
  status: {
    online: '#22C55E',
    offline: '#EF4444',
    pending: '#F59E0B',
    processing: '#3B82F6',
    suspended: '#6B7280',
  },

  // Chart Colors
  chart: [
    '#4F46E5',
    '#22C55E',
    '#F59E0B',
    '#EF4444',
    '#8B5CF6',
    '#06B6D4',
    '#EC4899',
    '#F97316',
  ],
} as const;

export default Colors;
