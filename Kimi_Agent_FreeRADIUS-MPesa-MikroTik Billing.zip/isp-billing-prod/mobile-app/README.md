# ISP Billing Mobile App

## 📱 React Native Mobile Application

A cross-platform mobile app for ISP Billing System - for both customers and administrators.

## Features

### Customer App
- ✅ Account dashboard
- ✅ View invoices & make payments
- ✅ Check internet usage
- ✅ Support tickets
- ✅ Payment history
- ✅ Service status
- ✅ Push notifications

### Admin App
- ✅ Customer management
- ✅ Invoice creation
- ✅ Payment tracking
- ✅ Network monitoring
- ✅ Real-time alerts
- ✅ Analytics dashboard

---

## 🚀 Quick Start

```bash
# Install dependencies
npm install

# iOS setup
cd ios && pod install && cd ..

# Run on iOS
npx react-native run-ios

# Run on Android
npx react-native run-android
```

---

## 📁 Project Structure

```
mobile-app/
├── src/
│   ├── api/                    # API client
│   │   ├── client.ts
│   │   ├── auth.ts
│   │   ├── customers.ts
│   │   ├── invoices.ts
│   │   └── payments.ts
│   │
│   ├── components/             # Reusable components
│   │   ├── common/
│   │   │   ├── Button.tsx
│   │   │   ├── Input.tsx
│   │   │   ├── Card.tsx
│   │   │   └── Loading.tsx
│   │   ├── charts/
│   │   │   ├── LineChart.tsx
│   │   │   ├── BarChart.tsx
│   │   │   └── PieChart.tsx
│   │   └── lists/
│   │       ├── CustomerList.tsx
│   │       └── InvoiceList.tsx
│   │
│   ├── screens/                # App screens
│   │   ├── auth/
│   │   │   ├── LoginScreen.tsx
│   │   │   ├── RegisterScreen.tsx
│   │   │   └── ForgotPasswordScreen.tsx
│   │   ├── customer/
│   │   │   ├── DashboardScreen.tsx
│   │   │   ├── InvoicesScreen.tsx
│   │   │   ├── PaymentsScreen.tsx
│   │   │   ├── UsageScreen.tsx
│   │   │   ├── ProfileScreen.tsx
│   │   │   └── SupportScreen.tsx
│   │   └── admin/
│   │       ├── AdminDashboard.tsx
│   │       ├── CustomersScreen.tsx
│   │       ├── NetworkScreen.tsx
│   │       ├── AnalyticsScreen.tsx
│   │       └── SettingsScreen.tsx
│   │
│   ├── navigation/             # Navigation setup
│   │   ├── AppNavigator.tsx
│   │   ├── AuthNavigator.tsx
│   │   ├── CustomerNavigator.tsx
│   │   └── AdminNavigator.tsx
│   │
│   ├── store/                  # State management (Zustand)
│   │   ├── authStore.ts
│   │   ├── customerStore.ts
│   │   └── appStore.ts
│   │
│   ├── hooks/                  # Custom hooks
│   │   ├── useAuth.ts
│   │   ├── useCustomers.ts
│   │   ├── useInvoices.ts
│   │   └── usePayments.ts
│   │
│   ├── utils/                  # Utilities
│   │   ├── constants.ts
│   │   ├── helpers.ts
│   │   ├── formatters.ts
│   │   └── notifications.ts
│   │
│   └── types/                  # TypeScript types
│       ├── auth.ts
│       ├── customer.ts
│       ├── invoice.ts
│       └── payment.ts
│
├── android/                    # Android native code
├── ios/                        # iOS native code
├── assets/                     # Images, fonts
├── App.tsx                     # Entry point
└── package.json
```

---

## 🔧 Setup Instructions

### Prerequisites
- Node.js 18+
- React Native CLI
- Xcode (for iOS)
- Android Studio (for Android)

### Installation

```bash
# 1. Clone repository
git clone https://github.com/yourusername/isp-billing-mobile.git
cd isp-billing-mobile

# 2. Install dependencies
npm install

# 3. Setup environment
cp .env.example .env
# Edit .env with your API URL

# 4. iOS setup
cd ios
pod install
cd ..

# 5. Run the app
npx react-native run-ios      # iOS
npx react-native run-android  # Android
```

---

## 📱 Screenshots

### Customer Screens
| Dashboard | Invoices | Payments | Usage |
|-----------|----------|----------|-------|
| ![Dashboard](screenshots/customer-dashboard.png) | ![Invoices](screenshots/customer-invoices.png) | ![Payments](screenshots/customer-payments.png) | ![Usage](screenshots/customer-usage.png) |

### Admin Screens
| Dashboard | Customers | Network | Analytics |
|-----------|-----------|---------|-----------|
| ![Admin Dashboard](screenshots/admin-dashboard.png) | ![Customers](screenshots/admin-customers.png) | ![Network](screenshots/admin-network.png) | ![Analytics](screenshots/admin-analytics.png) |

---

## 🔌 API Integration

```typescript
// src/api/client.ts
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

const apiClient = axios.create({
  baseURL: 'https://api.your-domain.com',
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor - add auth token
apiClient.interceptors.request.use(
  async (config) => {
    const token = await AsyncStorage.getItem('authToken');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor - handle errors
apiClient.interceptors.response.use(
  (response) => response,
  async (error) => {
    if (error.response?.status === 401) {
      // Token expired, logout user
      await AsyncStorage.removeItem('authToken');
      // Navigate to login
    }
    return Promise.reject(error);
  }
);

export default apiClient;
```

---

## 🔔 Push Notifications

### Setup

```bash
# Install dependencies
npm install @react-native-firebase/app @react-native-firebase/messaging
npm install @notifee/react-native

# iOS setup
cd ios && pod install
```

### Configuration

```typescript
// src/utils/notifications.ts
import messaging from '@react-native-firebase/messaging';
import notifee from '@notifee/react-native';

export async function requestNotificationPermission() {
  const authStatus = await messaging().requestPermission();
  const enabled =
    authStatus === messaging.AuthorizationStatus.AUTHORIZED ||
    authStatus === messaging.AuthorizationStatus.PROVISIONAL;

  if (enabled) {
    console.log('Notification permission granted');
    const token = await messaging().getToken();
    // Send token to backend
    return token;
  }
}

export function setupNotificationListeners() {
  // Foreground messages
  messaging().onMessage(async (remoteMessage) => {
    await notifee.displayNotification({
      title: remoteMessage.notification?.title,
      body: remoteMessage.notification?.body,
      android: {
        channelId: 'default',
        pressAction: {
          id: 'default',
        },
      },
    });
  });

  // Background messages
  messaging().setBackgroundMessageHandler(async (remoteMessage) => {
    console.log('Background message:', remoteMessage);
  });
}
```

---

## 🎨 Theme & Styling

```typescript
// src/utils/theme.ts
export const theme = {
  colors: {
    primary: '#667eea',
    secondary: '#764ba2',
    success: '#10b981',
    warning: '#f59e0b',
    error: '#ef4444',
    info: '#3b82f6',
    background: '#f8fafc',
    surface: '#ffffff',
    text: '#1e293b',
    textMuted: '#64748b',
    border: '#e2e8f0',
  },
  fonts: {
    regular: 'Inter-Regular',
    medium: 'Inter-Medium',
    semiBold: 'Inter-SemiBold',
    bold: 'Inter-Bold',
  },
  spacing: {
    xs: 4,
    sm: 8,
    md: 16,
    lg: 24,
    xl: 32,
  },
  borderRadius: {
    sm: 4,
    md: 8,
    lg: 12,
    xl: 16,
  },
};
```

---

## 🧪 Testing

```bash
# Run unit tests
npm test

# Run e2e tests (Detox)
npx detox test

# Check code coverage
npm run test:coverage
```

---

## 📦 Building for Production

### iOS
```bash
# Archive for App Store
npx react-native run-ios --configuration Release

# Or use Xcode
open ios/ISPBilling.xcworkspace
```

### Android
```bash
# Generate release APK
cd android
./gradlew assembleRelease

# Or AAB for Play Store
./gradlew bundleRelease
```

---

## 🚀 Deployment

### App Store (iOS)
1. Create App Store Connect account
2. Register app in App Store Connect
3. Configure signing certificates
4. Archive and upload via Xcode
5. Submit for review

### Play Store (Android)
1. Create Google Play Console account
2. Create new app
3. Upload AAB file
4. Configure store listing
5. Submit for review

---

## 📚 Documentation

- [API Documentation](../API_DOCUMENTATION.md)
- [Backend Setup](../DEPLOYMENT_GUIDE.md)
- [Contributing Guide](CONTRIBUTING.md)

---

## 📄 License

MIT License - See [LICENSE](LICENSE) file
