import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import dotenv from 'dotenv';
import { register } from 'prom-client';

// Load environment variables
dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(morgan('combined'));

// Health check endpoint
app.get('/health', (req, res) => {
  res.status(200).json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    version: '1.0.0'
  });
});

// Metrics endpoint for Prometheus
app.get('/metrics', async (req, res) => {
  res.set('Content-Type', register.contentType);
  res.end(await register.metrics());
});

// API Routes
app.get('/api', (req, res) => {
  res.json({
    message: 'ISP Billing System API',
    version: '1.0.0',
    endpoints: {
      health: '/health',
      metrics: '/metrics',
      auth: '/api/auth',
      customers: '/api/customers',
      invoices: '/api/invoices',
      payments: '/api/payments',
      plans: '/api/plans',
      routers: '/api/routers',
      olts: '/api/olts',
      reports: '/api/reports'
    }
  });
});

// Auth routes
app.use('/api/auth', require('./routes/auth').default);

// Customer routes
app.use('/api/customers', require('./routes/customers').default);

// Invoice routes
app.use('/api/invoices', require('./routes/invoices').default);

// Payment routes
app.use('/api/payments', require('./routes/payments').default);

// Plan routes
app.use('/api/plans', require('./routes/plans').default);

// Router routes
app.use('/api/routers', require('./routes/routers').default);

// OLT routes
app.use('/api/olts', require('./routes/olts').default);

// Report routes
app.use('/api/reports', require('./routes/reports').default);

// Error handling
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  console.error(err.stack);
  res.status(500).json({
    error: 'Internal Server Error',
    message: process.env.NODE_ENV === 'development' ? err.message : 'Something went wrong'
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 ISP Billing API running on port ${PORT}`);
  console.log(`📊 Health check: http://localhost:${PORT}/health`);
  console.log(`📈 Metrics: http://localhost:${PORT}/metrics`);
});

export default app;
