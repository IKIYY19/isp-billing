import express from 'express';

const router = express.Router();

const plans = [
  { id: '1', name: 'Basic', speed: '5Mbps', price: 1500, dataCap: '100GB', type: 'residential' },
  { id: '2', name: 'Standard', speed: '10Mbps', price: 2500, dataCap: '500GB', type: 'residential' },
  { id: '3', name: 'Premium', speed: '20Mbps', price: 4000, dataCap: 'Unlimited', type: 'residential' },
  { id: '4', name: 'Business Basic', speed: '50Mbps', price: 10000, dataCap: 'Unlimited', type: 'business' },
  { id: '5', name: 'Business Pro', speed: '100Mbps', price: 20000, dataCap: 'Unlimited', type: 'business' }
];

router.get('/', (req, res) => {
  res.json({ plans, total: plans.length });
});

router.get('/:id', (req, res) => {
  const plan = plans.find(p => p.id === req.params.id);
  if (!plan) return res.status(404).json({ error: 'Plan not found' });
  res.json(plan);
});

export default router;
