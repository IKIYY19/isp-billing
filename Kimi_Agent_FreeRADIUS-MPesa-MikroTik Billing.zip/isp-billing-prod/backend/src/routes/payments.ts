import express from 'express';

const router = express.Router();

const payments = [
  { id: 'PAY001', invoiceId: 'INV001', amount: 2500, method: 'mpesa', transactionId: 'MPESA123', status: 'completed', date: '2024-02-10' },
  { id: 'PAY002', invoiceId: 'INV002', amount: 1500, method: 'bank', transactionId: 'BANK456', status: 'pending', date: '2024-02-15' }
];

router.get('/', (req, res) => {
  res.json({ payments, total: payments.length });
});

router.post('/mpesa', (req, res) => {
  const { phone, amount, invoiceId } = req.body;
  // M-Pesa STK push logic here
  res.json({
    message: 'M-Pesa payment initiated',
    checkoutRequestId: 'ws_CO_123456789',
    amount,
    phone
  });
});

router.post('/mpesa/callback', (req, res) => {
  // M-Pesa callback handler
  console.log('M-Pesa callback:', req.body);
  res.json({ ResultCode: 0, ResultDesc: 'Success' });
});

export default router;
