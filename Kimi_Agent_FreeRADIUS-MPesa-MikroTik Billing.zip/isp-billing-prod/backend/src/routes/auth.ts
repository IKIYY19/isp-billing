import express from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

const router = express.Router();

// Mock users database (replace with real DB)
const users: any[] = [];

// Register
router.post('/register', async (req, res) => {
  try {
    const { email, password, phone, name } = req.body;
    
    const hashedPassword = await bcrypt.hash(password, 10);
    const user = {
      id: Date.now().toString(),
      email,
      phone,
      name,
      password: hashedPassword,
      role: 'user',
      createdAt: new Date()
    };
    
    users.push(user);
    
    res.status(201).json({
      message: 'User registered successfully',
      user: { id: user.id, email: user.email, name: user.name }
    });
  } catch (error) {
    res.status(500).json({ error: 'Registration failed' });
  }
});

// Login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    const user = users.find(u => u.email === email);
    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    const isValid = await bcrypt.compare(password, user.password);
    if (!isValid) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    const token = jwt.sign(
      { userId: user.id, email: user.email, role: user.role },
      process.env.JWT_SECRET || 'secret',
      { expiresIn: '7d' }
    );
    
    res.json({
      token,
      user: { id: user.id, email: user.email, name: user.name, role: user.role }
    });
  } catch (error) {
    res.status(500).json({ error: 'Login failed' });
  }
});

// Phone OTP login
router.post('/login/phone', (req, res) => {
  const { phone } = req.body;
  // Generate and send OTP
  const otp = Math.floor(100000 + Math.random() * 900000).toString();
  res.json({ message: 'OTP sent', otp }); // In production, don't return OTP
});

// Verify OTP
router.post('/verify-otp', (req, res) => {
  const { phone, otp } = req.body;
  // Verify OTP logic here
  res.json({ message: 'OTP verified', token: 'jwt-token-here' });
});

// Google OAuth
router.post('/google', (req, res) => {
  const { token } = req.body;
  // Verify Google token
  res.json({ message: 'Google login successful', token: 'jwt-token-here' });
});

// Get current user
router.get('/me', (req, res) => {
  res.json({ message: 'Current user endpoint' });
});

export default router;
