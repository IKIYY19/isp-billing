import express from 'express';

const router = express.Router();

const olts = [
  { 
    id: '1', 
    name: 'Huawei OLT 1', 
    ip: '10.0.1.1', 
    vendor: 'huawei', 
    model: 'MA5608T',
    status: 'online',
    ponPorts: 8,
    activeOnus: 124,
    totalOnus: 128
  },
  { 
    id: '2', 
    name: 'ZTE OLT 1', 
    ip: '10.0.1.2', 
    vendor: 'zte', 
    model: 'C320',
    status: 'online',
    ponPorts: 16,
    activeOnus: 189,
    totalOnus: 256
  }
];

router.get('/', (req, res) => {
  res.json({ olts, total: olts.length });
});

router.get('/:id', (req, res) => {
  const olt = olts.find(o => o.id === req.params.id);
  if (!olt) return res.status(404).json({ error: 'OLT not found' });
  res.json(olt);
});

router.get('/:id/ports', (req, res) => {
  res.json({
    ports: [
      { id: 'PON0/1/1', status: 'active', onus: 16, rxPower: '-15.2dBm' },
      { id: 'PON0/1/2', status: 'active', onus: 14, rxPower: '-18.5dBm' },
      { id: 'PON0/1/3', status: 'inactive', onus: 0, rxPower: null }
    ]
  });
});

router.get('/:id/onus', (req, res) => {
  res.json({
    onus: [
      { id: 'ONU001', serial: 'HWTC12345678', status: 'online', rxPower: '-20.5dBm', txPower: '2.5dBm', customer: 'John Doe' },
      { id: 'ONU002', serial: 'HWTC87654321', status: 'online', rxPower: '-22.1dBm', txPower: '2.3dBm', customer: 'Jane Smith' }
    ]
  });
});

router.post('/:id/provision', (req, res) => {
  const { serial, customerId, portId } = req.body;
  res.json({
    message: 'ONU provisioned successfully',
    onuId: `ONU${Date.now()}`,
    serial,
    portId
  });
});

export default router;
