import express from 'express';

const router = express.Router();

// Mock customers data
const customers = [
  { id: '1', name: 'John Doe', email: 'john@example.com', phone: '+254712345678', status: 'active', plan: 'Premium 10Mbps' },
  { id: '2', name: 'Jane Smith', email: 'jane@example.com', phone: '+254723456789', status: 'active', plan: 'Basic 5Mbps' },
  { id: '3', name: 'Bob Wilson', email: 'bob@example.com', phone: '+254734567890', status: 'suspended', plan: 'Standard 8Mbps' }
];

// Get all customers
router.get('/', (req, res) => {
  res.json({
    customers,
    total: customers.length,
    page: 1,
    limit: 10
  });
});

// Get customer by ID
router.get('/:id', (req, res) => {
  const customer = customers.find(c => c.id === req.params.id);
  if (!customer) {
    return res.status(404).json({ error: 'Customer not found' });
  }
  res.json(customer);
});

// Create customer
router.post('/', (req, res) => {
  const newCustomer = {
    id: Date.now().toString(),
    ...req.body,
    createdAt: new Date()
  };
  customers.push(newCustomer);
  res.status(201).json(newCustomer);
});

// Update customer
router.put('/:id', (req, res) => {
  const index = customers.findIndex(c => c.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: 'Customer not found' });
  }
  customers[index] = { ...customers[index], ...req.body };
  res.json(customers[index]);
});

// Delete customer
router.delete('/:id', (req, res) => {
  const index = customers.findIndex(c => c.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: 'Customer not found' });
  }
  customers.splice(index, 1);
  res.json({ message: 'Customer deleted' });
});

export default router;
