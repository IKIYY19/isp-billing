import express from 'express';

const router = express.Router();

router.get('/dashboard', (req, res) => {
  res.json({
    stats: {
      totalCustomers: 312,
      activeCustomers: 298,
      suspendedCustomers: 14,
      monthlyRevenue: 784500,
      pendingInvoices: 45000,
      overdueAmount: 23000,
      activeSessions: 245,
      totalBandwidth: '2.5 Gbps'
    },
    recentPayments: [
      { id: 'PAY001', customer: 'John Doe', amount: 2500, date: '2024-02-03', method: 'M-Pesa' },
      { id: 'PAY002', customer: 'Jane Smith', amount: 1500, date: '2024-02-03', method: 'Bank' }
    ],
    alerts: [
      { type: 'warning', message: 'Router MikroTik Backup high CPU usage', time: '5 min ago' },
      { type: 'error', message: 'OLT Huawei OLT 1 PON port 3 offline', time: '15 min ago' }
    ]
  });
});

router.get('/revenue', (req, res) => {
  res.json({
    daily: [
      { date: '2024-02-01', amount: 25000 },
      { date: '2024-02-02', amount: 32000 },
      { date: '2024-02-03', amount: 28000 }
    ],
    monthly: [
      { month: 'Jan 2024', amount: 750000 },
      { month: 'Feb 2024', amount: 784500 }
    ]
  });
});

router.get('/customers', (req, res) => {
  res.json({
    growth: [
      { month: 'Jan 2024', new: 25, churned: 5, total: 280 },
      { month: 'Feb 2024', new: 32, churned: 0, total: 312 }
    ],
    byPlan: [
      { plan: 'Basic', count: 120 },
      { plan: 'Standard', count: 145 },
      { plan: 'Premium', count: 47 }
    ]
  });
});

export default router;
