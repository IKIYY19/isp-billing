import express from 'express';

const router = express.Router();

const routers = [
  { id: '1', name: 'MikroTik Main', ip: '192.168.1.1', model: 'RB3011', status: 'online', type: 'mikrotik', customers: 45 },
  { id: '2', name: 'MikroTik Backup', ip: '192.168.1.2', model: 'RB2011', status: 'online', type: 'mikrotik', customers: 23 },
  { id: '3', name: 'Hotspot Router', ip: '192.168.2.1', model: 'hAP ac', status: 'offline', type: 'mikrotik', customers: 0 }
];

router.get('/', (req, res) => {
  res.json({ routers, total: routers.length });
});

router.get('/:id', (req, res) => {
  const r = routers.find(r => r.id === req.params.id);
  if (!r) return res.status(404).json({ error: 'Router not found' });
  res.json(r);
});

router.post('/:id/reboot', (req, res) => {
  res.json({ message: 'Router reboot initiated', routerId: req.params.id });
});

router.get('/:id/sessions', (req, res) => {
  res.json({
    sessions: [
      { id: 'S1', user: 'customer1', ip: '10.0.0.5', mac: '00:11:22:33:44:55', uptime: '2d 4h 30m', bytesIn: '10GB', bytesOut: '5GB' }
    ]
  });
});

export default router;
