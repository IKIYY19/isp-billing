import express from 'express';

const router = express.Router();

const invoices = [
  { id: 'INV001', customerId: '1', amount: 2500, status: 'paid', dueDate: '2024-02-15', paidDate: '2024-02-10' },
  { id: 'INV002', customerId: '2', amount: 1500, status: 'pending', dueDate: '2024-02-20', paidDate: null },
  { id: 'INV003', customerId: '3', amount: 2000, status: 'overdue', dueDate: '2024-01-30', paidDate: null }
];

router.get('/', (req, res) => {
  res.json({ invoices, total: invoices.length });
});

router.get('/:id', (req, res) => {
  const invoice = invoices.find(i => i.id === req.params.id);
  if (!invoice) return res.status(404).json({ error: 'Invoice not found' });
  res.json(invoice);
});

router.post('/', (req, res) => {
  const newInvoice = {
    id: `INV${Date.now()}`,
    ...req.body,
    createdAt: new Date()
  };
  invoices.push(newInvoice);
  res.status(201).json(newInvoice);
});

router.put('/:id/pay', (req, res) => {
  const invoice = invoices.find(i => i.id === req.params.id);
  if (!invoice) return res.status(404).json({ error: 'Invoice not found' });
  invoice.status = 'paid';
  invoice.paidDate = new Date().toISOString();
  res.json(invoice);
});

export default router;
