import { Parser } from 'json2csv';
import * as XLSX from 'xlsx';
import { parse } from 'csv-parse/sync';
import { stringify } from 'csv-stringify/sync';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// Export formats
export type ExportFormat = 'csv' | 'excel' | 'json' | 'pdf';

// Export options
interface ExportOptions {
  format: ExportFormat;
  filters?: Record<string, any>;
  columns?: string[];
  filename?: string;
}

// Import options
interface ImportOptions {
  format: 'csv' | 'excel' | 'json';
  skipDuplicates?: boolean;
  updateExisting?: boolean;
  validateData?: boolean;
}

// Import result
interface ImportResult {
  imported: number;
  updated: number;
  failed: number;
  errors: string[];
}

/**
 * Export customers to various formats
 */
export async function exportCustomers(options: ExportOptions): Promise<Buffer> {
  const customers = await prisma.customer.findMany({
    where: options.filters,
    include: {
      subscriptions: {
        include: { plan: true },
      },
    },
  });

  // Map to export format
  const data = customers.map((customer) => ({
    id: customer.id,
    accountNumber: customer.accountNumber,
    firstName: customer.firstName,
    lastName: customer.lastName,
    email: customer.email,
    phone: customer.phone,
    address: customer.address,
    city: customer.city,
    country: customer.country,
    plan: customer.subscriptions[0]?.plan?.name || '',
    status: customer.isActive ? 'Active' : 'Inactive',
    createdAt: customer.createdAt.toISOString(),
  }));

  switch (options.format) {
    case 'csv':
      return exportToCSV(data, options.columns);
    case 'excel':
      return exportToExcel(data, 'Customers');
    case 'json':
      return Buffer.from(JSON.stringify(data, null, 2));
    default:
      throw new Error(`Unsupported export format: ${options.format}`);
  }
}

/**
 * Export invoices to various formats
 */
export async function exportInvoices(options: ExportOptions): Promise<Buffer> {
  const invoices = await prisma.invoice.findMany({
    where: options.filters,
    include: {
      customer: true,
    },
  });

  const data = invoices.map((invoice) => ({
    invoiceNumber: invoice.invoiceNumber,
    customerName: `${invoice.customer.firstName} ${invoice.customer.lastName}`,
    customerEmail: invoice.customer.email,
    subtotal: invoice.subtotal,
    taxAmount: invoice.taxAmount,
    discountAmount: invoice.discountAmount,
    total: invoice.total,
    amountPaid: invoice.amountPaid,
    balanceDue: invoice.balanceDue,
    status: invoice.status,
    issueDate: invoice.issueDate.toISOString(),
    dueDate: invoice.dueDate.toISOString(),
    paidDate: invoice.paidDate?.toISOString(),
  }));

  switch (options.format) {
    case 'csv':
      return exportToCSV(data, options.columns);
    case 'excel':
      return exportToExcel(data, 'Invoices');
    case 'json':
      return Buffer.from(JSON.stringify(data, null, 2));
    default:
      throw new Error(`Unsupported export format: ${options.format}`);
  }
}

/**
 * Export payments to various formats
 */
export async function exportPayments(options: ExportOptions): Promise<Buffer> {
  const payments = await prisma.payment.findMany({
    where: options.filters,
    include: {
      customer: true,
    },
  });

  const data = payments.map((payment) => ({
    transactionId: payment.transactionId,
    customerName: `${payment.customer.firstName} ${payment.customer.lastName}`,
    amount: payment.amount,
    currency: payment.currency,
    method: payment.method,
    status: payment.status,
    processedAt: payment.processedAt?.toISOString(),
    createdAt: payment.createdAt.toISOString(),
  }));

  switch (options.format) {
    case 'csv':
      return exportToCSV(data, options.columns);
    case 'excel':
      return exportToExcel(data, 'Payments');
    case 'json':
      return Buffer.from(JSON.stringify(data, null, 2));
    default:
      throw new Error(`Unsupported export format: ${options.format}`);
  }
}

/**
 * Export to CSV format
 */
function exportToCSV(data: any[], columns?: string[]): Buffer {
  if (data.length === 0) {
    return Buffer.from('');
  }

  const fields = columns || Object.keys(data[0]);
  const parser = new Parser({ fields });
  const csv = parser.parse(data);
  
  return Buffer.from(csv);
}

/**
 * Export to Excel format
 */
function exportToExcel(data: any[], sheetName: string): Buffer {
  const worksheet = XLSX.utils.json_to_sheet(data);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, sheetName);
  
  return XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
}

/**
 * Import customers from CSV/Excel
 */
export async function importCustomers(
  fileBuffer: Buffer,
  options: ImportOptions
): Promise<ImportResult> {
  const result: ImportResult = {
    imported: 0,
    updated: 0,
    failed: 0,
    errors: [],
  };

  try {
    // Parse file based on format
    let data: any[];
    
    if (options.format === 'csv') {
      data = parse(fileBuffer.toString(), {
        columns: true,
        skip_empty_lines: true,
      });
    } else if (options.format === 'excel') {
      const workbook = XLSX.read(fileBuffer, { type: 'buffer' });
      const worksheet = workbook.Sheets[workbook.SheetNames[0]];
      data = XLSX.utils.sheet_to_json(worksheet);
    } else if (options.format === 'json') {
      data = JSON.parse(fileBuffer.toString());
    } else {
      throw new Error(`Unsupported import format: ${options.format}`);
    }

    // Process each record
    for (const record of data) {
      try {
        // Validate required fields
        if (options.validateData) {
          const requiredFields = ['email', 'firstName', 'lastName', 'phone'];
          const missingFields = requiredFields.filter((f) => !record[f]);
          
          if (missingFields.length > 0) {
            throw new Error(`Missing required fields: ${missingFields.join(', ')}`);
          }
        }

        // Check for existing customer
        const existingCustomer = await prisma.customer.findUnique({
          where: { email: record.email },
        });

        if (existingCustomer) {
          if (options.skipDuplicates) {
            continue;
          }
          
          if (options.updateExisting) {
            await prisma.customer.update({
              where: { id: existingCustomer.id },
              data: {
                firstName: record.firstName,
                lastName: record.lastName,
                phone: record.phone,
                address: record.address,
                city: record.city,
                country: record.country,
              },
            });
            result.updated++;
            continue;
          }
        }

        // Create new customer
        await prisma.customer.create({
          data: {
            email: record.email,
            firstName: record.firstName,
            lastName: record.lastName,
            phone: record.phone,
            address: record.address,
            city: record.city,
            country: record.country || 'Kenya',
            password: '', // Will need to set password separately
            accountNumber: `ACC${Date.now()}${Math.random().toString(36).substr(2, 5).toUpperCase()}`,
            isActive: true,
            emailVerified: false,
            phoneVerified: false,
            role: 'customer',
          },
        });

        result.imported++;
      } catch (error: any) {
        result.failed++;
        result.errors.push(`Row ${result.imported + result.updated + result.failed}: ${error.message}`);
      }
    }

    return result;
  } catch (error: any) {
    result.errors.push(`Import error: ${error.message}`);
    return result;
  }
}

/**
 * Import invoices from CSV/Excel
 */
export async function importInvoices(
  fileBuffer: Buffer,
  options: ImportOptions
): Promise<ImportResult> {
  const result: ImportResult = {
    imported: 0,
    updated: 0,
    failed: 0,
    errors: [],
  };

  try {
    let data: any[];
    
    if (options.format === 'csv') {
      data = parse(fileBuffer.toString(), {
        columns: true,
        skip_empty_lines: true,
      });
    } else if (options.format === 'excel') {
      const workbook = XLSX.read(fileBuffer, { type: 'buffer' });
      const worksheet = workbook.Sheets[workbook.SheetNames[0]];
      data = XLSX.utils.sheet_to_json(worksheet);
    } else {
      data = JSON.parse(fileBuffer.toString());
    }

    for (const record of data) {
      try {
        // Find customer by email or account number
        const customer = await prisma.customer.findFirst({
          where: {
            OR: [
              { email: record.customerEmail },
              { accountNumber: record.accountNumber },
            ],
          },
        });

        if (!customer) {
          throw new Error(`Customer not found: ${record.customerEmail || record.accountNumber}`);
        }

        // Create invoice
        await prisma.invoice.create({
          data: {
            invoiceNumber: record.invoiceNumber || `INV${Date.now()}`,
            customerId: customer.id,
            subtotal: parseFloat(record.subtotal) || 0,
            taxAmount: parseFloat(record.taxAmount) || 0,
            discountAmount: parseFloat(record.discountAmount) || 0,
            total: parseFloat(record.total) || 0,
            amountPaid: parseFloat(record.amountPaid) || 0,
            balanceDue: parseFloat(record.balanceDue) || parseFloat(record.total) || 0,
            status: record.status || 'sent',
            issueDate: new Date(record.issueDate),
            dueDate: new Date(record.dueDate),
            items: {
              create: [
                {
                  description: record.description || 'Internet Service',
                  quantity: 1,
                  unitPrice: parseFloat(record.total) || 0,
                  total: parseFloat(record.total) || 0,
                  type: 'subscription',
                },
              ],
            },
          },
        });

        result.imported++;
      } catch (error: any) {
        result.failed++;
        result.errors.push(`Row ${result.imported + result.updated + result.failed}: ${error.message}`);
      }
    }

    return result;
  } catch (error: any) {
    result.errors.push(`Import error: ${error.message}`);
    return result;
  }
}

/**
 * Generate import template
 */
export function generateImportTemplate(entity: 'customers' | 'invoices' | 'payments'): Buffer {
  let headers: string[] = [];
  let sampleData: any[] = [];

  switch (entity) {
    case 'customers':
      headers = ['email', 'firstName', 'lastName', 'phone', 'address', 'city', 'country'];
      sampleData = [
        {
          email: 'john.doe@example.com',
          firstName: 'John',
          lastName: 'Doe',
          phone: '254712345678',
          address: '123 Main St',
          city: 'Nairobi',
          country: 'Kenya',
        },
      ];
      break;
    case 'invoices':
      headers = ['customerEmail', 'total', 'description', 'issueDate', 'dueDate'];
      sampleData = [
        {
          customerEmail: 'john.doe@example.com',
          total: 2500,
          description: 'Monthly Internet Service',
          issueDate: '2024-01-01',
          dueDate: '2024-01-15',
        },
      ];
      break;
    case 'payments':
      headers = ['customerEmail', 'amount', 'method', 'transactionId'];
      sampleData = [
        {
          customerEmail: 'john.doe@example.com',
          amount: 2500,
          method: 'mpesa',
          transactionId: 'MPESA123456',
        },
      ];
      break;
  }

  const parser = new Parser({ fields: headers });
  const csv = parser.parse(sampleData);
  
  return Buffer.from(csv);
}

/**
 * Validate import file
 */
export async function validateImportFile(
  fileBuffer: Buffer,
  format: 'csv' | 'excel' | 'json',
  entity: 'customers' | 'invoices' | 'payments'
): Promise<{ valid: boolean; errors: string[] }> {
  const errors: string[] = [];

  try {
    let data: any[];
    
    if (format === 'csv') {
      data = parse(fileBuffer.toString(), {
        columns: true,
        skip_empty_lines: true,
      });
    } else if (format === 'excel') {
      const workbook = XLSX.read(fileBuffer, { type: 'buffer' });
      const worksheet = workbook.Sheets[workbook.SheetNames[0]];
      data = XLSX.utils.sheet_to_json(worksheet);
    } else {
      data = JSON.parse(fileBuffer.toString());
    }

    if (data.length === 0) {
      errors.push('File contains no data');
      return { valid: false, errors };
    }

    // Check required fields
    const requiredFields: Record<string, string[]> = {
      customers: ['email', 'firstName', 'lastName'],
      invoices: ['customerEmail', 'total'],
      payments: ['customerEmail', 'amount'],
    };

    const firstRecord = data[0];
    const missingFields = requiredFields[entity].filter((f) => !(f in firstRecord));
    
    if (missingFields.length > 0) {
      errors.push(`Missing required fields: ${missingFields.join(', ')}`);
    }

    return { valid: errors.length === 0, errors };
  } catch (error: any) {
    errors.push(`Validation error: ${error.message}`);
    return { valid: false, errors };
  }
}

export default {
  exportCustomers,
  exportInvoices,
  exportPayments,
  importCustomers,
  importInvoices,
  generateImportTemplate,
  validateImportFile,
};
