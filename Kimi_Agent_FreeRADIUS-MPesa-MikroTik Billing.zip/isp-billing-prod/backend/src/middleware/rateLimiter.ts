import rateLimit from 'express-rate-limit';
import Redis from 'ioredis';
import { RedisStore } from 'rate-limit-redis';
import { Request, Response } from 'express';

// Redis client for rate limiting
const redisClient = new Redis(process.env.REDIS_URL || 'redis://localhost:6379');

// Custom key generator
const keyGenerator = (req: Request): string => {
  // Use user ID if authenticated, otherwise use IP
  const userId = (req as any).user?.id;
  const identifier = userId || req.ip;
  return `ratelimit:${req.route?.path || req.path}:${identifier}`;
};

// Standard API rate limiter
export const apiLimiter = rateLimit({
  store: new RedisStore({
    sendCommand: (...args: string[]) => redisClient.call(...args) as any,
  }),
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // 100 requests per window
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator,
  handler: (req: Request, res: Response) => {
    res.status(429).json({
      success: false,
      error: {
        code: 'RATE_LIMIT_EXCEEDED',
        message: 'Too many requests, please try again later.',
        retryAfter: Math.ceil((req as any).rateLimit.resetTime / 1000),
      },
    });
  },
});

// Strict rate limiter for authentication endpoints
export const authLimiter = rateLimit({
  store: new RedisStore({
    sendCommand: (...args: string[]) => redisClient.call(...args) as any,
  }),
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // 5 attempts per window
  standardHeaders: true,
  legacyHeaders: false,
  skipSuccessfulRequests: true, // Don't count successful requests
  keyGenerator: (req: Request) => `auth:${req.ip}:${req.body.email || req.body.phone || 'unknown'}`,
  handler: (req: Request, res: Response) => {
    res.status(429).json({
      success: false,
      error: {
        code: 'AUTH_RATE_LIMIT_EXCEEDED',
        message: 'Too many authentication attempts. Please try again after 15 minutes.',
        retryAfter: 15 * 60,
      },
    });
  },
});

// OTP request rate limiter
export const otpLimiter = rateLimit({
  store: new RedisStore({
    sendCommand: (...args: string[]) => redisClient.call(...args) as any,
  }),
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 3, // 3 OTP requests per hour
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req: Request) => `otp:${req.body.phone || req.ip}`,
  handler: (req: Request, res: Response) => {
    res.status(429).json({
      success: false,
      error: {
        code: 'OTP_RATE_LIMIT_EXCEEDED',
        message: 'Too many OTP requests. Please try again after 1 hour.',
        retryAfter: 60 * 60,
      },
    });
  },
});

// Payment rate limiter
export const paymentLimiter = rateLimit({
  store: new RedisStore({
    sendCommand: (...args: string[]) => redisClient.call(...args) as any,
  }),
  windowMs: 60 * 1000, // 1 minute
  max: 10, // 10 payment requests per minute
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req: Request) => `payment:${(req as any).user?.id || req.ip}`,
  handler: (req: Request, res: Response) => {
    res.status(429).json({
      success: false,
      error: {
        code: 'PAYMENT_RATE_LIMIT_EXCEEDED',
        message: 'Too many payment requests. Please try again later.',
        retryAfter: 60,
      },
    });
  },
});

// M-Pesa STK push rate limiter
export const mpesaLimiter = rateLimit({
  store: new RedisStore({
    sendCommand: (...args: string[]) => redisClient.call(...args) as any,
  }),
  windowMs: 5 * 60 * 1000, // 5 minutes
  max: 3, // 3 STK pushes per 5 minutes per phone
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req: Request) => `mpesa:${req.body.phoneNumber || req.ip}`,
  handler: (req: Request, res: Response) => {
    res.status(429).json({
      success: false,
      error: {
        code: 'MPESA_RATE_LIMIT_EXCEEDED',
        message: 'Too many M-Pesa requests. Please try again after 5 minutes.',
        retryAfter: 5 * 60,
      },
    });
  },
});

// Bulk operation rate limiter
export const bulkOperationLimiter = rateLimit({
  store: new RedisStore({
    sendCommand: (...args: string[]) => redisClient.call(...args) as any,
  }),
  windowMs: 60 * 1000, // 1 minute
  max: 5, // 5 bulk operations per minute
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req: Request) => `bulk:${(req as any).user?.id || req.ip}`,
  handler: (req: Request, res: Response) => {
    res.status(429).json({
      success: false,
      error: {
        code: 'BULK_RATE_LIMIT_EXCEEDED',
        message: 'Too many bulk operations. Please try again later.',
        retryAfter: 60,
      },
    });
  },
});

// Export/Import rate limiter
export const exportImportLimiter = rateLimit({
  store: new RedisStore({
    sendCommand: (...args: string[]) => redisClient.call(...args) as any,
  }),
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 10, // 10 export/import operations per hour
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req: Request) => `export:${(req as any).user?.id || req.ip}`,
  handler: (req: Request, res: Response) => {
    res.status(429).json({
      success: false,
      error: {
        code: 'EXPORT_RATE_LIMIT_EXCEEDED',
        message: 'Too many export/import operations. Please try again later.',
        retryAfter: 60 * 60,
      },
    });
  },
});

// Create custom rate limiter
export const createRateLimiter = (options: {
  windowMs: number;
  max: number;
  keyPrefix?: string;
  message?: string;
}) => {
  return rateLimit({
    store: new RedisStore({
      sendCommand: (...args: string[]) => redisClient.call(...args) as any,
    }),
    windowMs: options.windowMs,
    max: options.max,
    standardHeaders: true,
    legacyHeaders: false,
    keyGenerator: (req: Request) => 
      `${options.keyPrefix || 'custom'}:${(req as any).user?.id || req.ip}`,
    handler: (req: Request, res: Response) => {
      res.status(429).json({
        success: false,
        error: {
          code: 'RATE_LIMIT_EXCEEDED',
          message: options.message || 'Too many requests, please try again later.',
          retryAfter: Math.ceil(options.windowMs / 1000),
        },
      });
    },
  });
};

// Webhook rate limiter (per endpoint)
export const webhookLimiter = rateLimit({
  store: new RedisStore({
    sendCommand: (...args: string[]) => redisClient.call(...args) as any,
  }),
  windowMs: 60 * 1000, // 1 minute
  max: 100, // 100 webhook calls per minute per endpoint
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req: Request) => `webhook:${req.params.endpoint || req.ip}`,
});

// Admin action rate limiter
export const adminActionLimiter = rateLimit({
  store: new RedisStore({
    sendCommand: (...args: string[]) => redisClient.call(...args) as any,
  }),
  windowMs: 60 * 1000, // 1 minute
  max: 30, // 30 admin actions per minute
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req: Request) => `admin:${(req as any).user?.id || req.ip}`,
  handler: (req: Request, res: Response) => {
    res.status(429).json({
      success: false,
      error: {
        code: 'ADMIN_RATE_LIMIT_EXCEEDED',
        message: 'Too many admin actions. Please try again later.',
        retryAfter: 60,
      },
    });
  },
});

export default {
  apiLimiter,
  authLimiter,
  otpLimiter,
  paymentLimiter,
  mpesaLimiter,
  bulkOperationLimiter,
  exportImportLimiter,
  webhookLimiter,
  adminActionLimiter,
  createRateLimiter,
};
