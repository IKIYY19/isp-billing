#!/usr/bin/env node

/**
 * ISP Billing System - Admin CLI Tool
 * 
 * A command-line interface for managing the ISP Billing System.
 * Provides commands for customer management, billing, reports, and system administration.
 */

const { Command } = require('commander');
const inquirer = require('inquirer');
const chalk = require('chalk');
const ora = require('ora');
const Table = require('cli-table3');
const axios = require('axios');
const fs = require('fs');
const path = require('path');

const program = new Command();

// Configuration
const CONFIG_FILE = path.join(require('os').homedir(), '.isp-cli-config.json');

// Load config
function loadConfig() {
  try {
    return JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
  } catch {
    return { apiUrl: 'http://localhost:3000/api/v1', token: null };
  }
}

// Save config
function saveConfig(config) {
  fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));
}

// API client
function createApiClient() {
  const config = loadConfig();
  return axios.create({
    baseURL: config.apiUrl,
    headers: config.token ? { Authorization: `Bearer ${config.token}` } : {},
  });
}

// Print banner
function printBanner() {
  console.log(chalk.cyan(`
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║           🌐 ISP Billing System - Admin CLI                  ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
  `));
}

// ==================== AUTH COMMANDS ====================

program
  .command('login')
  .description('Login to the ISP Billing System')
  .option('-e, --email <email>', 'Email address')
  .option('-p, --password <password>', 'Password')
  .action(async (options) => {
    printBanner();
    
    const answers = await inquirer.prompt([
      {
        type: 'input',
        name: 'email',
        message: 'Email:',
        when: !options.email,
        validate: (input) => input.includes('@') || 'Please enter a valid email',
      },
      {
        type: 'password',
        name: 'password',
        message: 'Password:',
        when: !options.password,
        mask: '*',
      },
    ]);

    const email = options.email || answers.email;
    const password = options.password || answers.password;

    const spinner = ora('Logging in...').start();

    try {
      const api = createApiClient();
      const response = await api.post('/auth/login', { email, password });
      
      const config = loadConfig();
      config.token = response.data.data.tokens.accessToken;
      saveConfig(config);

      spinner.succeed(chalk.green(`Logged in as ${response.data.data.user.email}`));
    } catch (error) {
      spinner.fail(chalk.red('Login failed: ' + (error.response?.data?.error?.message || error.message)));
      process.exit(1);
    }
  });

program
  .command('logout')
  .description('Logout from the system')
  .action(() => {
    const config = loadConfig();
    config.token = null;
    saveConfig(config);
    console.log(chalk.green('Logged out successfully'));
  });

// ==================== CUSTOMER COMMANDS ====================

program
  .command('customers:list')
  .alias('c:list')
  .description('List all customers')
  .option('-p, --page <page>', 'Page number', '1')
  .option('-l, --limit <limit>', 'Items per page', '20')
  .option('-s, --search <search>', 'Search query')
  .action(async (options) => {
    const spinner = ora('Fetching customers...').start();

    try {
      const api = createApiClient();
      const response = await api.get('/customers', {
        params: {
          page: options.page,
          limit: options.limit,
          search: options.search,
        },
      });

      spinner.stop();

      const customers = response.data.data.data;
      const meta = response.data.data.meta;

      const table = new Table({
        head: [chalk.cyan('ID'), chalk.cyan('Name'), chalk.cyan('Email'), chalk.cyan('Phone'), chalk.cyan('Status')],
        colWidths: [10, 25, 30, 18, 12],
      });

      customers.forEach((customer) => {
        table.push([
          customer.id.slice(0, 8),
          `${customer.firstName} ${customer.lastName}`,
          customer.email,
          customer.phone,
          customer.isActive ? chalk.green('Active') : chalk.red('Inactive'),
        ]);
      });

      console.log(table.toString());
      console.log(chalk.gray(`\nPage ${meta.page} of ${meta.totalPages} (${meta.total} total)`));
    } catch (error) {
      spinner.fail(chalk.red('Failed to fetch customers: ' + (error.response?.data?.error?.message || error.message)));
    }
  });

program
  .command('customers:create')
  .alias('c:create')
  .description('Create a new customer')
  .action(async () => {
    const answers = await inquirer.prompt([
      { type: 'input', name: 'firstName', message: 'First Name:', validate: (i) => i.length > 0 },
      { type: 'input', name: 'lastName', message: 'Last Name:', validate: (i) => i.length > 0 },
      { type: 'input', name: 'email', message: 'Email:', validate: (i) => i.includes('@') },
      { type: 'input', name: 'phone', message: 'Phone (254XXXXXXXXX):', validate: (i) => i.startsWith('254') },
      { type: 'input', name: 'address', message: 'Address:' },
      { type: 'input', name: 'city', message: 'City:' },
      { type: 'input', name: 'country', message: 'Country:', default: 'Kenya' },
      { type: 'password', name: 'password', message: 'Password:', mask: '*' },
    ]);

    const spinner = ora('Creating customer...').start();

    try {
      const api = createApiClient();
      const response = await api.post('/customers', answers);

      spinner.succeed(chalk.green(`Customer created: ${response.data.data.email}`));
      console.log(chalk.gray(`Account Number: ${response.data.data.accountNumber}`));
    } catch (error) {
      spinner.fail(chalk.red('Failed to create customer: ' + (error.response?.data?.error?.message || error.message)));
    }
  });

program
  .command('customers:view <id>')
  .alias('c:view')
  .description('View customer details')
  .action(async (id) => {
    const spinner = ora('Fetching customer...').start();

    try {
      const api = createApiClient();
      const response = await api.get(`/customers/${id}`);
      const customer = response.data.data;

      spinner.stop();

      console.log(chalk.cyan('\n📋 Customer Details\n'));
      console.log(`Name: ${chalk.bold(customer.firstName + ' ' + customer.lastName)}`);
      console.log(`Email: ${customer.email}`);
      console.log(`Phone: ${customer.phone}`);
      console.log(`Account: ${customer.accountNumber}`);
      console.log(`Status: ${customer.isActive ? chalk.green('Active') : chalk.red('Inactive')}`);
      console.log(`Address: ${customer.address}, ${customer.city}, ${customer.country}`);
      console.log(`Created: ${new Date(customer.createdAt).toLocaleDateString()}`);
    } catch (error) {
      spinner.fail(chalk.red('Failed to fetch customer: ' + (error.response?.data?.error?.message || error.message)));
    }
  });

// ==================== INVOICE COMMANDS ====================

program
  .command('invoices:list')
  .alias('i:list')
  .description('List invoices')
  .option('-p, --page <page>', 'Page number', '1')
  .option('-l, --limit <limit>', 'Items per page', '20')
  .option('-s, --status <status>', 'Filter by status')
  .action(async (options) => {
    const spinner = ora('Fetching invoices...').start();

    try {
      const api = createApiClient();
      const response = await api.get('/invoices', {
        params: {
          page: options.page,
          limit: options.limit,
          status: options.status,
        },
      });

      spinner.stop();

      const invoices = response.data.data.data;

      const table = new Table({
        head: [chalk.cyan('Invoice #'), chalk.cyan('Customer'), chalk.cyan('Amount'), chalk.cyan('Status'), chalk.cyan('Due Date')],
        colWidths: [15, 25, 15, 12, 15],
      });

      invoices.forEach((inv) => {
        const statusColor = {
          paid: chalk.green,
          pending: chalk.yellow,
          overdue: chalk.red,
        }[inv.status] || chalk.gray;

        table.push([
          inv.invoiceNumber,
          `${inv.customer?.firstName} ${inv.customer?.lastName}`,
          `KSh ${inv.total.toLocaleString()}`,
          statusColor(inv.status),
          new Date(inv.dueDate).toLocaleDateString(),
        ]);
      });

      console.log(table.toString());
    } catch (error) {
      spinner.fail(chalk.red('Failed to fetch invoices: ' + (error.response?.data?.error?.message || error.message)));
    }
  });

program
  .command('invoices:create')
  .alias('i:create')
  .description('Create a new invoice')
  .requiredOption('-c, --customer <id>', 'Customer ID')
  .requiredOption('-a, --amount <amount>', 'Invoice amount')
  .action(async (options) => {
    const spinner = ora('Creating invoice...').start();

    try {
      const api = createApiClient();
      const response = await api.post('/invoices', {
        customerId: options.customer,
        total: parseFloat(options.amount),
        items: [{
          description: 'Internet Service',
          quantity: 1,
          unitPrice: parseFloat(options.amount),
          total: parseFloat(options.amount),
        }],
      });

      spinner.succeed(chalk.green(`Invoice created: ${response.data.data.invoiceNumber}`));
    } catch (error) {
      spinner.fail(chalk.red('Failed to create invoice: ' + (error.response?.data?.error?.message || error.message)));
    }
  });

// ==================== PAYMENT COMMANDS ====================

program
  .command('payments:list')
  .alias('p:list')
  .description('List payments')
  .option('-p, --page <page>', 'Page number', '1')
  .option('-l, --limit <limit>', 'Items per page', '20')
  .action(async (options) => {
    const spinner = ora('Fetching payments...').start();

    try {
      const api = createApiClient();
      const response = await api.get('/payments', {
        params: {
          page: options.page,
          limit: options.limit,
        },
      });

      spinner.stop();

      const payments = response.data.data.data;

      const table = new Table({
        head: [chalk.cyan('ID'), chalk.cyan('Customer'), chalk.cyan('Amount'), chalk.cyan('Method'), chalk.cyan('Status')],
        colWidths: [10, 25, 15, 12, 12],
      });

      payments.forEach((pay) => {
        table.push([
          pay.id.slice(0, 8),
          `${pay.customer?.firstName} ${pay.customer?.lastName}`,
          `KSh ${pay.amount.toLocaleString()}`,
          pay.method,
          pay.status,
        ]);
      });

      console.log(table.toString());
    } catch (error) {
      spinner.fail(chalk.red('Failed to fetch payments: ' + (error.response?.data?.error?.message || error.message)));
    }
  });

// ==================== REPORT COMMANDS ====================

program
  .command('reports:daily')
  .alias('r:daily')
  .description('Generate daily report')
  .action(async () => {
    const spinner = ora('Generating report...').start();

    try {
      const api = createApiClient();
      const response = await api.get('/reports/daily');
      const report = response.data.data;

      spinner.stop();

      console.log(chalk.cyan('\n📊 Daily Report\n'));
      console.log(`New Customers: ${chalk.bold(report.newCustomers)}`);
      console.log(`Revenue: ${chalk.bold('KSh ' + report.revenue.toLocaleString())}`);
      console.log(`Payments: ${chalk.bold(report.payments)}`);
      console.log(`Invoices: ${chalk.bold(report.invoices)}`);
      console.log(`Network Uptime: ${chalk.bold(report.uptime + '%')}`);
    } catch (error) {
      spinner.fail(chalk.red('Failed to generate report: ' + (error.response?.data?.error?.message || error.message)));
    }
  });

program
  .command('reports:revenue')
  .alias('r:revenue')
  .description('Generate revenue report')
  .option('-s, --start <date>', 'Start date (YYYY-MM-DD)')
  .option('-e, --end <date>', 'End date (YYYY-MM-DD)')
  .action(async (options) => {
    const spinner = ora('Generating revenue report...').start();

    try {
      const api = createApiClient();
      const response = await api.get('/reports/revenue', {
        params: {
          startDate: options.start,
          endDate: options.end,
        },
      });

      spinner.stop();

      console.log(chalk.cyan('\n💰 Revenue Report\n'));
      console.log(response.data.data);
    } catch (error) {
      spinner.fail(chalk.red('Failed to generate report: ' + (error.response?.data?.error?.message || error.message)));
    }
  });

// ==================== SYSTEM COMMANDS ====================

program
  .command('system:status')
  .alias('sys:status')
  .description('Check system status')
  .action(async () => {
    const spinner = ora('Checking system status...').start();

    try {
      const api = createApiClient();
      const response = await api.get('/system/status');

      spinner.stop();

      console.log(chalk.cyan('\n🖥️  System Status\n'));
      console.log(`API Status: ${chalk.green('Online')}`);
      console.log(`Database: ${response.data.data.database}`);
      console.log(`Redis: ${response.data.data.redis}`);
      console.log(`Version: ${response.data.data.version}`);
    } catch (error) {
      spinner.fail(chalk.red('System appears to be offline'));
    }
  });

program
  .command('config:set')
  .description('Set configuration value')
  .requiredOption('-k, --key <key>', 'Configuration key')
  .requiredOption('-v, --value <value>', 'Configuration value')
  .action((options) => {
    const config = loadConfig();
    config[options.key] = options.value;
    saveConfig(config);
    console.log(chalk.green(`Configuration updated: ${options.key} = ${options.value}`));
  });

program
  .command('config:get')
  .description('Get configuration value')
  .option('-k, --key <key>', 'Configuration key')
  .action((options) => {
    const config = loadConfig();
    
    if (options.key) {
      console.log(`${options.key}: ${config[options.key]}`);
    } else {
      console.log(chalk.cyan('\nCurrent Configuration:\n'));
      Object.entries(config).forEach(([key, value]) => {
        console.log(`${key}: ${key === 'token' ? '[HIDDEN]' : value}`);
      });
    }
  });

// ==================== MAIN ====================

program
  .name('isp')
  .description('ISP Billing System - Admin CLI')
  .version('1.0.0')
  .option('-u, --url <url>', 'API URL', 'http://localhost:3000/api/v1');

// Show help if no command provided
if (process.argv.length === 2) {
  printBanner();
  program.help();
}

program.parse();
