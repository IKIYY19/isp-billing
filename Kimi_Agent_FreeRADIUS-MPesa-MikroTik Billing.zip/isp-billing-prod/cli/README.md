# ISP Billing CLI

A command-line interface for managing the ISP Billing System.

## Installation

```bash
# Install globally
npm install -g .

# Or run directly
npm install
node isp-cli.js
```

## Usage

```bash
# Show help
isp --help

# Login
isp login

# List customers
isp customers:list

# Create customer
isp customers:create

# List invoices
isp invoices:list

# Create invoice
isp invoices:create --customer <id> --amount <amount>

# List payments
isp payments:list

# Generate reports
isp reports:daily
isp reports:revenue --start 2024-01-01 --end 2024-01-31

# Check system status
isp system:status

# Configure API URL
isp config:set --key apiUrl --value http://localhost:3000/api/v1
```

## Commands

### Authentication
- `isp login` - Login to the system
- `isp logout` - Logout from the system

### Customers
- `isp customers:list` - List all customers
- `isp customers:create` - Create a new customer
- `isp customers:view <id>` - View customer details

### Invoices
- `isp invoices:list` - List all invoices
- `isp invoices:create` - Create a new invoice

### Payments
- `isp payments:list` - List all payments

### Reports
- `isp reports:daily` - Generate daily report
- `isp reports:revenue` - Generate revenue report

### System
- `isp system:status` - Check system status
- `isp config:set` - Set configuration
- `isp config:get` - Get configuration

## Configuration

Configuration is stored in `~/.isp-cli-config.json`:

```json
{
  "apiUrl": "http://localhost:3000/api/v1",
  "token": "your-jwt-token"
}
```
