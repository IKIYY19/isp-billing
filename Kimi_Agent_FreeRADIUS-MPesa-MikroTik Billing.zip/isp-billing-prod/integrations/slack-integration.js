/**
 * Slack Integration Module
 * 
 * Sends notifications to Slack channels for various events:
 * - New customer registrations
 * - Payment received
 * - Support tickets created/updated
 * - System alerts
 * - Daily/weekly reports
 */

const axios = require('axios');

class SlackIntegration {
  constructor(config = {}) {
    this.webhookUrl = config.webhookUrl || process.env.SLACK_WEBHOOK_URL;
    this.botToken = config.botToken || process.env.SLACK_BOT_TOKEN;
    this.defaultChannel = config.defaultChannel || '#general';
    this.enabled = !!this.webhookUrl;
  }

  /**
   * Send message to Slack
   */
  async sendMessage(message, options = {}) {
    if (!this.enabled) {
      console.log('Slack integration disabled - no webhook URL configured');
      return { success: false, error: 'Slack not configured' };
    }

    try {
      const payload = {
        text: message,
        channel: options.channel || this.defaultChannel,
        username: options.username || 'ISP Billing Bot',
        icon_emoji: options.icon || ':satellite_antenna:',
        ...options,
      };

      const response = await axios.post(this.webhookUrl, payload);
      
      return {
        success: true,
        data: response.data,
      };
    } catch (error) {
      console.error('Slack send message error:', error.message);
      return {
        success: false,
        error: error.message,
      };
    }
  }

  /**
   * Send rich message with blocks
   */
  async sendRichMessage(blocks, options = {}) {
    if (!this.enabled) {
      console.log('Slack integration disabled');
      return { success: false, error: 'Slack not configured' };
    }

    try {
      const payload = {
        blocks,
        channel: options.channel || this.defaultChannel,
        username: options.username || 'ISP Billing Bot',
        icon_emoji: options.icon || ':satellite_antenna:',
        ...options,
      };

      const response = await axios.post(this.webhookUrl, payload);
      
      return {
        success: true,
        data: response.data,
      };
    } catch (error) {
      console.error('Slack send rich message error:', error.message);
      return {
        success: false,
        error: error.message,
      };
    }
  }

  /**
   * Notify new customer registration
   */
  async notifyNewCustomer(customer) {
    const blocks = [
      {
        type: 'header',
        text: {
          type: 'plain_text',
          text: '🎉 New Customer Registration',
          emoji: true,
        },
      },
      {
        type: 'section',
        fields: [
          {
            type: 'mrkdwn',
            text: `*Name:*\n${customer.firstName} ${customer.lastName}`,
          },
          {
            type: 'mrkdwn',
            text: `*Account Number:*\n${customer.accountNumber}`,
          },
          {
            type: 'mrkdwn',
            text: `*Email:*\n${customer.email}`,
          },
          {
            type: 'mrkdwn',
            text: `*Phone:*\n${customer.phone}`,
          },
          {
            type: 'mrkdwn',
            text: `*Plan:*\n${customer.plan?.name || 'N/A'}`,
          },
          {
            type: 'mrkdwn',
            text: `*Location:*\n${customer.city}, ${customer.country}`,
          },
        ],
      },
      {
        type: 'actions',
        elements: [
          {
            type: 'button',
            text: {
              type: 'plain_text',
              text: 'View Customer',
              emoji: true,
            },
            url: `${process.env.ADMIN_URL}/customers/${customer.id}`,
            style: 'primary',
          },
        ],
      },
    ];

    return this.sendRichMessage(blocks, {
      channel: '#sales',
    });
  }

  /**
   * Notify payment received
   */
  async notifyPaymentReceived(payment, customer) {
    const blocks = [
      {
        type: 'header',
        text: {
          type: 'plain_text',
          text: '💰 Payment Received',
          emoji: true,
        },
      },
      {
        type: 'section',
        fields: [
          {
            type: 'mrkdwn',
            text: `*Amount:*\nKSh ${payment.amount.toLocaleString()}`,
          },
          {
            type: 'mrkdwn',
            text: `*Customer:*\n${customer.firstName} ${customer.lastName}`,
          },
          {
            type: 'mrkdwn',
            text: `*Method:*\n${payment.method.toUpperCase()}`,
          },
          {
            type: 'mrkdwn',
            text: `*Transaction ID:*\n${payment.transactionId}`,
          },
        ],
      },
      {
        type: 'context',
        elements: [
          {
            type: 'mrkdwn',
            text: `Account: ${customer.accountNumber}`,
          },
        ],
      },
    ];

    return this.sendRichMessage(blocks, {
      channel: '#payments',
    });
  }

  /**
   * Notify support ticket created
   */
  async notifyTicketCreated(ticket, customer) {
    const priorityEmoji = {
      low: '🔵',
      medium: '🟡',
      high: '🟠',
      urgent: '🔴',
    };

    const blocks = [
      {
        type: 'header',
        text: {
          type: 'plain_text',
          text: `${priorityEmoji[ticket.priority] || '⚪'} New Support Ticket`,
          emoji: true,
        },
      },
      {
        type: 'section',
        fields: [
          {
            type: 'mrkdwn',
            text: `*Ticket #:*\n${ticket.ticketNumber}`,
          },
          {
            type: 'mrkdwn',
            text: `*Priority:*\n${ticket.priority.toUpperCase()}`,
          },
          {
            type: 'mrkdwn',
            text: `*Category:*\n${ticket.category}`,
          },
          {
            type: 'mrkdwn',
            text: `*Customer:*\n${customer.firstName} ${customer.lastName}`,
          },
        ],
      },
      {
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: `*Subject:* ${ticket.subject}`,
        },
      },
      {
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: `*Description:*\n${ticket.description.substring(0, 500)}${
            ticket.description.length > 500 ? '...' : ''
          }`,
        },
      },
      {
        type: 'actions',
        elements: [
          {
            type: 'button',
            text: {
              type: 'plain_text',
              text: 'View Ticket',
              emoji: true,
            },
            url: `${process.env.ADMIN_URL}/tickets/${ticket.id}`,
            style: ticket.priority === 'urgent' ? 'danger' : 'primary',
          },
        ],
      },
    ];

    return this.sendRichMessage(blocks, {
      channel: ticket.priority === 'urgent' ? '#urgent-support' : '#support',
    });
  }

  /**
   * Notify system alert
   */
  async notifySystemAlert(alert) {
    const severityEmoji = {
      info: 'ℹ️',
      warning: '⚠️',
      critical: '🚨',
    };

    const severityColor = {
      info: '#3B82F6',
      warning: '#F59E0B',
      critical: '#EF4444',
    };

    const blocks = [
      {
        type: 'header',
        text: {
          type: 'plain_text',
          text: `${severityEmoji[alert.severity] || 'ℹ️'} System Alert`,
          emoji: true,
        },
      },
      {
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: `*${alert.title}*`,
        },
      },
      {
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: alert.message,
        },
      },
    ];

    if (alert.details) {
      blocks.push({
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: `\`\`\`json\n${JSON.stringify(alert.details, null, 2).substring(0, 2900)}\n\`\`\``,
        },
      });
    }

    return this.sendRichMessage(blocks, {
      channel: alert.severity === 'critical' ? '#alerts-critical' : '#alerts',
    });
  }

  /**
   * Send daily summary report
   */
  async sendDailyReport(stats) {
    const blocks = [
      {
        type: 'header',
        text: {
          type: 'plain_text',
          text: '📊 Daily Summary Report',
          emoji: true,
        },
      },
      {
        type: 'section',
        fields: [
          {
            type: 'mrkdwn',
            text: `*New Customers:*\n${stats.newCustomers}`,
          },
          {
            type: 'mrkdwn',
            text: `*Revenue:*\nKSh ${stats.revenue.toLocaleString()}`,
          },
          {
            type: 'mrkdwn',
            text: `*Payments:*\n${stats.payments}`,
          },
          {
            type: 'mrkdwn',
            text: `*Tickets:*\n${stats.tickets}`,
          },
          {
            type: 'mrkdwn',
            text: `*Network Uptime:*\n${stats.uptime}%`,
          },
          {
            type: 'mrkdwn',
            text: `*Data Usage:*\n${(stats.dataUsage / 1024 / 1024 / 1024).toFixed(2)} GB`,
          },
        ],
      },
      {
        type: 'context',
        elements: [
          {
            type: 'mrkdwn',
            text: `Report for ${new Date().toLocaleDateString()}`,
          },
        ],
      },
    ];

    return this.sendRichMessage(blocks, {
      channel: '#reports',
    });
  }

  /**
   * Send weekly summary report
   */
  async sendWeeklyReport(stats) {
    const blocks = [
      {
        type: 'header',
        text: {
          type: 'plain_text',
          text: '📈 Weekly Summary Report',
          emoji: true,
        },
      },
      {
        type: 'section',
        fields: [
          {
            type: 'mrkdwn',
            text: `*New Customers:*\n${stats.newCustomers}`,
          },
          {
            type: 'mrkdwn',
            text: `*Total Revenue:*\nKSh ${stats.revenue.toLocaleString()}`,
          },
          {
            type: 'mrkdwn',
            text: `*Total Payments:*\n${stats.payments}`,
          },
          {
            type: 'mrkdwn',
            text: `*Tickets Resolved:*\n${stats.ticketsResolved}/${stats.ticketsCreated}`,
          },
          {
            type: 'mrkdwn',
            text: `*Avg Network Uptime:*\n${stats.avgUptime}%`,
          },
          {
            type: 'mrkdwn',
            text: `*Total Data Usage:*\n${(stats.totalDataUsage / 1024 / 1024 / 1024 / 1024).toFixed(2)} TB`,
          },
        ],
      },
      {
        type: 'divider',
      },
      {
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: '*Top Plans This Week:*',
        },
      },
    ];

    // Add top plans
    if (stats.topPlans && stats.topPlans.length > 0) {
      stats.topPlans.forEach((plan, index) => {
        blocks.push({
          type: 'section',
          text: {
            type: 'mrkdwn',
            text: `${index + 1}. *${plan.name}* - ${plan.subscriptions} subscriptions`,
          },
        });
      });
    }

    blocks.push({
      type: 'context',
      elements: [
        {
          type: 'mrkdwn',
          text: `Week of ${stats.weekStart} to ${stats.weekEnd}`,
        },
      ],
    });

    return this.sendRichMessage(blocks, {
      channel: '#reports',
    });
  }

  /**
   * Test Slack connection
   */
  async testConnection() {
    return this.sendMessage('🔔 Slack integration test successful!', {
      channel: this.defaultChannel,
    });
  }
}

// Export singleton instance
const slackIntegration = new SlackIntegration();

module.exports = {
  SlackIntegration,
  slackIntegration,
};
