/**
 * Zapier Integration Module
 * 
 * Triggers Zapier webhooks for workflow automation:
 * - CRM integrations
 * - Email marketing
 * - Accounting software
 * - Project management tools
 * - Custom workflows
 */

const axios = require('axios');

class ZapierIntegration {
  constructor(config = {}) {
    this.webhookBaseUrl = config.webhookBaseUrl || process.env.ZAPIER_WEBHOOK_URL;
    this.enabled = !!this.webhookBaseUrl;
    this.timeout = config.timeout || 10000;
  }

  /**
   * Trigger Zapier webhook
   */
  async trigger(event, data, options = {}) {
    if (!this.enabled) {
      console.log(`Zapier integration disabled - would trigger: ${event}`);
      return { success: false, error: 'Zapier not configured', triggered: false };
    }

    const webhookUrl = options.webhookUrl || `${this.webhookBaseUrl}/${event}`;

    try {
      const payload = {
        event,
        timestamp: new Date().toISOString(),
        data,
        source: 'isp-billing-system',
        ...options.payload,
      };

      const response = await axios.post(webhookUrl, payload, {
        timeout: this.timeout,
        headers: {
          'Content-Type': 'application/json',
          'X-Webhook-Source': 'isp-billing-system',
          ...options.headers,
        },
      });

      console.log(`Zapier webhook triggered: ${event}`);
      
      return {
        success: true,
        triggered: true,
        data: response.data,
      };
    } catch (error) {
      console.error(`Zapier trigger error (${event}):`, error.message);
      return {
        success: false,
        triggered: false,
        error: error.message,
      };
    }
  }

  /**
   * Trigger new customer event
   */
  async newCustomer(customer, subscription = null) {
    return this.trigger('new_customer', {
      customer: {
        id: customer.id,
        accountNumber: customer.accountNumber,
        firstName: customer.firstName,
        lastName: customer.lastName,
        email: customer.email,
        phone: customer.phone,
        address: customer.address,
        city: customer.city,
        country: customer.country,
        plan: subscription?.plan?.name,
        planPrice: subscription?.plan?.price,
        createdAt: customer.createdAt,
      },
      subscription: subscription ? {
        id: subscription.id,
        planName: subscription.plan?.name,
        planSpeed: `${subscription.plan?.speed?.download} Mbps`,
        price: subscription.plan?.price,
        startDate: subscription.startDate,
      } : null,
    });
  }

  /**
   * Trigger payment received event
   */
  async paymentReceived(payment, customer, invoice = null) {
    return this.trigger('payment_received', {
      payment: {
        id: payment.id,
        transactionId: payment.transactionId,
        amount: payment.amount,
        currency: payment.currency,
        method: payment.method,
        status: payment.status,
        processedAt: payment.processedAt,
      },
      customer: {
        id: customer.id,
        accountNumber: customer.accountNumber,
        firstName: customer.firstName,
        lastName: customer.lastName,
        email: customer.email,
        phone: customer.phone,
      },
      invoice: invoice ? {
        id: invoice.id,
        invoiceNumber: invoice.invoiceNumber,
        total: invoice.total,
        dueDate: invoice.dueDate,
      } : null,
    });
  }

  /**
   * Trigger invoice generated event
   */
  async invoiceGenerated(invoice, customer) {
    return this.trigger('invoice_generated', {
      invoice: {
        id: invoice.id,
        invoiceNumber: invoice.invoiceNumber,
        total: invoice.total,
        subtotal: invoice.subtotal,
        taxAmount: invoice.taxAmount,
        discountAmount: invoice.discountAmount,
        currency: invoice.currency,
        issueDate: invoice.issueDate,
        dueDate: invoice.dueDate,
        items: invoice.items,
      },
      customer: {
        id: customer.id,
        accountNumber: customer.accountNumber,
        firstName: customer.firstName,
        lastName: customer.lastName,
        email: customer.email,
        phone: customer.phone,
        address: customer.address,
        city: customer.city,
        country: customer.country,
      },
    });
  }

  /**
   * Trigger invoice overdue event
   */
  async invoiceOverdue(invoice, customer, daysOverdue) {
    return this.trigger('invoice_overdue', {
      invoice: {
        id: invoice.id,
        invoiceNumber: invoice.invoiceNumber,
        total: invoice.total,
        balanceDue: invoice.balanceDue,
        currency: invoice.currency,
        dueDate: invoice.dueDate,
        daysOverdue,
      },
      customer: {
        id: customer.id,
        accountNumber: customer.accountNumber,
        firstName: customer.firstName,
        lastName: customer.lastName,
        email: customer.email,
        phone: customer.phone,
      },
    });
  }

  /**
   * Trigger subscription cancelled event
   */
  async subscriptionCancelled(subscription, customer, reason) {
    return this.trigger('subscription_cancelled', {
      subscription: {
        id: subscription.id,
        planName: subscription.plan?.name,
        planPrice: subscription.plan?.price,
        startDate: subscription.startDate,
        endDate: subscription.endDate,
        cancellationReason: reason,
      },
      customer: {
        id: customer.id,
        accountNumber: customer.accountNumber,
        firstName: customer.firstName,
        lastName: customer.lastName,
        email: customer.email,
        phone: customer.phone,
        lifetimeValue: customer.lifetimeValue,
      },
    });
  }

  /**
   * Trigger support ticket created event
   */
  async supportTicketCreated(ticket, customer) {
    return this.trigger('support_ticket_created', {
      ticket: {
        id: ticket.id,
        ticketNumber: ticket.ticketNumber,
        subject: ticket.subject,
        description: ticket.description,
        category: ticket.category,
        priority: ticket.priority,
        status: ticket.status,
        createdAt: ticket.createdAt,
      },
      customer: {
        id: customer.id,
        accountNumber: customer.accountNumber,
        firstName: customer.firstName,
        lastName: customer.lastName,
        email: customer.email,
        phone: customer.phone,
      },
    });
  }

  /**
   * Trigger support ticket resolved event
   */
  async supportTicketResolved(ticket, customer) {
    return this.trigger('support_ticket_resolved', {
      ticket: {
        id: ticket.id,
        ticketNumber: ticket.ticketNumber,
        subject: ticket.subject,
        category: ticket.category,
        priority: ticket.priority,
        resolution: ticket.resolution,
        createdAt: ticket.createdAt,
        resolvedAt: ticket.resolvedAt,
        resolutionTime: ticket.resolvedAt 
          ? new Date(ticket.resolvedAt).getTime() - new Date(ticket.createdAt).getTime()
          : null,
      },
      customer: {
        id: customer.id,
        accountNumber: customer.accountNumber,
        firstName: customer.firstName,
        lastName: customer.lastName,
        email: customer.email,
      },
    });
  }

  /**
   * Trigger network outage event
   */
  async networkOutage(outage) {
    return this.trigger('network_outage', {
      outage: {
        id: outage.id,
        type: outage.type,
        affectedCustomers: outage.affectedCustomers,
        affectedAreas: outage.affectedAreas,
        startTime: outage.startTime,
        estimatedResolution: outage.estimatedResolution,
        description: outage.description,
      },
    });
  }

  /**
   * Trigger network restored event
   */
  async networkRestored(outage) {
    return this.trigger('network_restored', {
      outage: {
        id: outage.id,
        type: outage.type,
        affectedCustomers: outage.affectedCustomers,
        startTime: outage.startTime,
        endTime: outage.endTime,
        duration: outage.endTime 
          ? new Date(outage.endTime).getTime() - new Date(outage.startTime).getTime()
          : null,
      },
    });
  }

  /**
   * Trigger daily summary event
   */
  async dailySummary(stats) {
    return this.trigger('daily_summary', {
      date: new Date().toISOString().split('T')[0],
      stats: {
        newCustomers: stats.newCustomers,
        activeCustomers: stats.activeCustomers,
        revenue: stats.revenue,
        payments: stats.payments,
        ticketsCreated: stats.ticketsCreated,
        ticketsResolved: stats.ticketsResolved,
        networkUptime: stats.networkUptime,
        dataUsage: stats.dataUsage,
      },
    });
  }

  /**
   * Trigger custom event
   */
  async customEvent(eventName, data) {
    return this.trigger(eventName, data);
  }

  /**
   * Test Zapier connection
   */
  async testConnection() {
    return this.trigger('test', {
      message: 'Zapier integration test',
      timestamp: new Date().toISOString(),
    });
  }

  /**
   * Batch trigger multiple events
   */
  async batchTrigger(events) {
    const results = [];
    
    for (const { event, data, options } of events) {
      const result = await this.trigger(event, data, options);
      results.push({ event, result });
    }
    
    return {
      success: results.every(r => r.result.success),
      results,
    };
  }
}

// Export singleton instance
const zapierIntegration = new ZapierIntegration();

module.exports = {
  ZapierIntegration,
  zapierIntegration,
};
