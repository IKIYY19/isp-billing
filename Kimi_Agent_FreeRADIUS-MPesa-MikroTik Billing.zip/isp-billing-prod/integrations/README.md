# ISP Billing System - Integrations

This directory contains integration modules for connecting the ISP Billing System with third-party services and platforms.

## Available Integrations

### 1. Slack Integration (`slack-integration.js`)

Send notifications and alerts to Slack channels.

**Features:**
- New customer registration notifications
- Payment received alerts
- Support ticket notifications
- System alerts (critical/warning/info)
- Daily and weekly summary reports
- Rich message formatting with blocks

**Setup:**
1. Create a Slack app at https://api.slack.com/apps
2. Enable Incoming Webhooks
3. Copy the webhook URL
4. Set environment variable: `SLACK_WEBHOOK_URL=https://hooks.slack.com/services/...`

**Usage:**
```javascript
const { slackIntegration } = require('./integrations/slack-integration');

// Send notification
await slackIntegration.notifyNewCustomer(customer);
await slackIntegration.notifyPaymentReceived(payment, customer);
await slackIntegration.notifyTicketCreated(ticket, customer);
await slackIntegration.notifySystemAlert(alert);

// Send reports
await slackIntegration.sendDailyReport(stats);
await slackIntegration.sendWeeklyReport(stats);
```

### 2. Zapier Integration (`zapier-integration.js`)

Trigger Zapier webhooks for workflow automation.

**Features:**
- New customer triggers
- Payment received triggers
- Invoice generated/overdue triggers
- Subscription cancellation triggers
- Support ticket triggers
- Network outage/restored triggers
- Daily summary triggers
- Custom event triggers

**Setup:**
1. Create a Zapier account at https://zapier.com
2. Create a new Zap with Webhook trigger
3. Copy the webhook URL
4. Set environment variable: `ZAPIER_WEBHOOK_URL=https://hooks.zapier.com/hooks/catch/...`

**Usage:**
```javascript
const { zapierIntegration } = require('./integrations/zapier-integration');

// Trigger events
await zapierIntegration.newCustomer(customer, subscription);
await zapierIntegration.paymentReceived(payment, customer, invoice);
await zapierIntegration.invoiceGenerated(invoice, customer);
await zapierIntegration.supportTicketCreated(ticket, customer);

// Custom events
await zapierIntegration.customEvent('my_custom_event', { key: 'value' });
```

## Environment Variables

Create a `.env` file in the project root:

```env
# Slack Integration
SLACK_WEBHOOK_URL=https://hooks.slack.com/services/YOUR/WEBHOOK/URL
SLACK_BOT_TOKEN=xoxb-your-bot-token
SLACK_DEFAULT_CHANNEL=#general

# Zapier Integration
ZAPIER_WEBHOOK_URL=https://hooks.zapier.com/hooks/catch/your/webhook/url

# Admin URL (for action links)
ADMIN_URL=https://admin.yourdomain.com
```

## Testing Integrations

### Test Slack Connection
```bash
node -e "
const { slackIntegration } = require('./integrations/slack-integration');
slackIntegration.testConnection().then(console.log);
"
```

### Test Zapier Connection
```bash
node -e "
const { zapierIntegration } = require('./integrations/zapier-integration');
zapierIntegration.testConnection().then(console.log);
"
```

## Integration with Main Application

Add to your main application code:

```javascript
const { slackIntegration } = require('./integrations/slack-integration');
const { zapierIntegration } = require('./integrations/zapier-integration');

// After customer registration
app.post('/customers', async (req, res) => {
  const customer = await createCustomer(req.body);
  
  // Send notifications
  await slackIntegration.notifyNewCustomer(customer);
  await zapierIntegration.newCustomer(customer);
  
  res.json(customer);
});

// After payment received
app.post('/payments', async (req, res) => {
  const payment = await processPayment(req.body);
  const customer = await getCustomer(payment.customerId);
  
  // Send notifications
  await slackIntegration.notifyPaymentReceived(payment, customer);
  await zapierIntegration.paymentReceived(payment, customer);
  
  res.json(payment);
});
```

## Adding New Integrations

To add a new integration:

1. Create a new file: `integrations/[name]-integration.js`
2. Implement the integration class
3. Export the class and singleton instance
4. Add documentation to this README
5. Add environment variables to `.env.example`

## Troubleshooting

### Slack Not Receiving Messages
- Verify webhook URL is correct
- Check channel permissions
- Ensure bot has access to the channel
- Check Slack app settings for webhook restrictions

### Zapier Not Triggering
- Verify webhook URL is correct
- Check Zap is turned on in Zapier
- Review Zapier task history for errors
- Ensure payload format matches Zapier expectations

## Support

For integration support:
- Slack API Docs: https://api.slack.com/
- Zapier Webhook Docs: https://zapier.com/apps/webhook/integrations
