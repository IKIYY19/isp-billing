#!/bin/bash
# ============================================
# ISP Billing System - Quick Deploy Script
# ============================================

set -e

echo "🚀 Starting ISP Billing System deployment..."
echo ""

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo "❌ Docker is not installed. Please install Docker first."
    echo "   Visit: https://docs.docker.com/get-docker/"
    exit 1
fi

if ! command -v docker-compose &> /dev/null; then
    echo "❌ Docker Compose is not installed. Please install Docker Compose first."
    echo "   Visit: https://docs.docker.com/compose/install/"
    exit 1
fi

echo "✅ Docker and Docker Compose are installed"
echo ""

# Navigate to project directory
cd "$(dirname "$0")"

echo "📦 Building and starting services..."
echo ""

# Build and start services
docker-compose up -d --build

echo ""
echo "⏳ Waiting for services to be ready..."
sleep 15

echo ""
echo "========================================"
echo "  🎉 Deployment Complete!"
echo "========================================"
echo ""
echo "Your ISP Billing System is now running:"
echo ""
echo "  🌐 Web App:     http://localhost"
echo "  🔌 API:         http://localhost/api"
echo "  📊 Grafana:     http://localhost:3002"
echo "  📈 Prometheus:  http://localhost:9090"
echo ""
echo "Default Login Credentials:"
echo "  Email:    admin@isp.com"
echo "  Password: admin123"
echo ""
echo "Useful Commands:"
echo "  View logs:    docker-compose logs -f"
echo "  Stop:         docker-compose down"
echo "  Restart:      docker-compose restart"
echo ""
echo "========================================"
