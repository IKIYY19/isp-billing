# ISP Billing System - Production Deployment

Complete production-ready deployment package for the ISP Billing System with Docker, monitoring, backups, and SSL.

## 📁 Directory Structure

```
isp-billing-prod/
├── docker/
│   ├── docker-compose.yml      # Main orchestration file
│   ├── frontend.Dockerfile     # Frontend build
│   ├── backend.Dockerfile      # Backend build
│   └── .env.example            # Environment variables template
├── nginx/
│   ├── nginx.conf              # Main nginx config
│   └── conf.d/
│       └── default.conf        # Server blocks
├── monitoring/
│   ├── prometheus.yml          # Prometheus config
│   └── grafana/
│       ├── dashboards/
│       │   └── isp-billing-dashboard.json
│       └── datasources/
│           └── datasources.yml
├── backups/
│   ├── Dockerfile              # Backup service
│   └── backup.sh               # Backup script
└── scripts/
    ├── deploy.sh               # Main deployment script
    └── setup-ssl.sh            # SSL certificate setup
```

## 🚀 Quick Start

### 1. Server Requirements

- **OS**: Ubuntu 22.04 LTS (recommended)
- **RAM**: 4GB minimum, 8GB recommended
- **CPU**: 2 cores minimum
- **Storage**: 50GB SSD
- **Network**: Static IP, ports 80, 443 open

### 2. One-Command Deployment

```bash
# Download and run deployment script
curl -fsSL https://your-domain.com/deploy.sh | sudo bash

# Or clone and run manually
git clone https://github.com/yourusername/isp-billing.git
cd isp-billing/isp-billing-prod
sudo ./scripts/deploy.sh
```

### 3. Manual Deployment

```bash
# 1. Install dependencies
sudo apt update
sudo apt install -y docker.io docker-compose nginx certbot

# 2. Configure environment
cp docker/.env.example docker/.env
nano docker/.env  # Edit with your values

# 3. Start services
cd docker
docker-compose up -d

# 4. Setup SSL (replace with your domain)
sudo ./scripts/setup-ssl.sh billing.yourcompany.com admin@yourcompany.com
```

## ⚙️ Configuration

### Environment Variables (docker/.env)

```bash
# Database
DB_PASSWORD=your_secure_password

# JWT Secret (generate with: openssl rand -base64 32)
JWT_SECRET=your-super-secret-key

# M-Pesa (Get from https://developer.safaricom.co.ke/)
MPESA_CONSUMER_KEY=your_key
MPESA_CONSUMER_SECRET=your_secret
MPESA_PASSKEY=your_passkey

# Africa's Talking SMS (Get from https://account.africastalking.com/)
AFRICASTALKING_API_KEY=your_key
AFRICASTALKING_USERNAME=your_username

# Email (SMTP)
SMTP_HOST=smtp.gmail.com
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password

# AWS S3 (for backups)
AWS_ACCESS_KEY_ID=your_key
AWS_SECRET_ACCESS_KEY=your_secret
AWS_S3_BUCKET=your-backup-bucket

# Domain
DOMAIN=billing.yourcompany.com
EMAIL=admin@yourcompany.com
```

## 📊 Access Points

| Service | URL | Description |
|---------|-----|-------------|
| **Main App** | https://your-domain.com | ISP Billing Dashboard |
| **API** | https://your-domain.com/api | REST API |
| **Grafana** | http://localhost:3002 | Monitoring Dashboard |
| **Prometheus** | http://localhost:9090 | Metrics Collection |

## 🔄 Management Commands

```bash
# View logs
docker-compose -f docker/docker-compose.yml logs -f

# Restart services
docker-compose -f docker/docker-compose.yml restart

# Update to latest version
sudo ./scripts/deploy.sh update

# Rollback to previous version
sudo ./scripts/deploy.sh rollback

# Manual backup
sudo ./scripts/deploy.sh backup

# Check SSL status
ssl-status your-domain.com
```

## 📈 Monitoring

### Grafana Dashboard

Default login: `admin` / `admin` (change on first login)

Pre-configured dashboards:
- System Overview (CPU, Memory, Disk)
- Application Metrics (Request rate, Response time)
- Database Metrics (Connections, Queries)

### Prometheus Metrics

Available at: http://localhost:9090

Key metrics:
- `up{job="backend"}` - Backend health
- `http_requests_total` - Total HTTP requests
- `http_request_duration_seconds` - Response times
- `node_cpu_seconds_total` - CPU usage
- `node_memory_MemAvailable_bytes` - Memory usage

## 💾 Backup & Recovery

### Automatic Backups

- Daily at 2:00 AM
- 30-day retention
- Local + S3 storage

### Manual Backup

```bash
# Run backup immediately
docker exec isp-backup /scripts/backup.sh

# Or use the script
sudo /opt/isp-billing/backup.sh
```

### Restore from Backup

```bash
# 1. Stop services
docker-compose -f docker/docker-compose.yml down

# 2. Restore database
docker exec -i isp-postgres psql -U isp_user isp_billing < backup_file.sql

# 3. Start services
docker-compose -f docker/docker-compose.yml up -d
```

## 🔒 Security

### SSL/TLS

- Let's Encrypt certificates (auto-renewal)
- TLS 1.2+ only
- HSTS enabled
- Security headers configured

### Firewall

```bash
# Allow only necessary ports
sudo ufw allow 22/tcp    # SSH
sudo ufw allow 80/tcp    # HTTP
sudo ufw allow 443/tcp   # HTTPS
sudo ufw enable
```

### Database Security

- PostgreSQL not exposed externally
- Strong passwords required
- Regular backups

## 🐛 Troubleshooting

### Services Won't Start

```bash
# Check logs
docker-compose -f docker/docker-compose.yml logs

# Check disk space
df -h

# Restart all
docker-compose -f docker/docker-compose.yml down
docker-compose -f docker/docker-compose.yml up -d
```

### Database Connection Issues

```bash
# Check PostgreSQL status
docker exec isp-postgres pg_isready -U isp_user

# Reset database (WARNING: data loss)
docker-compose -f docker/docker-compose.yml down -v
docker-compose -f docker/docker-compose.yml up -d
```

### SSL Certificate Issues

```bash
# Check certificate status
ssl-status your-domain.com

# Renew manually
sudo certbot renew --force-renewal

# Test renewal
sudo certbot renew --dry-run
```

## 📞 Support

- **Documentation**: https://docs.your-domain.com
- **Issues**: https://github.com/yourusername/isp-billing/issues
- **Email**: support@your-domain.com

## 📄 License

MIT License - See LICENSE file for details
