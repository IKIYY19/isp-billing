#!/bin/bash

# ISP Billing System - Production Deployment Script
# Usage: ./deploy.sh [environment]
# Example: ./deploy.sh production

set -e

ENV=${1:-production}
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

echo "======================================"
echo "ISP Billing System Deployment"
echo "Environment: $ENV"
echo "======================================"
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Helper functions
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check prerequisites
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    # Check Docker
    if ! command -v docker &> /dev/null; then
        log_error "Docker is not installed"
        exit 1
    fi
    
    # Check Docker Compose
    if ! command -v docker-compose &> /dev/null; then
        log_error "Docker Compose is not installed"
        exit 1
    fi
    
    # Check .env file
    if [ ! -f "$PROJECT_DIR/.env" ]; then
        log_warn ".env file not found. Copying from .env.example..."
        cp "$PROJECT_DIR/.env.example" "$PROJECT_DIR/.env"
        log_warn "Please edit .env file with your configuration before continuing"
        exit 1
    fi
    
    log_info "Prerequisites check passed"
}

# Create required directories
setup_directories() {
    log_info "Setting up directories..."
    
    mkdir -p "$PROJECT_DIR/logs"
    mkdir -p "$PROJECT_DIR/backups"
    mkdir -p "$PROJECT_DIR/uploads"
    mkdir -p "$PROJECT_DIR/nginx/ssl"
    
    log_info "Directories created"
}

# Pull latest images
pull_images() {
    log_info "Pulling Docker images..."
    
    cd "$PROJECT_DIR"
    docker-compose pull
    
    log_info "Images pulled successfully"
}

# Build custom images
build_images() {
    log_info "Building custom images..."
    
    cd "$PROJECT_DIR"
    docker-compose build --no-cache
    
    log_info "Images built successfully"
}

# Start services
start_services() {
    log_info "Starting services..."
    
    cd "$PROJECT_DIR"
    
    if [ "$ENV" == "production" ]; then
        docker-compose up -d
    else
        docker-compose -f docker-compose.yml -f docker-compose.dev.yml up -d
    fi
    
    log_info "Services started"
}

# Wait for database
wait_for_database() {
    log_info "Waiting for database to be ready..."
    
    cd "$PROJECT_DIR"
    
    for i in {1..30}; do
        if docker-compose exec -T postgres pg_isready -U postgres > /dev/null 2>&1; then
            log_info "Database is ready"
            return 0
        fi
        echo -n "."
        sleep 2
    done
    
    log_error "Database failed to start"
    exit 1
}

# Run migrations
run_migrations() {
    log_info "Running database migrations..."
    
    cd "$PROJECT_DIR"
    docker-compose exec -T api npm run migrate
    
    log_info "Migrations completed"
}

# Seed data (optional)
seed_data() {
    log_info "Seeding database..."
    
    cd "$PROJECT_DIR"
    docker-compose exec -T api npm run seed 2>/dev/null || log_warn "No seed data to run"
    
    log_info "Seeding completed"
}

# Health check
health_check() {
    log_info "Performing health check..."
    
    cd "$PROJECT_DIR"
    
    # Check API
    API_HEALTH=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:5000/health || echo "000")
    
    if [ "$API_HEALTH" == "200" ]; then
        log_info "API is healthy"
    else
        log_warn "API health check returned: $API_HEALTH"
    fi
    
    # Check frontend
    FRONTEND_HEALTH=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:80/health || echo "000")
    
    if [ "$FRONTEND_HEALTH" == "200" ]; then
        log_info "Frontend is healthy"
    else
        log_warn "Frontend health check returned: $FRONTEND_HEALTH"
    fi
}

# Display status
show_status() {
    log_info "Deployment Status:"
    echo ""
    
    cd "$PROJECT_DIR"
    docker-compose ps
    
    echo ""
    log_info "Services are running at:"
    echo "  - Frontend: http://localhost"
    echo "  - API: http://localhost:5000"
    echo "  - API Health: http://localhost:5000/health"
    
    if [ "$ENV" == "production" ]; then
        echo ""
        log_info "Monitoring (if enabled):"
        echo "  - Prometheus: http://localhost:9090"
        echo "  - Grafana: http://localhost:3000"
    fi
}

# Setup SSL (Let's Encrypt)
setup_ssl() {
    log_info "Setting up SSL certificate..."
    
    DOMAIN=$(grep -E "^DOMAIN=" "$PROJECT_DIR/.env" | cut -d= -f2 || echo "")
    
    if [ -z "$DOMAIN" ]; then
        log_warn "DOMAIN not set in .env, skipping SSL setup"
        return
    fi
    
    if command -v certbot &> /dev/null; then
        certbot certonly --standalone -d "$DOMAIN" --agree-tos --non-interactive --email admin@$DOMAIN 2>/dev/null || {
            log_warn "SSL certificate generation failed. You may need to generate it manually."
        }
        
        # Copy certificates
        cp "/etc/letsencrypt/live/$DOMAIN/fullchain.pem" "$PROJECT_DIR/nginx/ssl/" 2>/dev/null || true
        cp "/etc/letsencrypt/live/$DOMAIN/privkey.pem" "$PROJECT_DIR/nginx/ssl/" 2>/dev/null || true
    else
        log_warn "Certbot not installed, skipping SSL setup"
    fi
}

# Setup backup cron job
setup_backup() {
    log_info "Setting up backup schedule..."
    
    # Add backup cron job
    (crontab -l 2>/dev/null | grep -v "isp-billing-backup"; echo "0 2 * * * $PROJECT_DIR/scripts/backup.sh >> /var/log/isp-billing-backup.log 2>&1") | crontab -
    
    log_info "Backup scheduled for 02:00 daily"
}

# Rollback function
rollback() {
    log_error "Deployment failed! Rolling back..."
    
    cd "$PROJECT_DIR"
    docker-compose down
    
    log_info "Rollback completed"
    exit 1
}

# Main deployment flow
main() {
    trap rollback ERR
    
    check_prerequisites
    setup_directories
    
    if [ "$ENV" == "production" ]; then
        pull_images
        build_images
    fi
    
    start_services
    wait_for_database
    run_migrations
    seed_data
    
    if [ "$ENV" == "production" ]; then
        setup_ssl
        setup_backup
    fi
    
    sleep 5
    health_check
    
    echo ""
    log_info "Deployment completed successfully!"
    echo ""
    show_status
}

# Execute
main
