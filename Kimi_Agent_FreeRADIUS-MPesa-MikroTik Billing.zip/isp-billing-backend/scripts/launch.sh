#!/bin/bash

# ISP Billing System - Launch Script
# This script helps you deploy the ISP Billing System to production
# Supports: Docker Compose, Docker Swarm, and Kubernetes

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
DEPLOYMENT_TYPE="${1:-compose}"
DOMAIN="${2:-}"

# Logging functions
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

log_step() {
    echo -e "${BLUE}[STEP]${NC} $1"
}

# Print banner
print_banner() {
    echo ""
    echo "╔══════════════════════════════════════════════════════════════╗"
    echo "║                                                              ║"
    echo "║           ISP BILLING SYSTEM - PRODUCTION LAUNCH             ║"
    echo "║                                                              ║"
    echo "╚══════════════════════════════════════════════════════════════╝"
    echo ""
    echo "Deployment Type: $DEPLOYMENT_TYPE"
    echo "Project Directory: $PROJECT_DIR"
    echo ""
}

# Check prerequisites
check_prerequisites() {
    log_step "Checking prerequisites..."
    
    # Check Docker
    if ! command -v docker &> /dev/null; then
        log_error "Docker is not installed. Please install Docker first."
        log_info "Visit: https://docs.docker.com/get-docker/"
        exit 1
    fi
    log_info "✓ Docker installed"
    
    # Check Docker Compose
    if ! command -v docker-compose &> /dev/null; then
        log_error "Docker Compose is not installed."
        exit 1
    fi
    log_info "✓ Docker Compose installed"
    
    # Check environment file
    if [ ! -f "$PROJECT_DIR/.env" ]; then
        log_warn ".env file not found!"
        log_info "Creating from .env.example..."
        cp "$PROJECT_DIR/.env.example" "$PROJECT_DIR/.env"
        log_warn "⚠ Please edit $PROJECT_DIR/.env with your configuration before continuing!"
        exit 1
    fi
    log_info "✓ Environment file exists"
    
    # Check frontend build
    if [ ! -d "$PROJECT_DIR/frontend/dist" ]; then
        log_warn "Frontend build not found!"
        log_info "Building frontend..."
        mkdir -p "$PROJECT_DIR/frontend/dist"
        
        # Check if app dist exists
        if [ -d "/mnt/okcomputer/output/app/dist" ]; then
            cp -r /mnt/okcomputer/output/app/dist/* "$PROJECT_DIR/frontend/dist/"
            log_info "✓ Frontend copied from build"
        else
            log_error "Frontend build not available. Please build the frontend first."
            exit 1
        fi
    fi
    log_info "✓ Frontend build exists"
}

# Setup SSL certificates
setup_ssl() {
    log_step "Setting up SSL certificates..."
    
    if [ -z "$DOMAIN" ]; then
        log_warn "Domain not specified. Skipping SSL setup."
        log_info "To enable SSL, run: $0 $DEPLOYMENT_TYPE your-domain.com"
        return
    fi
    
    # Create SSL directory
    mkdir -p "$PROJECT_DIR/nginx/ssl"
    
    # Check if certbot is available
    if command -v certbot &> /dev/null; then
        log_info "Obtaining SSL certificate for $DOMAIN..."
        
        # Stop any service on port 80
        docker-compose -f "$PROJECT_DIR/docker-compose.yml" down 2>/dev/null || true
        
        # Obtain certificate
        if certbot certonly --standalone -d "$DOMAIN" --agree-tos --non-interactive --email "admin@$DOMAIN" 2>/dev/null; then
            # Copy certificates
            cp "/etc/letsencrypt/live/$DOMAIN/fullchain.pem" "$PROJECT_DIR/nginx/ssl/"
            cp "/etc/letsencrypt/live/$DOMAIN/privkey.pem" "$PROJECT_DIR/nginx/ssl/"
            log_info "✓ SSL certificates installed"
        else
            log_warn "Failed to obtain SSL certificate automatically"
            log_info "Please obtain certificates manually and place them in:"
            log_info "  - $PROJECT_DIR/nginx/ssl/fullchain.pem"
            log_info "  - $PROJECT_DIR/nginx/ssl/privkey.pem"
        fi
    else
        log_warn "Certbot not installed. Please install it or provide certificates manually."
    fi
}

# Deploy with Docker Compose
deploy_compose() {
    log_step "Deploying with Docker Compose..."
    
    cd "$PROJECT_DIR"
    
    # Create necessary directories
    mkdir -p logs backups uploads
    
    # Pull latest images
    log_info "Pulling Docker images..."
    docker-compose pull
    
    # Build custom images
    log_info "Building custom images..."
    docker-compose build --no-cache
    
    # Start services
    log_info "Starting services..."
    docker-compose up -d
    
    # Wait for database
    log_info "Waiting for database to be ready..."
    for i in {1..30}; do
        if docker-compose exec -T postgres pg_isready -U postgres > /dev/null 2>&1; then
            log_info "✓ Database is ready"
            break
        fi
        echo -n "."
        sleep 2
    done
    
    # Run migrations
    log_info "Running database migrations..."
    docker-compose exec -T api npm run migrate || log_warn "Migration may have already run"
    
    log_info "✓ Docker Compose deployment complete!"
}

# Deploy with Docker Swarm
deploy_swarm() {
    log_step "Deploying with Docker Swarm..."
    
    cd "$PROJECT_DIR/docker-swarm"
    
    # Check if swarm is initialized
    if ! docker info --format '{{.Swarm.LocalNodeState}}' | grep -q "active"; then
        log_info "Initializing Docker Swarm..."
        docker swarm init --advertise-addr $(hostname -i | awk '{print $1}')
    fi
    
    # Create necessary directories
    mkdir -p ../logs ../backups ../uploads
    
    # Deploy stack
    log_info "Deploying stack..."
    docker stack deploy -c docker-compose.yml isp-billing
    
    # Wait for services
    log_info "Waiting for services to be ready..."
    sleep 30
    
    log_info "✓ Docker Swarm deployment complete!"
    log_info ""
    log_info "Services status:"
    docker service ls | grep isp-billing
}

# Deploy with Kubernetes
deploy_kubernetes() {
    log_step "Deploying with Kubernetes..."
    
    # Check kubectl
    if ! command -v kubectl &> /dev/null; then
        log_error "kubectl not found. Please install kubectl."
        exit 1
    fi
    
    cd "$PROJECT_DIR/k8s"
    
    # Apply configurations
    log_info "Creating namespace..."
    kubectl apply -f namespace.yml
    
    log_info "Creating ConfigMap and Secrets..."
    kubectl apply -f configmap.yml
    
    log_info "Deploying PostgreSQL and Redis..."
    kubectl apply -f postgres.yml
    
    log_info "Deploying API..."
    kubectl apply -f api-deployment.yml
    
    log_info "Deploying Workers..."
    kubectl apply -f worker.yml
    
    log_info "Deploying Ingress..."
    kubectl apply -f ingress.yml
    
    # Wait for deployments
    log_info "Waiting for deployments to be ready..."
    kubectl wait --for=condition=available --timeout=300s deployment/isp-billing-api -n isp-billing || true
    
    log_info "✓ Kubernetes deployment complete!"
    log_info ""
    log_info "Pod status:"
    kubectl get pods -n isp-billing
}

# Health check
health_check() {
    log_step "Performing health checks..."
    
    case $DEPLOYMENT_TYPE in
        compose)
            cd "$PROJECT_DIR"
            API_HEALTH=$(docker-compose exec -T api wget -qO- http://localhost:5000/health 2>/dev/null || echo "FAILED")
            if [ "$API_HEALTH" == "FAILED" ]; then
                log_warn "API health check failed"
            else
                log_info "✓ API is healthy"
            fi
            ;;
        swarm)
            API_HEALTH=$(docker run --rm --network host curlimages/curl -s http://localhost:5000/health 2>/dev/null || echo "FAILED")
            if [ "$API_HEALTH" == "FAILED" ]; then
                log_warn "API health check failed"
            else
                log_info "✓ API is healthy"
            fi
            ;;
        k8s)
            API_POD=$(kubectl get pod -n isp-billing -l app=isp-billing-api -o jsonpath='{.items[0].metadata.name}' 2>/dev/null)
            if [ -n "$API_POD" ]; then
                kubectl exec -n isp-billing "$API_POD" -- wget -qO- http://localhost:5000/health 2>/dev/null || log_warn "API health check failed"
            fi
            ;;
    esac
}

# Print access information
print_access_info() {
    log_step "Access Information"
    echo ""
    echo "═══════════════════════════════════════════════════════════════"
    echo ""
    
    case $DEPLOYMENT_TYPE in
        compose)
            echo "  🌐 Frontend: http://localhost"
            echo "  🔌 API:      http://localhost:5000"
            echo "  📊 Health:   http://localhost:5000/health"
            echo ""
            echo "  Grafana:    http://localhost:3000 (admin/admin)"
            echo "  Prometheus: http://localhost:9090"
            ;;
        swarm)
            echo "  🌐 Frontend: http://$DOMAIN (or any node IP)"
            echo "  🔌 API:      https://$DOMAIN/api"
            echo "  📊 Health:   https://$DOMAIN/health"
            echo ""
            echo "  Traefik:    http://$NODE_IP:8080"
            if [ -n "$DOMAIN" ]; then
                echo "  Grafana:    https://grafana.$DOMAIN"
                echo "  Prometheus: https://prometheus.$DOMAIN"
            fi
            ;;
        k8s)
            echo "  🌐 Frontend: https://app.your-domain.com"
            echo "  🔌 API:      https://api.your-domain.com"
            echo ""
            echo "  Grafana:    https://grafana.your-domain.com"
            echo "  Prometheus: https://prometheus.your-domain.com"
            ;;
    esac
    
    echo ""
    echo "═══════════════════════════════════════════════════════════════"
    echo ""
}

# Main function
main() {
    print_banner
    check_prerequisites
    
    case $DEPLOYMENT_TYPE in
        compose)
            deploy_compose
            ;;
        swarm)
            deploy_swarm
            ;;
        k8s|kubernetes)
            deploy_kubernetes
            ;;
        *)
            log_error "Unknown deployment type: $DEPLOYMENT_TYPE"
            log_info "Usage: $0 [compose|swarm|k8s] [domain]"
            exit 1
            ;;
    esac
    
    setup_ssl
    health_check
    print_access_info
    
    log_info "🎉 Deployment complete! Your ISP Billing System is now running."
    log_info ""
    log_info "Next steps:"
    log_info "  1. Access the application using the URLs above"
    log_info "  2. Create your admin user"
    log_info "  3. Configure your first router"
    log_info "  4. Add your M-Pesa credentials"
    log_info ""
    log_info "For support, refer to the documentation in the docs/ folder."
}

# Show help
show_help() {
    echo "ISP Billing System - Launch Script"
    echo ""
    echo "Usage: $0 [compose|swarm|k8s] [domain]"
    echo ""
    echo "Options:"
    echo "  compose  - Deploy with Docker Compose (single server)"
    echo "  swarm    - Deploy with Docker Swarm (multi-server cluster)"
    echo "  k8s      - Deploy with Kubernetes (enterprise scale)"
    echo ""
    echo "Examples:"
    echo "  $0 compose                    # Single server deployment"
    echo "  $0 swarm billing.yourisp.com  # Swarm with SSL"
    echo "  $0 k8s                        # Kubernetes deployment"
    echo ""
}

# Handle help
if [ "$1" == "-h" ] || [ "$1" == "--help" ]; then
    show_help
    exit 0
fi

# Run main
main
