import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { AppError } from './errorHandler';
import { cache } from '../config/redis';
import { logger } from '../utils/logger';

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';
const JWT_REFRESH_SECRET = process.env.JWT_REFRESH_SECRET || JWT_SECRET + '-refresh';

export interface AuthUser {
  id: string;
  email: string;
  role: 'admin' | 'manager' | 'support' | 'technician' | 'agent' | 'customer';
  permissions: string[];
  companyId?: string;
}

declare global {
  namespace Express {
    interface Request {
      user?: AuthUser;
      token?: string;
    }
  }
}

/**
 * Generate JWT tokens (access and refresh)
 */
export const generateTokens = (user: Omit<AuthUser, 'iat' | 'exp'> & { id: string }) => {
  const accessToken = jwt.sign(
    {
      id: user.id,
      email: user.email,
      role: user.role,
      permissions: user.permissions || [],
      companyId: user.companyId
    },
    JWT_SECRET,
    { 
      expiresIn: '15m',
      issuer: 'isp-billing-api',
      audience: 'isp-billing-client'
    }
  );

  const refreshToken = jwt.sign(
    { id: user.id, type: 'refresh' },
    JWT_REFRESH_SECRET,
    { 
      expiresIn: '7d',
      issuer: 'isp-billing-api'
    }
  );

  // Store refresh token in cache
  storeRefreshToken(user.id, refreshToken);

  return { 
    accessToken, 
    refreshToken,
    expiresIn: 900 // 15 minutes in seconds
  };
};

/**
 * Store refresh token in Redis cache
 */
const storeRefreshToken = async (userId: string, token: string): Promise<void> => {
  try {
    await cache.set(`refresh:${userId}`, {
      token,
      createdAt: new Date().toISOString()
    }, 7 * 24 * 60 * 60); // 7 days
  } catch (error) {
    logger.error('Error storing refresh token:', error);
  }
};

/**
 * Verify JWT access token
 */
export const verifyAccessToken = (token: string): AuthUser | null => {
  try {
    return jwt.verify(token, JWT_SECRET) as AuthUser;
  } catch (error) {
    return null;
  }
};

/**
 * Verify JWT refresh token
 */
export const verifyRefreshToken = async (token: string): Promise<{ valid: boolean; userId?: string }> => {
  try {
    const decoded = jwt.verify(token, JWT_REFRESH_SECRET) as { id: string; type: string };
    
    if (decoded.type !== 'refresh') {
      return { valid: false };
    }

    // Check if token exists in cache
    const stored = await cache.get<{ token: string }>(`refresh:${decoded.id}`);
    
    if (!stored || stored.token !== token) {
      return { valid: false };
    }

    return { valid: true, userId: decoded.id };
  } catch (error) {
    return { valid: false };
  }
};

/**
 * Authentication middleware - validates JWT token
 */
export const authenticate = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      throw new AppError('Authentication required. Please provide a valid token.', 401, 'UNAUTHORIZED');
    }

    const token = authHeader.substring(7);

    // Check if token is blacklisted
    const isBlacklisted = await cache.get(`blacklist:${token}`);
    if (isBlacklisted) {
      throw new AppError('Token has been revoked. Please login again.', 401, 'TOKEN_REVOKED');
    }

    // Verify token
    const decoded = verifyAccessToken(token);

    if (!decoded) {
      throw new AppError('Invalid or expired token. Please login again.', 401, 'INVALID_TOKEN');
    }

    // Check if user session exists
    const sessionKey = `session:${decoded.id}`;
    const session = await cache.get(sessionKey);

    if (!session) {
      throw new AppError('Session expired. Please login again.', 401, 'SESSION_EXPIRED');
    }

    // Attach user to request
    req.user = decoded;
    req.token = token;

    next();
  } catch (error) {
    if (error instanceof AppError) {
      return next(error);
    }
    next(new AppError('Authentication failed', 401, 'AUTH_FAILED'));
  }
};

/**
 * Optional authentication - doesn't fail if no token
 */
export const optionalAuth = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const authHeader = req.headers.authorization;

    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.substring(7);
      const decoded = verifyAccessToken(token);
      
      if (decoded) {
        req.user = decoded;
        req.token = token;
      }
    }

    next();
  } catch (error) {
    // Continue without auth
    next();
  }
};

/**
 * Role-based authorization middleware
 */
export const authorize = (...allowedRoles: string[]) => {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) {
      return next(new AppError('Authentication required', 401, 'UNAUTHORIZED'));
    }

    if (!allowedRoles.includes(req.user.role)) {
      logger.warn('Unauthorized access attempt', {
        userId: req.user.id,
        role: req.user.role,
        requiredRoles: allowedRoles,
        url: req.originalUrl,
        method: req.method
      });
      return next(new AppError('Insufficient permissions', 403, 'FORBIDDEN'));
    }

    next();
  };
};

/**
 * Permission-based authorization middleware
 */
export const requirePermission = (...requiredPermissions: string[]) => {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) {
      return next(new AppError('Authentication required', 401, 'UNAUTHORIZED'));
    }

    // Admin has all permissions
    if (req.user.role === 'admin') {
      return next();
    }

    const hasPermission = requiredPermissions.every(permission =>
      req.user!.permissions.includes(permission)
    );

    if (!hasPermission) {
      logger.warn('Permission denied', {
        userId: req.user.id,
        permissions: req.user.permissions,
        requiredPermissions,
        url: req.originalUrl
      });
      return next(new AppError('Insufficient permissions', 403, 'FORBIDDEN'));
    }

    next();
  };
};

/**
 * Company/tenant isolation middleware
 */
export const requireCompanyAccess = (req: Request, res: Response, next: NextFunction) => {
  if (!req.user) {
    return next(new AppError('Authentication required', 401, 'UNAUTHORIZED'));
    }

  // Admin can access all companies
  if (req.user.role === 'admin') {
    return next();
  }

  // Check if user has company assigned
  if (!req.user.companyId) {
    return next(new AppError('Company access required', 403, 'COMPANY_REQUIRED'));
  }

  // If company ID is in params/body, verify access
  const requestedCompanyId = req.params.companyId || req.body.companyId || req.query.companyId;
  
  if (requestedCompanyId && requestedCompanyId !== req.user.companyId) {
    logger.warn('Cross-company access attempt', {
      userId: req.user.id,
      userCompanyId: req.user.companyId,
      requestedCompanyId
    });
    return next(new AppError('Access denied for this company', 403, 'COMPANY_ACCESS_DENIED'));
  }

  next();
};

/**
 * API key authentication for external integrations
 */
export const apiKeyAuth = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const apiKey = req.headers['x-api-key'] as string;

    if (!apiKey) {
      throw new AppError('API key required', 401, 'API_KEY_REQUIRED');
    }

    // Validate API key from cache/database
    const keyData = await cache.get(`apikey:${apiKey}`);

    if (!keyData) {
      throw new AppError('Invalid API key', 401, 'INVALID_API_KEY');
    }

    // Attach API key info to request
    (req as any).apiKey = keyData;

    next();
  } catch (error) {
    next(error);
  }
};

/**
 * Rate limiting helper for auth endpoints
 */
export const authRateLimit = async (identifier: string, maxAttempts: number = 5, windowSeconds: number = 900): Promise<{ allowed: boolean; remaining: number; resetTime?: number }> => {
  const key = `auth:ratelimit:${identifier}`;
  
  try {
    const current = await cache.get<{ count: number; firstAttempt: number }>(key);
    
    const now = Date.now();
    
    if (!current) {
      // First attempt
      await cache.set(key, { count: 1, firstAttempt: now }, windowSeconds);
      return { allowed: true, remaining: maxAttempts - 1 };
    }
    
    // Check if window has expired
    if (now - current.firstAttempt > windowSeconds * 1000) {
      await cache.set(key, { count: 1, firstAttempt: now }, windowSeconds);
      return { allowed: true, remaining: maxAttempts - 1 };
    }
    
    // Increment count
    const newCount = current.count + 1;
    await cache.set(key, { count: newCount, firstAttempt: current.firstAttempt }, windowSeconds);
    
    if (newCount > maxAttempts) {
      const resetTime = current.firstAttempt + (windowSeconds * 1000);
      return { allowed: false, remaining: 0, resetTime };
    }
    
    return { allowed: true, remaining: maxAttempts - newCount };
  } catch (error) {
    logger.error('Rate limit check error:', error);
    // Allow on error to prevent lockouts
    return { allowed: true, remaining: 1 };
  }
};

/**
 * Logout handler - revoke tokens
 */
export const logout = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const token = req.token;
    const userId = req.user?.id;

    if (token) {
      // Blacklist token (store until original expiry)
      const decoded = jwt.decode(token) as { exp?: number };
      if (decoded?.exp) {
        const ttl = decoded.exp - Math.floor(Date.now() / 1000);
        if (ttl > 0) {
          await cache.set(`blacklist:${token}`, { revokedAt: new Date().toISOString() }, ttl);
        }
      }
    }

    if (userId) {
      // Clear session
      await cache.del(`session:${userId}`);
      // Clear refresh token
      await cache.del(`refresh:${userId}`);
    }

    logger.info('User logged out', { userId });

    res.json({
      success: true,
      message: 'Logged out successfully'
    });
  } catch (error) {
    next(error);
  }
};

/**
 * Create user session
 */
export const createSession = async (userId: string, metadata?: any): Promise<string> => {
  const sessionId = `sess_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  
  await cache.set(`session:${userId}`, {
    sessionId,
    createdAt: new Date().toISOString(),
    ...metadata
  }, 24 * 60 * 60); // 24 hours
  
  return sessionId;
};

export default authenticate;
