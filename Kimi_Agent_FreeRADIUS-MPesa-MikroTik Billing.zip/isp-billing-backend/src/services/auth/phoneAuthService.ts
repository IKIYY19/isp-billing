import { database } from '../../config/database';
import { cache } from '../../config/redis';
import { logger } from '../../utils/logger';
import axios from 'axios';

export interface OTPConfig {
  codeLength: number;
  expiryMinutes: number;
  maxAttempts: number;
  cooldownMinutes: number;
}

export interface SMSServiceConfig {
  provider: 'africastalking' | 'twilio' | 'custom';
  apiKey: string;
  username?: string;
  senderId: string;
  apiUrl?: string;
}

export class PhoneAuthService {
  private config: OTPConfig = {
    codeLength: 6,
    expiryMinutes: 10,
    maxAttempts: 3,
    cooldownMinutes: 5
  };

  private smsConfig: SMSServiceConfig;

  constructor() {
    this.smsConfig = {
      provider: (process.env.SMS_PROVIDER as any) || 'africastalking',
      apiKey: process.env.SMS_API_KEY || '',
      username: process.env.SMS_USERNAME || '',
      senderId: process.env.SMS_SENDER_ID || 'ISP-BILLING',
      apiUrl: process.env.SMS_API_URL
    };
  }

  /**
   * Generate a random OTP code
   */
  private generateOTP(): string {
    const min = Math.pow(10, this.config.codeLength - 1);
    const max = Math.pow(10, this.config.codeLength) - 1;
    return Math.floor(min + Math.random() * (max - min + 1)).toString();
  }

  /**
   * Format phone number to international format
   */
  formatPhoneNumber(phone: string, countryCode: string = '254'): string {
    // Remove all non-numeric characters
    let cleaned = phone.replace(/\D/g, '');
    
    // Remove leading + if present
    cleaned = cleaned.replace(/^\+/, '');
    
    // If starts with 0, replace with country code
    if (cleaned.startsWith('0')) {
      cleaned = countryCode + cleaned.substring(1);
    }
    
    // If doesn't start with country code, add it
    if (!cleaned.startsWith(countryCode)) {
      cleaned = countryCode + cleaned;
    }
    
    return cleaned;
  }

  /**
   * Send OTP via SMS
   */
  async sendOTP(phoneNumber: string): Promise<{ success: boolean; message: string; trackingId?: string }> {
    try {
      const formattedPhone = this.formatPhoneNumber(phoneNumber);
      const cacheKey = `otp:${formattedPhone}`;
      const cooldownKey = `otp:cooldown:${formattedPhone}`;

      // Check cooldown
      const isInCooldown = await cache.get(cooldownKey);
      if (isInCooldown) {
        const remainingTime = await cache.ttl(cooldownKey);
        return {
          success: false,
          message: `Please wait ${remainingTime} seconds before requesting another OTP`
        };
      }

      // Generate OTP
      const otp = this.generateOTP();
      const trackingId = `OTP-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

      // Store OTP in cache
      await cache.set(cacheKey, {
        otp,
        attempts: 0,
        trackingId,
        createdAt: new Date().toISOString()
      }, this.config.expiryMinutes * 60);

      // Set cooldown
      await cache.set(cooldownKey, true, this.config.cooldownMinutes * 60);

      // Send SMS
      const smsResult = await this.sendSMS(formattedPhone, otp);

      if (smsResult.success) {
        logger.info('OTP sent successfully', {
          phoneNumber: formattedPhone,
          trackingId,
          provider: this.smsConfig.provider
        });

        return {
          success: true,
          message: 'OTP sent successfully',
          trackingId
        };
      } else {
        // Remove OTP from cache if SMS failed
        await cache.del(cacheKey);
        await cache.del(cooldownKey);

        return {
          success: false,
          message: `Failed to send OTP: ${smsResult.message}`
        };
      }
    } catch (error) {
      logger.error('Error sending OTP:', error);
      return {
        success: false,
        message: 'Internal error while sending OTP'
      };
    }
  }

  /**
   * Verify OTP
   */
  async verifyOTP(phoneNumber: string, code: string): Promise<{ success: boolean; message: string }> {
    try {
      const formattedPhone = this.formatPhoneNumber(phoneNumber);
      const cacheKey = `otp:${formattedPhone}`;

      const otpData = await cache.get<any>(cacheKey);

      if (!otpData) {
        return {
          success: false,
          message: 'OTP expired or not found. Please request a new one.'
        };
      }

      // Check max attempts
      if (otpData.attempts >= this.config.maxAttempts) {
        await cache.del(cacheKey);
        return {
          success: false,
          message: 'Maximum attempts exceeded. Please request a new OTP.'
        };
      }

      // Increment attempts
      otpData.attempts++;
      await cache.set(cacheKey, otpData, this.config.expiryMinutes * 60);

      // Verify code
      if (otpData.otp !== code) {
        const remainingAttempts = this.config.maxAttempts - otpData.attempts;
        return {
          success: false,
          message: `Invalid OTP. ${remainingAttempts} attempts remaining.`
        };
      }

      // OTP verified - clear from cache
      await cache.del(cacheKey);

      logger.info('OTP verified successfully', {
        phoneNumber: formattedPhone,
        trackingId: otpData.trackingId
      });

      return {
        success: true,
        message: 'OTP verified successfully'
      };
    } catch (error) {
      logger.error('Error verifying OTP:', error);
      return {
        success: false,
        message: 'Internal error while verifying OTP'
      };
    }
  }

  /**
   * Send SMS via configured provider
   */
  private async sendSMS(phoneNumber: string, otp: string): Promise<{ success: boolean; message: string }> {
    const message = `Your ISP Billing verification code is: ${otp}. Valid for ${this.config.expiryMinutes} minutes. Do not share this code.`;

    switch (this.smsConfig.provider) {
      case 'africastalking':
        return this.sendAfricaSTalking(phoneNumber, message);
      case 'twilio':
        return this.sendTwilio(phoneNumber, message);
      case 'custom':
        return this.sendCustomSMS(phoneNumber, message);
      default:
        // Development mode - log OTP instead of sending
        logger.info(`[DEV MODE] OTP for ${phoneNumber}: ${otp}`);
        return { success: true, message: 'OTP sent (development mode)' };
    }
  }

  /**
   * Send SMS via Africa's Talking
   */
  private async sendAfricaSTalking(phone: string, message: string): Promise<{ success: boolean; message: string }> {
    try {
      const response = await axios.post(
        'https://api.africastalking.com/version1/messaging',
        new URLSearchParams({
          username: this.smsConfig.username || '',
          to: phone,
          message: message,
          from: this.smsConfig.senderId
        }),
        {
          headers: {
            'apiKey': this.smsConfig.apiKey,
            'Content-Type': 'application/x-www-form-urlencoded',
            'Accept': 'application/json'
          }
        }
      );

      if (response.data.SMSMessageData && response.data.SMSMessageData.Recipients.length > 0) {
        const recipient = response.data.SMSMessageData.Recipients[0];
        if (recipient.status === 'Success') {
          return { success: true, message: 'SMS sent successfully' };
        } else {
          return { success: false, message: recipient.status };
        }
      }

      return { success: false, message: 'Unknown response from SMS provider' };
    } catch (error: any) {
      logger.error('Africa\'s Talking SMS error:', error.response?.data || error.message);
      return { success: false, message: error.response?.data?.message || error.message };
    }
  }

  /**
   * Send SMS via Twilio
   */
  private async sendTwilio(phone: string, message: string): Promise<{ success: boolean; message: string }> {
    try {
      const accountSid = process.env.TWILIO_ACCOUNT_SID;
      const authToken = process.env.TWILIO_AUTH_TOKEN;
      const fromNumber = process.env.TWILIO_PHONE_NUMBER;

      const response = await axios.post(
        `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`,
        new URLSearchParams({
          To: phone,
          From: fromNumber || '',
          Body: message
        }),
        {
          auth: {
            username: accountSid || '',
            password: authToken || ''
          },
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
          }
        }
      );

      if (response.data.sid) {
        return { success: true, message: 'SMS sent successfully' };
      }

      return { success: false, message: 'Failed to send SMS' };
    } catch (error: any) {
      logger.error('Twilio SMS error:', error.response?.data || error.message);
      return { success: false, message: error.response?.data?.message || error.message };
    }
  }

  /**
   * Send SMS via custom provider
   */
  private async sendCustomSMS(phone: string, message: string): Promise<{ success: boolean; message: string }> {
    try {
      if (!this.smsConfig.apiUrl) {
        return { success: false, message: 'Custom SMS API URL not configured' };
      }

      const response = await axios.post(
        this.smsConfig.apiUrl,
        {
          phone: phone,
          message: message,
          senderId: this.smsConfig.senderId
        },
        {
          headers: {
            'Authorization': `Bearer ${this.smsConfig.apiKey}`,
            'Content-Type': 'application/json'
          }
        }
      );

      if (response.data.success) {
        return { success: true, message: 'SMS sent successfully' };
      }

      return { success: false, message: response.data.message || 'Failed to send SMS' };
    } catch (error: any) {
      logger.error('Custom SMS error:', error.response?.data || error.message);
      return { success: false, message: error.response?.data?.message || error.message };
    }
  }

  /**
   * Check if phone number is registered
   */
  async isPhoneRegistered(phoneNumber: string): Promise<boolean> {
    const formattedPhone = this.formatPhoneNumber(phoneNumber);
    
    const user = await database('users')
      .where({ phone: formattedPhone })
      .orWhere({ phone: phoneNumber })
      .first();

    return !!user;
  }

  /**
   * Check if phone belongs to a customer
   */
  async isCustomerPhone(phoneNumber: string): Promise<{ isCustomer: boolean; customerId?: string }> {
    const formattedPhone = this.formatPhoneNumber(phoneNumber);
    
    const customer = await database('customers')
      .where({ phone: formattedPhone })
      .orWhere({ phone: phoneNumber })
      .first();

    return {
      isCustomer: !!customer,
      customerId: customer?.id
    };
  }
}

export const phoneAuthService = new PhoneAuthService();
