import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { database } from '../../config/database';
import { cache } from '../../config/redis';
import { logger } from '../../utils/logger';
import crypto from 'crypto';

export interface RegisterData {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  phone?: string;
  role?: string;
  companyId?: string;
}

export interface LoginData {
  email: string;
  password: string;
}

export interface TokenPayload {
  id: string;
  email: string;
  role: string;
  permissions: string[];
  companyId?: string;
  iat?: number;
  exp?: number;
}

export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
}

export class EmailAuthService {
  private readonly JWT_SECRET: string;
  private readonly JWT_REFRESH_SECRET: string;
  private readonly ACCESS_TOKEN_EXPIRY = '15m';
  private readonly REFRESH_TOKEN_EXPIRY = '7d';
  private readonly BCRYPT_ROUNDS = 12;

  constructor() {
    this.JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';
    this.JWT_REFRESH_SECRET = process.env.JWT_REFRESH_SECRET || this.JWT_SECRET + '-refresh';
  }

  /**
   * Hash password using bcrypt
   */
  async hashPassword(password: string): Promise<string> {
    return bcrypt.hash(password, this.BCRYPT_ROUNDS);
  }

  /**
   * Compare password with hash
   */
  async comparePassword(password: string, hash: string): Promise<boolean> {
    return bcrypt.compare(password, hash);
  }

  /**
   * Generate secure random token
   */
  generateSecureToken(length: number = 32): string {
    return crypto.randomBytes(length).toString('hex');
  }

  /**
   * Generate JWT tokens
   */
  generateTokens(payload: Omit<TokenPayload, 'iat' | 'exp'>): AuthTokens {
    const accessToken = jwt.sign(payload, this.JWT_SECRET, {
      expiresIn: this.ACCESS_TOKEN_EXPIRY,
      issuer: 'isp-billing-api',
      audience: 'isp-billing-client'
    });

    const refreshToken = jwt.sign(
      { id: payload.id, type: 'refresh' },
      this.JWT_REFRESH_SECRET,
      {
        expiresIn: this.REFRESH_TOKEN_EXPIRY,
        issuer: 'isp-billing-api'
      }
    );

    // Store refresh token in cache
    this.storeRefreshToken(payload.id, refreshToken);

    return {
      accessToken,
      refreshToken,
      expiresIn: 15 * 60 // 15 minutes in seconds
    };
  }

  /**
   * Store refresh token in cache
   */
  private async storeRefreshToken(userId: string, token: string): Promise<void> {
    const key = `refresh:${userId}`;
    await cache.set(key, {
      token,
      createdAt: new Date().toISOString()
    }, 7 * 24 * 60 * 60); // 7 days
  }

  /**
   * Verify refresh token
   */
  async verifyRefreshToken(token: string): Promise<{ valid: boolean; userId?: string }> {
    try {
      const decoded = jwt.verify(token, this.JWT_REFRESH_SECRET) as { id: string; type: string };
      
      if (decoded.type !== 'refresh') {
        return { valid: false };
      }

      // Check if token exists in cache
      const stored = await cache.get<{ token: string }>(`refresh:${decoded.id}`);
      
      if (!stored || stored.token !== token) {
        return { valid: false };
      }

      return { valid: true, userId: decoded.id };
    } catch (error) {
      return { valid: false };
    }
  }

  /**
   * Verify access token
   */
  verifyAccessToken(token: string): TokenPayload | null {
    try {
      return jwt.verify(token, this.JWT_SECRET) as TokenPayload;
    } catch (error) {
      return null;
    }
  }

  /**
   * Register new user with email/password
   */
  async register(data: RegisterData): Promise<{ success: boolean; user?: any; message?: string }> {
    try {
      // Check if email already exists
      const existingUser = await database('users')
        .where({ email: data.email.toLowerCase() })
        .first();

      if (existingUser) {
        return {
          success: false,
          message: 'Email already registered'
        };
      }

      // Check if phone already exists (if provided)
      if (data.phone) {
        const existingPhone = await database('users')
          .where({ phone: data.phone })
          .first();

        if (existingPhone) {
          return {
            success: false,
            message: 'Phone number already registered'
          };
        }
      }

      // Hash password
      const passwordHash = await this.hashPassword(data.password);

      // Create user
      const [user] = await database('users')
        .insert({
          email: data.email.toLowerCase(),
          password_hash: passwordHash,
          first_name: data.firstName,
          last_name: data.lastName,
          phone: data.phone,
          role: data.role || 'customer',
          company_id: data.companyId,
          status: 'active',
          email_verified_at: null,
          created_at: new Date(),
          updated_at: new Date()
        })
        .returning(['id', 'email', 'first_name', 'last_name', 'phone', 'role', 'company_id', 'status']);

      // Send verification email (async)
      this.sendVerificationEmail(user.id, user.email);

      logger.info('User registered successfully', {
        userId: user.id,
        email: user.email
      });

      return {
        success: true,
        user: {
          id: user.id,
          email: user.email,
          firstName: user.first_name,
          lastName: user.last_name,
          phone: user.phone,
          role: user.role,
          companyId: user.company_id,
          status: user.status
        }
      };
    } catch (error) {
      logger.error('Error registering user:', error);
      return {
        success: false,
        message: 'Internal error during registration'
      };
    }
  }

  /**
   * Login with email/password
   */
  async login(data: LoginData, ipAddress?: string, userAgent?: string): Promise<{ success: boolean; tokens?: AuthTokens; user?: any; message?: string }> {
    try {
      // Find user by email
      const user = await database('users')
        .where({ email: data.email.toLowerCase() })
        .first();

      if (!user) {
        return {
          success: false,
          message: 'Invalid email or password'
        };
      }

      // Check if account is active
      if (user.status !== 'active') {
        return {
          success: false,
          message: 'Account is not active. Please contact support.'
        };
      }

      // Verify password
      const isPasswordValid = await this.comparePassword(data.password, user.password_hash);

      if (!isPasswordValid) {
        // Log failed attempt
        this.logFailedLogin(user.id, ipAddress, userAgent);
        
        return {
          success: false,
          message: 'Invalid email or password'
        };
      }

      // Update last login
      await database('users')
        .where({ id: user.id })
        .update({
          last_login_at: new Date(),
          last_login_ip: ipAddress,
          updated_at: new Date()
        });

      // Generate tokens
      const tokens = this.generateTokens({
        id: user.id,
        email: user.email,
        role: user.role,
        permissions: user.permissions || [],
        companyId: user.company_id
      });

      // Store session
      await this.createSession(user.id, tokens.refreshToken, ipAddress, userAgent);

      logger.info('User logged in successfully', {
        userId: user.id,
        email: user.email,
        ipAddress
      });

      return {
        success: true,
        tokens,
        user: {
          id: user.id,
          email: user.email,
          firstName: user.first_name,
          lastName: user.last_name,
          phone: user.phone,
          role: user.role,
          companyId: user.company_id,
          emailVerified: !!user.email_verified_at
        }
      };
    } catch (error) {
      logger.error('Error during login:', error);
      return {
        success: false,
        message: 'Internal error during login'
      };
    }
  }

  /**
   * Create user session
   */
  private async createSession(userId: string, refreshToken: string, ipAddress?: string, userAgent?: string): Promise<void> {
    const sessionId = this.generateSecureToken(16);
    
    await cache.set(`session:${sessionId}`, {
      userId,
      refreshToken,
      ipAddress,
      userAgent,
      createdAt: new Date().toISOString()
    }, 7 * 24 * 60 * 60); // 7 days
  }

  /**
   * Log failed login attempt
   */
  private async logFailedLogin(userId: string, ipAddress?: string, userAgent?: string): Promise<void> {
    const key = `failed_login:${userId}`;
    const attempts = await cache.increment(key, 3600); // 1 hour window

    if (attempts >= 5) {
      // Lock account temporarily
      await database('users')
        .where({ id: userId })
        .update({ status: 'locked' });

      logger.warn('Account locked due to failed login attempts', {
        userId,
        attempts,
        ipAddress
      });
    }
  }

  /**
   * Send verification email
   */
  private async sendVerificationEmail(userId: string, email: string): Promise<void> {
    const token = this.generateSecureToken(32);
    const verificationKey = `email_verify:${token}`;
    
    await cache.set(verificationKey, { userId, email }, 24 * 60 * 60); // 24 hours

    // TODO: Integrate with email service
    logger.info('Email verification token generated', {
      userId,
      email,
      token: token.substring(0, 8) + '...'
    });
  }

  /**
   * Verify email
   */
  async verifyEmail(token: string): Promise<{ success: boolean; message: string }> {
    try {
      const verificationKey = `email_verify:${token}`;
      const data = await cache.get<{ userId: string; email: string }>(verificationKey);

      if (!data) {
        return {
          success: false,
          message: 'Invalid or expired verification token'
        };
      }

      await database('users')
        .where({ id: data.userId })
        .update({
          email_verified_at: new Date(),
          updated_at: new Date()
        });

      await cache.del(verificationKey);

      logger.info('Email verified successfully', {
        userId: data.userId,
        email: data.email
      });

      return {
        success: true,
        message: 'Email verified successfully'
      };
    } catch (error) {
      logger.error('Error verifying email:', error);
      return {
        success: false,
        message: 'Internal error during email verification'
      };
    }
  }

  /**
   * Request password reset
   */
  async requestPasswordReset(email: string): Promise<{ success: boolean; message: string }> {
    try {
      const user = await database('users')
        .where({ email: email.toLowerCase() })
        .first();

      if (!user) {
        // Don't reveal if email exists
        return {
          success: true,
          message: 'If the email exists, a reset link has been sent'
        };
      }

      const token = this.generateSecureToken(32);
      const resetKey = `password_reset:${token}`;
      
      await cache.set(resetKey, { userId: user.id, email }, 60 * 60); // 1 hour

      // TODO: Send email with reset link
      logger.info('Password reset token generated', {
        userId: user.id,
        email,
        token: token.substring(0, 8) + '...'
      });

      return {
        success: true,
        message: 'If the email exists, a reset link has been sent'
      };
    } catch (error) {
      logger.error('Error requesting password reset:', error);
      return {
        success: false,
        message: 'Internal error'
      };
    }
  }

  /**
   * Reset password
   */
  async resetPassword(token: string, newPassword: string): Promise<{ success: boolean; message: string }> {
    try {
      const resetKey = `password_reset:${token}`;
      const data = await cache.get<{ userId: string; email: string }>(resetKey);

      if (!data) {
        return {
          success: false,
          message: 'Invalid or expired reset token'
        };
      }

      const passwordHash = await this.hashPassword(newPassword);

      await database('users')
        .where({ id: data.userId })
        .update({
          password_hash: passwordHash,
          updated_at: new Date()
        });

      await cache.del(resetKey);

      // Invalidate all refresh tokens
      await cache.del(`refresh:${data.userId}`);

      logger.info('Password reset successfully', {
        userId: data.userId
      });

      return {
        success: true,
        message: 'Password reset successfully'
      };
    } catch (error) {
      logger.error('Error resetting password:', error);
      return {
        success: false,
        message: 'Internal error during password reset'
      };
    }
  }

  /**
   * Logout user
   */
  async logout(userId: string, refreshToken?: string): Promise<void> {
    try {
      // Remove refresh token
      if (refreshToken) {
        await cache.del(`refresh:${userId}`);
      }

      // TODO: Add token to blacklist

      logger.info('User logged out', { userId });
    } catch (error) {
      logger.error('Error during logout:', error);
    }
  }

  /**
   * Refresh access token
   */
  async refreshTokens(refreshToken: string): Promise<{ success: boolean; tokens?: AuthTokens; message?: string }> {
    try {
      const { valid, userId } = await this.verifyRefreshToken(refreshToken);

      if (!valid || !userId) {
        return {
          success: false,
          message: 'Invalid or expired refresh token'
        };
      }

      // Get user data
      const user = await database('users')
        .where({ id: userId })
        .first();

      if (!user || user.status !== 'active') {
        return {
          success: false,
          message: 'User not found or inactive'
        };
      }

      // Generate new tokens
      const tokens = this.generateTokens({
        id: user.id,
        email: user.email,
        role: user.role,
        permissions: user.permissions || [],
        companyId: user.company_id
      });

      return {
        success: true,
        tokens
      };
    } catch (error) {
      logger.error('Error refreshing tokens:', error);
      return {
        success: false,
        message: 'Internal error during token refresh'
      };
    }
  }
}

export const emailAuthService = new EmailAuthService();
