import { database } from '../../config/database';
import { cache } from '../../config/redis';
import { logger } from '../../utils/logger';
import axios from 'axios';
import crypto from 'crypto';

export interface OAuthProfile {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  picture?: string;
  provider: 'google' | 'microsoft' | 'apple';
  accessToken: string;
  refreshToken?: string;
}

export interface GoogleTokens {
  access_token: string;
  refresh_token?: string;
  id_token: string;
  expires_in: number;
}

export class OAuthService {
  private readonly GOOGLE_CLIENT_ID: string;
  private readonly GOOGLE_CLIENT_SECRET: string;
  private readonly GOOGLE_REDIRECT_URI: string;
  private readonly GOOGLE_AUTH_URL = 'https://accounts.google.com/o/oauth2/v2/auth';
  private readonly GOOGLE_TOKEN_URL = 'https://oauth2.googleapis.com/token';
  private readonly GOOGLE_USERINFO_URL = 'https://www.googleapis.com/oauth2/v2/userinfo';

  constructor() {
    this.GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID || '';
    this.GOOGLE_CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET || '';
    this.GOOGLE_REDIRECT_URI = process.env.GOOGLE_REDIRECT_URI || 'http://localhost:5000/api/auth/google/callback';
  }

  /**
   * Generate Google OAuth URL
   */
  getGoogleAuthUrl(state?: string): string {
    const params = new URLSearchParams({
      client_id: this.GOOGLE_CLIENT_ID,
      redirect_uri: this.GOOGLE_REDIRECT_URI,
      response_type: 'code',
      scope: [
        'openid',
        'email',
        'profile',
        'https://www.googleapis.com/auth/userinfo.email',
        'https://www.googleapis.com/auth/userinfo.profile'
      ].join(' '),
      access_type: 'offline',
      prompt: 'consent',
      state: state || this.generateState()
    });

    return `${this.GOOGLE_AUTH_URL}?${params.toString()}`;
  }

  /**
   * Generate random state parameter
   */
  private generateState(): string {
    return crypto.randomBytes(32).toString('hex');
  }

  /**
   * Store state in cache for verification
   */
  async storeState(state: string, data?: any): Promise<void> {
    await cache.set(`oauth:state:${state}`, {
      createdAt: new Date().toISOString(),
      data
    }, 10 * 60); // 10 minutes
  }

  /**
   * Verify state parameter
   */
  async verifyState(state: string): Promise<{ valid: boolean; data?: any }> {
    const stored = await cache.get<{ createdAt: string; data: any }>(`oauth:state:${state}`);
    
    if (!stored) {
      return { valid: false };
    }

    // Delete state after verification (one-time use)
    await cache.del(`oauth:state:${state}`);

    return { valid: true, data: stored.data };
  }

  /**
   * Exchange authorization code for tokens
   */
  async exchangeCodeForTokens(code: string): Promise<{ success: boolean; tokens?: GoogleTokens; message?: string }> {
    try {
      const response = await axios.post(
        this.GOOGLE_TOKEN_URL,
        new URLSearchParams({
          code,
          client_id: this.GOOGLE_CLIENT_ID,
          client_secret: this.GOOGLE_CLIENT_SECRET,
          redirect_uri: this.GOOGLE_REDIRECT_URI,
          grant_type: 'authorization_code'
        }),
        {
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
          }
        }
      );

      return {
        success: true,
        tokens: response.data
      };
    } catch (error: any) {
      logger.error('Error exchanging code for tokens:', error.response?.data || error.message);
      return {
        success: false,
        message: error.response?.data?.error_description || 'Failed to exchange authorization code'
      };
    }
  }

  /**
   * Get user profile from Google
   */
  async getGoogleProfile(accessToken: string): Promise<{ success: boolean; profile?: OAuthProfile; message?: string }> {
    try {
      const response = await axios.get(this.GOOGLE_USERINFO_URL, {
        headers: {
          Authorization: `Bearer ${accessToken}`
        }
      });

      const data = response.data;

      return {
        success: true,
        profile: {
          id: data.id,
          email: data.email,
          firstName: data.given_name || data.name?.split(' ')[0] || '',
          lastName: data.family_name || data.name?.split(' ').slice(1).join(' ') || '',
          picture: data.picture,
          provider: 'google',
          accessToken
        }
      };
    } catch (error: any) {
      logger.error('Error fetching Google profile:', error.response?.data || error.message);
      return {
        success: false,
        message: 'Failed to fetch user profile'
      };
    }
  }

  /**
   * Find or create user from OAuth profile
   */
  async findOrCreateUser(profile: OAuthProfile, companyId?: string): Promise<{ success: boolean; user?: any; isNew?: boolean; message?: string }> {
    try {
      // Check if user exists with this OAuth provider
      let user = await database('users')
        .where({
          oauth_provider: profile.provider,
          oauth_id: profile.id
        })
        .first();

      if (user) {
        // Update OAuth tokens
        await database('users')
          .where({ id: user.id })
          .update({
            oauth_access_token: profile.accessToken,
            oauth_refresh_token: profile.refreshToken,
            last_login_at: new Date(),
            updated_at: new Date()
          });

        logger.info('OAuth user logged in', {
          userId: user.id,
          provider: profile.provider,
          email: profile.email
        });

        return {
          success: true,
          user: this.sanitizeUser(user),
          isNew: false
        };
      }

      // Check if user exists with same email
      user = await database('users')
        .where({ email: profile.email.toLowerCase() })
        .first();

      if (user) {
        // Link OAuth to existing account
        await database('users')
          .where({ id: user.id })
          .update({
            oauth_provider: profile.provider,
            oauth_id: profile.id,
            oauth_access_token: profile.accessToken,
            oauth_refresh_token: profile.refreshToken,
            email_verified_at: user.email_verified_at || new Date(),
            last_login_at: new Date(),
            updated_at: new Date()
          });

        logger.info('OAuth linked to existing user', {
          userId: user.id,
          provider: profile.provider,
          email: profile.email
        });

        return {
          success: true,
          user: this.sanitizeUser(user),
          isNew: false
        };
      }

      // Create new user
      const [newUser] = await database('users')
        .insert({
          email: profile.email.toLowerCase(),
          first_name: profile.firstName,
          last_name: profile.lastName,
          avatar_url: profile.picture,
          oauth_provider: profile.provider,
          oauth_id: profile.id,
          oauth_access_token: profile.accessToken,
          oauth_refresh_token: profile.refreshToken,
          email_verified_at: new Date(),
          role: 'customer',
          company_id: companyId,
          status: 'active',
          created_at: new Date(),
          updated_at: new Date()
        })
        .returning(['id', 'email', 'first_name', 'last_name', 'phone', 'role', 'company_id', 'status', 'avatar_url']);

      logger.info('New OAuth user created', {
        userId: newUser.id,
        provider: profile.provider,
        email: profile.email
      });

      return {
        success: true,
        user: this.sanitizeUser(newUser),
        isNew: true
      };
    } catch (error) {
      logger.error('Error finding/creating OAuth user:', error);
      return {
        success: false,
        message: 'Internal error during OAuth authentication'
      };
    }
  }

  /**
   * Sanitize user object for response
   */
  private sanitizeUser(user: any): any {
    return {
      id: user.id,
      email: user.email,
      firstName: user.first_name,
      lastName: user.last_name,
      phone: user.phone,
      role: user.role,
      companyId: user.company_id,
      status: user.status,
      avatarUrl: user.avatar_url,
      emailVerified: !!user.email_verified_at,
      oauthProvider: user.oauth_provider
    };
  }

  /**
   * Refresh Google access token
   */
  async refreshGoogleToken(refreshToken: string): Promise<{ success: boolean; tokens?: GoogleTokens; message?: string }> {
    try {
      const response = await axios.post(
        this.GOOGLE_TOKEN_URL,
        new URLSearchParams({
          refresh_token: refreshToken,
          client_id: this.GOOGLE_CLIENT_ID,
          client_secret: this.GOOGLE_CLIENT_SECRET,
          grant_type: 'refresh_token'
        }),
        {
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
          }
        }
      );

      return {
        success: true,
        tokens: response.data
      };
    } catch (error: any) {
      logger.error('Error refreshing Google token:', error.response?.data || error.message);
      return {
        success: false,
        message: 'Failed to refresh access token'
      };
    }
  }

  /**
   * Revoke Google access
   */
  async revokeGoogleAccess(accessToken: string): Promise<boolean> {
    try {
      await axios.post(`https://oauth2.googleapis.com/revoke?token=${accessToken}`);
      return true;
    } catch (error) {
      logger.error('Error revoking Google access:', error);
      return false;
    }
  }

  /**
   * Unlink OAuth provider from user account
   */
  async unlinkOAuth(userId: string, provider: string): Promise<{ success: boolean; message: string }> {
    try {
      const user = await database('users')
        .where({ id: userId })
        .first();

      if (!user) {
        return {
          success: false,
          message: 'User not found'
        };
      }

      // Check if user has password set
      if (!user.password_hash) {
        return {
          success: false,
          message: 'Please set a password before unlinking OAuth provider'
        };
      }

      await database('users')
        .where({ id: userId })
        .update({
          oauth_provider: null,
          oauth_id: null,
          oauth_access_token: null,
          oauth_refresh_token: null,
          updated_at: new Date()
        });

      logger.info('OAuth provider unlinked', {
        userId,
        provider
      });

      return {
        success: true,
        message: 'OAuth provider unlinked successfully'
      };
    } catch (error) {
      logger.error('Error unlinking OAuth:', error);
      return {
        success: false,
        message: 'Internal error during OAuth unlinking'
      };
    }
  }

  /**
   * Get OAuth providers for user
   */
  async getUserOAuthProviders(userId: string): Promise<string[]> {
    try {
      const user = await database('users')
        .where({ id: userId })
        .select('oauth_provider')
        .first();

      return user?.oauth_provider ? [user.oauth_provider] : [];
    } catch (error) {
      logger.error('Error getting OAuth providers:', error);
      return [];
    }
  }
}

export const oauthService = new OAuthService();
