import { db } from '../../config/database';
import { logger } from '../../utils/logger';

/**
 * AI-Powered Customer Insights Service
 * Analyzes customer behavior and provides actionable insights
 */
export class CustomerInsightsService {
  /**
   * Get customer churn risk score
   * Returns 0-100 where higher = more likely to churn
   */
  async getChurnRisk(customerId: string): Promise<{
    score: number;
    factors: string[];
    recommendations: string[];
  }> {
    try {
      // Get customer data
      const customer = await db.query(
        `SELECT c.*, 
          COUNT(i.id) as total_invoices,
          COUNT(CASE WHEN i.status = 'overdue' THEN 1 END) as overdue_invoices,
          AVG(CASE WHEN p.status = 'completed' THEN 1 ELSE 0 END) as payment_success_rate,
          MAX(p.created_at) as last_payment_date,
          MAX(s.last_seen) as last_session_date
        FROM customers c
        LEFT JOIN invoices i ON c.id = i.customer_id
        LEFT JOIN payments p ON c.id = p.customer_id
        LEFT JOIN sessions s ON c.id = s.customer_id
        WHERE c.id = $1
        GROUP BY c.id`,
        [customerId]
      );

      if (!customer.rows[0]) {
        return { score: 0, factors: [], recommendations: [] };
      }

      const data = customer.rows[0];
      let score = 0;
      const factors: string[] = [];
      const recommendations: string[] = [];

      // Factor 1: Payment history
      if (data.overdue_invoices > 0) {
        score += Math.min(data.overdue_invoices * 15, 45);
        factors.push(`${data.overdue_invoices} overdue invoice(s)`);
        recommendations.push('Send payment reminder with flexible payment options');
      }

      // Factor 2: Payment success rate
      if (data.payment_success_rate !== null && data.payment_success_rate < 0.8) {
        score += 20;
        factors.push('Low payment success rate');
        recommendations.push('Offer alternative payment methods');
      }

      // Factor 3: Last payment date
      if (data.last_payment_date) {
        const daysSincePayment = Math.floor(
          (Date.now() - new Date(data.last_payment_date).getTime()) / (1000 * 60 * 60 * 24)
        );
        if (daysSincePayment > 45) {
          score += 25;
          factors.push(`No payment in ${daysSincePayment} days`);
          recommendations.push('Reach out with personalized retention offer');
        }
      }

      // Factor 4: Last session date
      if (data.last_session_date) {
        const daysSinceSession = Math.floor(
          (Date.now() - new Date(data.last_session_date).getTime()) / (1000 * 60 * 60 * 24)
        );
        if (daysSinceSession > 30) {
          score += 15;
          factors.push('Inactive for ' + daysSinceSession + ' days');
          recommendations.push('Send re-engagement campaign');
        }
      }

      // Cap score at 100
      score = Math.min(score, 100);

      return { score, factors, recommendations };
    } catch (error: any) {
      logger.error('Failed to calculate churn risk', { error: error.message, customerId });
      return { score: 0, factors: [], recommendations: [] };
    }
  }

  /**
   * Get customer lifetime value prediction
   */
  async getLifetimeValue(customerId: string): Promise<{
    predictedValue: number;
    confidence: number;
    factors: string[];
  }> {
    try {
      const result = await db.query(
        `SELECT 
          c.monthly_revenue,
          COUNT(i.id) as total_invoices,
          AVG(i.amount) as avg_invoice_amount,
          EXTRACT(DAY FROM AGE(NOW(), c.created_at)) as customer_age_days,
          COUNT(CASE WHEN i.status = 'paid' THEN 1 END) as paid_invoices
        FROM customers c
        LEFT JOIN invoices i ON c.id = i.customer_id
        WHERE c.id = $1
        GROUP BY c.id, c.monthly_revenue, c.created_at`,
        [customerId]
      );

      if (!result.rows[0]) {
        return { predictedValue: 0, confidence: 0, factors: [] };
      }

      const data = result.rows[0];
      
      // Simple LTV calculation
      const monthlyRevenue = parseFloat(data.monthly_revenue) || parseFloat(data.avg_invoice_amount) || 0;
      const customerAgeMonths = Math.max(parseFloat(data.customer_age_days) / 30, 1);
      const paymentRate = data.total_invoices > 0 
        ? parseFloat(data.paid_invoices) / parseFloat(data.total_invoices) 
        : 0.5;

      // Predict 24-month LTV
      const predictedValue = monthlyRevenue * 24 * paymentRate;
      const confidence = Math.min(customerAgeMonths / 12 * 100, 95);

      const factors = [
        `Monthly revenue: KES ${monthlyRevenue.toLocaleString()}`,
        `Customer for ${Math.floor(customerAgeMonths)} months`,
        `Payment rate: ${(paymentRate * 100).toFixed(1)}%`
      ];

      return { predictedValue, confidence, factors };
    } catch (error: any) {
      logger.error('Failed to calculate LTV', { error: error.message, customerId });
      return { predictedValue: 0, confidence: 0, factors: [] };
    }
  }

  /**
   * Get recommended plan for customer
   */
  async getRecommendedPlan(customerId: string): Promise<{
    currentPlan: string;
    recommendedPlan: string;
    reason: string;
    potentialRevenue: number;
  } | null> {
    try {
      // Get customer's usage patterns
      const usage = await db.query(
        `SELECT 
          c.plan_id,
          p.name as plan_name,
          p.price as current_price,
          AVG(s.data_usage_gb) as avg_data_usage,
          MAX(s.data_usage_gb) as peak_data_usage
        FROM customers c
        JOIN plans p ON c.plan_id = p.id
        LEFT JOIN usage_logs s ON c.id = s.customer_id
        WHERE c.id = $1
          AND s.created_at >= NOW() - INTERVAL '30 days'
        GROUP BY c.id, c.plan_id, p.name, p.price`,
        [customerId]
      );

      if (!usage.rows[0]) {
        return null;
      }

      const data = usage.rows[0];
      const avgUsage = parseFloat(data.avg_data_usage) || 0;
      const peakUsage = parseFloat(data.peak_data_usage) || 0;

      // Find better plan based on usage
      const plans = await db.query(
        `SELECT * FROM plans 
         WHERE is_active = true 
         AND price > $1
         ORDER BY price ASC`,
        [data.current_price]
      );

      for (const plan of plans.rows) {
        const planDataLimit = parseFloat(plan.data_limit) || 0;
        
        // If customer is regularly exceeding their limit
        if (avgUsage > planDataLimit * 0.8) {
          return {
            currentPlan: data.plan_name,
            recommendedPlan: plan.name,
            reason: `You're using ${avgUsage.toFixed(1)}GB on average. Upgrade to ${plan.name} for better value.`,
            potentialRevenue: parseFloat(plan.price) - parseFloat(data.current_price)
          };
        }
      }

      return null;
    } catch (error: any) {
      logger.error('Failed to get recommended plan', { error: error.message, customerId });
      return null;
    }
  }

  /**
   * Get payment behavior analysis
   */
  async getPaymentBehavior(customerId: string): Promise<{
    pattern: 'early' | 'on_time' | 'late' | 'irregular';
    avgDaysToPay: number;
    consistency: number; // 0-100
    insights: string[];
  }> {
    try {
      const result = await db.query(
        `SELECT 
          i.due_date,
          i.paid_date,
          EXTRACT(DAY FROM (i.paid_date - i.due_date)) as days_to_pay
        FROM invoices i
        WHERE i.customer_id = $1
          AND i.status = 'paid'
          AND i.paid_date IS NOT NULL
        ORDER BY i.due_date DESC
        LIMIT 12`,
        [customerId]
      );

      if (result.rows.length === 0) {
        return { pattern: 'irregular', avgDaysToPay: 0, consistency: 0, insights: ['No payment history available'] };
      }

      const payments = result.rows.map(r => parseFloat(r.days_to_pay) || 0);
      const avgDaysToPay = payments.reduce((a, b) => a + b, 0) / payments.length;
      
      // Calculate consistency (standard deviation)
      const variance = payments.reduce((sum, val) => sum + Math.pow(val - avgDaysToPay, 2), 0) / payments.length;
      const stdDev = Math.sqrt(variance);
      const consistency = Math.max(0, 100 - (stdDev * 10));

      // Determine pattern
      let pattern: 'early' | 'on_time' | 'late' | 'irregular';
      if (avgDaysToPay < -2) {
        pattern = 'early';
      } else if (avgDaysToPay <= 2) {
        pattern = 'on_time';
      } else if (avgDaysToPay <= 7) {
        pattern = 'late';
      } else {
        pattern = 'irregular';
      }

      const insights: string[] = [];
      
      if (pattern === 'early') {
        insights.push('Excellent payment behavior - always pays early');
        insights.push('Eligible for loyalty rewards');
      } else if (pattern === 'on_time') {
        insights.push('Reliable payment behavior');
      } else if (pattern === 'late') {
        insights.push('Often pays a few days late');
        insights.push('Consider sending reminders 3 days before due date');
      } else {
        insights.push('Irregular payment pattern');
        insights.push('May need payment plan options');
      }

      return { pattern, avgDaysToPay, consistency, insights };
    } catch (error: any) {
      logger.error('Failed to analyze payment behavior', { error: error.message, customerId });
      return { pattern: 'irregular', avgDaysToPay: 0, consistency: 0, insights: [] };
    }
  }

  /**
   * Get network usage insights
   */
  async getUsageInsights(customerId: string): Promise<{
    peakHours: string[];
    avgDailyUsage: number;
    trend: 'increasing' | 'stable' | 'decreasing';
    recommendations: string[];
  }> {
    try {
      // Get hourly usage for last 7 days
      const hourlyUsage = await db.query(
        `SELECT 
          EXTRACT(HOUR FROM created_at) as hour,
          AVG(data_usage_gb) as avg_usage
        FROM usage_logs
        WHERE customer_id = $1
          AND created_at >= NOW() - INTERVAL '7 days'
        GROUP BY EXTRACT(HOUR FROM created_at)
        ORDER BY hour`,
        [customerId]
      );

      // Get daily usage trend
      const dailyTrend = await db.query(
        `SELECT 
          DATE(created_at) as date,
          SUM(data_usage_gb) as total_usage
        FROM usage_logs
        WHERE customer_id = $1
          AND created_at >= NOW() - INTERVAL '30 days'
        GROUP BY DATE(created_at)
        ORDER BY date`,
        [customerId]
      );

      // Find peak hours (top 3)
      const peakHours = hourlyUsage.rows
        .sort((a, b) => parseFloat(b.avg_usage) - parseFloat(a.avg_usage))
        .slice(0, 3)
        .map(r => `${r.hour}:00`);

      // Calculate average daily usage
      const totalUsage = dailyTrend.rows.reduce((sum, r) => sum + parseFloat(r.total_usage), 0);
      const avgDailyUsage = totalUsage / dailyTrend.rows.length;

      // Determine trend
      let trend: 'increasing' | 'stable' | 'decreasing' = 'stable';
      if (dailyTrend.rows.length >= 14) {
        const firstWeek = dailyTrend.rows.slice(0, 7).reduce((s, r) => s + parseFloat(r.total_usage), 0);
        const lastWeek = dailyTrend.rows.slice(-7).reduce((s, r) => s + parseFloat(r.total_usage), 0);
        
        if (lastWeek > firstWeek * 1.2) {
          trend = 'increasing';
        } else if (lastWeek < firstWeek * 0.8) {
          trend = 'decreasing';
        }
      }

      const recommendations: string[] = [];
      
      if (trend === 'increasing') {
        recommendations.push('Usage is trending up - consider plan upgrade');
      }
      
      if (avgDailyUsage > 5) {
        recommendations.push('High usage detected - monitor for optimal plan');
      }

      return { peakHours, avgDailyUsage, trend, recommendations };
    } catch (error: any) {
      logger.error('Failed to get usage insights', { error: error.message, customerId });
      return { peakHours: [], avgDailyUsage: 0, trend: 'stable', recommendations: [] };
    }
  }

  /**
   * Get at-risk customers (high churn probability)
   */
  async getAtRiskCustomers(limit: number = 50): Promise<Array<{
    customerId: string;
    customerName: string;
    churnRisk: number;
    factors: string[];
    recommendedAction: string;
  }>> {
    try {
      // Get customers with recent activity
      const customers = await db.query(
        `SELECT 
          c.id,
          c.first_name || ' ' || c.last_name as name,
          c.phone,
          c.email,
          c.status,
          COUNT(CASE WHEN i.status = 'overdue' THEN 1 END) as overdue_count,
          MAX(p.created_at) as last_payment,
          MAX(s.last_seen) as last_session
        FROM customers c
        LEFT JOIN invoices i ON c.id = i.customer_id
        LEFT JOIN payments p ON c.id = p.customer_id
        LEFT JOIN sessions s ON c.id = s.customer_id
        WHERE c.status = 'active'
        GROUP BY c.id
        HAVING COUNT(CASE WHEN i.status = 'overdue' THEN 1 END) > 0
           OR MAX(p.created_at) < NOW() - INTERVAL '45 days'
           OR MAX(s.last_seen) < NOW() - INTERVAL '30 days'
        LIMIT $1`,
        [limit]
      );

      const results = [];
      
      for (const customer of customers.rows) {
        const churnAnalysis = await this.getChurnRisk(customer.id);
        
        if (churnAnalysis.score > 30) {
          results.push({
            customerId: customer.id,
            customerName: customer.name,
            churnRisk: churnAnalysis.score,
            factors: churnAnalysis.factors,
            recommendedAction: churnAnalysis.recommendations[0] || 'Contact customer'
          });
        }
      }

      return results.sort((a, b) => b.churnRisk - a.churnRisk);
    } catch (error: any) {
      logger.error('Failed to get at-risk customers', { error: error.message });
      return [];
    }
  }

  /**
   * Get revenue forecast
   */
  async getRevenueForecast(days: number = 30): Promise<{
    predictedRevenue: number;
    confidence: number;
    breakdown: Array<{ date: string; amount: number }>;
  }> {
    try {
      // Get historical revenue patterns
      const history = await db.query(
        `SELECT 
          DATE(created_at) as date,
          SUM(amount) as total
        FROM payments
        WHERE status = 'completed'
          AND created_at >= NOW() - INTERVAL '90 days'
        GROUP BY DATE(created_at)
        ORDER BY date`
      );

      if (history.rows.length === 0) {
        return { predictedRevenue: 0, confidence: 0, breakdown: [] };
      }

      // Calculate average daily revenue
      const dailyRevenues = history.rows.map(r => parseFloat(r.total));
      const avgDailyRevenue = dailyRevenues.reduce((a, b) => a + b, 0) / dailyRevenues.length;

      // Simple forecast (can be enhanced with ML)
      const predictedRevenue = avgDailyRevenue * days;
      const confidence = Math.min(history.rows.length / 90 * 100, 95);

      // Generate breakdown
      const breakdown = [];
      for (let i = 0; i < days; i++) {
        const date = new Date();
        date.setDate(date.getDate() + i);
        breakdown.push({
          date: date.toISOString().split('T')[0],
          amount: avgDailyRevenue
        });
      }

      return { predictedRevenue, confidence, breakdown };
    } catch (error: any) {
      logger.error('Failed to get revenue forecast', { error: error.message });
      return { predictedRevenue: 0, confidence: 0, breakdown: [] };
    }
  }

  /**
   * Get customer segmentation
   */
  async getCustomerSegments(): Promise<{
    vip: number;
    loyal: number;
    regular: number;
    atRisk: number;
    new: number;
  }> {
    try {
      const result = await db.query(
        `WITH customer_stats AS (
          SELECT 
            c.id,
            c.created_at,
            COUNT(DISTINCT i.id) as invoice_count,
            SUM(CASE WHEN p.status = 'completed' THEN p.amount ELSE 0 END) as total_paid,
            MAX(p.created_at) as last_payment,
            COUNT(CASE WHEN i.status = 'overdue' THEN 1 END) as overdue_count
          FROM customers c
          LEFT JOIN invoices i ON c.id = i.customer_id
          LEFT JOIN payments p ON c.id = p.customer_id
          GROUP BY c.id, c.created_at
        )
        SELECT 
          COUNT(CASE WHEN total_paid > 50000 AND invoice_count > 12 THEN 1 END) as vip,
          COUNT(CASE WHEN total_paid > 20000 AND invoice_count > 6 AND overdue_count = 0 THEN 1 END) as loyal,
          COUNT(CASE WHEN total_paid > 0 AND invoice_count > 0 THEN 1 END) as regular,
          COUNT(CASE WHEN overdue_count > 0 OR last_payment < NOW() - INTERVAL '45 days' THEN 1 END) as at_risk,
          COUNT(CASE WHEN created_at >= NOW() - INTERVAL '30 days' THEN 1 END) as new
        FROM customer_stats`
      );

      return result.rows[0] || { vip: 0, loyal: 0, regular: 0, atRisk: 0, new: 0 };
    } catch (error: any) {
      logger.error('Failed to get customer segments', { error: error.message });
      return { vip: 0, loyal: 0, regular: 0, atRisk: 0, new: 0 };
    }
  }
}

export const customerInsights = new CustomerInsightsService();
