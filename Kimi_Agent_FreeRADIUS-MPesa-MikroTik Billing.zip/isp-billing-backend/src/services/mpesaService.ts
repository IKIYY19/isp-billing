import axios from 'axios';
import { database } from '../config/database';
import { logger } from '../utils/logger';

export interface MPesaConfig {
  consumerKey: string;
  consumerSecret: string;
  passkey: string;
  shortcode: string;
  environment: 'sandbox' | 'production';
  callbackUrl: string;
}

export interface STKPushRequest {
  phoneNumber: string;
  amount: number;
  accountNumber: string;
  description?: string;
  callbackUrl?: string;
}

export interface STKPushResponse {
  success: boolean;
  merchantRequestId?: string;
  checkoutRequestId?: string;
  responseCode?: string;
  responseDescription?: string;
  customerMessage?: string;
  error?: string;
}

export interface PaymentStatus {
  success: boolean;
  resultCode?: string;
  resultDesc?: string;
  amount?: number;
  mpesaReceiptNumber?: string;
  transactionDate?: string;
  phoneNumber?: string;
  status: 'pending' | 'completed' | 'failed' | 'cancelled';
}

export class MPesaService {
  private config: MPesaConfig;
  private baseUrl: string;
  private accessToken: string | null = null;
  private tokenExpiry: Date | null = null;

  constructor(config: MPesaConfig) {
    this.config = config;
    this.baseUrl = config.environment === 'production'
      ? 'https://api.safaricom.co.ke'
      : 'https://sandbox.safaricom.co.ke';
  }

  /**
   * Get OAuth access token
   */
  private async getAccessToken(): Promise<string> {
    // Check if token is still valid
    if (this.accessToken && this.tokenExpiry && new Date() < this.tokenExpiry) {
      return this.accessToken;
    }

    try {
      const auth = Buffer.from(`${this.config.consumerKey}:${this.config.consumerSecret}`).toString('base64');
      
      const response = await axios.get(`${this.baseUrl}/oauth/v1/generate?grant_type=client_credentials`, {
        headers: {
          Authorization: `Basic ${auth}`
        }
      });

      this.accessToken = response.data.access_token;
      // Token expires in 3600 seconds, refresh after 3500
      this.tokenExpiry = new Date(Date.now() + 3500 * 1000);

      return this.accessToken;
    } catch (error: any) {
      logger.error('Failed to get M-Pesa access token:', error.response?.data || error.message);
      throw new Error('Failed to authenticate with M-Pesa');
    }
  }

  /**
   * Generate password for STK push
   */
  private generatePassword(timestamp: string): string {
    const data = `${this.config.shortcode}${this.config.passkey}${timestamp}`;
    return Buffer.from(data).toString('base64');
  }

  /**
   * Initiate STK Push (Paybill payment)
   */
  async initiateSTKPush(request: STKPushRequest): Promise<STKPushResponse> {
    try {
      const accessToken = await this.getAccessToken();
      const timestamp = new Date().toISOString().replace(/[^0-9]/g, '').slice(0, -3);
      const password = this.generatePassword(timestamp);

      // Format phone number (remove leading 0 or +254, add 254)
      let phoneNumber = request.phoneNumber.replace(/\s/g, '');
      if (phoneNumber.startsWith('0')) {
        phoneNumber = '254' + phoneNumber.slice(1);
      } else if (phoneNumber.startsWith('+')) {
        phoneNumber = phoneNumber.slice(1);
      }

      const payload = {
        BusinessShortCode: this.config.shortcode,
        Password: password,
        Timestamp: timestamp,
        TransactionType: 'CustomerPayBillOnline',
        Amount: Math.round(request.amount),
        PartyA: phoneNumber,
        PartyB: this.config.shortcode,
        PhoneNumber: phoneNumber,
        CallBackURL: request.callbackUrl || this.config.callbackUrl,
        AccountReference: request.accountNumber.slice(0, 20), // Max 20 chars
        TransactionDesc: (request.description || 'Payment').slice(0, 13) // Max 13 chars
      };

      logger.info('Initiating M-Pesa STK Push', { 
        phoneNumber, 
        amount: request.amount, 
        accountNumber: request.accountNumber 
      });

      const response = await axios.post(
        `${this.baseUrl}/mpesa/stkpush/v1/processrequest`,
        payload,
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
          }
        }
      );

      // Save payment request to database
      await database('mpesa_requests').insert({
        merchant_request_id: response.data.MerchantRequestID,
        checkout_request_id: response.data.CheckoutRequestID,
        phone_number: phoneNumber,
        amount: request.amount,
        account_reference: request.accountNumber,
        description: request.description,
        status: 'pending',
        created_at: new Date()
      });

      return {
        success: true,
        merchantRequestId: response.data.MerchantRequestID,
        checkoutRequestId: response.data.CheckoutRequestID,
        responseCode: response.data.ResponseCode,
        responseDescription: response.data.ResponseDescription,
        customerMessage: response.data.CustomerMessage
      };

    } catch (error: any) {
      logger.error('M-Pesa STK Push failed:', error.response?.data || error.message);
      return {
        success: false,
        error: error.response?.data?.errorMessage || error.message
      };
    }
  }

  /**
   * Query STK Push status
   */
  async querySTKStatus(checkoutRequestId: string): Promise<PaymentStatus> {
    try {
      const accessToken = await this.getAccessToken();
      const timestamp = new Date().toISOString().replace(/[^0-9]/g, '').slice(0, -3);
      const password = this.generatePassword(timestamp);

      const payload = {
        BusinessShortCode: this.config.shortcode,
        Password: password,
        Timestamp: timestamp,
        CheckoutRequestID: checkoutRequestId
      };

      const response = await axios.post(
        `${this.baseUrl}/mpesa/stkpushquery/v1/query`,
        payload,
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
          }
        }
      );

      const resultCode = response.data.ResultCode;
      let status: 'pending' | 'completed' | 'failed' | 'cancelled' = 'pending';

      if (resultCode === '0') {
        status = 'completed';
      } else if (resultCode === '1032') {
        status = 'cancelled';
      } else if (resultCode) {
        status = 'failed';
      }

      // Update database
      await database('mpesa_requests')
        .where({ checkout_request_id: checkoutRequestId })
        .update({
          result_code: resultCode,
          result_desc: response.data.ResultDesc,
          mpesa_receipt_number: response.data.CallbackMetadata?.Item?.find((i: any) => i.Name === 'MpesaReceiptNumber')?.Value,
          transaction_date: response.data.CallbackMetadata?.Item?.find((i: any) => i.Name === 'TransactionDate')?.Value,
          status,
          updated_at: new Date()
        });

      return {
        success: resultCode === '0',
        resultCode,
        resultDesc: response.data.ResultDesc,
        amount: response.data.CallbackMetadata?.Item?.find((i: any) => i.Name === 'Amount')?.Value,
        mpesaReceiptNumber: response.data.CallbackMetadata?.Item?.find((i: any) => i.Name === 'MpesaReceiptNumber')?.Value,
        transactionDate: response.data.CallbackMetadata?.Item?.find((i: any) => i.Name === 'TransactionDate')?.Value?.toString(),
        phoneNumber: response.data.CallbackMetadata?.Item?.find((i: any) => i.Name === 'PhoneNumber')?.Value?.toString(),
        status
      };

    } catch (error: any) {
      logger.error('M-Pesa query failed:', error.response?.data || error.message);
      return {
        success: false,
        error: error.response?.data?.errorMessage || error.message,
        status: 'failed'
      };
    }
  }

  /**
   * Process M-Pesa callback
   */
  async processCallback(callbackData: any): Promise<boolean> {
    try {
      const { Body } = callbackData;
      
      if (!Body || !Body.stkCallback) {
        logger.error('Invalid callback data received');
        return false;
      }

      const { stkCallback } = Body;
      const resultCode = stkCallback.ResultCode;
      const checkoutRequestId = stkCallback.CheckoutRequestID;

      let status: 'pending' | 'completed' | 'failed' | 'cancelled' = 'pending';
      let mpesaReceiptNumber: string | undefined;
      let amount: number | undefined;
      let phoneNumber: string | undefined;
      let transactionDate: string | undefined;

      if (resultCode === 0) {
        status = 'completed';
        
        // Extract metadata
        const callbackMetadata = stkCallback.CallbackMetadata?.Item || [];
        callbackMetadata.forEach((item: any) => {
          switch (item.Name) {
            case 'MpesaReceiptNumber':
              mpesaReceiptNumber = item.Value;
              break;
            case 'Amount':
              amount = item.Value;
              break;
            case 'PhoneNumber':
              phoneNumber = item.Value?.toString();
              break;
            case 'TransactionDate':
              transactionDate = item.Value?.toString();
              break;
          }
        });

        // Find the pending request
        const request = await database('mpesa_requests')
          .where({ checkout_request_id: checkoutRequestId })
          .first();

        if (request) {
          // Create payment record
          await database('payments').insert({
            transaction_id: mpesaReceiptNumber,
            customer_id: request.customer_id,
            invoice_id: request.invoice_id,
            amount: amount || request.amount,
            method: 'mpesa',
            status: 'completed',
            mpesa_receipt: mpesaReceiptNumber,
            mpesa_phone: phoneNumber,
            metadata: {
              checkout_request_id: checkoutRequestId,
              merchant_request_id: stkCallback.MerchantRequestID,
              transaction_date: transactionDate
            },
            created_at: new Date()
          });

          // Update customer balance if applicable
          if (request.customer_id) {
            await database.raw(`
              UPDATE customers 
              SET balance = balance - ? 
              WHERE id = ?
            `, [amount || request.amount, request.customer_id]);
          }
        }
      } else if (resultCode === 1032) {
        status = 'cancelled';
      } else {
        status = 'failed';
      }

      // Update request status
      await database('mpesa_requests')
        .where({ checkout_request_id: checkoutRequestId })
        .update({
          result_code: resultCode?.toString(),
          result_desc: stkCallback.ResultDesc,
          mpesa_receipt_number: mpesaReceiptNumber,
          transaction_date: transactionDate,
          status,
          callback_received_at: new Date(),
          updated_at: new Date()
        });

      logger.info('M-Pesa callback processed', { 
        checkoutRequestId, 
        resultCode, 
        status,
        mpesaReceiptNumber 
      });

      return true;

    } catch (error: any) {
      logger.error('Failed to process M-Pesa callback:', error);
      return false;
    }
  }

  /**
   * Register URLs for C2B (Customer to Business)
   */
  async registerC2BUrls(validationUrl: string, confirmationUrl: string): Promise<any> {
    try {
      const accessToken = await this.getAccessToken();

      const payload = {
        ShortCode: this.config.shortcode,
        ResponseType: 'Completed',
        ConfirmationURL: confirmationUrl,
        ValidationURL: validationUrl
      };

      const response = await axios.post(
        `${this.baseUrl}/mpesa/c2b/v1/registerurl`,
        payload,
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
          }
        }
      );

      return response.data;

    } catch (error: any) {
      logger.error('Failed to register C2B URLs:', error.response?.data || error.message);
      throw error;
    }
  }

  /**
   * Simulate C2B payment (sandbox only)
   */
  async simulateC2BPayment(phoneNumber: string, amount: number, accountNumber: string): Promise<any> {
    if (this.config.environment !== 'sandbox') {
      throw new Error('C2B simulation is only available in sandbox environment');
    }

    try {
      const accessToken = await this.getAccessToken();

      // Format phone number
      let msisdn = phoneNumber.replace(/\s/g, '');
      if (msisdn.startsWith('0')) {
        msisdn = '254' + msisdn.slice(1);
      } else if (msisdn.startsWith('+')) {
        msisdn = msisdn.slice(1);
      }

      const payload = {
        ShortCode: this.config.shortcode,
        CommandID: 'CustomerPayBillOnline',
        Amount: Math.round(amount),
        Msisdn: msisdn,
        BillRefNumber: accountNumber.slice(0, 20)
      };

      const response = await axios.post(
        `${this.baseUrl}/mpesa/c2b/v1/simulate`,
        payload,
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
          }
        }
      );

      return response.data;

    } catch (error: any) {
      logger.error('C2B simulation failed:', error.response?.data || error.message);
      throw error;
    }
  }

  /**
   * Get payment history for a customer
   */
  async getCustomerPaymentHistory(customerId: string, limit: number = 50): Promise<any[]> {
    return await database('payments')
      .where({ customer_id: customerId, method: 'mpesa' })
      .orderBy('created_at', 'desc')
      .limit(limit);
  }

  /**
   * Get pending payments
   */
  async getPendingPayments(): Promise<any[]> {
    return await database('mpesa_requests')
      .where({ status: 'pending' })
      .where('created_at', '>', new Date(Date.now() - 3600000)) // Last hour
      .orderBy('created_at', 'desc');
  }

  /**
   * Retry failed payment query
   */
  async retryFailedQueries(): Promise<void> {
    const failedRequests = await database('mpesa_requests')
      .where({ status: 'pending' })
      .where('created_at', '<', new Date(Date.now() - 120000)) // Older than 2 minutes
      .where('retry_count', '<', 3)
      .limit(10);

    for (const request of failedRequests) {
      try {
        await this.querySTKStatus(request.checkout_request_id);
        
        // Increment retry count
        await database('mpesa_requests')
          .where({ id: request.id })
          .increment('retry_count', 1);
          
      } catch (error) {
        logger.error(`Failed to retry query for ${request.checkout_request_id}:`, error);
      }
    }
  }
}

// Create service instance from environment variables
export const mpesaService = new MPesaService({
  consumerKey: process.env.MPESA_CONSUMER_KEY || '',
  consumerSecret: process.env.MPESA_CONSUMER_SECRET || '',
  passkey: process.env.MPESA_PASSKEY || '',
  shortcode: process.env.MPESA_SHORTCODE || '',
  environment: (process.env.MPESA_ENVIRONMENT as 'sandbox' | 'production') || 'sandbox',
  callbackUrl: process.env.MPESA_CALLBACK_URL || ''
});

export default mpesaService;
