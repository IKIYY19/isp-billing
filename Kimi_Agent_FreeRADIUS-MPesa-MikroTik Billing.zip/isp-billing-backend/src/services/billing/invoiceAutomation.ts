import { db } from '../../config/database';
import { notificationManager } from '../notifications/notificationManager';
import { logger } from '../../utils/logger';

/**
 * Automated Invoice Generation Service
 * Handles recurring billing and invoice generation
 */
export class InvoiceAutomationService {
  /**
   * Generate invoices for all active customers
   * Should be run on the 1st of each month
   */
  async generateMonthlyInvoices(): Promise<{
    generated: number;
    failed: number;
    totalAmount: number;
    errors: string[];
  }> {
    const errors: string[] = [];
    let generated = 0;
    let failed = 0;
    let totalAmount = 0;

    try {
      logger.info('Starting monthly invoice generation');

      // Get all active customers with their plans
      const customers = await db.query(
        `SELECT 
          c.id,
          c.first_name || ' ' || c.last_name as customer_name,
          c.phone,
          c.email,
          c.account_number,
          p.id as plan_id,
          p.name as plan_name,
          p.price as plan_price,
          p.duration as plan_duration,
          p.duration_unit as plan_duration_unit
        FROM customers c
        JOIN plans p ON c.plan_id = p.id
        WHERE c.status = 'active'
          AND c.plan_id IS NOT NULL`
      );

      logger.info(`Found ${customers.rows.length} customers to invoice`);

      const currentDate = new Date();
      const dueDate = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 5); // Due on 5th

      for (const customer of customers.rows) {
        try {
          // Check if invoice already exists for this month
          const existingInvoice = await db.query(
            `SELECT id FROM invoices 
             WHERE customer_id = $1 
               AND EXTRACT(MONTH FROM created_at) = $2
               AND EXTRACT(YEAR FROM created_at) = $3`,
            [customer.id, currentDate.getMonth() + 1, currentDate.getFullYear()]
          );

          if (existingInvoice.rows.length > 0) {
            logger.info(`Invoice already exists for ${customer.customer_name}, skipping`);
            continue;
          }

          // Generate invoice number
          const invoiceNumber = await this.generateInvoiceNumber();

          // Calculate amounts
          const amount = parseFloat(customer.plan_price);
          const tax = amount * 0.16; // 16% VAT
          const total = amount + tax;

          // Create invoice
          const invoice = await db.query(
            `INSERT INTO invoices (
              customer_id, plan_id, invoice_number, amount, tax, total, 
              balance, status, due_date, created_at, updated_at
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, NOW(), NOW())
            RETURNING *`,
            [
              customer.id,
              customer.plan_id,
              invoiceNumber,
              amount,
              tax,
              total,
              total,
              'sent',
              dueDate
            ]
          );

          // Send notification
          await notificationManager.sendNotification({
            customerId: customer.id,
            phone: customer.phone,
            email: customer.email,
            type: 'invoice',
            data: {
              customerName: customer.customer_name,
              invoiceNumber,
              amount: total,
              dueDate: dueDate.toISOString().split('T')[0],
              planName: customer.plan_name,
              paybillNumber: '174379',
              accountNumber: customer.account_number
            }
          });

          generated++;
          totalAmount += total;

          logger.info(`Invoice generated for ${customer.customer_name}: ${invoiceNumber}`);
        } catch (error: any) {
          failed++;
          errors.push(`Failed for ${customer.customer_name}: ${error.message}`);
          logger.error(`Failed to generate invoice for ${customer.customer_name}`, { error: error.message });
        }
      }

      logger.info(`Monthly invoice generation completed: ${generated} generated, ${failed} failed`);

      return { generated, failed, totalAmount, errors };
    } catch (error: any) {
      logger.error('Monthly invoice generation failed', { error: error.message });
      return { generated, failed, totalAmount, errors: [error.message] };
    }
  }

  /**
   * Generate invoice for a specific customer
   */
  async generateCustomerInvoice(customerId: string, options?: {
    amount?: number;
    description?: string;
    dueDate?: Date;
  }): Promise<{ success: boolean; invoice?: any; error?: string }> {
    try {
      // Get customer details
      const customer = await db.query(
        `SELECT 
          c.*,
          p.id as plan_id,
          p.name as plan_name,
          p.price as plan_price
        FROM customers c
        LEFT JOIN plans p ON c.plan_id = p.id
        WHERE c.id = $1`,
        [customerId]
      );

      if (!customer.rows[0]) {
        return { success: false, error: 'Customer not found' };
      }

      const data = customer.rows[0];
      const invoiceNumber = await this.generateInvoiceNumber();

      const amount = options?.amount || parseFloat(data.plan_price) || 0;
      const tax = amount * 0.16;
      const total = amount + tax;
      const dueDate = options?.dueDate || new Date(Date.now() + 14 * 24 * 60 * 60 * 1000); // 14 days

      const invoice = await db.query(
        `INSERT INTO invoices (
          customer_id, plan_id, invoice_number, amount, tax, total,
          balance, status, due_date, notes, created_at, updated_at
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, NOW(), NOW())
        RETURNING *`,
        [
          customerId,
          data.plan_id,
          invoiceNumber,
          amount,
          tax,
          total,
          total,
          'sent',
          dueDate,
          options?.description || null
        ]
      );

      // Send notification
      await notificationManager.sendNotification({
        customerId,
        phone: data.phone,
        email: data.email,
        type: 'invoice',
        data: {
          customerName: `${data.first_name} ${data.last_name}`,
          invoiceNumber,
          amount: total,
          dueDate: dueDate.toISOString().split('T')[0],
          planName: data.plan_name,
          paybillNumber: '174379',
          accountNumber: data.account_number
        }
      });

      logger.info(`Invoice generated for customer ${customerId}: ${invoiceNumber}`);

      return { success: true, invoice: invoice.rows[0] };
    } catch (error: any) {
      logger.error(`Failed to generate invoice for customer ${customerId}`, { error: error.message });
      return { success: false, error: error.message };
    }
  }

  /**
   * Generate unique invoice number
   */
  private async generateInvoiceNumber(): Promise<string> {
    const date = new Date();
    const year = date.getFullYear().toString().slice(-2);
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    
    // Get count of invoices this month
    const count = await db.query(
      `SELECT COUNT(*) as count FROM invoices 
       WHERE EXTRACT(YEAR FROM created_at) = $1 
         AND EXTRACT(MONTH FROM created_at) = $2`,
      [date.getFullYear(), date.getMonth() + 1]
    );

    const sequence = (parseInt(count.rows[0].count) + 1).toString().padStart(4, '0');
    
    return `INV-${year}${month}-${sequence}`;
  }

  /**
   * Send payment reminders for overdue invoices
   */
  async sendPaymentReminders(): Promise<{
    sent: number;
    failed: number;
  }> {
    let sent = 0;
    let failed = 0;

    try {
      logger.info('Starting payment reminder process');

      // Get overdue invoices
      const overdue = await db.query(
        `SELECT 
          i.id as invoice_id,
          i.invoice_number,
          i.amount,
          i.total,
          i.due_date,
          c.id as customer_id,
          c.first_name || ' ' || c.last_name as customer_name,
          c.phone,
          c.email,
          c.account_number,
          EXTRACT(DAY FROM NOW() - i.due_date) as days_overdue
        FROM invoices i
        JOIN customers c ON i.customer_id = c.id
        WHERE i.status = 'unpaid'
          AND i.due_date < NOW()
          AND NOT EXISTS (
            SELECT 1 FROM notifications n 
            WHERE n.invoice_id = i.id 
              AND n.type = 'payment_reminder'
              AND n.created_at > NOW() - INTERVAL '3 days'
          )`
      );

      logger.info(`Found ${overdue.rows.length} overdue invoices`);

      for (const invoice of overdue.rows) {
        try {
          const daysOverdue = Math.floor(parseFloat(invoice.days_overdue));

          await notificationManager.sendNotification({
            customerId: invoice.customer_id,
            phone: invoice.phone,
            email: invoice.email,
            type: 'payment_reminder',
            data: {
              customerName: invoice.customer_name,
              amount: parseFloat(invoice.total),
              dueDate: new Date(invoice.due_date).toISOString().split('T')[0],
              daysOverdue,
              paybillNumber: '174379',
              accountNumber: invoice.account_number
            }
          });

          // Log notification
          await db.query(
            `INSERT INTO notifications (customer_id, invoice_id, type, status, created_at)
             VALUES ($1, $2, 'payment_reminder', 'sent', NOW())`,
            [invoice.customer_id, invoice.invoice_id]
          );

          sent++;
        } catch (error: any) {
          failed++;
          logger.error(`Failed to send reminder for invoice ${invoice.invoice_number}`, { error: error.message });
        }
      }

      logger.info(`Payment reminders completed: ${sent} sent, ${failed} failed`);

      return { sent, failed };
    } catch (error: any) {
      logger.error('Payment reminder process failed', { error: error.message });
      return { sent, failed };
    }
  }

  /**
   * Send suspension warnings for severely overdue accounts
   */
  async sendSuspensionWarnings(): Promise<{
    sent: number;
    suspended: number;
  }> {
    let sent = 0;
    let suspended = 0;

    try {
      logger.info('Starting suspension warning process');

      // Get severely overdue accounts (14+ days)
      const severeOverdue = await db.query(
        `SELECT 
          c.id as customer_id,
          c.first_name || ' ' || c.last_name as customer_name,
          c.phone,
          c.email,
          c.account_number,
          SUM(i.total) as total_due,
          MAX(i.due_date) as latest_due_date
        FROM customers c
        JOIN invoices i ON c.id = i.customer_id
        WHERE i.status = 'unpaid'
          AND i.due_date < NOW() - INTERVAL '14 days'
          AND c.status = 'active'
        GROUP BY c.id
        HAVING NOT EXISTS (
          SELECT 1 FROM notifications n 
          WHERE n.customer_id = c.id 
            AND n.type = 'suspension_warning'
            AND n.created_at > NOW() - INTERVAL '7 days'
        )`
      );

      for (const account of severeOverdue.rows) {
        try {
          const suspensionDate = new Date();
          suspensionDate.setDate(suspensionDate.getDate() + 3);

          await notificationManager.sendNotification({
            customerId: account.customer_id,
            phone: account.phone,
            email: account.email,
            type: 'suspension_warning',
            data: {
              customerName: account.customer_name,
              suspensionDate: suspensionDate.toISOString().split('T')[0],
              amount: parseFloat(account.total_due),
              paybillNumber: '174379',
              accountNumber: account.account_number
            }
          });

          sent++;
        } catch (error: any) {
          logger.error(`Failed to send suspension warning for ${account.customer_name}`, { error: error.message });
        }
      }

      // Suspend accounts that are 21+ days overdue
      const toSuspend = await db.query(
        `SELECT c.id, c.first_name || ' ' || c.last_name as name
         FROM customers c
         JOIN invoices i ON c.id = i.customer_id
         WHERE i.status = 'unpaid'
           AND i.due_date < NOW() - INTERVAL '21 days'
           AND c.status = 'active'
         GROUP BY c.id`
      );

      for (const account of toSuspend.rows) {
        try {
          await db.query(
            `UPDATE customers SET status = 'suspended', updated_at = NOW() WHERE id = $1`,
            [account.id]
          );

          // Disable RADIUS user
          await db.query(
            `UPDATE radcheck SET value = '0' WHERE username = (SELECT username FROM customers WHERE id = $1)`,
            [account.id]
          );

          suspended++;
          logger.info(`Account suspended: ${account.name}`);
        } catch (error: any) {
          logger.error(`Failed to suspend account ${account.name}`, { error: error.message });
        }
      }

      logger.info(`Suspension process completed: ${sent} warnings sent, ${suspended} accounts suspended`);

      return { sent, suspended };
    } catch (error: any) {
      logger.error('Suspension process failed', { error: error.message });
      return { sent, suspended };
    }
  }

  /**
   * Get billing statistics
   */
  async getBillingStats(): Promise<{
    totalInvoices: number;
    totalRevenue: number;
    paidAmount: number;
    outstandingAmount: number;
    overdueAmount: number;
    collectionRate: number;
  }> {
    try {
      const result = await db.query(
        `SELECT 
          COUNT(*) as total_invoices,
          COALESCE(SUM(total), 0) as total_revenue,
          COALESCE(SUM(CASE WHEN status = 'paid' THEN total ELSE 0 END), 0) as paid_amount,
          COALESCE(SUM(CASE WHEN status IN ('unpaid', 'sent') THEN total ELSE 0 END), 0) as outstanding_amount,
          COALESCE(SUM(CASE WHEN status = 'unpaid' AND due_date < NOW() THEN total ELSE 0 END), 0) as overdue_amount
        FROM invoices
        WHERE EXTRACT(YEAR FROM created_at) = EXTRACT(YEAR FROM NOW())
          AND EXTRACT(MONTH FROM created_at) = EXTRACT(MONTH FROM NOW())`
      );

      const data = result.rows[0];
      const totalRevenue = parseFloat(data.total_revenue) || 0;
      const paidAmount = parseFloat(data.paid_amount) || 0;
      const collectionRate = totalRevenue > 0 ? (paidAmount / totalRevenue) * 100 : 0;

      return {
        totalInvoices: parseInt(data.total_invoices) || 0,
        totalRevenue,
        paidAmount,
        outstandingAmount: parseFloat(data.outstanding_amount) || 0,
        overdueAmount: parseFloat(data.overdue_amount) || 0,
        collectionRate
      };
    } catch (error: any) {
      logger.error('Failed to get billing stats', { error: error.message });
      return {
        totalInvoices: 0,
        totalRevenue: 0,
        paidAmount: 0,
        outstandingAmount: 0,
        overdueAmount: 0,
        collectionRate: 0
      };
    }
  }
}

export const invoiceAutomation = new InvoiceAutomationService();
