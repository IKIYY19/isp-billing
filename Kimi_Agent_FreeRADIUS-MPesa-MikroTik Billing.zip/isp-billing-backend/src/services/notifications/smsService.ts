import axios from 'axios';
import { logger } from '../../utils/logger';

/**
 * SMS Service using Africa's Talking API
 * For sending SMS notifications in Kenya/East Africa
 */
export class SMSService {
  private apiKey: string;
  private username: string;
  private senderId: string;
  private baseUrl: string;

  constructor() {
    this.apiKey = process.env.AFRICASTALKING_API_KEY || '';
    this.username = process.env.AFRICASTALKING_USERNAME || 'sandbox';
    this.senderId = process.env.SMS_SENDER_ID || 'ISPBilling';
    this.baseUrl = this.username === 'sandbox' 
      ? 'https://api.sandbox.africastalking.com/version1/messaging'
      : 'https://api.africastalking.com/version1/messaging';
  }

  /**
   * Check if SMS is configured
   */
  isConfigured(): boolean {
    return !!(this.apiKey && this.username);
  }

  /**
   * Send SMS to single recipient
   */
  async sendSMS(to: string, message: string): Promise<{ success: boolean; messageId?: string; error?: string }> {
    if (!this.isConfigured()) {
      logger.warn('SMS service not configured');
      return { success: false, error: 'SMS not configured' };
    }

    try {
      const response = await axios.post(
        this.baseUrl,
        new URLSearchParams({
          username: this.username,
          to: this.formatPhoneNumber(to),
          message: message,
          from: this.senderId
        }),
        {
          headers: {
            'apiKey': this.apiKey,
            'Content-Type': 'application/x-www-form-urlencoded',
            'Accept': 'application/json'
          }
        }
      );

      const result = response.data;
      
      if (result.SMSMessageData?.Recipients?.[0]?.status === 'Success') {
        const messageId = result.SMSMessageData.Recipients[0].messageId;
        logger.info(`SMS sent successfully to ${to}`, { messageId });
        return { success: true, messageId };
      } else {
        const error = result.SMSMessageData?.Recipients?.[0]?.status || 'Unknown error';
        logger.error('SMS sending failed', { error, to });
        return { success: false, error };
      }
    } catch (error: any) {
      logger.error('Failed to send SMS', { error: error.message, to });
      return { success: false, error: error.message };
    }
  }

  /**
   * Send SMS to multiple recipients (bulk)
   */
  async sendBulkSMS(recipients: string[], message: string): Promise<{ 
    success: boolean; 
    sent: number; 
    failed: number;
    results: Array<{ phone: string; success: boolean; messageId?: string; error?: string }> 
  }> {
    if (!this.isConfigured()) {
      logger.warn('SMS service not configured');
      return { success: false, sent: 0, failed: recipients.length, results: [] };
    }

    const results: Array<{ phone: string; success: boolean; messageId?: string; error?: string }> = [];
    let sent = 0;
    let failed = 0;

    // Africa's Talking allows up to 100 recipients per request
    const batchSize = 100;
    
    for (let i = 0; i < recipients.length; i += batchSize) {
      const batch = recipients.slice(i, i + batchSize);
      const phoneNumbers = batch.map(p => this.formatPhoneNumber(p)).join(',');

      try {
        const response = await axios.post(
          this.baseUrl,
          new URLSearchParams({
            username: this.username,
            to: phoneNumbers,
            message: message,
            from: this.senderId
          }),
          {
            headers: {
              'apiKey': this.apiKey,
              'Content-Type': 'application/x-www-form-urlencoded',
              'Accept': 'application/json'
            }
          }
        );

        const result = response.data;
        
        if (result.SMSMessageData?.Recipients) {
          for (const recipient of result.SMSMessageData.Recipients) {
            const phone = recipient.number;
            const success = recipient.status === 'Success';
            const messageId = recipient.messageId;
            
            results.push({ phone, success, messageId });
            
            if (success) {
              sent++;
            } else {
              failed++;
            }
          }
        }
      } catch (error: any) {
        logger.error('Bulk SMS batch failed', { error: error.message, batch });
        
        for (const phone of batch) {
          results.push({ phone, success: false, error: error.message });
          failed++;
        }
      }
    }

    logger.info(`Bulk SMS completed: ${sent} sent, ${failed} failed`);
    return { success: sent > 0, sent, failed, results };
  }

  /**
   * Send OTP code
   */
  async sendOTP(phone: string, code: string, expiryMinutes: number = 5): Promise<boolean> {
    const message = `Your ISP Billing verification code is: ${code}\n\n` +
      `This code will expire in ${expiryMinutes} minutes.\n\n` +
      `Do not share this code with anyone.`;

    const result = await this.sendSMS(phone, message);
    return result.success;
  }

  /**
   * Send payment reminder
   */
  async sendPaymentReminder(phone: string, customerName: string, amount: number, dueDate: string): Promise<boolean> {
    const message = `Hi ${customerName},\n` +
      `Payment reminder: KES ${amount.toLocaleString()} due on ${dueDate}.\n` +
      `Pay via M-Pesa Paybill 174379.\n` +
      `Call 0700123456 for help.`;

    const result = await this.sendSMS(phone, message);
    return result.success;
  }

  /**
   * Send payment confirmation
   */
  async sendPaymentConfirmation(phone: string, customerName: string, amount: number, transactionId: string): Promise<boolean> {
    const message = `Hi ${customerName},\n` +
      `Payment received: KES ${amount.toLocaleString()}.\n` +
      `Tx ID: ${transactionId}\n` +
      `Thank you for your payment!`;

    const result = await this.sendSMS(phone, message);
    return result.success;
  }

  /**
   * Send invoice notification
   */
  async sendInvoiceNotification(phone: string, customerName: string, invoiceNumber: string, amount: number, dueDate: string): Promise<boolean> {
    const message = `Hi ${customerName},\n` +
      `Invoice ${invoiceNumber}: KES ${amount.toLocaleString()}\n` +
      `Due: ${dueDate}\n` +
      `View: https://your-domain.com/invoice/${invoiceNumber}\n` +
      `Pay via M-Pesa Paybill 174379`;

    const result = await this.sendSMS(phone, message);
    return result.success;
  }

  /**
   * Send service activation
   */
  async sendServiceActivation(phone: string, customerName: string, planName: string, username: string): Promise<boolean> {
    const message = `Welcome ${customerName}!\n` +
      `Your ${planName} is now active.\n` +
      `Username: ${username}\n` +
      `Portal: https://your-domain.com/portal\n` +
      `Support: 0700123456`;

    const result = await this.sendSMS(phone, message);
    return result.success;
  }

  /**
   * Send suspension warning
   */
  async sendSuspensionWarning(phone: string, customerName: string, daysRemaining: number): Promise<boolean> {
    const message = `Hi ${customerName},\n` +
      `URGENT: Service suspended in ${daysRemaining} day${daysRemaining > 1 ? 's' : ''}.\n` +
      `Pay now via M-Pesa Paybill 174379\n` +
      `Call 0700123456 for help.`;

    const result = await this.sendSMS(phone, message);
    return result.success;
  }

  /**
   * Send outage notification
   */
  async sendOutageNotification(phone: string, customerName: string, affectedArea: string, estimatedRestore: string): Promise<boolean> {
    const message = `Hi ${customerName},\n` +
      `Service outage in ${affectedArea}.\n` +
      `Expected restoration: ${estimatedRestore}\n` +
      `We apologize for the inconvenience.`;

    const result = await this.sendSMS(phone, message);
    return result.success;
  }

  /**
   * Send promotional message
   */
  async sendPromotional(phone: string, message: string): Promise<boolean> {
    // Add opt-out option for promotional messages
    const fullMessage = `${message}\n\nReply STOP to opt out.`;
    
    const result = await this.sendSMS(phone, fullMessage);
    return result.success;
  }

  /**
   * Get SMS balance
   */
  async getBalance(): Promise<{ success: boolean; balance?: number; error?: string }> {
    if (!this.isConfigured()) {
      return { success: false, error: 'SMS not configured' };
    }

    try {
      const response = await axios.get(
        `https://api.africastalking.com/version1/user`,
        {
          params: { username: this.username },
          headers: { 'apiKey': this.apiKey }
        }
      );

      const balance = response.data.UserData?.balance;
      logger.info('SMS balance retrieved', { balance });
      return { success: true, balance };
    } catch (error: any) {
      logger.error('Failed to get SMS balance', { error: error.message });
      return { success: false, error: error.message };
    }
  }

  /**
   * Format phone number for Africa's Talking
   */
  private formatPhoneNumber(phone: string): string {
    // Remove all non-numeric characters
    let cleaned = phone.replace(/\D/g, '');
    
    // Remove leading 0 if present
    if (cleaned.startsWith('0')) {
      cleaned = cleaned.substring(1);
    }
    
    // Add country code if not present (default to Kenya +254)
    if (!cleaned.startsWith('254')) {
      cleaned = '254' + cleaned;
    }
    
    return '+' + cleaned;
  }
}

export const smsService = new SMSService();
