import { whatsappService } from './whatsappService';
import { smsService } from './smsService';
import { emailService } from './emailService';
import { logger } from '../../utils/logger';

/**
 * Notification Manager - Orchestrates all notification channels
 * Sends notifications via WhatsApp, SMS, and Email based on customer preferences
 */
export class NotificationManager {
  /**
   * Send notification through all available channels
   */
  async sendNotification(options: {
    customerId: string;
    phone?: string;
    email?: string;
    type: 'payment_reminder' | 'payment_confirmation' | 'invoice' | 'welcome' | 'suspension_warning' | 'outage' | 'usage_report';
    data: any;
    channels?: ('whatsapp' | 'sms' | 'email')[];
  }): Promise<{ success: boolean; results: Record<string, boolean> }> {
    const { phone, email, type, data, channels = ['whatsapp', 'sms', 'email'] } = options;
    const results: Record<string, boolean> = {};

    logger.info(`Sending ${type} notification`, { customerId: options.customerId, channels });

    // WhatsApp
    if (channels.includes('whatsapp') && phone) {
      try {
        results.whatsapp = await this.sendWhatsAppNotification(phone, type, data);
      } catch (error: any) {
        logger.error('WhatsApp notification failed', { error: error.message });
        results.whatsapp = false;
      }
    }

    // SMS
    if (channels.includes('sms') && phone) {
      try {
        results.sms = await this.sendSMSNotification(phone, type, data);
      } catch (error: any) {
        logger.error('SMS notification failed', { error: error.message });
        results.sms = false;
      }
    }

    // Email
    if (channels.includes('email') && email) {
      try {
        results.email = await this.sendEmailNotification(email, type, data);
      } catch (error: any) {
        logger.error('Email notification failed', { error: error.message });
        results.email = false;
      }
    }

    const success = Object.values(results).some(r => r);
    logger.info(`Notification completed`, { success, results });

    return { success, results };
  }

  /**
   * Send WhatsApp notification
   */
  private async sendWhatsAppNotification(phone: string, type: string, data: any): Promise<boolean> {
    switch (type) {
      case 'payment_reminder':
        return whatsappService.sendPaymentReminder(phone, data.customerName, data.amount, data.dueDate);
      
      case 'payment_confirmation':
        return whatsappService.sendPaymentConfirmation(phone, data.customerName, data.amount, data.transactionId);
      
      case 'welcome':
        return whatsappService.sendServiceActivation(phone, data.customerName, data.planName, data.username, data.password);
      
      case 'suspension_warning':
        return whatsappService.sendSuspensionWarning(phone, data.customerName, data.daysRemaining);
      
      case 'outage':
        return whatsappService.sendOutageNotification(phone, data.customerName, data.affectedArea, data.estimatedRestore);
      
      case 'usage_report':
        return whatsappService.sendUsageReport(phone, data.customerName, data.dataUsed, data.dataLimit, data.daysRemaining);
      
      default:
        logger.warn(`Unknown WhatsApp notification type: ${type}`);
        return false;
    }
  }

  /**
   * Send SMS notification
   */
  private async sendSMSNotification(phone: string, type: string, data: any): Promise<boolean> {
    switch (type) {
      case 'payment_reminder':
        return smsService.sendPaymentReminder(phone, data.customerName, data.amount, data.dueDate);
      
      case 'payment_confirmation':
        return smsService.sendPaymentConfirmation(phone, data.customerName, data.amount, data.transactionId);
      
      case 'welcome':
        return smsService.sendServiceActivation(phone, data.customerName, data.planName, data.username);
      
      case 'suspension_warning':
        return smsService.sendSuspensionWarning(phone, data.customerName, data.daysRemaining);
      
      case 'outage':
        return smsService.sendOutageNotification(phone, data.customerName, data.affectedArea, data.estimatedRestore);
      
      case 'invoice':
        return smsService.sendInvoiceNotification(phone, data.customerName, data.invoiceNumber, data.amount, data.dueDate);
      
      default:
        logger.warn(`Unknown SMS notification type: ${type}`);
        return false;
    }
  }

  /**
   * Send Email notification
   */
  private async sendEmailNotification(email: string, type: string, data: any): Promise<boolean> {
    switch (type) {
      case 'payment_reminder':
        return emailService.sendPaymentReminder(email, {
          customerName: data.customerName,
          amount: data.amount,
          dueDate: data.dueDate,
          daysOverdue: data.daysOverdue || 0,
          paybillNumber: data.paybillNumber,
          accountNumber: data.accountNumber
        });
      
      case 'payment_confirmation':
        return emailService.sendPaymentReceipt(email, {
          customerName: data.customerName,
          amount: data.amount,
          transactionId: data.transactionId,
          date: data.date,
          paymentMethod: data.paymentMethod
        });
      
      case 'welcome':
        return emailService.sendWelcome(email, {
          customerName: data.customerName,
          planName: data.planName,
          username: data.username,
          portalUrl: data.portalUrl,
          supportPhone: data.supportPhone
        });
      
      case 'invoice':
        return emailService.sendInvoice(email, {
          customerName: data.customerName,
          invoiceNumber: data.invoiceNumber,
          amount: data.amount,
          dueDate: data.dueDate,
          planName: data.planName,
          paybillNumber: data.paybillNumber,
          accountNumber: data.accountNumber
        });
      
      case 'suspension_warning':
        return emailService.sendSuspensionNotice(email, {
          customerName: data.customerName,
          suspensionDate: data.suspensionDate,
          amount: data.amount,
          paybillNumber: data.paybillNumber,
          accountNumber: data.accountNumber
        });
      
      default:
        logger.warn(`Unknown email notification type: ${type}`);
        return false;
    }
  }

  /**
   * Send OTP to customer
   */
  async sendOTP(phone: string, code: string, expiryMinutes: number = 5): Promise<boolean> {
    // Try WhatsApp first, fallback to SMS
    if (whatsappService.isConfigured()) {
      const message = `Your ISP Billing verification code is: *${code}*\n\n` +
        `This code will expire in ${expiryMinutes} minutes.\n\n` +
        `Do not share this code with anyone.`;
      
      const result = await whatsappService.sendTextMessage(phone, message);
      if (result) return true;
    }

    // Fallback to SMS
    return smsService.sendOTP(phone, code, expiryMinutes);
  }

  /**
   * Send bulk notifications
   */
  async sendBulkNotifications(options: {
    customers: Array<{ phone?: string; email?: string; customerName: string }>;
    type: string;
    data: any;
    channels?: ('whatsapp' | 'sms' | 'email')[];
  }): Promise<{ total: number; sent: number; failed: number }> {
    const { customers, type, data, channels } = options;
    let sent = 0;
    let failed = 0;

    for (const customer of customers) {
      try {
        const result = await this.sendNotification({
          customerId: '', // Will be set by caller
          phone: customer.phone,
          email: customer.email,
          type: type as any,
          data: { ...data, customerName: customer.customerName },
          channels
        });

        if (result.success) {
          sent++;
        } else {
          failed++;
        }
      } catch (error) {
        failed++;
      }
    }

    logger.info(`Bulk notification completed`, { total: customers.length, sent, failed });
    return { total: customers.length, sent, failed };
  }

  /**
   * Get notification status summary
   */
  getStatus(): { whatsapp: boolean; sms: boolean; email: boolean } {
    return {
      whatsapp: whatsappService.isConfigured(),
      sms: smsService.isConfigured(),
      email: emailService.isConfigured()
    };
  }
}

export const notificationManager = new NotificationManager();
