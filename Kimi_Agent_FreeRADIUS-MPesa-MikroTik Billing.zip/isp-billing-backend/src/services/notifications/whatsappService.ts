import axios from 'axios';
import { logger } from '../../utils/logger';

/**
 * WhatsApp Business API Service
 * For sending notifications via WhatsApp
 */
export class WhatsAppService {
  private apiKey: string;
  private phoneNumberId: string;
  private baseUrl: string;

  constructor() {
    this.apiKey = process.env.WHATSAPP_API_KEY || '';
    this.phoneNumberId = process.env.WHATSAPP_PHONE_ID || '';
    this.baseUrl = 'https://graph.facebook.com/v18.0';
  }

  /**
   * Check if WhatsApp is configured
   */
  isConfigured(): boolean {
    return !!(this.apiKey && this.phoneNumberId);
  }

  /**
   * Send a text message
   */
  async sendTextMessage(to: string, message: string): Promise<boolean> {
    if (!this.isConfigured()) {
      logger.warn('WhatsApp not configured');
      return false;
    }

    try {
      const response = await axios.post(
        `${this.baseUrl}/${this.phoneNumberId}/messages`,
        {
          messaging_product: 'whatsapp',
          recipient_type: 'individual',
          to: this.formatPhoneNumber(to),
          type: 'text',
          text: { body: message }
        },
        {
          headers: {
            'Authorization': `Bearer ${this.apiKey}`,
            'Content-Type': 'application/json'
          }
        }
      );

      logger.info(`WhatsApp message sent to ${to}`, { messageId: response.data.messages?.[0]?.id });
      return true;
    } catch (error: any) {
      logger.error('Failed to send WhatsApp message', { error: error.message, to });
      return false;
    }
  }

  /**
   * Send a template message
   */
  async sendTemplateMessage(to: string, templateName: string, languageCode: string = 'en', components?: any[]): Promise<boolean> {
    if (!this.isConfigured()) {
      logger.warn('WhatsApp not configured');
      return false;
    }

    try {
      const payload: any = {
        messaging_product: 'whatsapp',
        recipient_type: 'individual',
        to: this.formatPhoneNumber(to),
        type: 'template',
        template: {
          name: templateName,
          language: { code: languageCode }
        }
      };

      if (components) {
        payload.template.components = components;
      }

      const response = await axios.post(
        `${this.baseUrl}/${this.phoneNumberId}/messages`,
        payload,
        {
          headers: {
            'Authorization': `Bearer ${this.apiKey}`,
            'Content-Type': 'application/json'
          }
        }
      );

      logger.info(`WhatsApp template sent to ${to}`, { templateName, messageId: response.data.messages?.[0]?.id });
      return true;
    } catch (error: any) {
      logger.error('Failed to send WhatsApp template', { error: error.message, to, templateName });
      return false;
    }
  }

  /**
   * Send payment reminder
   */
  async sendPaymentReminder(to: string, customerName: string, amount: number, dueDate: string): Promise<boolean> {
    const message = `Hi ${customerName},\n\n` +
      `This is a friendly reminder that your internet service payment of *KES ${amount.toLocaleString()}* is due on *${dueDate}*.\n\n` +
      `Please make your payment via M-Pesa to avoid service interruption.\n\n` +
      `Thank you!`;

    return this.sendTextMessage(to, message);
  }

  /**
   * Send payment confirmation
   */
  async sendPaymentConfirmation(to: string, customerName: string, amount: number, transactionId: string): Promise<boolean> {
    const message = `Hi ${customerName},\n\n` +
      `Thank you for your payment of *KES ${amount.toLocaleString()}*.\n\n` +
      `Transaction ID: *${transactionId}*\n\n` +
      `Your internet service is now active.\n\n` +
      `Have a great day!`;

    return this.sendTextMessage(to, message);
  }

  /**
   * Send service activation
   */
  async sendServiceActivation(to: string, customerName: string, planName: string, username: string, password: string): Promise<boolean> {
    const message = `Welcome ${customerName}! 🎉\n\n` +
      `Your *${planName}* internet service has been activated.\n\n` +
      `Login Details:\n` +
      `Username: *${username}*\n` +
      `Password: *${password}*\n\n` +
      `To get started:\n` +
      `1. Connect to your WiFi network\n` +
      `2. Open a browser\n` +
      `3. Enter your login details\n\n` +
      `Need help? Contact us anytime!`;

    return this.sendTextMessage(to, message);
  }

  /**
   * Send service suspension warning
   */
  async sendSuspensionWarning(to: string, customerName: string, daysRemaining: number): Promise<boolean> {
    const message = `Hi ${customerName},\n\n` +
      `⚠️ *Service Suspension Warning*\n\n` +
      `Your internet service will be suspended in *${daysRemaining} day${daysRemaining > 1 ? 's' : ''}* due to non-payment.\n\n` +
      `Please make your payment as soon as possible to avoid service interruption.\n\n` +
      `Pay via M-Pesa or contact us for assistance.`;

    return this.sendTextMessage(to, message);
  }

  /**
   * Send outage notification
   */
  async sendOutageNotification(to: string, customerName: string, affectedArea: string, estimatedRestore: string): Promise<boolean> {
    const message = `Hi ${customerName},\n\n` +
      `🔧 *Service Maintenance Notice*\n\n` +
      `We're experiencing a temporary outage in *${affectedArea}*.\n\n` +
      `Our team is working to restore service.\n` +
      `Estimated restoration: *${estimatedRestore}*\n\n` +
      `We apologize for any inconvenience.`;

    return this.sendTextMessage(to, message);
  }

  /**
   * Send monthly usage report
   */
  async sendUsageReport(to: string, customerName: string, dataUsed: string, dataLimit: string, daysRemaining: number): Promise<boolean> {
    const percentage = Math.round((parseFloat(dataUsed) / parseFloat(dataLimit)) * 100);
    const message = `Hi ${customerName},\n\n` +
      `📊 *Monthly Usage Report*\n\n` +
      `Data Used: *${dataUsed} GB* / ${dataLimit} GB (${percentage}%)\n` +
      `Days Remaining: *${daysRemaining}*\n\n` +
      percentage > 80 
        ? `⚠️ You're approaching your data limit. Consider upgrading your plan.` 
        : `You're on track with your data usage. Keep it up!`;

    return this.sendTextMessage(to, message);
  }

  /**
   * Format phone number for WhatsApp
   */
  private formatPhoneNumber(phone: string): string {
    // Remove all non-numeric characters
    let cleaned = phone.replace(/\D/g, '');
    
    // Remove leading 0 if present
    if (cleaned.startsWith('0')) {
      cleaned = cleaned.substring(1);
    }
    
    // Add country code if not present (default to Kenya +254)
    if (!cleaned.startsWith('254') && !cleaned.startsWith('+')) {
      cleaned = '254' + cleaned;
    }
    
    // Remove + if present
    if (cleaned.startsWith('+')) {
      cleaned = cleaned.substring(1);
    }
    
    return cleaned;
  }

  /**
   * Verify webhook signature
   */
  verifyWebhookSignature(body: string, signature: string): boolean {
    const crypto = require('crypto');
    const expectedSignature = crypto
      .createHmac('sha256', this.apiKey)
      .update(body)
      .digest('hex');
    
    return crypto.timingSafeEqual(
      Buffer.from(signature),
      Buffer.from(expectedSignature)
    );
  }

  /**
   * Handle incoming webhook
   */
  async handleWebhook(payload: any): Promise<void> {
    logger.info('Received WhatsApp webhook', { payload });

    // Handle different message types
    if (payload.entry?.[0]?.changes?.[0]?.value?.messages) {
      const messages = payload.entry[0].changes[0].value.messages;
      
      for (const message of messages) {
        await this.handleIncomingMessage(message);
      }
    }
  }

  /**
   * Handle incoming message
   */
  private async handleIncomingMessage(message: any): Promise<void> {
    const from = message.from;
    const type = message.type;

    logger.info('Processing incoming WhatsApp message', { from, type });

    // Handle text messages
    if (type === 'text') {
      const text = message.text.body.toLowerCase();

      // Simple auto-responses
      if (text.includes('balance') || text.includes('status')) {
        await this.sendTextMessage(from, 
          'To check your account balance, please visit: https://your-domain.com/portal\n\n' +
          'Or contact our support team for assistance.'
        );
      } else if (text.includes('pay') || text.includes('payment')) {
        await this.sendTextMessage(from,
          'To make a payment:\n\n' +
          '1. Go to M-Pesa\n' +
          '2. Select Lipa na M-Pesa\n' +
          '3. Enter Paybill: *174379*\n' +
          '4. Account: Your phone number\n\n' +
          'Or pay online: https://your-domain.com/pay'
        );
      } else if (text.includes('help') || text.includes('support')) {
        await this.sendTextMessage(from,
          '🆘 *Support Options*\n\n' +
          '📞 Call: 0700 123 456\n' +
          '💬 WhatsApp: 0700 123 456\n' +
          '📧 Email: support@your-domain.com\n\n' +
          'Our team is available 24/7!'
        );
      } else {
        await this.sendTextMessage(from,
          'Thank you for contacting us!\n\n' +
          'How can we help you today?\n\n' +
          'Type:\n' +
          '• *balance* - Check account status\n' +
          '• *pay* - Payment options\n' +
          '• *help* - Contact support'
        );
      }
    }
  }
}

export const whatsappService = new WhatsAppService();
