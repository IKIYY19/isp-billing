import nodemailer from 'nodemailer';
import { logger } from '../../utils/logger';

/**
 * Email Service for sending transactional emails
 */
export class EmailService {
  private transporter: nodemailer.Transporter | null = null;
  private fromEmail: string;
  private fromName: string;

  constructor() {
    this.fromEmail = process.env.FROM_EMAIL || 'noreply@isp-billing.com';
    this.fromName = process.env.FROM_NAME || 'ISP Billing';
    this.initializeTransporter();
  }

  /**
   * Initialize email transporter
   */
  private initializeTransporter(): void {
    const smtpHost = process.env.SMTP_HOST;
    const smtpPort = parseInt(process.env.SMTP_PORT || '587');
    const smtpUser = process.env.SMTP_USER;
    const smtpPass = process.env.SMTP_PASS;
    const smtpSecure = process.env.SMTP_SECURE === 'true';

    if (!smtpHost || !smtpUser || !smtpPass) {
      logger.warn('Email service not fully configured');
      return;
    }

    this.transporter = nodemailer.createTransport({
      host: smtpHost,
      port: smtpPort,
      secure: smtpSecure,
      auth: {
        user: smtpUser,
        pass: smtpPass
      },
      tls: {
        rejectUnauthorized: false
      }
    });
  }

  /**
   * Check if email is configured
   */
  isConfigured(): boolean {
    return this.transporter !== null;
  }

  /**
   * Send email
   */
  async sendEmail(options: {
    to: string | string[];
    subject: string;
    html?: string;
    text?: string;
    attachments?: any[];
    cc?: string | string[];
    bcc?: string | string[];
  }): Promise<{ success: boolean; messageId?: string; error?: string }> {
    if (!this.transporter) {
      logger.warn('Email transporter not configured');
      return { success: false, error: 'Email not configured' };
    }

    try {
      const result = await this.transporter.sendMail({
        from: `"${this.fromName}" <${this.fromEmail}>`,
        to: options.to,
        cc: options.cc,
        bcc: options.bcc,
        subject: options.subject,
        text: options.text,
        html: options.html,
        attachments: options.attachments
      });

      logger.info(`Email sent successfully`, { 
        to: options.to, 
        subject: options.subject,
        messageId: result.messageId 
      });

      return { success: true, messageId: result.messageId };
    } catch (error: any) {
      logger.error('Failed to send email', { 
        error: error.message, 
        to: options.to, 
        subject: options.subject 
      });
      return { success: false, error: error.message };
    }
  }

  /**
   * Send invoice email
   */
  async sendInvoice(to: string, data: {
    customerName: string;
    invoiceNumber: string;
    amount: number;
    dueDate: string;
    planName: string;
    paybillNumber: string;
    accountNumber: string;
    pdfUrl?: string;
  }): Promise<boolean> {
    const html = this.getInvoiceTemplate(data);
    
    const result = await this.sendEmail({
      to,
      subject: `Invoice #${data.invoiceNumber} - ${data.planName}`,
      html,
      text: this.getInvoiceText(data)
    });

    return result.success;
  }

  /**
   * Send payment receipt
   */
  async sendPaymentReceipt(to: string, data: {
    customerName: string;
    amount: number;
    transactionId: string;
    date: string;
    paymentMethod: string;
  }): Promise<boolean> {
    const html = this.getPaymentReceiptTemplate(data);
    
    const result = await this.sendEmail({
      to,
      subject: `Payment Receipt - ${data.transactionId}`,
      html,
      text: this.getPaymentReceiptText(data)
    });

    return result.success;
  }

  /**
   * Send welcome email
   */
  async sendWelcome(to: string, data: {
    customerName: string;
    planName: string;
    username: string;
    portalUrl: string;
    supportPhone: string;
  }): Promise<boolean> {
    const html = this.getWelcomeTemplate(data);
    
    const result = await this.sendEmail({
      to,
      subject: 'Welcome to ISP Billing!',
      html,
      text: this.getWelcomeText(data)
    });

    return result.success;
  }

  /**
   * Send password reset email
   */
  async sendPasswordReset(to: string, data: {
    customerName: string;
    resetUrl: string;
    expiryHours: number;
  }): Promise<boolean> {
    const html = this.getPasswordResetTemplate(data);
    
    const result = await this.sendEmail({
      to,
      subject: 'Password Reset Request',
      html,
      text: this.getPasswordResetText(data)
    });

    return result.success;
  }

  /**
   * Send payment reminder
   */
  async sendPaymentReminder(to: string, data: {
    customerName: string;
    amount: number;
    dueDate: string;
    daysOverdue: number;
    paybillNumber: string;
    accountNumber: string;
  }): Promise<boolean> {
    const html = this.getPaymentReminderTemplate(data);
    
    const result = await this.sendEmail({
      to,
      subject: `Payment Reminder - ${data.daysOverdue > 0 ? 'OVERDUE' : 'Upcoming'}`,
      html,
      text: this.getPaymentReminderText(data)
    });

    return result.success;
  }

  /**
   * Send service suspension notice
   */
  async sendSuspensionNotice(to: string, data: {
    customerName: string;
    suspensionDate: string;
    amount: number;
    paybillNumber: string;
    accountNumber: string;
  }): Promise<boolean> {
    const html = this.getSuspensionNoticeTemplate(data);
    
    const result = await this.sendEmail({
      to,
      subject: 'URGENT: Service Suspension Notice',
      html,
      text: this.getSuspensionNoticeText(data)
    });

    return result.success;
  }

  // ============================================
  // Email Templates
  // ============================================

  private getInvoiceTemplate(data: any): string {
    return `
<!DOCTYPE html>
<html>
<head>
  <style>
    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
    .header { background: #667eea; color: white; padding: 20px; text-align: center; }
    .content { background: #f9f9f9; padding: 20px; }
    .invoice-details { background: white; padding: 20px; margin: 20px 0; border-radius: 5px; }
    .amount { font-size: 24px; font-weight: bold; color: #667eea; }
    .button { display: inline-block; background: #667eea; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; margin: 20px 0; }
    .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>Invoice</h1>
    </div>
    <div class="content">
      <p>Hi ${data.customerName},</p>
      <p>Thank you for your business. Please find your invoice details below:</p>
      
      <div class="invoice-details">
        <p><strong>Invoice Number:</strong> ${data.invoiceNumber}</p>
        <p><strong>Plan:</strong> ${data.planName}</p>
        <p><strong>Due Date:</strong> ${data.dueDate}</p>
        <p class="amount">Amount: KES ${data.amount.toLocaleString()}</p>
      </div>
      
      <h3>Payment Options:</h3>
      <p><strong>M-Pesa Paybill:</strong> ${data.paybillNumber}</p>
      <p><strong>Account Number:</strong> ${data.accountNumber}</p>
      
      <a href="https://your-domain.com/pay" class="button">Pay Online</a>
      
      <p>If you have any questions, please contact our support team.</p>
    </div>
    <div class="footer">
      <p>ISP Billing System</p>
      <p>support@your-domain.com | 0700 123 456</p>
    </div>
  </div>
</body>
</html>`;
  }

  private getInvoiceText(data: any): string {
    return `Hi ${data.customerName},

Invoice #${data.invoiceNumber}
Plan: ${data.planName}
Amount: KES ${data.amount.toLocaleString()}
Due Date: ${data.dueDate}

Payment Options:
M-Pesa Paybill: ${data.paybillNumber}
Account Number: ${data.accountNumber}

Pay online: https://your-domain.com/pay

Support: support@your-domain.com | 0700 123 456`;
  }

  private getPaymentReceiptTemplate(data: any): string {
    return `
<!DOCTYPE html>
<html>
<head>
  <style>
    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
    .header { background: #10b981; color: white; padding: 20px; text-align: center; }
    .content { background: #f9f9f9; padding: 20px; }
    .receipt { background: white; padding: 20px; margin: 20px 0; border-radius: 5px; }
    .amount { font-size: 24px; font-weight: bold; color: #10b981; }
    .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>✓ Payment Received</h1>
    </div>
    <div class="content">
      <p>Hi ${data.customerName},</p>
      <p>Thank you for your payment. Here are your receipt details:</p>
      
      <div class="receipt">
        <p><strong>Transaction ID:</strong> ${data.transactionId}</p>
        <p><strong>Date:</strong> ${data.date}</p>
        <p><strong>Payment Method:</strong> ${data.paymentMethod}</p>
        <p class="amount">Amount Paid: KES ${data.amount.toLocaleString()}</p>
      </div>
      
      <p>Your internet service is now active. Thank you for your business!</p>
    </div>
    <div class="footer">
      <p>ISP Billing System</p>
      <p>support@your-domain.com | 0700 123 456</p>
    </div>
  </div>
</body>
</html>`;
  }

  private getPaymentReceiptText(data: any): string {
    return `Hi ${data.customerName},

Payment Received!

Transaction ID: ${data.transactionId}
Date: ${data.date}
Payment Method: ${data.paymentMethod}
Amount: KES ${data.amount.toLocaleString()}

Thank you for your payment!

ISP Billing System`;
  }

  private getWelcomeTemplate(data: any): string {
    return `
<!DOCTYPE html>
<html>
<head>
  <style>
    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
    .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; }
    .content { background: #f9f9f9; padding: 20px; }
    .details { background: white; padding: 20px; margin: 20px 0; border-radius: 5px; }
    .button { display: inline-block; background: #667eea; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; margin: 20px 0; }
    .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>Welcome to ISP Billing!</h1>
      <p>Your internet service is now active</p>
    </div>
    <div class="content">
      <p>Hi ${data.customerName},</p>
      <p>Welcome to our family! We're excited to have you on board.</p>
      
      <div class="details">
        <h3>Your Service Details:</h3>
        <p><strong>Plan:</strong> ${data.planName}</p>
        <p><strong>Username:</strong> ${data.username}</p>
        <p><strong>Support Phone:</strong> ${data.supportPhone}</p>
      </div>
      
      <h3>Getting Started:</h3>
      <ol>
        <li>Connect to your WiFi network</li>
        <li>Open a web browser</li>
        <li>Enter your login details when prompted</li>
        <li>Start browsing!</li>
      </ol>
      
      <a href="${data.portalUrl}" class="button">Access Customer Portal</a>
      
      <p>Need help? Our support team is available 24/7.</p>
    </div>
    <div class="footer">
      <p>ISP Billing System</p>
      <p>support@your-domain.com | ${data.supportPhone}</p>
    </div>
  </div>
</body>
</html>`;
  }

  private getWelcomeText(data: any): string {
    return `Welcome to ISP Billing!

Hi ${data.customerName},

Your ${data.planName} is now active!

Username: ${data.username}
Portal: ${data.portalUrl}
Support: ${data.supportPhone}

Getting Started:
1. Connect to your WiFi network
2. Open a web browser
3. Enter your login details
4. Start browsing!

Need help? Contact us anytime!`;
  }

  private getPasswordResetTemplate(data: any): string {
    return `
<!DOCTYPE html>
<html>
<head>
  <style>
    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
    .header { background: #f59e0b; color: white; padding: 20px; text-align: center; }
    .content { background: #f9f9f9; padding: 20px; }
    .button { display: inline-block; background: #f59e0b; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; margin: 20px 0; }
    .warning { color: #ef4444; font-size: 12px; }
    .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>Password Reset Request</h1>
    </div>
    <div class="content">
      <p>Hi ${data.customerName},</p>
      <p>We received a request to reset your password. Click the button below to create a new password:</p>
      
      <a href="${data.resetUrl}" class="button">Reset Password</a>
      
      <p class="warning">This link will expire in ${data.expiryHours} hours.</p>
      
      <p>If you didn't request this, please ignore this email or contact support if you have concerns.</p>
    </div>
    <div class="footer">
      <p>ISP Billing System</p>
    </div>
  </div>
</body>
</html>`;
  }

  private getPasswordResetText(data: any): string {
    return `Password Reset Request

Hi ${data.customerName},

We received a request to reset your password.

Reset Link: ${data.resetUrl}

This link will expire in ${data.expiryHours} hours.

If you didn't request this, please ignore this email.`;
  }

  private getPaymentReminderTemplate(data: any): string {
    const urgencyColor = data.daysOverdue > 0 ? '#ef4444' : '#f59e0b';
    const status = data.daysOverdue > 0 ? `OVERDUE (${data.daysOverdue} days)` : 'Upcoming';
    
    return `
<!DOCTYPE html>
<html>
<head>
  <style>
    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
    .header { background: ${urgencyColor}; color: white; padding: 20px; text-align: center; }
    .content { background: #f9f9f9; padding: 20px; }
    .amount { font-size: 24px; font-weight: bold; color: ${urgencyColor}; }
    .button { display: inline-block; background: ${urgencyColor}; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; margin: 20px 0; }
    .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>Payment Reminder - ${status}</h1>
    </div>
    <div class="content">
      <p>Hi ${data.customerName},</p>
      
      <p class="amount">Amount Due: KES ${data.amount.toLocaleString()}</p>
      <p><strong>Due Date:</strong> ${data.dueDate}</p>
      
      <h3>Payment Options:</h3>
      <p><strong>M-Pesa Paybill:</strong> ${data.paybillNumber}</p>
      <p><strong>Account Number:</strong> ${data.accountNumber}</p>
      
      <a href="https://your-domain.com/pay" class="button">Pay Now</a>
      
      <p>Please make your payment to avoid service interruption.</p>
    </div>
    <div class="footer">
      <p>ISP Billing System</p>
      <p>support@your-domain.com | 0700 123 456</p>
    </div>
  </div>
</body>
</html>`;
  }

  private getPaymentReminderText(data: any): string {
    const status = data.daysOverdue > 0 ? `OVERDUE (${data.daysOverdue} days)` : 'Upcoming';
    
    return `Payment Reminder - ${status}

Hi ${data.customerName},

Amount Due: KES ${data.amount.toLocaleString()}
Due Date: ${data.dueDate}

Payment Options:
M-Pesa Paybill: ${data.paybillNumber}
Account Number: ${data.accountNumber}

Pay now: https://your-domain.com/pay

Support: support@your-domain.com`;
  }

  private getSuspensionNoticeTemplate(data: any): string {
    return `
<!DOCTYPE html>
<html>
<head>
  <style>
    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
    .header { background: #ef4444; color: white; padding: 20px; text-align: center; }
    .content { background: #f9f9f9; padding: 20px; }
    .amount { font-size: 24px; font-weight: bold; color: #ef4444; }
    .button { display: inline-block; background: #ef4444; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; margin: 20px 0; }
    .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>⚠️ Service Suspension Notice</h1>
    </div>
    <div class="content">
      <p>Hi ${data.customerName},</p>
      
      <p><strong>Your internet service will be suspended on ${data.suspensionDate} due to non-payment.</strong></p>
      
      <p class="amount">Amount Due: KES ${data.amount.toLocaleString()}</p>
      
      <h3>Pay Now to Avoid Disruption:</h3>
      <p><strong>M-Pesa Paybill:</strong> ${data.paybillNumber}</p>
      <p><strong>Account Number:</strong> ${data.accountNumber}</p>
      
      <a href="https://your-domain.com/pay" class="button">Pay Now</a>
      
      <p>Need help? Contact our support team immediately.</p>
    </div>
    <div class="footer">
      <p>ISP Billing System</p>
      <p>support@your-domain.com | 0700 123 456</p>
    </div>
  </div>
</body>
</html>`;
  }

  private getSuspensionNoticeText(data: any): string {
    return `URGENT: Service Suspension Notice

Hi ${data.customerName},

Your internet service will be suspended on ${data.suspensionDate}.

Amount Due: KES ${data.amount.toLocaleString()}

Pay Now:
M-Pesa Paybill: ${data.paybillNumber}
Account Number: ${data.accountNumber}

Pay online: https://your-domain.com/pay

Support: support@your-domain.com | 0700 123 456`;
  }
}

export const emailService = new EmailService();
