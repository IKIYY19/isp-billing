import { NodeSSH } from 'node-ssh';
import { Client } from 'ssh2';
import { SNMPSession } from 'net-snmp';
import { logger } from '../../utils/logger';
import {
  OLTConfig,
  PONPort,
  ONU,
  ONT,
  OLTCommand,
  OLTAlarm,
  OLTPerformance,
  ONUProvisioningData,
  OLTDiscoveryResult
} from './types';

export abstract class BaseOLTAdapter {
  protected config: OLTConfig;
  protected sshClient: NodeSSH | null = null;
  protected ssh2Client: Client | null = null;
  protected snmpSession: SNMPSession | null = null;
  protected isConnected: boolean = false;
  protected lastCommandTime: number = 0;
  protected readonly COMMAND_DELAY = 500; // ms between commands

  constructor(config: OLTConfig) {
    this.config = config;
  }

  // ============================================
  // Connection Management
  // ============================================

  abstract connect(): Promise<boolean>;
  abstract disconnect(): Promise<void>;

  protected async connectSSH(): Promise<boolean> {
    try {
      this.sshClient = new NodeSSH();
      
      await this.sshClient.connect({
        host: this.config.ipAddress,
        port: this.config.port || 22,
        username: this.config.username,
        password: this.config.password,
        readyTimeout: 30000,
        keepaliveInterval: 10000
      });

      // Enter enable mode if password provided
      if (this.config.enablePassword) {
        await this.sshClient.execCommand('enable', {
          stdin: this.config.enablePassword + '\n'
        });
      }

      this.isConnected = true;
      logger.info(`SSH connected to OLT ${this.config.name} (${this.config.ipAddress})`);
      return true;
    } catch (error) {
      logger.error(`SSH connection failed to OLT ${this.config.name}:`, error);
      this.isConnected = false;
      return false;
    }
  }

  protected async connectTelnet(): Promise<boolean> {
    // Telnet implementation using telnet-client
    try {
      const { Telnet } = await import('telnet-client');
      const connection = new Telnet();

      const params = {
        host: this.config.ipAddress,
        port: this.config.port || 23,
        loginPrompt: /[Uu]sername:|[Ll]ogin:/,
        passwordPrompt: /[Pp]assword:/,
        username: this.config.username,
        password: this.config.password,
        shellPrompt: /[#>]\s*$/,
        timeout: 30000
      };

      await connection.connect(params);
      this.isConnected = true;
      logger.info(`Telnet connected to OLT ${this.config.name}`);
      return true;
    } catch (error) {
      logger.error(`Telnet connection failed to OLT ${this.config.name}:`, error);
      return false;
    }
  }

  protected async connectSNMP(): Promise<boolean> {
    try {
      const snmp = await import('net-snmp');
      
      this.snmpSession = snmp.createSession(
        this.config.ipAddress,
        this.config.snmpCommunity || 'public',
        {
          version: this.config.snmpVersion === 'v3' 
            ? snmp.Version3 
            : this.config.snmpVersion === 'v1' 
              ? snmp.Version1 
              : snmp.Version2c,
          timeout: 10000
        }
      );

      this.isConnected = true;
      logger.info(`SNMP connected to OLT ${this.config.name}`);
      return true;
    } catch (error) {
      logger.error(`SNMP connection failed to OLT ${this.config.name}:`, error);
      return false;
    }
  }

  protected async executeCommand(command: string, timeout: number = 30000): Promise<{ success: boolean; output: string; error?: string }> {
    if (!this.isConnected || !this.sshClient) {
      return { success: false, output: '', error: 'Not connected to OLT' };
    }

    // Rate limiting
    const now = Date.now();
    const timeSinceLastCommand = now - this.lastCommandTime;
    if (timeSinceLastCommand < this.COMMAND_DELAY) {
      await new Promise(resolve => setTimeout(resolve, this.COMMAND_DELAY - timeSinceLastCommand));
    }

    try {
      this.lastCommandTime = Date.now();
      
      const result = await this.sshClient.execCommand(command, {
        execOptions: { timeout }
      });

      return {
        success: result.code === 0,
        output: result.stdout,
        error: result.stderr
      };
    } catch (error: any) {
      logger.error(`Command execution failed on OLT ${this.config.name}:`, error);
      return {
        success: false,
        output: '',
        error: error.message
      };
    }
  }

  // ============================================
  // Abstract Methods - Must be implemented by vendors
  // ============================================

  abstract getSystemInfo(): Promise<any>;
  abstract getPONPorts(): Promise<PONPort[]>;
  abstract getONUs(ponPortId?: string): Promise<ONU[]>;
  abstract getONUDetail(onuId: string): Promise<ONU | null>;
  abstract getONTs(onuId: string): Promise<ONT[]>;
  abstract provisionONU(data: ONUProvisioningData): Promise<{ success: boolean; message: string; onuId?: string }>;
  abstract deprovisionONU(onuId: string): Promise<{ success: boolean; message: string }>;
  abstract updateONUConfig(onuId: string, config: Partial<ONU>): Promise<{ success: boolean; message: string }>;
  abstract resetONU(onuId: string): Promise<{ success: boolean; message: string }>;
  abstract getAlarms(): Promise<OLTAlarm[]>;
  abstract getPerformance(): Promise<OLTPerformance>;
  abstract executeCustomCommand(command: string): Promise<{ success: boolean; output: string }>;

  // ============================================
  // Common Utility Methods
  // ============================================

  protected parseOpticalPower(value: string | number): number | undefined {
    if (typeof value === 'number') return value;
    if (typeof value === 'string') {
      const parsed = parseFloat(value);
      return isNaN(parsed) ? undefined : parsed;
    }
    return undefined;
  }

  protected parseMacAddress(mac: string): string {
    // Normalize MAC address format (XX:XX:XX:XX:XX:XX)
    return mac
      .replace(/[-.]/g, ':')
      .toUpperCase()
      .replace(/[^0-9A-F:]/g, '');
  }

  protected parseSerialNumber(sn: string): string {
    return sn.trim().toUpperCase();
  }

  protected calculateDistance(rxPower: number, txPower: number): number | undefined {
    // Rough estimation based on optical power
    // In reality, this depends on fiber type, splices, etc.
    if (rxPower === undefined || txPower === undefined) return undefined;
    
    const loss = txPower - rxPower;
    // Assuming ~0.35 dB/km loss for single-mode fiber
    const distance = loss / 0.35;
    return Math.round(distance * 100) / 100;
  }

  protected isSignalQualityGood(rxPower: number): boolean {
    // GPON typical range: -8 to -27 dBm
    // Good signal: -8 to -25 dBm
    return rxPower >= -25 && rxPower <= -8;
  }

  protected formatUptime(seconds: number): string {
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    
    if (days > 0) return `${days}d ${hours}h ${minutes}m`;
    if (hours > 0) return `${hours}h ${minutes}m`;
    return `${minutes}m`;
  }

  // ============================================
  // Health Check Methods
  // ============================================

  async healthCheck(): Promise<{ healthy: boolean; issues: string[]; metrics: any }> {
    const issues: string[] = [];
    const metrics: any = {};

    try {
      // Check connection
      if (!this.isConnected) {
        issues.push('Not connected to OLT');
        return { healthy: false, issues, metrics };
      }

      // Get system info
      const sysInfo = await this.getSystemInfo();
      metrics.system = sysInfo;

      // Check CPU/Memory if available
      if (sysInfo.cpuUsage && sysInfo.cpuUsage > 80) {
        issues.push(`High CPU usage: ${sysInfo.cpuUsage}%`);
      }

      if (sysInfo.memoryUsage && sysInfo.memoryUsage > 80) {
        issues.push(`High memory usage: ${sysInfo.memoryUsage}%`);
      }

      // Check temperature
      if (sysInfo.temperature && sysInfo.temperature > 70) {
        issues.push(`High temperature: ${sysInfo.temperature}°C`);
      }

      // Check PON ports
      const ponPorts = await this.getPONPorts();
      metrics.ponPorts = {
        total: ponPorts.length,
        online: ponPorts.filter(p => p.status === 'online').length,
        offline: ponPorts.filter(p => p.status === 'offline').length
      };

      // Check ONUs
      const onus = await this.getONUs();
      metrics.onus = {
        total: onus.length,
        online: onus.filter(o => o.status === 'online').length,
        offline: onus.filter(o => o.status === 'offline').length
      };

      // Check for offline ONUs
      const offlineOnus = onus.filter(o => o.status === 'offline');
      if (offlineOnus.length > 0) {
        issues.push(`${offlineOnus.length} ONUs are offline`);
      }

      // Check signal quality
      const poorSignalOnus = onus.filter(o => 
        o.rxPower !== undefined && !this.isSignalQualityGood(o.rxPower)
      );
      if (poorSignalOnus.length > 0) {
        issues.push(`${poorSignalOnus.length} ONUs have poor signal quality`);
      }

      return {
        healthy: issues.length === 0,
        issues,
        metrics
      };
    } catch (error: any) {
      logger.error(`Health check failed for OLT ${this.config.name}:`, error);
      issues.push(`Health check error: ${error.message}`);
      return { healthy: false, issues, metrics };
    }
  }

  // ============================================
  // Bulk Operations
  // ============================================

  async bulkProvisionONUs(dataArray: ONUProvisioningData[]): Promise<{ 
    success: boolean; 
    results: Array<{ serialNumber: string; success: boolean; message: string; onuId?: string }>;
  }> {
    const results: Array<{ serialNumber: string; success: boolean; message: string; onuId?: string }> = [];

    for (const data of dataArray) {
      try {
        const result = await this.provisionONU(data);
        results.push({
          serialNumber: data.serialNumber,
          success: result.success,
          message: result.message,
          onuId: result.onuId
        });
      } catch (error: any) {
        results.push({
          serialNumber: data.serialNumber,
          success: false,
          message: error.message
        });
      }
    }

    return {
      success: results.every(r => r.success),
      results
    };
  }

  async bulkResetONU(onuIds: string[]): Promise<{
    success: boolean;
    results: Array<{ onuId: string; success: boolean; message: string }>;
  }> {
    const results: Array<{ onuId: string; success: boolean; message: string }> = [];

    for (const onuId of onuIds) {
      try {
        const result = await this.resetONU(onuId);
        results.push({ onuId, ...result });
      } catch (error: any) {
        results.push({ onuId, success: false, message: error.message });
      }
    }

    return {
      success: results.every(r => r.success),
      results
    };
  }

  // ============================================
  // Auto-Discovery
  // ============================================

  async discoverONUs(ponPortId?: string): Promise<{
    discovered: Array<{ serialNumber: string; ponPortId: string; status: string }>;
    unprovisioned: Array<{ serialNumber: string; ponPortId: string; lastSeen: Date }>;
  }> {
    const onus = await this.getONUs(ponPortId);
    
    const discovered = onus
      .filter(o => o.status === 'online' || o.status === 'offline')
      .map(o => ({
        serialNumber: o.serialNumber,
        ponPortId: o.ponPortId,
        status: o.status
      }));

    // ONUs that are visible but not fully provisioned
    const unprovisioned = onus
      .filter(o => o.status === 'auth-fail' || o.status === 'config-fail' || !o.customerId)
      .map(o => ({
        serialNumber: o.serialNumber,
        ponPortId: o.ponPortId,
        lastSeen: o.lastOnlineAt || o.updatedAt
      }));

    return { discovered, unprovisioned };
  }

  // ============================================
  // Cleanup
  // ============================================

  async dispose(): Promise<void> {
    await this.disconnect();
    this.sshClient = null;
    this.snmpSession = null;
    this.isConnected = false;
  }
}

export default BaseOLTAdapter;
