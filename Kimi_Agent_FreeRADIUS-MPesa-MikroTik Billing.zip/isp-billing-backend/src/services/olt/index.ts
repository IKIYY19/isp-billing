// OLT Service Exports
export { BaseOLTAdapter } from './baseOltAdapter';
export { oltManager, OLTManager } from './oltManager';
export * from './types';

// Vendor Adapters
export { GenericOLTAdapter } from './vendors/genericAdapter';
export { HuaweiOLTAdapter } from './vendors/huaweiAdapter';
export { ZTEOLTAdapter } from './vendors/zteAdapter';
export { NokiaOLTAdapter } from './vendors/nokiaAdapter';
export { FiberHomeOLTAdapter } from './vendors/fiberhomeAdapter';

// Supported vendors list
export const SUPPORTED_OLT_VENDORS = [
  { id: 'generic', name: 'Generic/Other', models: ['Generic GPON', 'Generic EPON', 'Other'] },
  { id: 'huawei', name: 'Huawei', models: ['MA5600T', 'MA5800', 'EA5800'] },
  { id: 'zte', name: 'ZTE', models: ['C220', 'C300', 'C320', 'C350', 'C600'] },
  { id: 'nokia', name: 'Nokia/Alcatel-Lucent', models: ['ISAM 7302', 'ISAM 7330', 'ISAM 7360'] },
  { id: 'fiberhome', name: 'FiberHome', models: ['AN5516-01', 'AN5516-04', 'AN5516-06'] }
] as const;

// Vendor protocols
export const VENDOR_PROTOCOLS = {
  huawei: ['ssh', 'telnet', 'snmp'],
  zte: ['ssh', 'telnet', 'snmp'],
  nokia: ['ssh', 'telnet'],
  fiberhome: ['ssh', 'telnet', 'snmp']
} as const;

// Default ports by protocol
export const DEFAULT_PORTS = {
  ssh: 22,
  telnet: 23,
  snmp: 161
} as const;
