// OLT Types and Interfaces

export type OLTVendor = 'huawei' | 'zte' | 'nokia' | 'fiberhome' | 'calix' | 'dasan' | 'edgecore' | 'bdcom';

export type OLTProtocol = 'telnet' | 'ssh' | 'snmp' | 'netconf' | 'rest' | 'tr069';

export type ONUStatus = 'online' | 'offline' | 'dying-gasp' | 'los' | 'auth-fail' | 'config-fail' | 'mismatch';

export type ONTStatus = 'online' | 'offline' | 'power-off' | 'mismatch';

export interface OLTConfig {
  id: string;
  name: string;
  vendor: OLTVendor;
  model: string;
  ipAddress: string;
  port: number;
  protocol: OLTProtocol;
  username: string;
  password: string;
  enablePassword?: string;
  snmpCommunity?: string;
  snmpVersion?: 'v1' | 'v2c' | 'v3';
  location?: string;
  coordinates?: { lat: number; lng: number };
  capacity: {
    maxPonPorts: number;
    maxOnusPerPort: number;
  };
  isActive: boolean;
  lastSeenAt?: Date;
  firmwareVersion?: string;
  systemUptime?: number;
  companyId?: string;
}

export interface PONPort {
  id: string;
  oltId: string;
  portNumber: number;
  shelf?: number;
  slot?: number;
  subSlot?: number;
  status: 'online' | 'offline' | 'disabled';
  type: 'gpon' | 'xgpon' | 'xgspon' | 'epon';
  maxDistance: number;
  transmitPower: number;
  receivePower: number;
  temperature: number;
  voltage: number;
  biasCurrent: number;
  onuCount: number;
  maxOnus: number;
  description?: string;
  lastUpdated: Date;
}

export interface ONU {
  id: string;
  oltId: string;
  ponPortId: string;
  onuId: number;
  serialNumber: string;
  macAddress: string;
  vendorId?: string;
  model?: string;
  firmwareVersion?: string;
  status: ONUStatus;
  adminState: 'enabled' | 'disabled';
  authMode: 'sn' | 'password' | 'loid' | 'mac';
  authInfo?: string;
  customerId?: string;
  customerName?: string;
  serviceProfile?: string;
  lineProfile?: string;
  trafficProfile?: string;
  rxPower?: number;
  txPower?: number;
  oltRxPower?: number;
  distance?: number;
  temperature?: number;
  voltage?: number;
  lastOnlineAt?: Date;
  lastOfflineAt?: Date;
  offlineCount: number;
  uptime?: number;
  description?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface ONT {
  id: string;
  onuId: string;
  ontId: number;
  serialNumber: string;
  macAddress: string;
  vendorId?: string;
  model?: string;
  status: ONTStatus;
  adminState: 'enabled' | 'disabled';
  rxPower?: number;
  txPower?: number;
  temperature?: number;
  voltage?: number;
  ethernetPorts: EthernetPort[];
  voipPorts?: VoIPPort[];
  wifiEnabled?: boolean;
  wifiSsid?: string;
  lastUpdated: Date;
}

export interface EthernetPort {
  id: string;
  ontId: string;
  portNumber: number;
  status: 'up' | 'down';
  speed: '10M' | '100M' | '1G' | '2.5G' | '10G';
  duplex: 'half' | 'full';
  vlanMode: 'tag' | 'untag' | 'hybrid';
  nativeVlan?: number;
  allowedVlans?: number[];
  rxBytes: number;
  txBytes: number;
  rxPackets: number;
  txPackets: number;
  rxErrors: number;
  txErrors: number;
}

export interface VoIPPort {
  id: string;
  ontId: string;
  portNumber: number;
  status: 'registered' | 'unregistered' | 'error';
  phoneNumber?: string;
  sipServer?: string;
  sipUsername?: string;
}

export interface ServiceProfile {
  id: string;
  name: string;
  vendor: OLTVendor;
  gemPorts: GemPort[];
  tconts: TCont[];
  vlans: VLANConfig[];
  qos: QoSConfig;
}

export interface GemPort {
  id: number;
  name: string;
  tcontId: number;
  direction: 'upstream' | 'downstream' | 'bidirectional';
  encryption: boolean;
  vlanId?: number;
  priority?: number;
}

export interface TCont {
  id: number;
  name: string;
  dbaProfileId?: number;
  fixedBandwidth?: number;
  assuredBandwidth?: number;
  maximumBandwidth: number;
  priority?: number;
}

export interface VLANConfig {
  id: number;
  name: string;
  mode: 'tag' | 'untag' | 'translate' | 'transparent';
  nativeVlan?: number;
  translateOldVlan?: number;
  translateNewVlan?: number;
}

export interface QoSConfig {
  mode: 'strict-priority' | 'weighted-round-robin';
  queues: QueueConfig[];
}

export interface QueueConfig {
  id: number;
  priority: number;
  weight?: number;
  cir?: number;
  pir?: number;
}

export interface OLTCommand {
  id: string;
  oltId: string;
  command: string;
  parameters: Record<string, any>;
  status: 'pending' | 'running' | 'completed' | 'failed';
  result?: any;
  error?: string;
  createdAt: Date;
  completedAt?: Date;
}

export interface OLTAlarm {
  id: string;
  oltId: string;
  onuId?: string;
  ponPortId?: string;
  severity: 'critical' | 'major' | 'minor' | 'warning' | 'info';
  category: 'communication' | 'equipment' | 'processing' | 'environmental' | 'service';
  type: string;
  description: string;
  source: string;
  acknowledged: boolean;
  acknowledgedBy?: string;
  acknowledgedAt?: Date;
  cleared: boolean;
  clearedAt?: Date;
  createdAt: Date;
}

export interface OLTPerformance {
  oltId: string;
  timestamp: Date;
  cpuUsage: number;
  memoryUsage: number;
  temperature: number;
  ponPorts: PONPortPerformance[];
}

export interface PONPortPerformance {
  portId: string;
  onuCount: number;
  onlineOnuCount: number;
  offlineOnuCount: number;
  rxPower: number;
  txPower: number;
  bandwidthUsage: {
    upstream: number;
    downstream: number;
  };
}

export interface ONUProvisioningData {
  serialNumber: string;
  ponPortId: string;
  onuId?: number;
  customerId?: string;
  serviceProfile?: string;
  lineProfile?: string;
  description?: string;
  vlanConfig?: VLANConfig[];
}

export interface OLTDiscoveryResult {
  success: boolean;
  oltInfo?: {
    vendor: OLTVendor;
    model: string;
    firmwareVersion: string;
    serialNumber: string;
    ponPorts: number;
  };
  error?: string;
}

export interface OLTAutoProvisioningConfig {
  enabled: boolean;
  defaultServiceProfile: string;
  defaultLineProfile: string;
  autoAssignOnuId: boolean;
  notifyCustomer: boolean;
  requireApproval: boolean;
}

export interface OLTVendorCapabilities {
  vendor: OLTVendor;
  protocols: OLTProtocol[];
  supportsNetconf: boolean;
  supportsSnmp: boolean;
  supportsTr069: boolean;
  maxPonPorts: number;
  maxOnusPerPort: number;
  supportedPonTypes: ('gpon' | 'xgpon' | 'xgspon' | 'epon')[];
  features: string[];
}

// Creative Features

export interface OLTSelfHealingConfig {
  enabled: boolean;
  checkInterval: number; // minutes
  actions: {
    restartOfflineOnus: boolean;
    resetLosOnus: boolean;
    rebalanceLoad: boolean;
    autoUpgradeFirmware: boolean;
  };
  thresholds: {
    maxOfflineDuration: number; // minutes
    maxLosDuration: number; // minutes
    minSignalQuality: number; // dBm
  };
}

export interface OLTAIOptimization {
  enabled: boolean;
  features: {
    predictFailures: boolean;
    optimizeBandwidth: boolean;
    suggestUpgrades: boolean;
    detectAnomalies: boolean;
  };
  mlModelVersion?: string;
  lastTrainingDate?: Date;
}

export interface OLTBandwidthOptimization {
  enabled: boolean;
  mode: 'automatic' | 'scheduled' | 'manual';
  timeWindows: {
    peak: { start: string; end: string };
    offPeak: { start: string; end: string };
  };
  policies: {
    prioritizeVoip: boolean;
    prioritizeVideo: boolean;
    fairSharing: boolean;
    burstAllowance: boolean;
  };
}
