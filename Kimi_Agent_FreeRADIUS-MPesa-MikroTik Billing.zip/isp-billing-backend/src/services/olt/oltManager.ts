import { database } from '../../config/database';
import { cache } from '../../config/redis';
import { logger } from '../../utils/logger';
import { jobQueue } from '../../config/queue';
import {
  OLTConfig,
  PONPort,
  ONU,
  ONT,
  OLTAlarm,
  OLTPerformance,
  ONUProvisioningData,
  OLTVendor,
  OLTSelfHealingConfig,
  OLTAIOptimization,
  OLTBandwidthOptimization
} from './types';
import { BaseOLTAdapter } from './baseOltAdapter';

// Vendor adapters
import { GenericOLTAdapter } from './vendors/genericAdapter';
import { HuaweiOLTAdapter } from './vendors/huaweiAdapter';
import { ZTEOLTAdapter } from './vendors/zteAdapter';
import { NokiaOLTAdapter } from './vendors/nokiaAdapter';
import { FiberHomeOLTAdapter } from './vendors/fiberhomeAdapter';

export class OLTManager {
  private adapters: Map<string, BaseOLTAdapter> = new Map();
  private selfHealingConfig: OLTSelfHealingConfig = {
    enabled: true,
    checkInterval: 5,
    actions: {
      restartOfflineOnus: true,
      resetLosOnus: true,
      rebalanceLoad: false,
      autoUpgradeFirmware: false
    },
    thresholds: {
      maxOfflineDuration: 30,
      maxLosDuration: 15,
      minSignalQuality: -27
    }
  };

  private aiOptimization: OLTAIOptimization = {
    enabled: true,
    features: {
      predictFailures: true,
      optimizeBandwidth: true,
      suggestUpgrades: true,
      detectAnomalies: true
    }
  };

  private bandwidthOptimization: OLTBandwidthOptimization = {
    enabled: true,
    mode: 'automatic',
    timeWindows: {
      peak: { start: '18:00', end: '23:00' },
      offPeak: { start: '01:00', end: '06:00' }
    },
    policies: {
      prioritizeVoip: true,
      prioritizeVideo: true,
      fairSharing: true,
      burstAllowance: true
    }
  };

  /**
   * Get adapter for OLT vendor
   */
  private getAdapter(config: OLTConfig): BaseOLTAdapter {
    const cacheKey = `olt-adapter:${config.id}`;
    
    // Check if adapter exists
    if (this.adapters.has(config.id)) {
      return this.adapters.get(config.id)!;
    }

    // Create new adapter based on vendor
    let adapter: BaseOLTAdapter;
    
    switch (config.vendor) {
      case 'generic':
        adapter = new GenericOLTAdapter(config);
        break;
      case 'huawei':
        adapter = new HuaweiOLTAdapter(config);
        break;
      case 'zte':
        adapter = new ZTEOLTAdapter(config);
        break;
      case 'nokia':
        adapter = new NokiaOLTAdapter(config);
        break;
      case 'fiberhome':
        adapter = new FiberHomeOLTAdapter(config);
        break;
      default:
        // Fall back to generic adapter for unknown vendors
        logger.warn(`Unknown OLT vendor: ${config.vendor}, using generic adapter`);
        adapter = new GenericOLTAdapter(config);
    }

    this.adapters.set(config.id, adapter);
    return adapter;
  }

  /**
   * Add new OLT to system
   */
  async addOLT(config: Omit<OLTConfig, 'id'>): Promise<{ success: boolean; olt?: OLTConfig; message?: string }> {
    try {
      // Test connection first
      const tempAdapter = this.getAdapter({ ...config, id: 'temp' } as OLTConfig);
      const connected = await tempAdapter.connect();
      
      if (!connected) {
        return { success: false, message: 'Failed to connect to OLT' };
      }

      // Get system info
      const sysInfo = await tempAdapter.getSystemInfo();
      await tempAdapter.disconnect();

      // Save to database
      const [olt] = await database('olts')
        .insert({
          ...config,
          model: sysInfo?.model || config.model,
          firmware_version: sysInfo?.firmwareVersion,
          is_active: true,
          created_at: new Date(),
          updated_at: new Date()
        })
        .returning('*');

      logger.info(`OLT added: ${olt.name} (${olt.vendor})`);

      // Start monitoring
      this.startOLTMonitoring(olt.id);

      return {
        success: true,
        olt: this.mapOLTFromDB(olt)
      };
    } catch (error: any) {
      logger.error('Failed to add OLT:', error);
      return { success: false, message: error.message };
    }
  }

  /**
   * Get OLT by ID
   */
  async getOLT(oltId: string): Promise<OLTConfig | null> {
    const olt = await database('olts')
      .where({ id: oltId })
      .first();

    return olt ? this.mapOLTFromDB(olt) : null;
  }

  /**
   * Get all OLTs
   */
  async getAllOLTs(companyId?: string): Promise<OLTConfig[]> {
    const query = database('olts')
      .where({ is_active: true });

    if (companyId) {
      query.where({ company_id: companyId });
    }

    const olts = await query;
    return olts.map(this.mapOLTFromDB);
  }

  /**
   * Get OLT status with real-time data
   */
  async getOLTStatus(oltId: string): Promise<any> {
    const olt = await this.getOLT(oltId);
    if (!olt) return null;

    const cacheKey = `olt-status:${oltId}`;
    let status = await cache.get(cacheKey);

    if (!status) {
      try {
        const adapter = this.getAdapter(olt);
        await adapter.connect();

        const [sysInfo, ponPorts, health] = await Promise.all([
          adapter.getSystemInfo(),
          adapter.getPONPorts(),
          adapter.healthCheck()
        ]);

        await adapter.disconnect();

        status = {
          oltId,
          name: olt.name,
          vendor: olt.vendor,
          model: olt.model,
          ipAddress: olt.ipAddress,
          connected: true,
          system: sysInfo,
          ponPorts: ponPorts.length,
          onuCount: ponPorts.reduce((sum, p) => sum + p.onuCount, 0),
          health: health.healthy ? 'healthy' : 'degraded',
          issues: health.issues,
          metrics: health.metrics,
          lastUpdated: new Date().toISOString()
        };

        // Cache for 2 minutes
        await cache.set(cacheKey, status, 120);
      } catch (error) {
        status = {
          oltId,
          name: olt.name,
          connected: false,
          error: 'Failed to connect',
          lastUpdated: new Date().toISOString()
        };
      }
    }

    return status;
  }

  /**
   * Get PON ports for OLT
   */
  async getPONPorts(oltId: string): Promise<PONPort[]> {
    const olt = await this.getOLT(oltId);
    if (!olt) return [];

    try {
      const adapter = this.getAdapter(olt);
      await adapter.connect();
      const ports = await adapter.getPONPorts();
      await adapter.disconnect();
      return ports;
    } catch (error) {
      logger.error(`Failed to get PON ports for OLT ${oltId}:`, error);
      return [];
    }
  }

  /**
   * Get ONUs for OLT or specific PON port
   */
  async getONUs(oltId: string, ponPortId?: string): Promise<ONU[]> {
    const olt = await this.getOLT(oltId);
    if (!olt) return [];

    try {
      const adapter = this.getAdapter(olt);
      await adapter.connect();
      const onus = await adapter.getONUs(ponPortId);
      await adapter.disconnect();

      // Enrich with customer data
      for (const onu of onus) {
        if (onu.customerId) {
          const customer = await database('customers')
            .where({ id: onu.customerId })
            .first(['first_name', 'last_name', 'account_number']);
          
          if (customer) {
            onu.customerName = `${customer.first_name} ${customer.last_name}`;
          }
        }
      }

      return onus;
    } catch (error) {
      logger.error(`Failed to get ONUs for OLT ${oltId}:`, error);
      return [];
    }
  }

  /**
   * Provision new ONU
   */
  async provisionONU(oltId: string, data: ONUProvisioningData): Promise<{ success: boolean; message: string; onuId?: string }> {
    const olt = await this.getOLT(oltId);
    if (!olt) {
      return { success: false, message: 'OLT not found' };
    }

    try {
      const adapter = this.getAdapter(olt);
      await adapter.connect();
      const result = await adapter.provisionONU(data);
      await adapter.disconnect();

      if (result.success) {
        // Log provisioning
        await database('olt_provisioning_logs').insert({
          olt_id: oltId,
          onu_id: result.onuId,
          serial_number: data.serialNumber,
          action: 'provision',
          status: 'success',
          details: result.message,
          created_at: new Date()
        });

        // Update customer if linked
        if (data.customerId && result.onuId) {
          await database('customers')
            .where({ id: data.customerId })
            .update({
              onu_id: result.onuId,
              olt_id: oltId,
              updated_at: new Date()
            });
        }
      }

      return result;
    } catch (error: any) {
      logger.error(`Failed to provision ONU on OLT ${oltId}:`, error);
      return { success: false, message: error.message };
    }
  }

  /**
   * Deprovision ONU
   */
  async deprovisionONU(oltId: string, onuId: string): Promise<{ success: boolean; message: string }> {
    const olt = await this.getOLT(oltId);
    if (!olt) {
      return { success: false, message: 'OLT not found' };
    }

    try {
      const adapter = this.getAdapter(olt);
      await adapter.connect();
      const result = await adapter.deprovisionONU(onuId);
      await adapter.disconnect();

      if (result.success) {
        await database('olt_provisioning_logs').insert({
          olt_id: oltId,
          onu_id: onuId,
          action: 'deprovision',
          status: 'success',
          created_at: new Date()
        });

        // Unlink from customer
        await database('customers')
          .where({ onu_id: onuId })
          .update({
            onu_id: null,
            olt_id: null,
            updated_at: new Date()
          });
      }

      return result;
    } catch (error: any) {
      logger.error(`Failed to deprovision ONU ${onuId}:`, error);
      return { success: false, message: error.message };
    }
  }

  /**
   * Reset ONU
   */
  async resetONU(oltId: string, onuId: string): Promise<{ success: boolean; message: string }> {
    const olt = await this.getOLT(oltId);
    if (!olt) {
      return { success: false, message: 'OLT not found' };
    }

    try {
      const adapter = this.getAdapter(olt);
      await adapter.connect();
      const result = await adapter.resetONU(onuId);
      await adapter.disconnect();

      // Log action
      await database('olt_actions').insert({
        olt_id: oltId,
        onu_id: onuId,
        action: 'reset',
        status: result.success ? 'success' : 'failed',
        details: result.message,
        created_at: new Date()
      });

      return result;
    } catch (error: any) {
      logger.error(`Failed to reset ONU ${onuId}:`, error);
      return { success: false, message: error.message };
    }
  }

  /**
   * Get OLT alarms
   */
  async getAlarms(oltId: string): Promise<OLTAlarm[]> {
    const olt = await this.getOLT(oltId);
    if (!olt) return [];

    try {
      const adapter = this.getAdapter(olt);
      await adapter.connect();
      const alarms = await adapter.getAlarms();
      await adapter.disconnect();
      return alarms;
    } catch (error) {
      logger.error(`Failed to get alarms for OLT ${oltId}:`, error);
      return [];
    }
  }

  /**
   * Get OLT performance metrics
   */
  async getPerformance(oltId: string): Promise<OLTPerformance | null> {
    const olt = await this.getOLT(oltId);
    if (!olt) return null;

    try {
      const adapter = this.getAdapter(olt);
      await adapter.connect();
      const performance = await adapter.getPerformance();
      await adapter.disconnect();
      return performance;
    } catch (error) {
      logger.error(`Failed to get performance for OLT ${oltId}:`, error);
      return null;
    }
  }

  /**
   * Execute custom command on OLT
   */
  async executeCommand(oltId: string, command: string): Promise<{ success: boolean; output: string }> {
    const olt = await this.getOLT(oltId);
    if (!olt) {
      return { success: false, output: 'OLT not found' };
    }

    try {
      const adapter = this.getAdapter(olt);
      await adapter.connect();
      const result = await adapter.executeCustomCommand(command);
      await adapter.disconnect();

      // Log command
      await database('olt_commands').insert({
        olt_id: oltId,
        command,
        status: result.success ? 'success' : 'failed',
        output: result.output,
        created_at: new Date()
      });

      return result;
    } catch (error: any) {
      logger.error(`Failed to execute command on OLT ${oltId}:`, error);
      return { success: false, output: error.message };
    }
  }

  /**
   * Start OLT monitoring
   */
  private startOLTMonitoring(oltId: string): void {
    // Schedule monitoring job
    jobQueue.addMikrotikJob({
      type: 'olt-monitor',
      oltId
    }, {
      repeat: {
        every: 5 * 60 * 1000 // 5 minutes
      }
    });
  }

  /**
   * Self-healing: Check and fix issues automatically
   */
  async runSelfHealing(oltId: string): Promise<{ actions: string[]; issues: string[] }> {
    if (!this.selfHealingConfig.enabled) {
      return { actions: [], issues: [] };
    }

    const actions: string[] = [];
    const issues: string[] = [];

    try {
      const olt = await this.getOLT(oltId);
      if (!olt) return { actions, issues };

      const adapter = this.getAdapter(olt);
      await adapter.connect();

      const onus = await adapter.getONUs();

      for (const onu of onus) {
        // Check for offline ONUs
        if (onu.status === 'offline' && this.selfHealingConfig.actions.restartOfflineOnus) {
          const offlineDuration = onu.lastOfflineAt 
            ? (Date.now() - new Date(onu.lastOfflineAt).getTime()) / 60000 
            : 0;

          if (offlineDuration > this.selfHealingConfig.thresholds.maxOfflineDuration) {
            issues.push(`ONU ${onu.serialNumber} offline for ${Math.round(offlineDuration)} minutes`);
            
            // Attempt reset
            await adapter.resetONU(onu.id);
            actions.push(`Reset ONU ${onu.serialNumber}`);
          }
        }

        // Check for LOS (Loss of Signal)
        if (onu.status === 'los' && this.selfHealingConfig.actions.resetLosOnus) {
          issues.push(`ONU ${onu.serialNumber} has LOS`);
          
          await adapter.resetONU(onu.id);
          actions.push(`Reset ONU ${onu.serialNumber} due to LOS`);
        }

        // Check signal quality
        if (onu.rxPower !== undefined && onu.rxPower < this.selfHealingConfig.thresholds.minSignalQuality) {
          issues.push(`ONU ${onu.serialNumber} has poor signal (${onu.rxPower} dBm)`);
        }
      }

      await adapter.disconnect();

      // Log self-healing actions
      if (actions.length > 0) {
        await database('olt_self_healing_logs').insert({
          olt_id: oltId,
          actions,
          issues,
          created_at: new Date()
        });
      }

      return { actions, issues };
    } catch (error: any) {
      logger.error(`Self-healing failed for OLT ${oltId}:`, error);
      return { actions, issues: [error.message] };
    }
  }

  /**
   * AI-powered optimization suggestions
   */
  async getAIOptimizations(oltId: string): Promise<any[]> {
    if (!this.aiOptimization.enabled) return [];

    const suggestions: any[] = [];

    try {
      const olt = await this.getOLT(oltId);
      if (!olt) return suggestions;

      const adapter = this.getAdapter(olt);
      await adapter.connect();

      const onus = await adapter.getONUs();
      const performance = await adapter.getPerformance();

      await adapter.disconnect();

      // Analyze patterns and make suggestions

      // 1. Bandwidth optimization
      if (this.aiOptimization.features.optimizeBandwidth) {
        const highUsagePorts = performance?.ponPorts.filter(
          p => p.bandwidthUsage.downstream > 80 || p.bandwidthUsage.upstream > 80
        );

        if (highUsagePorts && highUsagePorts.length > 0) {
          suggestions.push({
            type: 'bandwidth',
            priority: 'high',
            title: 'High Bandwidth Usage Detected',
            description: `${highUsagePorts.length} PON ports are experiencing high bandwidth usage.`,
            recommendation: 'Consider load balancing or upgrading to XGS-PON.',
            affectedPorts: highUsagePorts.map(p => p.portId)
          });
        }
      }

      // 2. Failure prediction
      if (this.aiOptimization.features.predictFailures) {
        const unstableOnus = onus.filter(o => 
          o.offlineCount > 5 || (o.rxPower !== undefined && o.rxPower < -25)
        );

        if (unstableOnus.length > 0) {
          suggestions.push({
            type: 'maintenance',
            priority: 'medium',
            title: 'Potential Equipment Failures',
            description: `${unstableOnus.length} ONUs show signs of instability.`,
            recommendation: 'Schedule maintenance checks for these ONUs.',
            affectedONUs: unstableOnus.map(o => ({ id: o.id, serialNumber: o.serialNumber }))
          });
        }
      }

      // 3. Upgrade suggestions
      if (this.aiOptimization.features.suggestUpgrades) {
        const gponPorts = (await this.getPONPorts(oltId)).filter(p => p.type === 'gpon');
        const highDensityPorts = gponPorts.filter(p => p.onuCount > 100);

        if (highDensityPorts.length > 0) {
          suggestions.push({
            type: 'upgrade',
            priority: 'low',
            title: 'Consider XGS-PON Upgrade',
            description: `${highDensityPorts.length} GPON ports are nearing capacity.`,
            recommendation: 'Upgrade to XGS-PON for higher bandwidth and capacity.',
            affectedPorts: highDensityPorts.map(p => p.id)
          });
        }
      }

      // 4. Anomaly detection
      if (this.aiOptimization.features.detectAnomalies) {
        const offlineOnus = onus.filter(o => o.status === 'offline');
        const offlinePercentage = (offlineOnus.length / onus.length) * 100;

        if (offlinePercentage > 20) {
          suggestions.push({
            type: 'anomaly',
            priority: 'critical',
            title: 'High Offline ONU Rate',
            description: `${offlinePercentage.toFixed(1)}% of ONUs are offline.`,
            recommendation: 'Investigate potential network-wide issue.',
            metrics: { offlineCount: offlineOnus.length, totalCount: onus.length }
          });
        }
      }

      return suggestions;
    } catch (error: any) {
      logger.error(`AI optimization failed for OLT ${oltId}:`, error);
      return suggestions;
    }
  }

  /**
   * Auto-discovery: Find unprovisioned ONUs
   */
  async autoDiscoverONUs(oltId: string): Promise<{
    discovered: Array<{ serialNumber: string; ponPortId: string; signalQuality: string }>;
    autoProvisioned: number;
  }> {
    const discovered: Array<{ serialNumber: string; ponPortId: string; signalQuality: string }> = [];
    let autoProvisioned = 0;

    try {
      const olt = await this.getOLT(oltId);
      if (!olt) return { discovered, autoProvisioned };

      const adapter = this.getAdapter(olt);
      await adapter.connect();

      const { unprovisioned } = await adapter.discoverONUs();

      for (const onu of unprovisioned) {
        const signalQuality = 'good'; // Would calculate from actual signal data
        
        discovered.push({
          serialNumber: onu.serialNumber,
          ponPortId: onu.ponPortId,
          signalQuality
        });

        // Auto-provision if enabled
        if (this.selfHealingConfig.actions.autoUpgradeFirmware) {
          // Check if customer exists with this serial
          const customer = await database('customers')
            .where({ onu_serial: onu.serialNumber })
            .first();

          if (customer) {
            await adapter.provisionONU({
              serialNumber: onu.serialNumber,
              ponPortId: onu.ponPortId,
              customerId: customer.id,
              description: `Auto-provisioned for ${customer.first_name} ${customer.last_name}`
            });
            autoProvisioned++;
          }
        }
      }

      await adapter.disconnect();

      return { discovered, autoProvisioned };
    } catch (error: any) {
      logger.error(`Auto-discovery failed for OLT ${oltId}:`, error);
      return { discovered, autoProvisioned };
    }
  }

  /**
   * Map database OLT to OLTConfig
   */
  private mapOLTFromDB(olt: any): OLTConfig {
    return {
      id: olt.id,
      name: olt.name,
      vendor: olt.vendor,
      model: olt.model,
      ipAddress: olt.ip_address,
      port: olt.port,
      protocol: olt.protocol,
      username: olt.username,
      password: olt.password,
      enablePassword: olt.enable_password,
      snmpCommunity: olt.snmp_community,
      snmpVersion: olt.snmp_version,
      location: olt.location,
      coordinates: olt.coordinates,
      capacity: olt.capacity,
      isActive: olt.is_active,
      lastSeenAt: olt.last_seen_at,
      firmwareVersion: olt.firmware_version,
      systemUptime: olt.system_uptime,
      companyId: olt.company_id
    };
  }

  /**
   * Update self-healing configuration
   */
  updateSelfHealingConfig(config: Partial<OLTSelfHealingConfig>): void {
    this.selfHealingConfig = { ...this.selfHealingConfig, ...config };
  }

  /**
   * Update AI optimization configuration
   */
  updateAIOptimizationConfig(config: Partial<OLTAIOptimization>): void {
    this.aiOptimization = { ...this.aiOptimization, ...config };
  }

  /**
   * Update bandwidth optimization configuration
   */
  updateBandwidthOptimizationConfig(config: Partial<OLTBandwidthOptimization>): void {
    this.bandwidthOptimization = { ...this.bandwidthOptimization, ...config };
  }
}

export const oltManager = new OLTManager();
export default oltManager;
