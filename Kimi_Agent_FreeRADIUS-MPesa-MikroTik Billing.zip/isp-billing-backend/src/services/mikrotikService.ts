import { NodeSSH } from 'node-ssh';
import { logger } from '../utils/logger';
import { database } from '../config/database';
import { cache } from '../config/redis';

export interface MikrotikRouterConfig {
  id?: string;
  name: string;
  ipAddress: string;
  port: number;
  username: string;
  password: string;
  apiPort?: number;
  apiUseSsl?: boolean;
  location?: string;
  description?: string;
  companyId?: string;
}

export interface RouterStatus {
  connected: boolean;
  version?: string;
  uptime?: string;
  cpuUsage?: number;
  memoryUsage?: number;
  diskUsage?: number;
  totalUsers?: number;
  activeUsers?: number;
  interfaces?: InterfaceInfo[];
  routes?: RouteInfo[];
  firewallRules?: number;
  queues?: number;
  health?: RouterHealth;
  lastError?: string;
}

export interface InterfaceInfo {
  name: string;
  type: string;
  status: 'up' | 'down' | 'disabled';
  macAddress?: string;
  ipAddress?: string;
  rxBytes: number;
  txBytes: number;
  rxPackets: number;
  txPackets: number;
  rxErrors: number;
  txErrors: number;
  rxDrops: number;
  txDrops: number;
  running: boolean;
  comment?: string;
}

export interface RouteInfo {
  dst: string;
  gateway: string;
  distance: number;
  scope: number;
  targetScope: number;
  active: boolean;
  dynamic: boolean;
  comment?: string;
}

export interface RouterHealth {
  voltage?: number;
  temperature?: number;
  cpuTemperature?: number;
  fanSpeed?: number;
  fanSpeed2?: number;
  powerConsumption?: number;
}

export interface ActiveUser {
  id: string;
  name: string;
  address: string;
  macAddress: string;
  uptime: string;
  service: string;
  comment?: string;
  bytesIn: number;
  bytesOut: number;
  packetsIn: number;
  packetsOut: number;
}

export interface LogEntry {
  time: string;
  topics: string;
  message: string;
}

export interface TroubleshootingResult {
  issues: string[];
  recommendations: string[];
  autoFixes: string[];
  commands: string[];
}

export class MikrotikService {
  private connections: Map<string, NodeSSH> = new Map();

  /**
   * Test connection to a MikroTik router
   */
  async testConnection(config: Omit<MikrotikRouterConfig, 'id'>): Promise<{ success: boolean; message: string; status?: RouterStatus }> {
    let ssh: NodeSSH | null = null;
    try {
      ssh = new NodeSSH();
      await ssh.connect({
        host: config.ipAddress,
        port: config.port || 22,
        username: config.username,
        password: config.password,
        readyTimeout: 15000,
        keepaliveInterval: 5000
      });

      // Test by running a simple command
      const result = await ssh.execCommand('/system resource print');
      
      if (result.code === 0) {
        const status = this.parseResourceOutput(result.stdout);
        await ssh.dispose();
        return { 
          success: true, 
          message: 'Connection successful',
          status
        };
      } else {
        await ssh.dispose();
        return { success: false, message: result.stderr || 'Connection failed' };
      }
    } catch (error: any) {
      if (ssh) await ssh.dispose().catch(() => {});
      logger.error('MikroTik connection test failed:', error);
      return { success: false, message: error.message };
    }
  }

  /**
   * Add a new MikroTik router
   */
  async addRouter(config: Omit<MikrotikRouterConfig, 'id'>): Promise<{ success: boolean; router?: any; message?: string }> {
    try {
      // Test connection first
      const testResult = await this.testConnection(config);
      if (!testResult.success) {
        return { success: false, message: `Connection failed: ${testResult.message}` };
      }

      // Save to database
      const [router] = await database('mikrotik_routers')
        .insert({
          name: config.name,
          ip_address: config.ipAddress,
          port: config.port || 22,
          username: config.username,
          password: config.password, // In production, encrypt this
          api_port: config.apiPort || 8728,
          api_use_ssl: config.apiUseSsl || false,
          location: config.location,
          description: config.description,
          company_id: config.companyId,
          is_active: true,
          version: testResult.status?.version,
          last_connected: new Date(),
          created_at: new Date(),
          updated_at: new Date()
        })
        .returning('*');

      logger.info(`MikroTik router added: ${config.name} (${config.ipAddress})`);

      return {
        success: true,
        router: this.mapRouterFromDB(router)
      };
    } catch (error: any) {
      logger.error('Failed to add MikroTik router:', error);
      return { success: false, message: error.message };
    }
  }

  /**
   * Get all routers
   */
  async getRouters(companyId?: string): Promise<any[]> {
    const query = database('mikrotik_routers')
      .where({ is_active: true });

    if (companyId) {
      query.where({ company_id: companyId });
    }

    const routers = await query.orderBy('created_at', 'desc');
    return routers.map(r => this.mapRouterFromDB(r));
  }

  /**
   * Get router by ID
   */
  async getRouter(routerId: string): Promise<any | null> {
    const router = await database('mikrotik_routers')
      .where({ id: routerId, is_active: true })
      .first();

    return router ? this.mapRouterFromDB(router) : null;
  }

  /**
   * Update router
   */
  async updateRouter(routerId: string, updates: Partial<MikrotikRouterConfig>): Promise<{ success: boolean; router?: any; message?: string }> {
    try {
      const [router] = await database('mikrotik_routers')
        .where({ id: routerId })
        .update({
          ...updates,
          updated_at: new Date()
        })
        .returning('*');

      return {
        success: true,
        router: this.mapRouterFromDB(router)
      };
    } catch (error: any) {
      logger.error('Failed to update MikroTik router:', error);
      return { success: false, message: error.message };
    }
  }

  /**
   * Delete router (soft delete)
   */
  async deleteRouter(routerId: string): Promise<{ success: boolean; message?: string }> {
    try {
      await database('mikrotik_routers')
        .where({ id: routerId })
        .update({
          is_active: false,
          updated_at: new Date()
        });

      // Close any open connection
      await this.disconnect(routerId);

      return { success: true };
    } catch (error: any) {
      logger.error('Failed to delete MikroTik router:', error);
      return { success: false, message: error.message };
    }
  }

  /**
   * Get router status with caching
   */
  async getRouterStatus(routerId: string): Promise<RouterStatus> {
    const cacheKey = `mikrotik-status:${routerId}`;
    let status = await cache.get(cacheKey);

    if (!status) {
      const router = await this.getRouter(routerId);
      if (!router) {
        return { connected: false, lastError: 'Router not found' };
      }

      try {
        const ssh = await this.getConnection(routerId);
        
        // Get resource info
        const resourceResult = await ssh.execCommand('/system resource print');
        const resourceStatus = this.parseResourceOutput(resourceResult.stdout);

        // Get interface count
        const interfaceResult = await ssh.execCommand('/interface print count-only');
        const interfaceCount = parseInt(interfaceResult.stdout.trim()) || 0;

        // Get active users (PPPoE + Hotspot)
        const pppoeResult = await ssh.execCommand('/ppp active print count-only');
        const hotspotResult = await ssh.execCommand('/ip hotspot active print count-only');
        const activeUsers = (parseInt(pppoeResult.stdout.trim()) || 0) + 
                           (parseInt(hotspotResult.stdout.trim()) || 0);

        status = {
          ...resourceStatus,
          totalUsers: activeUsers,
          connected: true
        };

        // Cache for 2 minutes
        await cache.set(cacheKey, status, 120);

        // Update last connected
        await database('mikrotik_routers')
          .where({ id: routerId })
          .update({
            last_connected: new Date(),
            version: resourceStatus.version,
            updated_at: new Date()
          });

      } catch (error: any) {
        logger.error(`Failed to get status for router ${routerId}:`, error);
        status = {
          connected: false,
          lastError: error.message
        };
      }
    }

    return status;
  }

  /**
   * Get interfaces
   */
  async getInterfaces(routerId: string): Promise<InterfaceInfo[]> {
    try {
      const ssh = await this.getConnection(routerId);
      const result = await ssh.execCommand('/interface print detail');
      return this.parseInterfaces(result.stdout);
    } catch (error: any) {
      logger.error(`Failed to get interfaces for router ${routerId}:`, error);
      throw error;
    }
  }

  /**
   * Get routes
   */
  async getRoutes(routerId: string): Promise<RouteInfo[]> {
    try {
      const ssh = await this.getConnection(routerId);
      const result = await ssh.execCommand('/ip route print detail');
      return this.parseRoutes(result.stdout);
    } catch (error: any) {
      logger.error(`Failed to get routes for router ${routerId}:`, error);
      throw error;
    }
  }

  /**
   * Get active users
   */
  async getActiveUsers(routerId: string): Promise<ActiveUser[]> {
    try {
      const ssh = await this.getConnection(routerId);
      
      // Get PPPoE active users
      const pppoeResult = await ssh.execCommand('/ppp active print detail');
      const pppoeUsers = this.parsePPPActive(pppoeResult.stdout, 'pppoe');

      // Get Hotspot active users
      const hotspotResult = await ssh.execCommand('/ip hotspot active print detail');
      const hotspotUsers = this.parseHotspotActive(hotspotResult.stdout);

      return [...pppoeUsers, ...hotspotUsers];
    } catch (error: any) {
      logger.error(`Failed to get active users for router ${routerId}:`, error);
      throw error;
    }
  }

  /**
   * Get logs
   */
  async getLogs(routerId: string, limit: number = 100): Promise<LogEntry[]> {
    try {
      const ssh = await this.getConnection(routerId);
      const result = await ssh.execCommand(`/log print detail limit=${limit}`);
      return this.parseLogs(result.stdout);
    } catch (error: any) {
      logger.error(`Failed to get logs for router ${routerId}:`, error);
      throw error;
    }
  }

  /**
   * Execute custom command
   */
  async executeCommand(routerId: string, command: string): Promise<{ success: boolean; output: string }> {
    try {
      const ssh = await this.getConnection(routerId);
      
      // Log command for audit
      await database('mikrotik_commands').insert({
        router_id: routerId,
        command,
        executed_by: 'system', // Should be current user
        created_at: new Date()
      });

      const result = await ssh.execCommand(command);
      return {
        success: result.code === 0,
        output: result.stdout || result.stderr
      };
    } catch (error: any) {
      logger.error(`Failed to execute command on router ${routerId}:`, error);
      return {
        success: false,
        output: error.message
      };
    }
  }

  /**
   * Run troubleshooting diagnostics
   */
  async runTroubleshooting(routerId: string): Promise<TroubleshootingResult> {
    const issues: string[] = [];
    const recommendations: string[] = [];
    const autoFixes: string[] = [];
    const commands: string[] = [];

    try {
      const ssh = await this.getConnection(routerId);

      // Check CPU usage
      const resourceResult = await ssh.execCommand('/system resource print');
      const status = this.parseResourceOutput(resourceResult.stdout);

      if (status.cpuUsage && status.cpuUsage > 80) {
        issues.push(`High CPU usage: ${status.cpuUsage}%`);
        recommendations.push('Check for CPU-intensive processes, consider upgrading hardware');
        commands.push('/system resource cpu print');
        commands.push('/tool profile');
      }

      // Check memory usage
      if (status.memoryUsage && status.memoryUsage > 85) {
        issues.push(`High memory usage: ${status.memoryUsage}%`);
        recommendations.push('Consider adding more RAM or optimizing configuration');
      }

      // Check interface errors
      const interfaceResult = await ssh.execCommand('/interface print stats');
      const interfaces = this.parseInterfaceStats(interfaceResult.stdout);
      
      interfaces.forEach(iface => {
        if (iface.rxErrors > 1000 || iface.txErrors > 1000) {
          issues.push(`Interface ${iface.name} has errors: RX=${iface.rxErrors}, TX=${iface.txErrors}`);
          recommendations.push(`Check cable/connectors for ${iface.name}`);
        }
      });

      // Check for disabled interfaces
      const disabledInterfaces = interfaces.filter(i => i.status === 'disabled');
      if (disabledInterfaces.length > 0) {
        issues.push(`${disabledInterfaces.length} interfaces are disabled`);
        recommendations.push('Review disabled interfaces and enable if needed');
      }

      // Check DNS resolution
      const dnsResult = await ssh.execCommand('/ip dns print');
      if (!dnsResult.stdout.includes('servers:')) {
        issues.push('DNS servers not configured');
        recommendations.push('Configure DNS servers: /ip dns set servers=8.8.8.8,1.1.1.1');
        autoFixes.push('DNS configuration needed');
      }

      // Check NTP
      const ntpResult = await ssh.execCommand('/system ntp client print');
      if (ntpResult.stdout.includes('enabled: no')) {
        issues.push('NTP client not enabled');
        recommendations.push('Enable NTP for accurate time: /system ntp client set enabled=yes');
      }

      // Check for default password
      const userResult = await ssh.execCommand('/user print where name=admin');
      if (userResult.stdout.includes('admin')) {
        recommendations.push('Ensure admin password is changed from default');
      }

      // Check firewall
      const firewallResult = await ssh.execCommand('/ip firewall filter print count-only');
      const firewallRules = parseInt(firewallResult.stdout.trim()) || 0;
      if (firewallRules === 0) {
        issues.push('No firewall rules configured');
        recommendations.push('Configure basic firewall rules for security');
      }

      // Check for package updates
      const packageResult = await ssh.execCommand('/system package update print');
      if (packageResult.stdout.includes('status: New version')) {
        issues.push('RouterOS update available');
        recommendations.push('Consider updating RouterOS to latest version');
      }

      // Log troubleshooting session
      await database('mikrotik_troubleshooting').insert({
        router_id: routerId,
        issues_found: issues.length,
        recommendations: recommendations.length,
        details: { issues, recommendations, autoFixes },
        created_at: new Date()
      });

      return { issues, recommendations, autoFixes, commands };

    } catch (error: any) {
      logger.error(`Troubleshooting failed for router ${routerId}:`, error);
      return {
        issues: [`Error running diagnostics: ${error.message}`],
        recommendations: ['Check router connectivity'],
        autoFixes: [],
        commands: []
      };
    }
  }

  /**
   * Auto-fix common issues
   */
  async autoFix(routerId: string, fixes: string[]): Promise<{ success: boolean; results: string[] }> {
    const results: string[] = [];

    try {
      const ssh = await this.getConnection(routerId);

      for (const fix of fixes) {
        switch (fix) {
          case 'enable-ntp':
            await ssh.execCommand('/system ntp client set enabled=yes');
            results.push('NTP client enabled');
            break;
          case 'configure-dns':
            await ssh.execCommand('/ip dns set servers=8.8.8.8,1.1.1.1');
            results.push('DNS servers configured (8.8.8.8, 1.1.1.1)');
            break;
          case 'clear-arp':
            await ssh.execCommand('/ip arp remove [find dynamic=yes]');
            results.push('Dynamic ARP entries cleared');
            break;
          case 'clear-connections':
            await ssh.execCommand('/ip firewall connection remove [find]');
            results.push('Firewall connections cleared');
            break;
          default:
            results.push(`Unknown fix: ${fix}`);
        }
      }

      return { success: true, results };
    } catch (error: any) {
      logger.error(`Auto-fix failed for router ${routerId}:`, error);
      return { success: false, results: [error.message] };
    }
  }

  /**
   * Monitor router in real-time
   */
  async getRealtimeMetrics(routerId: string): Promise<any> {
    try {
      const ssh = await this.getConnection(routerId);

      const [resource, interfaces, cpu] = await Promise.all([
        ssh.execCommand('/system resource print'),
        ssh.execCommand('/interface print stats'),
        ssh.execCommand('/system resource cpu print')
      ]);

      return {
        resource: this.parseResourceOutput(resource.stdout),
        interfaces: this.parseInterfaceStats(interfaces.stdout),
        cpu: this.parseCpuUsage(cpu.stdout),
        timestamp: new Date().toISOString()
      };
    } catch (error: any) {
      logger.error(`Failed to get realtime metrics for router ${routerId}:`, error);
      throw error;
    }
  }

  /**
   * Get or create SSH connection
   */
  private async getConnection(routerId: string): Promise<NodeSSH> {
    // Check existing connection
    if (this.connections.has(routerId)) {
      const existing = this.connections.get(routerId)!;
      try {
        // Test connection
        await existing.execCommand('/system identity print');
        return existing;
      } catch {
        // Connection dead, remove it
        this.connections.delete(routerId);
      }
    }

    // Create new connection
    const router = await this.getRouter(routerId);
    if (!router) {
      throw new Error('Router not found');
    }

    const ssh = new NodeSSH();
    await ssh.connect({
      host: router.ipAddress,
      port: router.port || 22,
      username: router.username,
      password: router.password,
      readyTimeout: 15000,
      keepaliveInterval: 10000
    });

    this.connections.set(routerId, ssh);
    return ssh;
  }

  /**
   * Disconnect from router
   */
  async disconnect(routerId: string): Promise<void> {
    const ssh = this.connections.get(routerId);
    if (ssh) {
      await ssh.dispose();
      this.connections.delete(routerId);
    }
  }

  // ============================================
  // Parser Methods
  // ============================================

  private parseResourceOutput(output: string): Partial<RouterStatus> {
    const status: Partial<RouterStatus> = {};
    
    const versionMatch = output.match(/version:\s*(.+)/i);
    if (versionMatch) status.version = versionMatch[1].trim();

    const uptimeMatch = output.match(/uptime:\s*(.+)/i);
    if (uptimeMatch) status.uptime = uptimeMatch[1].trim();

    const cpuMatch = output.match(/cpu-load:\s*(\d+)%/i);
    if (cpuMatch) status.cpuUsage = parseInt(cpuMatch[1]);

    const memMatch = output.match(/free-memory:\s*(\d+)/i);
    const totalMemMatch = output.match(/total-memory:\s*(\d+)/i);
    if (memMatch && totalMemMatch) {
      const free = parseInt(memMatch[1]);
      const total = parseInt(totalMemMatch[1]);
      status.memoryUsage = Math.round(((total - free) / total) * 100);
    }

    const diskMatch = output.match(/free-hdd-space:\s*(\d+)/i);
    const totalDiskMatch = output.match(/total-hdd-space:\s*(\d+)/i);
    if (diskMatch && totalDiskMatch) {
      const free = parseInt(diskMatch[1]);
      const total = parseInt(totalDiskMatch[1]);
      status.diskUsage = Math.round(((total - free) / total) * 100);
    }

    return status;
  }

  private parseInterfaces(output: string): InterfaceInfo[] {
    const interfaces: InterfaceInfo[] = [];
    const lines = output.split('\n');
    
    for (const line of lines) {
      const match = line.match(/(\d+)\s+(\S+)\s+(\S+)\s+(\S+)/);
      if (match) {
        interfaces.push({
          name: match[2],
          type: match[3],
          status: match[4] as any,
          rxBytes: 0,
          txBytes: 0,
          rxPackets: 0,
          txPackets: 0,
          rxErrors: 0,
          txErrors: 0,
          rxDrops: 0,
          txDrops: 0,
          running: match[4] === 'running'
        });
      }
    }

    return interfaces;
  }

  private parseInterfaceStats(output: string): any[] {
    const interfaces: any[] = [];
    const lines = output.split('\n');

    for (const line of lines) {
      const parts = line.trim().split(/\s+/);
      if (parts.length >= 4) {
        interfaces.push({
          name: parts[1],
          status: parts[2],
          rxBytes: parseInt(parts[3]) || 0,
          txBytes: parseInt(parts[4]) || 0,
          rxErrors: parseInt(parts[5]) || 0,
          txErrors: parseInt(parts[6]) || 0
        });
      }
    }

    return interfaces;
  }

  private parseRoutes(output: string): RouteInfo[] {
    const routes: RouteInfo[] = [];
    const lines = output.split('\n');

    for (const line of lines) {
      const dstMatch = line.match(/dst-address=([^\s]+)/);
      const gatewayMatch = line.match(/gateway=([^\s]+)/);
      
      if (dstMatch) {
        routes.push({
          dst: dstMatch[1],
          gateway: gatewayMatch ? gatewayMatch[1] : '',
          distance: 0,
          scope: 0,
          targetScope: 0,
          active: line.includes('active=yes'),
          dynamic: line.includes('dynamic=yes')
        });
      }
    }

    return routes;
  }

  private parsePPPActive(output: string, service: string): ActiveUser[] {
    const users: ActiveUser[] = [];
    const lines = output.split('\n');

    for (const line of lines) {
      const nameMatch = line.match(/name="([^"]+)"/);
      const addressMatch = line.match(/address=([^\s]+)/);
      const macMatch = line.match(/caller-id="([^"]+)"/);
      const uptimeMatch = line.match(/uptime=([^\s]+)/);

      if (nameMatch) {
        users.push({
          id: `${service}-${nameMatch[1]}`,
          name: nameMatch[1],
          address: addressMatch ? addressMatch[1] : '',
          macAddress: macMatch ? macMatch[1] : '',
          uptime: uptimeMatch ? uptimeMatch[1] : '',
          service,
          bytesIn: 0,
          bytesOut: 0,
          packetsIn: 0,
          packetsOut: 0
        });
      }
    }

    return users;
  }

  private parseHotspotActive(output: string): ActiveUser[] {
    const users: ActiveUser[] = [];
    const lines = output.split('\n');

    for (const line of lines) {
      const userMatch = line.match(/user="([^"]+)"/);
      const addressMatch = line.match(/address=([^\s]+)/);
      const macMatch = line.match(/mac-address=([^\s]+)/);
      const uptimeMatch = line.match(/uptime=([^\s]+)/);

      if (userMatch) {
        users.push({
          id: `hotspot-${userMatch[1]}`,
          name: userMatch[1],
          address: addressMatch ? addressMatch[1] : '',
          macAddress: macMatch ? macMatch[1] : '',
          uptime: uptimeMatch ? uptimeMatch[1] : '',
          service: 'hotspot',
          bytesIn: 0,
          bytesOut: 0,
          packetsIn: 0,
          packetsOut: 0
        });
      }
    }

    return users;
  }

  private parseLogs(output: string): LogEntry[] {
    const logs: LogEntry[] = [];
    const lines = output.split('\n');

    for (const line of lines) {
      const match = line.match(/(time=[^\s]+)\s+topics=([^\s]+)\s+message="(.+)"/);
      if (match) {
        logs.push({
          time: match[1].replace('time=', ''),
          topics: match[2].replace('topics=', ''),
          message: match[3]
        });
      }
    }

    return logs;
  }

  private parseCpuUsage(output: string): any[] {
    const cpus: any[] = [];
    const lines = output.split('\n');

    for (const line of lines) {
      const match = line.match(/(\d+)\s+(\d+)%/);
      if (match) {
        cpus.push({
          cpu: parseInt(match[1]),
          usage: parseInt(match[2])
        });
      }
    }

    return cpus;
  }

  private mapRouterFromDB(router: any): any {
    return {
      id: router.id,
      name: router.name,
      ipAddress: router.ip_address,
      port: router.port,
      username: router.username,
      password: '********', // Never return actual password
      apiPort: router.api_port,
      apiUseSsl: router.api_use_ssl,
      location: router.location,
      description: router.description,
      isActive: router.is_active,
      lastConnected: router.last_connected,
      version: router.version,
      companyId: router.company_id,
      createdAt: router.created_at,
      updatedAt: router.updated_at
    };
  }
}

export const mikrotikService = new MikrotikService();
export default mikrotikService;
