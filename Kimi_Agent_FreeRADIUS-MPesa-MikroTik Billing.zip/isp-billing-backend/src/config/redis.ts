import Redis from 'ioredis';
import { logger } from '../utils/logger';

const redisConfig = {
  host: process.env.REDIS_HOST || 'localhost',
  port: parseInt(process.env.REDIS_PORT || '6379'),
  password: process.env.REDIS_PASSWORD || undefined,
  db: parseInt(process.env.REDIS_DB || '0'),
  maxRetriesPerRequest: 3,
  enableReadyCheck: true,
  retryStrategy: (times: number) => {
    const delay = Math.min(times * 50, 2000);
    return delay;
  },
  reconnectOnError: (err: Error) => {
    const targetErrors = ['READONLY', 'ECONNREFUSED', 'ETIMEDOUT'];
    return targetErrors.some(e => err.message.includes(e));
  }
};

export const redis = new Redis(redisConfig);

export const redisPub = new Redis(redisConfig);
export const redisSub = new Redis(redisConfig);

// Event handlers
redis.on('connect', () => {
  logger.info('Redis client connected');
});

redis.on('ready', () => {
  logger.info('Redis client ready');
});

redis.on('error', (error) => {
  logger.error('Redis client error:', error);
});

redis.on('reconnecting', () => {
  logger.warn('Redis client reconnecting...');
});

// Cache utilities
export const cache = {
  async get<T>(key: string): Promise<T | null> {
    try {
      const value = await redis.get(key);
      return value ? JSON.parse(value) : null;
    } catch (error) {
      logger.error('Cache get error:', error);
      return null;
    }
  },

  async set(key: string, value: any, ttlSeconds?: number): Promise<void> {
    try {
      const serialized = JSON.stringify(value);
      if (ttlSeconds) {
        await redis.setex(key, ttlSeconds, serialized);
      } else {
        await redis.set(key, serialized);
      }
    } catch (error) {
      logger.error('Cache set error:', error);
    }
  },

  async del(key: string): Promise<void> {
    try {
      await redis.del(key);
    } catch (error) {
      logger.error('Cache del error:', error);
    }
  },

  async delPattern(pattern: string): Promise<void> {
    try {
      const keys = await redis.keys(pattern);
      if (keys.length > 0) {
        await redis.del(...keys);
      }
    } catch (error) {
      logger.error('Cache delPattern error:', error);
    }
  },

  async exists(key: string): Promise<boolean> {
    try {
      const result = await redis.exists(key);
      return result === 1;
    } catch (error) {
      logger.error('Cache exists error:', error);
      return false;
    }
  },

  async increment(key: string, amount: number = 1): Promise<number> {
    try {
      return await redis.incrby(key, amount);
    } catch (error) {
      logger.error('Cache increment error:', error);
      return 0;
    }
  },

  async expire(key: string, seconds: number): Promise<void> {
    try {
      await redis.expire(key, seconds);
    } catch (error) {
      logger.error('Cache expire error:', error);
    }
  }
};

// Session store utilities
export const sessionStore = {
  async get(sessionId: string): Promise<any> {
    return cache.get(`session:${sessionId}`);
  },

  async set(sessionId: string, data: any, ttlSeconds: number = 86400): Promise<void> {
    return cache.set(`session:${sessionId}`, data, ttlSeconds);
  },

  async destroy(sessionId: string): Promise<void> {
    return cache.del(`session:${sessionId}`);
  }
};

// Rate limiting utilities
export const rateLimiter = {
  async increment(key: string, windowSeconds: number): Promise<number> {
    const multi = redis.multi();
    multi.incr(key);
    multi.expire(key, windowSeconds);
    const results = await multi.exec();
    return results?.[0]?.[1] as number || 0;
  },

  async getCount(key: string): Promise<number> {
    const count = await redis.get(key);
    return parseInt(count || '0');
  },

  async reset(key: string): Promise<void> {
    await redis.del(key);
  }
};

// Pub/Sub utilities
export const pubsub = {
  async publish(channel: string, message: any): Promise<void> {
    try {
      await redisPub.publish(channel, JSON.stringify(message));
    } catch (error) {
      logger.error('Pub/Sub publish error:', error);
    }
  },

  subscribe(channel: string, callback: (message: any) => void): void {
    redisSub.subscribe(channel);
    redisSub.on('message', (receivedChannel, message) => {
      if (receivedChannel === channel) {
        try {
          callback(JSON.parse(message));
        } catch (error) {
          logger.error('Pub/Sub message parse error:', error);
        }
      }
    });
  },

  unsubscribe(channel: string): void {
    redisSub.unsubscribe(channel);
  }
};

export default redis;
