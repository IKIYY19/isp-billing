import knex from 'knex';
import { logger } from '../utils/logger';

const config: knex.Knex.Config = {
  client: 'postgresql',
  connection: {
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT || '5432'),
    database: process.env.DB_NAME || 'isp_billing',
    user: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASSWORD || 'password',
    ssl: process.env.DB_SSL === 'true' ? { rejectUnauthorized: false } : false
  },
  pool: {
    min: parseInt(process.env.DB_POOL_MIN || '2'),
    max: parseInt(process.env.DB_POOL_MAX || '10'),
    acquireTimeoutMillis: 30000,
    createTimeoutMillis: 30000,
    destroyTimeoutMillis: 5000,
    idleTimeoutMillis: 30000,
    reapIntervalMillis: 1000,
    createRetryIntervalMillis: 100
  },
  migrations: {
    directory: './migrations',
    tableName: 'knex_migrations',
    extension: 'ts'
  },
  seeds: {
    directory: './seeds',
    extension: 'ts'
  },
  debug: process.env.DB_DEBUG === 'true'
};

export const database = knex(config);

// Test connection
export const testConnection = async (): Promise<boolean> => {
  try {
    await database.raw('SELECT 1');
    logger.info('Database connection established successfully');
    return true;
  } catch (error) {
    logger.error('Database connection failed:', error);
    return false;
  }
};

// Initialize database with required extensions and schemas
export const initializeDatabase = async (): Promise<void> => {
  try {
    // Enable required extensions
    await database.raw('CREATE EXTENSION IF NOT EXISTS "uuid-ossp"');
    await database.raw('CREATE EXTENSION IF NOT EXISTS "pgcrypto"');
    await database.raw('CREATE EXTENSION IF NOT EXISTS "pg_trgm"');
    
    logger.info('Database extensions enabled successfully');
  } catch (error) {
    logger.error('Failed to initialize database:', error);
    throw error;
  }
};

export default database;
