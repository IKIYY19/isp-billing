import Queue from 'bull';
import { logger } from '../utils/logger';

const redisUrl = {
  host: process.env.REDIS_HOST || 'localhost',
  port: parseInt(process.env.REDIS_PORT || '6379'),
  password: process.env.REDIS_PASSWORD || undefined
};

// Job queues
export const invoiceQueue = new Queue('invoice generation', {
  redis: redisUrl,
  defaultJobOptions: {
    attempts: 3,
    backoff: {
      type: 'exponential',
      delay: 2000
    },
    removeOnComplete: 100,
    removeOnFail: 50
  }
});

export const paymentQueue = new Queue('payment processing', {
  redis: redisUrl,
  defaultJobOptions: {
    attempts: 5,
    backoff: {
      type: 'exponential',
      delay: 5000
    },
    removeOnComplete: 100,
    removeOnFail: 50
  }
});

export const notificationQueue = new Queue('notifications', {
  redis: redisUrl,
  defaultJobOptions: {
    attempts: 3,
    backoff: {
      type: 'fixed',
      delay: 1000
    },
    removeOnComplete: 200,
    removeOnFail: 100
  }
});

export const reportQueue = new Queue('report generation', {
  redis: redisUrl,
  defaultJobOptions: {
    attempts: 2,
    backoff: {
      type: 'fixed',
      delay: 5000
    },
    removeOnComplete: 50,
    removeOnFail: 20
  }
});

export const mikrotikQueue = new Queue('mikrotik operations', {
  redis: redisUrl,
  defaultJobOptions: {
    attempts: 3,
    backoff: {
      type: 'exponential',
      delay: 3000
    },
    removeOnComplete: 100,
    removeOnFail: 50
  }
});

export const radiusQueue = new Queue('radius operations', {
  redis: redisUrl,
  defaultJobOptions: {
    attempts: 3,
    backoff: {
      type: 'fixed',
      delay: 2000
    },
    removeOnComplete: 100,
    removeOnFail: 50
  }
});

export const backupQueue = new Queue('backup operations', {
  redis: redisUrl,
  defaultJobOptions: {
    attempts: 2,
    backoff: {
      type: 'fixed',
      delay: 10000
    },
    removeOnComplete: 10,
    removeOnFail: 5
  }
});

export const usageSyncQueue = new Queue('usage sync', {
  redis: redisUrl,
  defaultJobOptions: {
    attempts: 3,
    backoff: {
      type: 'exponential',
      delay: 5000
    },
    removeOnComplete: 50,
    removeOnFail: 25
  }
});

// Queue event handlers
const setupQueueEvents = (queue: Queue.Queue, name: string) => {
  queue.on('completed', (job, result) => {
    logger.info(`Job ${job.id} completed in ${name} queue`, { result });
  });

  queue.on('failed', (job, err) => {
    logger.error(`Job ${job.id} failed in ${name} queue`, { error: err.message });
  });

  queue.on('stalled', (job) => {
    logger.warn(`Job ${job.id} stalled in ${name} queue`);
  });

  queue.on('error', (error) => {
    logger.error(`${name} queue error:`, error);
  });
};

setupQueueEvents(invoiceQueue, 'invoice');
setupQueueEvents(paymentQueue, 'payment');
setupQueueEvents(notificationQueue, 'notification');
setupQueueEvents(reportQueue, 'report');
setupQueueEvents(mikrotikQueue, 'mikrotik');
setupQueueEvents(radiusQueue, 'radius');
setupQueueEvents(backupQueue, 'backup');
setupQueueEvents(usageSyncQueue, 'usageSync');

// Queue management
export const jobQueue = {
  async addInvoiceJob(data: any, options?: Queue.JobOptions) {
    return invoiceQueue.add(data, options);
  },

  async addPaymentJob(data: any, options?: Queue.JobOptions) {
    return paymentQueue.add(data, options);
  },

  async addNotificationJob(data: any, options?: Queue.JobOptions) {
    return notificationQueue.add(data, options);
  },

  async addReportJob(data: any, options?: Queue.JobOptions) {
    return reportQueue.add(data, options);
  },

  async addMikrotikJob(data: any, options?: Queue.JobOptions) {
    return mikrotikQueue.add(data, options);
  },

  async addRadiusJob(data: any, options?: Queue.JobOptions) {
    return radiusQueue.add(data, options);
  },

  async addBackupJob(data: any, options?: Queue.JobOptions) {
    return backupQueue.add(data, options);
  },

  async addUsageSyncJob(data: any, options?: Queue.JobOptions) {
    return usageSyncQueue.add(data, options);
  },

  async getQueueStatus() {
    const queues = [
      { name: 'invoice', queue: invoiceQueue },
      { name: 'payment', queue: paymentQueue },
      { name: 'notification', queue: notificationQueue },
      { name: 'report', queue: reportQueue },
      { name: 'mikrotik', queue: mikrotikQueue },
      { name: 'radius', queue: radiusQueue },
      { name: 'backup', queue: backupQueue },
      { name: 'usageSync', queue: usageSyncQueue }
    ];

    const status = await Promise.all(
      queues.map(async ({ name, queue }) => ({
        name,
        waiting: await queue.getWaitingCount(),
        active: await queue.getActiveCount(),
        completed: await queue.getCompletedCount(),
        failed: await queue.getFailedCount(),
        delayed: await queue.getDelayedCount()
      }))
    );

    return status;
  },

  async close() {
    await Promise.all([
      invoiceQueue.close(),
      paymentQueue.close(),
      notificationQueue.close(),
      reportQueue.close(),
      mikrotikQueue.close(),
      radiusQueue.close(),
      backupQueue.close(),
      usageSyncQueue.close()
    ]);
  }
};

export default jobQueue;
