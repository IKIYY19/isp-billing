import { Router } from 'express';
import { body, param, query } from 'express-validator';
import { oltManager } from '../../services/olt/oltManager';
import { database } from '../../config/database';
import { authenticate, authorize } from '../../middleware/auth';
import { AppError, asyncHandler } from '../../middleware/errorHandler';
import { logger } from '../../utils/logger';

const router = Router();

// ============================================
// OLT Management
// ============================================

/**
 * @route   GET /api/olt
 * @desc    Get all OLTs
 * @access  Private
 */
router.get('/',
  authenticate,
  asyncHandler(async (req, res) => {
    const olts = await oltManager.getAllOLTs(req.user!.companyId);
    
    res.json({
      success: true,
      data: { olts }
    });
  })
);

/**
 * @route   POST /api/olt
 * @desc    Add new OLT
 * @access  Private (Admin, Manager)
 */
router.post('/',
  authenticate,
  authorize('admin', 'manager'),
  body('name').trim().notEmpty().withMessage('OLT name is required'),
  body('vendor').isIn(['huawei', 'zte', 'nokia', 'fiberhome']).withMessage('Valid vendor required'),
  body('ipAddress').isIP().withMessage('Valid IP address required'),
  body('username').trim().notEmpty(),
  body('password').trim().notEmpty(),
  asyncHandler(async (req, res) => {
    const result = await oltManager.addOLT({
      name: req.body.name,
      vendor: req.body.vendor,
      model: req.body.model,
      ipAddress: req.body.ipAddress,
      port: req.body.port || 22,
      protocol: req.body.protocol || 'ssh',
      username: req.body.username,
      password: req.body.password,
      enablePassword: req.body.enablePassword,
      snmpCommunity: req.body.snmpCommunity,
      snmpVersion: req.body.snmpVersion,
      location: req.body.location,
      coordinates: req.body.coordinates,
      capacity: req.body.capacity || { maxPonPorts: 16, maxOnusPerPort: 128 },
      isActive: true,
      companyId: req.user!.companyId
    });

    if (!result.success) {
      return res.status(400).json({
        success: false,
        message: result.message
      });
    }

    res.status(201).json({
      success: true,
      message: 'OLT added successfully',
      data: { olt: result.olt }
    });
  })
);

/**
 * @route   GET /api/olt/:oltId
 * @desc    Get OLT details
 * @access  Private
 */
router.get('/:oltId',
  authenticate,
  param('oltId').isUUID(),
  asyncHandler(async (req, res) => {
    const olt = await oltManager.getOLT(req.params.oltId);
    
    if (!olt) {
      throw new AppError('OLT not found', 404);
    }

    res.json({
      success: true,
      data: { olt }
    });
  })
);

/**
 * @route   GET /api/olt/:oltId/status
 * @desc    Get OLT real-time status
 * @access  Private
 */
router.get('/:oltId/status',
  authenticate,
  param('oltId').isUUID(),
  asyncHandler(async (req, res) => {
    const status = await oltManager.getOLTStatus(req.params.oltId);
    
    if (!status) {
      throw new AppError('OLT not found', 404);
    }

    res.json({
      success: true,
      data: { status }
    });
  })
);

/**
 * @route   DELETE /api/olt/:oltId
 * @desc    Remove OLT
 * @access  Private (Admin)
 */
router.delete('/:oltId',
  authenticate,
  authorize('admin'),
  param('oltId').isUUID(),
  asyncHandler(async (req, res) => {
    await database('olts')
      .where({ id: req.params.oltId })
      .update({ is_active: false, updated_at: new Date() });

    res.json({
      success: true,
      message: 'OLT removed successfully'
    });
  })
);

// ============================================
// PON Ports
// ============================================

/**
 * @route   GET /api/olt/:oltId/ports
 * @desc    Get PON ports for OLT
 * @access  Private
 */
router.get('/:oltId/ports',
  authenticate,
  param('oltId').isUUID(),
  asyncHandler(async (req, res) => {
    const ports = await oltManager.getPONPorts(req.params.oltId);
    
    res.json({
      success: true,
      data: { ports }
    });
  })
);

// ============================================
// ONU Management
// ============================================

/**
 * @route   GET /api/olt/:oltId/onu
 * @desc    Get all ONUs for OLT
 * @access  Private
 */
router.get('/:oltId/onu',
  authenticate,
  param('oltId').isUUID(),
  query('portId').optional().isUUID(),
  asyncHandler(async (req, res) => {
    const onus = await oltManager.getONUs(
      req.params.oltId,
      req.query.portId as string
    );
    
    res.json({
      success: true,
      data: { onus }
    });
  })
);

/**
 * @route   POST /api/olt/:oltId/onu
 * @desc    Provision new ONU
 * @access  Private (Admin, Manager, Technician)
 */
router.post('/:oltId/onu',
  authenticate,
  authorize('admin', 'manager', 'technician'),
  param('oltId').isUUID(),
  body('serialNumber').trim().notEmpty(),
  body('ponPortId').isUUID(),
  body('customerId').optional().isUUID(),
  asyncHandler(async (req, res) => {
    const result = await oltManager.provisionONU(req.params.oltId, {
      serialNumber: req.body.serialNumber,
      ponPortId: req.body.ponPortId,
      onuId: req.body.onuId,
      customerId: req.body.customerId,
      serviceProfile: req.body.serviceProfile,
      lineProfile: req.body.lineProfile,
      description: req.body.description,
      vlanConfig: req.body.vlanConfig
    });

    if (!result.success) {
      return res.status(400).json({
        success: false,
        message: result.message
      });
    }

    res.status(201).json({
      success: true,
      message: result.message,
      data: { onuId: result.onuId }
    });
  })
);

/**
 * @route   DELETE /api/olt/:oltId/onu/:onuId
 * @desc    Deprovision ONU
 * @access  Private (Admin, Manager, Technician)
 */
router.delete('/:oltId/onu/:onuId',
  authenticate,
  authorize('admin', 'manager', 'technician'),
  param('oltId').isUUID(),
  param('onuId').notEmpty(),
  asyncHandler(async (req, res) => {
    const result = await oltManager.deprovisionONU(
      req.params.oltId,
      req.params.onuId
    );

    if (!result.success) {
      return res.status(400).json({
        success: false,
        message: result.message
      });
    }

    res.json({
      success: true,
      message: result.message
    });
  })
);

/**
 * @route   POST /api/olt/:oltId/onu/:onuId/reset
 * @desc    Reset ONU
 * @access  Private (Admin, Manager, Technician)
 */
router.post('/:oltId/onu/:onuId/reset',
  authenticate,
  authorize('admin', 'manager', 'technician'),
  param('oltId').isUUID(),
  param('onuId').notEmpty(),
  asyncHandler(async (req, res) => {
    const result = await oltManager.resetONU(
      req.params.oltId,
      req.params.onuId
    );

    if (!result.success) {
      return res.status(400).json({
        success: false,
        message: result.message
      });
    }

    res.json({
      success: true,
      message: result.message
    });
  })
);

// ============================================
// Alarms & Performance
// ============================================

/**
 * @route   GET /api/olt/:oltId/alarms
 * @desc    Get OLT alarms
 * @access  Private
 */
router.get('/:oltId/alarms',
  authenticate,
  param('oltId').isUUID(),
  asyncHandler(async (req, res) => {
    const alarms = await oltManager.getAlarms(req.params.oltId);
    
    res.json({
      success: true,
      data: { alarms }
    });
  })
);

/**
 * @route   GET /api/olt/:oltId/performance
 * @desc    Get OLT performance metrics
 * @access  Private
 */
router.get('/:oltId/performance',
  authenticate,
  param('oltId').isUUID(),
  asyncHandler(async (req, res) => {
    const performance = await oltManager.getPerformance(req.params.oltId);
    
    res.json({
      success: true,
      data: { performance }
    });
  })
);

// ============================================
// Commands
// ============================================

/**
 * @route   POST /api/olt/:oltId/command
 * @desc    Execute custom command on OLT
 * @access  Private (Admin, Manager, Technician)
 */
router.post('/:oltId/command',
  authenticate,
  authorize('admin', 'manager', 'technician'),
  param('oltId').isUUID(),
  body('command').trim().notEmpty(),
  asyncHandler(async (req, res) => {
    const result = await oltManager.executeCommand(
      req.params.oltId,
      req.body.command
    );

    res.json({
      success: result.success,
      data: { output: result.output }
    });
  })
);

// ============================================
// Self-Healing & AI Features
// ============================================

/**
 * @route   POST /api/olt/:oltId/self-healing
 * @desc    Run self-healing on OLT
 * @access  Private (Admin, Manager)
 */
router.post('/:oltId/self-healing',
  authenticate,
  authorize('admin', 'manager'),
  param('oltId').isUUID(),
  asyncHandler(async (req, res) => {
    const result = await oltManager.runSelfHealing(req.params.oltId);
    
    res.json({
      success: true,
      data: result
    });
  })
);

/**
 * @route   GET /api/olt/:oltId/ai-optimizations
 * @desc    Get AI optimization suggestions
 * @access  Private (Admin, Manager)
 */
router.get('/:oltId/ai-optimizations',
  authenticate,
  authorize('admin', 'manager'),
  param('oltId').isUUID(),
  asyncHandler(async (req, res) => {
    const suggestions = await oltManager.getAIOptimizations(req.params.oltId);
    
    res.json({
      success: true,
      data: { suggestions }
    });
  })
);

/**
 * @route   POST /api/olt/:oltId/auto-discover
 * @desc    Run auto-discovery for unprovisioned ONUs
 * @access  Private (Admin, Manager, Technician)
 */
router.post('/:oltId/auto-discover',
  authenticate,
  authorize('admin', 'manager', 'technician'),
  param('oltId').isUUID(),
  asyncHandler(async (req, res) => {
    const result = await oltManager.autoDiscoverONUs(req.params.oltId);
    
    res.json({
      success: true,
      data: result
    });
  })
);

// ============================================
// Dashboard Stats
// ============================================

/**
 * @route   GET /api/olt/dashboard/stats
 * @desc    Get OLT dashboard statistics
 * @access  Private
 */
router.get('/dashboard/stats',
  authenticate,
  asyncHandler(async (req, res) => {
    const olts = await oltManager.getAllOLTs(req.user!.companyId);
    
    let totalONUs = 0;
    let onlineONUs = 0;
    let offlineONUs = 0;
    let totalPorts = 0;
    let activeAlarms = 0;

    for (const olt of olts) {
      const status = await oltManager.getOLTStatus(olt.id);
      if (status) {
        totalONUs += status.onuCount || 0;
        totalPorts += status.ponPorts || 0;
        
        if (status.metrics?.onus) {
          onlineONUs += status.metrics.onus.online || 0;
          offlineONUs += status.metrics.onus.offline || 0;
        }

        const alarms = await oltManager.getAlarms(olt.id);
        activeAlarms += alarms.filter(a => !a.cleared).length;
      }
    }

    res.json({
      success: true,
      data: {
        oltCount: olts.length,
        totalPorts,
        totalONUs,
        onlineONUs,
        offlineONUs,
        activeAlarms,
        utilization: totalPorts > 0 ? (totalONUs / (totalPorts * 128)) * 100 : 0
      }
    });
  })
);

// ============================================
// Bulk Operations
// ============================================

/**
 * @route   POST /api/olt/:oltId/bulk-provision
 * @desc    Bulk provision ONUs
 * @access  Private (Admin, Manager, Technician)
 */
router.post('/:oltId/bulk-provision',
  authenticate,
  authorize('admin', 'manager', 'technician'),
  param('oltId').isUUID(),
  body('onus').isArray(),
  asyncHandler(async (req, res) => {
    const olt = await oltManager.getOLT(req.params.oltId);
    if (!olt) {
      throw new AppError('OLT not found', 404);
    }

    const adapter = oltManager['getAdapter'](olt);
    await adapter.connect();
    const result = await adapter.bulkProvisionONUs(req.body.onus);
    await adapter.disconnect();

    res.json({
      success: result.success,
      data: { results: result.results }
    });
  })
);

/**
 * @route   POST /api/olt/:oltId/bulk-reset
 * @desc    Bulk reset ONUs
 * @access  Private (Admin, Manager, Technician)
 */
router.post('/:oltId/bulk-reset',
  authenticate,
  authorize('admin', 'manager', 'technician'),
  param('oltId').isUUID(),
  body('onuIds').isArray(),
  asyncHandler(async (req, res) => {
    const olt = await oltManager.getOLT(req.params.oltId);
    if (!olt) {
      throw new AppError('OLT not found', 404);
    }

    const adapter = oltManager['getAdapter'](olt);
    await adapter.connect();
    const result = await adapter.bulkResetONU(req.body.onuIds);
    await adapter.disconnect();

    res.json({
      success: result.success,
      data: { results: result.results }
    });
  })
);

// ============================================
// Alarm Management
// ============================================

/**
 * @route   POST /api/olt/:oltId/alarms/:alarmId/acknowledge
 * @desc    Acknowledge an alarm
 * @access  Private (Admin, Manager)
 */
router.post('/:oltId/alarms/:alarmId/acknowledge',
  authenticate,
  authorize('admin', 'manager'),
  param('oltId').isUUID(),
  param('alarmId').notEmpty(),
  asyncHandler(async (req, res) => {
    await database('olt_alarms')
      .where({ id: req.params.alarmId, olt_id: req.params.oltId })
      .update({
        acknowledged: true,
        acknowledged_by: req.user!.id,
        acknowledged_at: new Date(),
        updated_at: new Date()
      });

    res.json({
      success: true,
      message: 'Alarm acknowledged'
    });
  })
);

/**
 * @route   POST /api/olt/:oltId/alarms/:alarmId/clear
 * @desc    Clear an alarm
 * @access  Private (Admin, Manager)
 */
router.post('/:oltId/alarms/:alarmId/clear',
  authenticate,
  authorize('admin', 'manager'),
  param('oltId').isUUID(),
  param('alarmId').notEmpty(),
  asyncHandler(async (req, res) => {
    await database('olt_alarms')
      .where({ id: req.params.alarmId, olt_id: req.params.oltId })
      .update({
        cleared: true,
        cleared_at: new Date(),
        updated_at: new Date()
      });

    res.json({
      success: true,
      message: 'Alarm cleared'
    });
  })
);

export default router;
