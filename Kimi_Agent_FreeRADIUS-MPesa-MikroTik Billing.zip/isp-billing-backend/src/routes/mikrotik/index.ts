import { Router } from 'express';
import { body, param, query } from 'express-validator';
import { mikrotikService } from '../../services/mikrotikService';
import { database } from '../../config/database';
import { authenticate, authorize } from '../../middleware/auth';
import { AppError, asyncHandler } from '../../middleware/errorHandler';
import { logger } from '../../utils/logger';

const router = Router();

// ============================================
// Router Management
// ============================================

/**
 * @route   GET /api/mikrotik
 * @desc    Get all MikroTik routers
 * @access  Private
 */
router.get('/',
  authenticate,
  asyncHandler(async (req, res) => {
    const routers = await mikrotikService.getRouters(req.user!.companyId);
    
    res.json({
      success: true,
      data: { routers }
    });
  })
);

/**
 * @route   POST /api/mikrotik
 * @desc    Add new MikroTik router
 * @access  Private (Admin, Manager)
 */
router.post('/',
  authenticate,
  authorize('admin', 'manager'),
  body('name').trim().notEmpty().withMessage('Router name is required'),
  body('ipAddress').isIP().withMessage('Valid IP address required'),
  body('username').trim().notEmpty(),
  body('password').trim().notEmpty(),
  asyncHandler(async (req, res) => {
    const result = await mikrotikService.addRouter({
      name: req.body.name,
      ipAddress: req.body.ipAddress,
      port: req.body.port || 22,
      username: req.body.username,
      password: req.body.password,
      apiPort: req.body.apiPort || 8728,
      apiUseSsl: req.body.apiUseSsl || false,
      location: req.body.location,
      description: req.body.description,
      companyId: req.user!.companyId
    });

    if (!result.success) {
      return res.status(400).json({
        success: false,
        message: result.message
      });
    }

    res.status(201).json({
      success: true,
      message: 'Router added successfully',
      data: { router: result.router }
    });
  })
);

/**
 * @route   POST /api/mikrotik/test
 * @desc    Test connection to a MikroTik router
 * @access  Private (Admin, Manager)
 */
router.post('/test',
  authenticate,
  authorize('admin', 'manager'),
  body('ipAddress').isIP().withMessage('Valid IP address required'),
  body('username').trim().notEmpty(),
  body('password').trim().notEmpty(),
  asyncHandler(async (req, res) => {
    const result = await mikrotikService.testConnection({
      name: 'test',
      ipAddress: req.body.ipAddress,
      port: req.body.port || 22,
      username: req.body.username,
      password: req.body.password,
      apiPort: req.body.apiPort || 8728
    });

    res.json({
      success: result.success,
      message: result.message,
      data: { status: result.status }
    });
  })
);

/**
 * @route   GET /api/mikrotik/:routerId
 * @desc    Get router details
 * @access  Private
 */
router.get('/:routerId',
  authenticate,
  param('routerId').isUUID(),
  asyncHandler(async (req, res) => {
    const router = await mikrotikService.getRouter(req.params.routerId);
    
    if (!router) {
      throw new AppError('Router not found', 404);
    }

    res.json({
      success: true,
      data: { router }
    });
  })
);

/**
 * @route   PUT /api/mikrotik/:routerId
 * @desc    Update router
 * @access  Private (Admin, Manager)
 */
router.put('/:routerId',
  authenticate,
  authorize('admin', 'manager'),
  param('routerId').isUUID(),
  asyncHandler(async (req, res) => {
    const result = await mikrotikService.updateRouter(req.params.routerId, req.body);

    if (!result.success) {
      return res.status(400).json({
        success: false,
        message: result.message
      });
    }

    res.json({
      success: true,
      message: 'Router updated successfully',
      data: { router: result.router }
    });
  })
);

/**
 * @route   DELETE /api/mikrotik/:routerId
 * @desc    Remove router
 * @access  Private (Admin)
 */
router.delete('/:routerId',
  authenticate,
  authorize('admin'),
  param('routerId').isUUID(),
  asyncHandler(async (req, res) => {
    const result = await mikrotikService.deleteRouter(req.params.routerId);

    if (!result.success) {
      return res.status(400).json({
        success: false,
        message: result.message
      });
    }

    res.json({
      success: true,
      message: 'Router removed successfully'
    });
  })
);

// ============================================
// Router Status & Monitoring
// ============================================

/**
 * @route   GET /api/mikrotik/:routerId/status
 * @desc    Get router real-time status
 * @access  Private
 */
router.get('/:routerId/status',
  authenticate,
  param('routerId').isUUID(),
  asyncHandler(async (req, res) => {
    const status = await mikrotikService.getRouterStatus(req.params.routerId);
    
    res.json({
      success: true,
      data: { status }
    });
  })
);

/**
 * @route   GET /api/mikrotik/:routerId/interfaces
 * @desc    Get router interfaces
 * @access  Private
 */
router.get('/:routerId/interfaces',
  authenticate,
  param('routerId').isUUID(),
  asyncHandler(async (req, res) => {
    const interfaces = await mikrotikService.getInterfaces(req.params.routerId);
    
    res.json({
      success: true,
      data: { interfaces }
    });
  })
);

/**
 * @route   GET /api/mikrotik/:routerId/routes
 * @desc    Get router routes
 * @access  Private
 */
router.get('/:routerId/routes',
  authenticate,
  param('routerId').isUUID(),
  asyncHandler(async (req, res) => {
    const routes = await mikrotikService.getRoutes(req.params.routerId);
    
    res.json({
      success: true,
      data: { routes }
    });
  })
);

/**
 * @route   GET /api/mikrotik/:routerId/users
 * @desc    Get active users (PPPoE + Hotspot)
 * @access  Private
 */
router.get('/:routerId/users',
  authenticate,
  param('routerId').isUUID(),
  asyncHandler(async (req, res) => {
    const users = await mikrotikService.getActiveUsers(req.params.routerId);
    
    res.json({
      success: true,
      data: { users }
    });
  })
);

/**
 * @route   GET /api/mikrotik/:routerId/logs
 * @desc    Get router logs
 * @access  Private
 */
router.get('/:routerId/logs',
  authenticate,
  param('routerId').isUUID(),
  query('limit').optional().isInt({ min: 1, max: 1000 }),
  asyncHandler(async (req, res) => {
    const limit = parseInt(req.query.limit as string) || 100;
    const logs = await mikrotikService.getLogs(req.params.routerId, limit);
    
    res.json({
      success: true,
      data: { logs }
    });
  })
);

/**
 * @route   GET /api/mikrotik/:routerId/realtime
 * @desc    Get real-time metrics
 * @access  Private
 */
router.get('/:routerId/realtime',
  authenticate,
  param('routerId').isUUID(),
  asyncHandler(async (req, res) => {
    const metrics = await mikrotikService.getRealtimeMetrics(req.params.routerId);
    
    res.json({
      success: true,
      data: { metrics }
    });
  })
);

// ============================================
// Command Execution
// ============================================

/**
 * @route   POST /api/mikrotik/:routerId/command
 * @desc    Execute custom command on router
 * @access  Private (Admin, Manager, Technician)
 */
router.post('/:routerId/command',
  authenticate,
  authorize('admin', 'manager', 'technician'),
  param('routerId').isUUID(),
  body('command').trim().notEmpty(),
  asyncHandler(async (req, res) => {
    const result = await mikrotikService.executeCommand(
      req.params.routerId,
      req.body.command
    );

    res.json({
      success: result.success,
      data: { output: result.output }
    });
  })
);

// ============================================
// Troubleshooting
// ============================================

/**
 * @route   POST /api/mikrotik/:routerId/troubleshoot
 * @desc    Run troubleshooting diagnostics
 * @access  Private (Admin, Manager, Technician)
 */
router.post('/:routerId/troubleshoot',
  authenticate,
  authorize('admin', 'manager', 'technician'),
  param('routerId').isUUID(),
  asyncHandler(async (req, res) => {
    const result = await mikrotikService.runTroubleshooting(req.params.routerId);
    
    res.json({
      success: true,
      data: result
    });
  })
);

/**
 * @route   POST /api/mikrotik/:routerId/autofix
 * @desc    Auto-fix common issues
 * @access  Private (Admin, Manager)
 */
router.post('/:routerId/autofix',
  authenticate,
  authorize('admin', 'manager'),
  param('routerId').isUUID(),
  body('fixes').isArray(),
  asyncHandler(async (req, res) => {
    const result = await mikrotikService.autoFix(req.params.routerId, req.body.fixes);
    
    res.json({
      success: result.success,
      data: { results: result.results }
    });
  })
);

// ============================================
// Dashboard Stats
// ============================================

/**
 * @route   GET /api/mikrotik/dashboard/stats
 * @desc    Get MikroTik dashboard statistics
 * @access  Private
 */
router.get('/dashboard/stats',
  authenticate,
  asyncHandler(async (req, res) => {
    const routers = await mikrotikService.getRouters(req.user!.companyId);
    
    let totalUsers = 0;
    let onlineRouters = 0;
    let offlineRouters = 0;
    let avgCpu = 0;
    let avgMemory = 0;
    let totalInterfaces = 0;

    for (const router of routers) {
      const status = await mikrotikService.getRouterStatus(router.id);
      
      if (status.connected) {
        onlineRouters++;
        totalUsers += status.totalUsers || 0;
        avgCpu += status.cpuUsage || 0;
        avgMemory += status.memoryUsage || 0;
        
        try {
          const interfaces = await mikrotikService.getInterfaces(router.id);
          totalInterfaces += interfaces.length;
        } catch {
          // Ignore interface errors
        }
      } else {
        offlineRouters++;
      }
    }

    if (onlineRouters > 0) {
      avgCpu = avgCpu / onlineRouters;
      avgMemory = avgMemory / onlineRouters;
    }

    res.json({
      success: true,
      data: {
        routerCount: routers.length,
        onlineRouters,
        offlineRouters,
        totalUsers,
        avgCpu: Math.round(avgCpu * 10) / 10,
        avgMemory: Math.round(avgMemory * 10) / 10,
        totalInterfaces,
        networkHealth: routers.length > 0 ? Math.round((onlineRouters / routers.length) * 100) : 0
      }
    });
  })
);

// ============================================
// Bulk Operations
// ============================================

/**
 * @route   POST /api/mikrotik/bulk/command
 * @desc    Execute command on multiple routers
 * @access  Private (Admin, Manager)
 */
router.post('/bulk/command',
  authenticate,
  authorize('admin', 'manager'),
  body('routerIds').isArray(),
  body('command').trim().notEmpty(),
  asyncHandler(async (req, res) => {
    const results: Array<{ routerId: string; success: boolean; output: string }> = [];

    for (const routerId of req.body.routerIds) {
      try {
        const result = await mikrotikService.executeCommand(routerId, req.body.command);
        results.push({ routerId, ...result });
      } catch (error: any) {
        results.push({ routerId, success: false, output: error.message });
      }
    }

    res.json({
      success: true,
      data: { results }
    });
  })
);

export default router;
