import { Router } from 'express';
import { body, param, query } from 'express-validator';
import { mpesaService } from '../../services/mpesaService';
import { database } from '../../config/database';
import { authenticate, authorize } from '../../middleware/auth';
import { AppError, asyncHandler } from '../../middleware/errorHandler';
import { logger } from '../../utils/logger';

const router = Router();

// ============================================
// STK Push Payments
// ============================================

/**
 * @route   POST /api/mpesa/stkpush
 * @desc    Initiate STK Push payment
 * @access  Private
 */
router.post('/stkpush',
  authenticate,
  body('phoneNumber').isMobilePhone('any').withMessage('Valid phone number required'),
  body('amount').isFloat({ min: 1 }).withMessage('Amount must be at least 1'),
  body('accountNumber').trim().notEmpty().withMessage('Account number required'),
  body('customerId').optional().isUUID(),
  body('invoiceId').optional().isUUID(),
  asyncHandler(async (req, res) => {
    const { phoneNumber, amount, accountNumber, description, customerId, invoiceId } = req.body;

    // Validate customer exists if customerId provided
    if (customerId) {
      const customer = await database('customers')
        .where({ id: customerId, company_id: req.user!.companyId })
        .first();
      
      if (!customer) {
        throw new AppError('Customer not found', 404);
      }
    }

    // Initiate STK Push
    const result = await mpesaService.initiateSTKPush({
      phoneNumber,
      amount,
      accountNumber,
      description: description || `Payment for ${accountNumber}`,
      callbackUrl: `${process.env.BACKEND_URL}/api/mpesa/callback`
    });

    if (!result.success) {
      return res.status(400).json({
        success: false,
        message: result.error || 'Failed to initiate payment'
      });
    }

    // Update request with customer/invoice info
    if (customerId || invoiceId) {
      await database('mpesa_requests')
        .where({ checkout_request_id: result.checkoutRequestId })
        .update({
          customer_id: customerId,
          invoice_id: invoiceId,
          updated_at: new Date()
        });
    }

    res.json({
      success: true,
      message: result.customerMessage || 'Payment request sent to phone',
      data: {
        merchantRequestId: result.merchantRequestId,
        checkoutRequestId: result.checkoutRequestId,
        accountNumber
      }
    });
  })
);

/**
 * @route   POST /api/mpesa/query
 * @desc    Query STK Push status
 * @access  Private
 */
router.post('/query',
  authenticate,
  body('checkoutRequestId').trim().notEmpty(),
  asyncHandler(async (req, res) => {
    const { checkoutRequestId } = req.body;

    const status = await mpesaService.querySTKStatus(checkoutRequestId);

    res.json({
      success: status.success,
      data: status
    });
  })
);

// ============================================
// M-Pesa Callback (Public endpoint)
// ============================================

/**
 * @route   POST /api/mpesa/callback
 * @desc    M-Pesa callback endpoint
 * @access  Public
 */
router.post('/callback', asyncHandler(async (req, res) => {
  logger.info('M-Pesa callback received', { body: req.body });

  // Process callback asynchronously
  mpesaService.processCallback(req.body).catch(error => {
    logger.error('Failed to process M-Pesa callback:', error);
  });

  // Always return success to M-Pesa
  res.json({
    ResultCode: 0,
    ResultDesc: 'Callback received successfully'
  });
}));

// ============================================
// C2B Integration
// ============================================

/**
 * @route   POST /api/mpesa/register-urls
 * @desc    Register C2B URLs
 * @access  Private (Admin only)
 */
router.post('/register-urls',
  authenticate,
  authorize('admin'),
  body('validationUrl').isURL(),
  body('confirmationUrl').isURL(),
  asyncHandler(async (req, res) => {
    const { validationUrl, confirmationUrl } = req.body;

    const result = await mpesaService.registerC2BUrls(validationUrl, confirmationUrl);

    res.json({
      success: true,
      data: result
    });
  })
);

/**
 * @route   POST /api/mpesa/simulate
 * @desc    Simulate C2B payment (sandbox only)
 * @access  Private (Admin only)
 */
router.post('/simulate',
  authenticate,
  authorize('admin'),
  body('phoneNumber').isMobilePhone('any'),
  body('amount').isFloat({ min: 1 }),
  body('accountNumber').trim().notEmpty(),
  asyncHandler(async (req, res) => {
    const { phoneNumber, amount, accountNumber } = req.body;

    const result = await mpesaService.simulateC2BPayment(phoneNumber, amount, accountNumber);

    res.json({
      success: true,
      data: result
    });
  })
);

// ============================================
// Payment History & Management
// ============================================

/**
 * @route   GET /api/mpesa/history/:customerId
 * @desc    Get M-Pesa payment history for a customer
 * @access  Private
 */
router.get('/history/:customerId',
  authenticate,
  param('customerId').isUUID(),
  query('limit').optional().isInt({ min: 1, max: 100 }),
  asyncHandler(async (req, res) => {
    const { customerId } = req.params;
    const limit = parseInt(req.query.limit as string) || 50;

    // Verify customer belongs to user's company
    const customer = await database('customers')
      .where({ id: customerId, company_id: req.user!.companyId })
      .first();

    if (!customer) {
      throw new AppError('Customer not found', 404);
    }

    const payments = await mpesaService.getCustomerPaymentHistory(customerId, limit);

    res.json({
      success: true,
      data: { payments }
    });
  })
);

/**
 * @route   GET /api/mpesa/pending
 * @desc    Get pending M-Pesa payments
 * @access  Private (Admin, Manager)
 */
router.get('/pending',
  authenticate,
  authorize('admin', 'manager'),
  asyncHandler(async (req, res) => {
    const pending = await mpesaService.getPendingPayments();

    res.json({
      success: true,
      data: { pending }
    });
  })
);

/**
 * @route   POST /api/mpesa/retry
 * @desc    Retry failed payment queries
 * @access  Private (Admin)
 */
router.post('/retry',
  authenticate,
  authorize('admin'),
  asyncHandler(async (req, res) => {
    await mpesaService.retryFailedQueries();

    res.json({
      success: true,
      message: 'Retry process initiated'
    });
  })
);

// ============================================
// Customer Payment Page
// ============================================

/**
 * @route   GET /api/mpesa/customer/:accountNumber
 * @desc    Get customer info by account number for payment
 * @access  Public (for payment portal)
 */
router.get('/customer/:accountNumber',
  asyncHandler(async (req, res) => {
    const { accountNumber } = req.params;

    const customer = await database('customers')
      .where({ account_number: accountNumber })
      .first([
        'id',
        'account_number',
        'first_name',
        'last_name',
        'email',
        'phone',
        'balance',
        'plan_id',
        'status'
      ]);

    if (!customer) {
      throw new AppError('Account not found', 404);
    }

    // Get current plan
    const plan = customer.plan_id 
      ? await database('plans').where({ id: customer.plan_id }).first('name', 'price')
      : null;

    // Get last payment
    const lastPayment = await database('payments')
      .where({ customer_id: customer.id })
      .orderBy('created_at', 'desc')
      .first();

    // Get outstanding invoices
    const outstandingInvoices = await database('invoices')
      .where({ 
        customer_id: customer.id,
        status: 'sent'
      })
      .sum('balance as total')
      .first();

    res.json({
      success: true,
      data: {
        customer: {
          ...customer,
          plan,
          lastPayment,
          outstandingAmount: outstandingInvoices?.total || 0
        }
      }
    });
  })
);

/**
 * @route   POST /api/mpesa/pay
 * @desc    Public payment endpoint (no auth required)
 * @access  Public
 */
router.post('/pay',
  body('accountNumber').trim().notEmpty(),
  body('phoneNumber').isMobilePhone('any'),
  body('amount').isFloat({ min: 1 }),
  asyncHandler(async (req, res) => {
    const { accountNumber, phoneNumber, amount } = req.body;

    // Find customer by account number
    const customer = await database('customers')
      .where({ account_number: accountNumber })
      .first();

    if (!customer) {
      throw new AppError('Account number not found', 404);
    }

    if (customer.status !== 'active') {
      throw new AppError('Account is not active', 400);
    }

    // Initiate payment
    const result = await mpesaService.initiateSTKPush({
      phoneNumber,
      amount,
      accountNumber,
      description: `Payment for ${customer.first_name} ${customer.last_name}`,
      callbackUrl: `${process.env.BACKEND_URL}/api/mpesa/callback`
    });

    if (!result.success) {
      return res.status(400).json({
        success: false,
        message: result.error || 'Failed to initiate payment'
      });
    }

    // Link to customer
    await database('mpesa_requests')
      .where({ checkout_request_id: result.checkoutRequestId })
      .update({
        customer_id: customer.id,
        updated_at: new Date()
      });

    res.json({
      success: true,
      message: 'Payment request sent to your phone. Please enter your M-Pesa PIN to complete.',
      data: {
        checkoutRequestId: result.checkoutRequestId,
        accountNumber,
        amount
      }
    });
  })
);

// ============================================
// Configuration
// ============================================

/**
 * @route   GET /api/mpesa/config
 * @desc    Get M-Pesa configuration status
 * @access  Private (Admin)
 */
router.get('/config',
  authenticate,
  authorize('admin'),
  asyncHandler(async (req, res) => {
    const config = {
      environment: process.env.MPESA_ENVIRONMENT || 'sandbox',
      shortcode: process.env.MPESA_SHORTCODE ? '****' + process.env.MPESA_SHORTCODE.slice(-4) : null,
      consumerKey: process.env.MPESA_CONSUMER_KEY ? '****' + process.env.MPESA_CONSUMER_KEY.slice(-4) : null,
      passkey: process.env.MPESA_PASSKEY ? 'Configured' : 'Not configured',
      callbackUrl: process.env.MPESA_CALLBACK_URL
    };

    res.json({
      success: true,
      data: { config }
    });
  })
);

export default router;
