import { Router } from 'express';
import { body, validationResult } from 'express-validator';
import { phoneAuthService } from '../../services/auth/phoneAuthService';
import { emailAuthService } from '../../services/auth/emailAuthService';
import { oauthService } from '../../services/auth/oauthService';
import { database } from '../../config/database';
import { cache } from '../../config/redis';
import { logger } from '../../utils/logger';
import { AppError, asyncHandler } from '../../middleware/errorHandler';
import { generateTokens, authenticate, requirePermission } from '../../middleware/auth';

const router = Router();

// Validation middleware helper
const validate = (req: any, res: any, next: any) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      message: 'Validation failed',
      errors: errors.array()
    });
  }
  next();
};

// ============================================
// PHONE AUTHENTICATION (OTP)
// ============================================

/**
 * @route   POST /api/auth/phone/send-otp
 * @desc    Send OTP to phone number
 * @access  Public
 */
router.post('/phone/send-otp',
  body('phoneNumber').isMobilePhone('any').withMessage('Valid phone number required'),
  validate,
  asyncHandler(async (req, res) => {
    const { phoneNumber, purpose = 'login' } = req.body;

    // Check if phone is registered (for login)
    if (purpose === 'login') {
      const isRegistered = await phoneAuthService.isPhoneRegistered(phoneNumber);
      if (!isRegistered) {
        // Check if it's a customer phone
        const { isCustomer, customerId } = await phoneAuthService.isCustomerPhone(phoneNumber);
        
        if (!isCustomer) {
          return res.status(404).json({
            success: false,
            message: 'Phone number not registered. Please sign up first.',
            code: 'PHONE_NOT_REGISTERED'
          });
        }

        // Auto-create user account for existing customer
        const formattedPhone = phoneAuthService.formatPhoneNumber(phoneNumber);
        const customer = await database('customers')
          .where({ id: customerId })
          .first();

        if (customer) {
          // Create user account linked to customer
          const [user] = await database('users')
            .insert({
              email: customer.email || `${formattedPhone}@temp.isp`,
              first_name: customer.first_name,
              last_name: customer.last_name,
              phone: formattedPhone,
              role: 'customer',
              company_id: customer.company_id,
              status: 'active',
              created_at: new Date(),
              updated_at: new Date()
            })
            .returning('id');

          // Link customer to user
          await database('customers')
            .where({ id: customerId })
            .update({ user_id: user.id });

          logger.info('Auto-created user account for customer', {
            userId: user.id,
            customerId,
            phone: formattedPhone
          });
        }
      }
    }

    const result = await phoneAuthService.sendOTP(phoneNumber);

    res.json({
      success: result.success,
      message: result.message,
      ...(result.trackingId && { trackingId: result.trackingId })
    });
  })
);

/**
 * @route   POST /api/auth/phone/verify-otp
 * @desc    Verify OTP and login/register
 * @access  Public
 */
router.post('/phone/verify-otp',
  body('phoneNumber').isMobilePhone('any').withMessage('Valid phone number required'),
  body('otp').isLength({ min: 6, max: 6 }).isNumeric().withMessage('6-digit OTP required'),
  validate,
  asyncHandler(async (req, res) => {
    const { phoneNumber, otp, purpose = 'login' } = req.body;

    // Verify OTP
    const verifyResult = await phoneAuthService.verifyOTP(phoneNumber, otp);

    if (!verifyResult.success) {
      return res.status(400).json({
        success: false,
        message: verifyResult.message
      });
    }

    const formattedPhone = phoneAuthService.formatPhoneNumber(phoneNumber);

    // Find or create user
    let user = await database('users')
      .where({ phone: formattedPhone })
      .orWhere({ phone: phoneNumber })
      .first();

    // If registering and user exists
    if (purpose === 'register' && user) {
      return res.status(409).json({
        success: false,
        message: 'Phone number already registered. Please login instead.',
        code: 'PHONE_ALREADY_REGISTERED'
      });
    }

    // If logging in and user doesn't exist
    if (purpose === 'login' && !user) {
      return res.status(404).json({
        success: false,
        message: 'User not found. Please register first.',
        code: 'USER_NOT_FOUND'
      });
    }

    // Create new user if registering
    if (purpose === 'register' && !user) {
      const [newUser] = await database('users')
        .insert({
          phone: formattedPhone,
          email: req.body.email || `${formattedPhone}@temp.isp`,
          first_name: req.body.firstName || '',
          last_name: req.body.lastName || '',
          role: 'customer',
          status: 'active',
          created_at: new Date(),
          updated_at: new Date()
        })
        .returning(['id', 'email', 'first_name', 'last_name', 'phone', 'role', 'company_id', 'status']);

      user = newUser;

      logger.info('New user registered via phone OTP', {
        userId: user.id,
        phone: formattedPhone
      });
    }

    // Update last login
    await database('users')
      .where({ id: user.id })
      .update({
        last_login_at: new Date(),
        last_login_ip: req.ip,
        updated_at: new Date()
      });

    // Generate tokens
    const tokens = generateTokens({
      id: user.id,
      email: user.email,
      role: user.role,
      permissions: user.permissions || [],
      companyId: user.company_id
    });

    res.json({
      success: true,
      message: purpose === 'register' ? 'Registration successful' : 'Login successful',
      data: {
        user: {
          id: user.id,
          email: user.email,
          firstName: user.first_name,
          lastName: user.last_name,
          phone: user.phone,
          role: user.role,
          companyId: user.company_id,
          status: user.status
        },
        tokens
      }
    });
  })
);

// ============================================
// EMAIL/PASSWORD AUTHENTICATION
// ============================================

/**
 * @route   POST /api/auth/email/register
 * @desc    Register with email and password
 * @access  Public
 */
router.post('/email/register',
  body('email').isEmail().normalizeEmail().withMessage('Valid email required'),
  body('password').isLength({ min: 8 }).withMessage('Password must be at least 8 characters'),
  body('firstName').trim().notEmpty().withMessage('First name required'),
  body('lastName').trim().notEmpty().withMessage('Last name required'),
  body('phone').optional().isMobilePhone('any'),
  validate,
  asyncHandler(async (req, res) => {
    const result = await emailAuthService.register({
      email: req.body.email,
      password: req.body.password,
      firstName: req.body.firstName,
      lastName: req.body.lastName,
      phone: req.body.phone,
      role: req.body.role,
      companyId: req.body.companyId
    });

    if (!result.success) {
      return res.status(400).json({
        success: false,
        message: result.message
      });
    }

    res.status(201).json({
      success: true,
      message: 'Registration successful. Please verify your email.',
      data: {
        user: result.user
      }
    });
  })
);

/**
 * @route   POST /api/auth/email/login
 * @desc    Login with email and password
 * @access  Public
 */
router.post('/email/login',
  body('email').isEmail().normalizeEmail().withMessage('Valid email required'),
  body('password').notEmpty().withMessage('Password required'),
  validate,
  asyncHandler(async (req, res) => {
    const result = await emailAuthService.login(
      {
        email: req.body.email,
        password: req.body.password
      },
      req.ip,
      req.headers['user-agent']
    );

    if (!result.success) {
      return res.status(401).json({
        success: false,
        message: result.message
      });
    }

    res.json({
      success: true,
      message: 'Login successful',
      data: {
        user: result.user,
        tokens: result.tokens
      }
    });
  })
);

/**
 * @route   POST /api/auth/email/verify
 * @desc    Verify email address
 * @access  Public
 */
router.post('/email/verify',
  body('token').notEmpty().withMessage('Verification token required'),
  validate,
  asyncHandler(async (req, res) => {
    const result = await emailAuthService.verifyEmail(req.body.token);

    if (!result.success) {
      return res.status(400).json({
        success: false,
        message: result.message
      });
    }

    res.json({
      success: true,
      message: result.message
    });
  })
);

/**
 * @route   POST /api/auth/email/forgot-password
 * @desc    Request password reset
 * @access  Public
 */
router.post('/email/forgot-password',
  body('email').isEmail().normalizeEmail().withMessage('Valid email required'),
  validate,
  asyncHandler(async (req, res) => {
    const result = await emailAuthService.requestPasswordReset(req.body.email);

    // Always return success to prevent email enumeration
    res.json({
      success: true,
      message: 'If the email exists, a password reset link has been sent'
    });
  })
);

/**
 * @route   POST /api/auth/email/reset-password
 * @desc    Reset password with token
 * @access  Public
 */
router.post('/email/reset-password',
  body('token').notEmpty().withMessage('Reset token required'),
  body('newPassword').isLength({ min: 8 }).withMessage('Password must be at least 8 characters'),
  validate,
  asyncHandler(async (req, res) => {
    const result = await emailAuthService.resetPassword(
      req.body.token,
      req.body.newPassword
    );

    if (!result.success) {
      return res.status(400).json({
        success: false,
        message: result.message
      });
    }

    res.json({
      success: true,
      message: result.message
    });
  })
);

// ============================================
// GOOGLE OAUTH
// ============================================

/**
 * @route   GET /api/auth/google
 * @desc    Initiate Google OAuth login
 * @access  Public
 */
router.get('/google', asyncHandler(async (req, res) => {
  const state = await oauthService.generateState();
  
  // Store state with optional redirect URL
  await oauthService.storeState(state, {
    redirectUrl: req.query.redirect as string,
    companyId: req.query.companyId as string
  });

  const authUrl = oauthService.getGoogleAuthUrl(state);
  
  res.json({
    success: true,
    data: {
      authUrl
    }
  });
}));

/**
 * @route   GET /api/auth/google/callback
 * @desc    Google OAuth callback
 * @access  Public
 */
router.get('/google/callback', asyncHandler(async (req, res) => {
  const { code, state, error } = req.query;

  // Handle OAuth errors
  if (error) {
    logger.error('Google OAuth error:', error);
    return res.redirect(`${process.env.FRONTEND_URL}/auth/error?message=${encodeURIComponent(error as string)}`);
  }

  if (!code || !state) {
    return res.redirect(`${process.env.FRONTEND_URL}/auth/error?message=Invalid OAuth response`);
  }

  // Verify state
  const stateVerification = await oauthService.verifyState(state as string);
  if (!stateVerification.valid) {
    return res.redirect(`${process.env.FRONTEND_URL}/auth/error?message=Invalid state parameter`);
  }

  // Exchange code for tokens
  const tokenResult = await oauthService.exchangeCodeForTokens(code as string);
  if (!tokenResult.success) {
    return res.redirect(`${process.env.FRONTEND_URL}/auth/error?message=${encodeURIComponent(tokenResult.message || 'OAuth failed')}`);
  }

  // Get user profile
  const profileResult = await oauthService.getGoogleProfile(tokenResult.tokens!.access_token);
  if (!profileResult.success) {
    return res.redirect(`${process.env.FRONTEND_URL}/auth/error?message=${encodeURIComponent(profileResult.message || 'Failed to get profile')}`);
  }

  // Find or create user
  const userResult = await oauthService.findOrCreateUser(
    profileResult.profile!,
    stateVerification.data?.companyId
  );

  if (!userResult.success) {
    return res.redirect(`${process.env.FRONTEND_URL}/auth/error?message=${encodeURIComponent(userResult.message || 'Authentication failed')}`);
  }

  // Generate tokens
  const tokens = generateTokens({
    id: userResult.user!.id,
    email: userResult.user!.email,
    role: userResult.user!.role,
    permissions: userResult.user!.permissions || [],
    companyId: userResult.user!.companyId
  });

  // Redirect to frontend with tokens
  const redirectUrl = stateVerification.data?.redirectUrl || `${process.env.FRONTEND_URL}/auth/callback`;
  const tokenParam = encodeURIComponent(JSON.stringify({
    user: userResult.user,
    tokens
  }));

  res.redirect(`${redirectUrl}?data=${tokenParam}`);
}));

// ============================================
// TOKEN MANAGEMENT
// ============================================

/**
 * @route   POST /api/auth/refresh
 * @desc    Refresh access token
 * @access  Public (with refresh token)
 */
router.post('/refresh',
  body('refreshToken').notEmpty().withMessage('Refresh token required'),
  validate,
  asyncHandler(async (req, res) => {
    const result = await emailAuthService.refreshTokens(req.body.refreshToken);

    if (!result.success) {
      return res.status(401).json({
        success: false,
        message: result.message
      });
    }

    res.json({
      success: true,
      data: {
        tokens: result.tokens
      }
    });
  })
);

/**
 * @route   POST /api/auth/logout
 * @desc    Logout user
 * @access  Private
 */
router.post('/logout',
  authenticate,
  asyncHandler(async (req, res) => {
    await emailAuthService.logout(req.user!.id, req.body.refreshToken);

    res.json({
      success: true,
      message: 'Logged out successfully'
    });
  })
);

// ============================================
// USER PROFILE & SETTINGS
// ============================================

/**
 * @route   GET /api/auth/me
 * @desc    Get current user profile
 * @access  Private
 */
router.get('/me',
  authenticate,
  asyncHandler(async (req, res) => {
    const user = await database('users')
      .where({ id: req.user!.id })
      .select('id', 'email', 'first_name', 'last_name', 'phone', 'role', 'company_id', 'status', 'avatar_url', 'email_verified_at', 'oauth_provider', 'created_at')
      .first();

    if (!user) {
      throw new AppError('User not found', 404);
    }

    // Get linked OAuth providers
    const oauthProviders = await oauthService.getUserOAuthProviders(user.id);

    res.json({
      success: true,
      data: {
        user: {
          id: user.id,
          email: user.email,
          firstName: user.first_name,
          lastName: user.last_name,
          phone: user.phone,
          role: user.role,
          companyId: user.company_id,
          status: user.status,
          avatarUrl: user.avatar_url,
          emailVerified: !!user.email_verified_at,
          oauthProviders,
          createdAt: user.created_at
        }
      }
    });
  })
);

/**
 * @route   PUT /api/auth/me
 * @desc    Update current user profile
 * @access  Private
 */
router.put('/me',
  authenticate,
  body('firstName').optional().trim().notEmpty(),
  body('lastName').optional().trim().notEmpty(),
  body('phone').optional().isMobilePhone('any'),
  validate,
  asyncHandler(async (req, res) => {
    const updates: any = {
      updated_at: new Date()
    };

    if (req.body.firstName) updates.first_name = req.body.firstName;
    if (req.body.lastName) updates.last_name = req.body.lastName;
    if (req.body.phone) updates.phone = req.body.phone;

    const [user] = await database('users')
      .where({ id: req.user!.id })
      .update(updates)
      .returning(['id', 'email', 'first_name', 'last_name', 'phone', 'role', 'company_id', 'status', 'avatar_url']);

    res.json({
      success: true,
      message: 'Profile updated successfully',
      data: {
        user: {
          id: user.id,
          email: user.email,
          firstName: user.first_name,
          lastName: user.last_name,
          phone: user.phone,
          role: user.role,
          companyId: user.company_id,
          status: user.status,
          avatarUrl: user.avatar_url
        }
      }
    });
  })
);

/**
 * @route   PUT /api/auth/password
 * @desc    Change password
 * @access  Private
 */
router.put('/password',
  authenticate,
  body('currentPassword').notEmpty().withMessage('Current password required'),
  body('newPassword').isLength({ min: 8 }).withMessage('New password must be at least 8 characters'),
  validate,
  asyncHandler(async (req, res) => {
    // Get user with password
    const user = await database('users')
      .where({ id: req.user!.id })
      .first();

    if (!user) {
      throw new AppError('User not found', 404);
    }

    // Verify current password
    const isValid = await emailAuthService.comparePassword(
      req.body.currentPassword,
      user.password_hash
    );

    if (!isValid) {
      return res.status(400).json({
        success: false,
        message: 'Current password is incorrect'
      });
    }

    // Hash and update new password
    const newPasswordHash = await emailAuthService.hashPassword(req.body.newPassword);
    
    await database('users')
      .where({ id: req.user!.id })
      .update({
        password_hash: newPasswordHash,
        updated_at: new Date()
      });

    // Invalidate all refresh tokens
    await cache.del(`refresh:${req.user!.id}`);

    res.json({
      success: true,
      message: 'Password changed successfully. Please login again.'
    });
  })
);

/**
 * @route   POST /api/auth/unlink-oauth
 * @desc    Unlink OAuth provider
 * @access  Private
 */
router.post('/unlink-oauth',
  authenticate,
  body('provider').isIn(['google', 'microsoft', 'apple']).withMessage('Valid provider required'),
  validate,
  asyncHandler(async (req, res) => {
    const result = await oauthService.unlinkOAuth(req.user!.id, req.body.provider);

    if (!result.success) {
      return res.status(400).json({
        success: false,
        message: result.message
      });
    }

    res.json({
      success: true,
      message: result.message
    });
  })
);

// ============================================
// HEALTH CHECK
// ============================================

/**
 * @route   GET /api/auth/health
 * @desc    Auth service health check
 * @access  Public
 */
router.get('/health', (req, res) => {
  res.json({
    success: true,
    status: 'healthy',
    timestamp: new Date().toISOString()
  });
});

export default router;
