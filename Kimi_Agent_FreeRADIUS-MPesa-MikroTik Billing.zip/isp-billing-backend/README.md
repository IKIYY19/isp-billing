# ISP Billing System - Production Backend

A production-ready Node.js/Express backend for ISP Billing System with FreeRADIUS, M-Pesa, and MikroTik integration.

## Features

- **Authentication & Authorization**: JWT-based auth with role-based access control
- **Customer Management**: Complete customer lifecycle management
- **Billing & Invoicing**: Automated invoicing with multiple payment methods
- **M-Pesa Integration**: STK Push, C2B, B2C payments via Daraja API
- **FreeRADIUS Integration**: RADIUS authentication and accounting
- **MikroTik Integration**: Router management, PPPoE, Hotspot control
- **Network Monitoring**: Real-time router and user session monitoring
- **Queue Management**: Background job processing with Bull
- **Caching**: Redis-based caching for performance
- **Reporting**: Comprehensive analytics and reporting
- **API Documentation**: RESTful API with comprehensive endpoints

## Tech Stack

- **Runtime**: Node.js 20+
- **Framework**: Express.js
- **Language**: TypeScript
- **Database**: PostgreSQL 16
- **Cache**: Redis 7
- **Queue**: Bull (Redis-based)
- **WebSocket**: Socket.io
- **Testing**: Jest
- **Deployment**: Docker & Docker Compose

## Quick Start

### Prerequisites

- Docker & Docker Compose
- Domain name (for production)
- SSL certificate
- M-Pesa Daraja credentials

### Installation

```bash
# Clone repository
git clone https://your-repo.git
cd isp-billing-backend

# Copy environment file
cp .env.example .env
# Edit .env with your configuration

# Start services
docker-compose up -d

# Run migrations
docker-compose exec api npm run migrate

# Create admin user
docker-compose exec api node scripts/create-admin.js
```

### Development

```bash
# Install dependencies
npm install

# Run in development mode
npm run dev

# Run tests
npm test

# Build for production
npm run build
```

## Project Structure

```
isp-billing-backend/
├── src/
│   ├── config/          # Configuration files
│   │   ├── database.ts  # PostgreSQL connection
│   │   ├── redis.ts     # Redis connection
│   │   └── queue.ts     # Bull queue setup
│   ├── controllers/     # Request handlers
│   ├── middleware/      # Express middleware
│   │   ├── auth.ts      # Authentication
│   │   └── errorHandler.ts
│   ├── models/          # Database models
│   ├── routes/          # API routes
│   ├── services/        # Business logic
│   │   ├── mpesaService.ts
│   │   ├── mikrotikService.ts
│   │   └── radiusService.ts
│   ├── utils/           # Utilities
│   │   └── logger.ts    # Winston logger
│   └── server.ts        # Entry point
├── migrations/          # Database migrations
├── docs/                # Documentation
├── nginx/               # Nginx configuration
├── docker-compose.yml   # Docker orchestration
├── Dockerfile           # API container
└── package.json
```

## API Endpoints

### Authentication
- `POST /api/auth/login` - User login
- `POST /api/auth/register` - User registration
- `POST /api/auth/refresh` - Refresh token
- `POST /api/auth/logout` - Logout

### Customers
- `GET /api/customers` - List customers
- `POST /api/customers` - Create customer
- `GET /api/customers/:id` - Get customer details
- `PUT /api/customers/:id` - Update customer
- `DELETE /api/customers/:id` - Delete customer

### Billing
- `GET /api/invoices` - List invoices
- `POST /api/invoices` - Create invoice
- `GET /api/invoices/:id` - Get invoice
- `PUT /api/invoices/:id/pay` - Record payment

### Payments
- `POST /api/mpesa/stkpush` - Initiate STK Push
- `POST /api/mpesa/callback` - M-Pesa callback
- `POST /api/mpesa/c2b/confirm` - C2B confirmation

### Network
- `GET /api/routers` - List routers
- `GET /api/routers/:id` - Router details
- `POST /api/mikrotik/sync-user` - Sync user to router
- `GET /api/network/sessions` - Active sessions

### Reports
- `GET /api/reports/revenue` - Revenue report
- `GET /api/reports/customers` - Customer report
- `GET /api/reports/usage` - Usage report

## Environment Variables

See `.env.example` for complete list of environment variables.

### Required
- `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASSWORD`
- `REDIS_HOST`, `REDIS_PORT`
- `JWT_SECRET`
- `MPESA_CONSUMER_KEY`, `MPESA_CONSUMER_SECRET`, `MPESA_SHORTCODE`, `MPESA_PASSKEY`

### Optional
- `SMTP_*` - Email configuration
- `SMS_*` - SMS gateway
- `BACKUP_*` - Backup settings

## Database Schema

The system uses PostgreSQL with the following main tables:

- `companies` - Multi-tenant support
- `users` - System users
- `customers` - ISP customers
- `plans` - Internet plans/packages
- `invoices` - Customer invoices
- `payments` - Payment records
- `routers` - MikroTik routers
- `radius_*` - FreeRADIUS tables
- `audit_logs` - Activity tracking

## Background Jobs

Scheduled tasks via node-cron:

| Job | Schedule | Description |
|-----|----------|-------------|
| Invoice Generation | Monthly 1st | Generate recurring invoices |
| Payment Reminders | Daily 9:00 | Send overdue reminders |
| Account Suspension | Daily 00:30 | Suspend expired accounts |
| Usage Sync | Every 5 min | Sync RADIUS usage data |
| Backup | Daily 02:00 | Database backup |
| FUP Check | Hourly | Fair usage policy enforcement |

## Monitoring

### Health Check
```bash
curl https://your-domain.com/health
```

### Metrics (Prometheus)
```
http://your-domain.com:9090
```

### Dashboards (Grafana)
```
http://your-domain.com:3000
```

## Security

- JWT authentication with refresh tokens
- Role-based access control (RBAC)
- API rate limiting
- SQL injection protection
- XSS protection
- CORS configuration
- Helmet security headers
- Input validation

## Backup & Recovery

### Automated Backup
```bash
# Daily backup at 02:00
docker-compose exec api node dist/jobs/backup.js
```

### Manual Backup
```bash
# Database dump
docker-compose exec postgres pg_dump -U postgres isp_billing > backup.sql
```

### Restore
```bash
# Restore database
cat backup.sql | docker-compose exec -T postgres psql -U postgres isp_billing
```

## Troubleshooting

### View Logs
```bash
# All services
docker-compose logs -f

# Specific service
docker-compose logs -f api

# Last 100 lines
docker-compose logs --tail 100 api
```

### Restart Services
```bash
docker-compose restart api
docker-compose restart worker
```

### Database Issues
```bash
# Connect to database
docker-compose exec postgres psql -U postgres isp_billing

# Reset (CAUTION: Data loss!)
docker-compose down -v
```

## Contributing

1. Fork the repository
2. Create feature branch: `git checkout -b feature-name`
3. Commit changes: `git commit -am 'Add feature'`
4. Push to branch: `git push origin feature-name`
5. Submit pull request

## License

MIT License - see LICENSE file

## Support

- Documentation: /docs folder
- Issues: GitHub Issues
- Email: support@your-isp.com

## Roadmap

- [ ] GraphQL API
- [ ] Mobile app API
- [ ] Multi-currency support
- [ ] Advanced analytics
- [ ] Customer portal
- [ ] API webhooks
