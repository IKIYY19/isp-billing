# MikroTik RouterOS Integration Guide

## Overview

MikroTik RouterOS integration enables:
- **PPPoE Server Management**
- **Hotspot Configuration**
- **Bandwidth Control**
- **User Session Monitoring**
- **Queue Management**
- **Firewall Automation**

## Architecture

```
┌─────────────────┐     ┌──────────────┐     ┌─────────────────┐
│   ISP Billing   │────▶│  RouterOS    │────▶│   Customer      │
│     System      │◀────│   API        │◀────│   Devices       │
└─────────────────┘     └──────────────┘     └─────────────────┘
                              │
                              ▼
                       ┌──────────────┐
                       │  FreeRADIUS  │
                       └──────────────┘
```

## RouterOS API Service

```typescript
// src/services/mikrotikService.ts
import { Client } from 'ssh2';
import { logger } from '../utils/logger';
import { cache } from '../config/redis';

export interface RouterConfig {
  id: string;
  name: string;
  ipAddress: string;
  apiPort: number;
  username: string;
  password: string;
}

export interface PPPoEUser {
  name: string;
  password: string;
  profile: string;
  service?: string;
  callerId?: string;
  ipAddress?: string;
}

export interface QueueConfig {
  name: string;
  target: string;
  maxLimit: string;
  burstLimit?: string;
  burstThreshold?: string;
  burstTime?: string;
  priority?: number;
}

export class MikrotikService {
  private async executeCommand(
    router: RouterConfig,
    command: string
  ): Promise<any> {
    const cacheKey = `mikrotik:${router.id}:${Buffer.from(command).toString('base64')}`;
    
    // Check cache for read operations
    if (command.startsWith('/')) {
      const cached = await cache.get(cacheKey);
      if (cached) return cached;
    }

    return new Promise((resolve, reject) => {
      const conn = new Client();
      const results: any[] = [];

      conn.on('ready', () => {
        conn.exec(command, (err, stream) => {
          if (err) {
            conn.end();
            return reject(err);
          }

          let output = '';
          stream.on('close', (code: number) => {
            conn.end();
            if (code !== 0) {
              reject(new Error(`Command failed with code ${code}: ${output}`));
            } else {
              try {
                const parsed = JSON.parse(output || '[]');
                // Cache read operations
                if (command.startsWith('/')) {
                  cache.set(cacheKey, parsed, 60);
                }
                resolve(parsed);
              } catch {
                resolve(output);
              }
            }
          }).on('data', (data: Buffer) => {
            output += data.toString();
          }).stderr.on('data', (data) => {
            logger.error('MikroTik stderr:', data.toString());
          });
        });
      }).on('error', (err) => {
        reject(new Error(`SSH connection failed: ${err.message}`));
      }).connect({
        host: router.ipAddress,
        port: router.apiPort || 22,
        username: router.username,
        password: router.password,
        readyTimeout: 10000
      });
    });
  }

  // API-REST method (RouterOS v7+)
  async apiRequest(
    router: RouterConfig,
    endpoint: string,
    method: string = 'GET',
    data?: any
  ): Promise<any> {
    const axios = require('axios');
    const https = require('https');

    const url = `https://${router.ipAddress}/rest${endpoint}`;
    
    try {
      const response = await axios({
        method,
        url,
        auth: {
          username: router.username,
          password: router.password
        },
        data,
        httpsAgent: new https.Agent({
          rejectUnauthorized: false // For self-signed certs
        }),
        timeout: 10000
      });

      return response.data;
    } catch (error: any) {
      logger.error('MikroTik API request failed:', {
        router: router.name,
        endpoint,
        error: error.message
      });
      throw error;
    }
  }

  // ==================== PPPoE Management ====================

  async getPPPoESecrets(router: RouterConfig): Promise<any[]> {
    return this.apiRequest(router, '/ppp/secret');
  }

  async addPPPoEUser(router: RouterConfig, user: PPPoEUser): Promise<any> {
    const data = {
      name: user.name,
      password: user.password,
      profile: user.profile,
      service: user.service || 'pppoe',
      'caller-id': user.callerId || '',
      'remote-address': user.ipAddress || '',
      disabled: 'false'
    };

    return this.apiRequest(router, '/ppp/secret', 'PUT', data);
  }

  async updatePPPoEUser(
    router: RouterConfig,
    userId: string,
    updates: Partial<PPPoEUser>
  ): Promise<any> {
    const data: any = {};
    if (updates.password) data.password = updates.password;
    if (updates.profile) data.profile = updates.profile;
    if (updates.callerId) data['caller-id'] = updates.callerId;
    if (updates.ipAddress) data['remote-address'] = updates.ipAddress;

    return this.apiRequest(router, `/ppp/secret/${userId}`, 'PATCH', data);
  }

  async removePPPoEUser(router: RouterConfig, userId: string): Promise<any> {
    return this.apiRequest(router, `/ppp/secret/${userId}`, 'DELETE');
  }

  async disablePPPoEUser(router: RouterConfig, userId: string): Promise<any> {
    return this.apiRequest(
      router,
      `/ppp/secret/${userId}`,
      'PATCH',
      { disabled: 'true' }
    );
  }

  async enablePPPoEUser(router: RouterConfig, userId: string): Promise<any> {
    return this.apiRequest(
      router,
      `/ppp/secret/${userId}`,
      'PATCH',
      { disabled: 'false' }
    );
  }

  async getPPPoEActive(router: RouterConfig): Promise<any[]> {
    return this.apiRequest(router, '/ppp/active');
  }

  async disconnectPPPoEUser(router: RouterConfig, activeId: string): Promise<any> {
    return this.apiRequest(router, `/ppp/active/${activeId}`, 'DELETE');
  }

  // ==================== Hotspot Management ====================

  async getHotspotUsers(router: RouterConfig): Promise<any[]> {
    return this.apiRequest(router, '/ip/hotspot/user');
  }

  async addHotspotUser(
    router: RouterConfig,
    user: {
      name: string;
      password: string;
      profile?: string;
      limitUptime?: string;
      limitBytesTotal?: string;
    }
  ): Promise<any> {
    const data: any = {
      name: user.name,
      password: user.password,
      profile: user.profile || 'default',
      disabled: 'false'
    };

    if (user.limitUptime) data['limit-uptime'] = user.limitUptime;
    if (user.limitBytesTotal) data['limit-bytes-total'] = user.limitBytesTotal;

    return this.apiRequest(router, '/ip/hotspot/user', 'PUT', data);
  }

  async removeHotspotUser(router: RouterConfig, userId: string): Promise<any> {
    return this.apiRequest(router, `/ip/hotspot/user/${userId}`, 'DELETE');
  }

  async getHotspotActive(router: RouterConfig): Promise<any[]> {
    return this.apiRequest(router, '/ip/hotspot/active');
  }

  async disconnectHotspotUser(router: RouterConfig, activeId: string): Promise<any> {
    return this.apiRequest(router, `/ip/hotspot/active/${activeId}`, 'DELETE');
  }

  // ==================== Queue Management ====================

  async getQueues(router: RouterConfig): Promise<any[]> {
    return this.apiRequest(router, '/queue/simple');
  }

  async addQueue(router: RouterConfig, queue: QueueConfig): Promise<any> {
    const data: any = {
      name: queue.name,
      target: queue.target,
      'max-limit': queue.maxLimit
    };

    if (queue.burstLimit) data['burst-limit'] = queue.burstLimit;
    if (queue.burstThreshold) data['burst-threshold'] = queue.burstThreshold;
    if (queue.burstTime) data['burst-time'] = queue.burstTime;
    if (queue.priority) data.priority = queue.priority.toString();

    return this.apiRequest(router, '/queue/simple', 'PUT', data);
  }

  async updateQueue(
    router: RouterConfig,
    queueId: string,
    updates: Partial<QueueConfig>
  ): Promise<any> {
    const data: any = {};
    if (updates.maxLimit) data['max-limit'] = updates.maxLimit;
    if (updates.burstLimit) data['burst-limit'] = updates.burstLimit;
    if (updates.burstThreshold) data['burst-threshold'] = updates.burstThreshold;
    if (updates.priority) data.priority = updates.priority.toString();

    return this.apiRequest(router, `/queue/simple/${queueId}`, 'PATCH', data);
  }

  async removeQueue(router: RouterConfig, queueId: string): Promise<any> {
    return this.apiRequest(router, `/queue/simple/${queueId}`, 'DELETE');
  }

  // ==================== Bandwidth Profiles ====================

  async getPPPProfiles(router: RouterConfig): Promise<any[]> {
    return this.apiRequest(router, '/ppp/profile');
  }

  async addPPPProfile(
    router: RouterConfig,
    profile: {
      name: string;
      rateLimit?: string;
      localAddress?: string;
      remoteAddress?: string;
      dnsServer?: string;
    }
  ): Promise<any> {
    const data: any = {
      name: profile.name
    };

    if (profile.rateLimit) data['rate-limit'] = profile.rateLimit;
    if (profile.localAddress) data['local-address'] = profile.localAddress;
    if (profile.remoteAddress) data['remote-address'] = profile.remoteAddress;
    if (profile.dnsServer) data['dns-server'] = profile.dnsServer;

    return this.apiRequest(router, '/ppp/profile', 'PUT', data);
  }

  // ==================== System Monitoring ====================

  async getSystemResources(router: RouterConfig): Promise<any> {
    return this.apiRequest(router, '/system/resource');
  }

  async getSystemHealth(router: RouterConfig): Promise<any> {
    return this.apiRequest(router, '/system/health');
  }

  async getInterfaces(router: RouterConfig): Promise<any[]> {
    return this.apiRequest(router, '/interface');
  }

  async getInterfaceStats(router: RouterConfig, interfaceId: string): Promise<any> {
    return this.apiRequest(router, `/interface/${interfaceId}`);
  }

  async getIPAddress(router: RouterConfig): Promise<any[]> {
    return this.apiRequest(router, '/ip/address');
  }

  async getRoutes(router: RouterConfig): Promise<any[]> {
    return this.apiRequest(router, '/ip/route');
  }

  async getDHCPLeases(router: RouterConfig): Promise<any[]> {
    return this.apiRequest(router, '/ip/dhcp-server/lease');
  }

  async getARPTable(router: RouterConfig): Promise<any[]> {
    return this.apiRequest(router, '/ip/arp');
  }

  async getFirewallConnections(router: RouterConfig): Promise<any[]> {
    return this.apiRequest(router, '/ip/firewall/connection');
  }

  // ==================== Traffic Monitoring ====================

  async getTrafficData(
    router: RouterConfig,
    interfaceName: string,
    duration: number = 60
  ): Promise<any> {
    const command = `/interface/monitor-traffic interface=${interfaceName} once`;
    return this.executeCommand(router, command);
  }

  async getQueueStats(router: RouterConfig): Promise<any[]> {
    return this.apiRequest(router, '/queue/simple/stats');
  }

  // ==================== User Session Management ====================

  async getUserSession(router: RouterConfig, username: string): Promise<any> {
    const active = await this.getPPPoEActive(router);
    return active.find((session: any) => session.name === username);
  }

  async getUserBandwidthUsage(
    router: RouterConfig,
    username: string
  ): Promise<{ rx: number; tx: number }> {
    const session = await this.getUserSession(router, username);
    
    if (!session) {
      return { rx: 0, tx: 0 };
    }

    return {
      rx: parseInt(session['rx-byte']) || 0,
      tx: parseInt(session['tx-byte']) || 0
    };
  }

  // ==================== Bulk Operations ====================

  async syncUsers(
    router: RouterConfig,
    users: Array<{ username: string; password: string; profile: string }>
  ): Promise<{ added: number; updated: number; removed: number }> {
    const existing = await this.getPPPoESecrets(router);
    const existingMap = new Map(existing.map((u: any) => [u.name, u]));
    
    let added = 0;
    let updated = 0;
    let removed = 0;

    // Add or update users
    for (const user of users) {
      const existing = existingMap.get(user.username);
      
      if (!existing) {
        await this.addPPPoEUser(router, {
          name: user.username,
          password: user.password,
          profile: user.profile
        });
        added++;
      } else if (existing.profile !== user.profile) {
        await this.updatePPPoEUser(router, existing['.id'], {
          profile: user.profile
        });
        updated++;
      }
      
      existingMap.delete(user.username);
    }

    // Remove users not in the list
    for (const [username, user] of existingMap) {
      await this.removePPPoEUser(router, user['.id']);
      removed++;
    }

    return { added, updated, removed };
  }

  // ==================== Router Health Check ====================

  async checkHealth(router: RouterConfig): Promise<{
    online: boolean;
    latency?: number;
    version?: string;
    uptime?: string;
    cpuLoad?: number;
    freeMemory?: number;
    totalMemory?: number;
  }> {
    const startTime = Date.now();
    
    try {
      const resources = await this.getSystemResources(router);
      const latency = Date.now() - startTime;

      return {
        online: true,
        latency,
        version: resources.version,
        uptime: resources.uptime,
        cpuLoad: parseFloat(resources['cpu-load']),
        freeMemory: parseInt(resources['free-memory']),
        totalMemory: parseInt(resources['total-memory'])
      };
    } catch (error) {
      logger.error('Router health check failed', {
        router: router.name,
        error: (error as Error).message
      });

      return {
        online: false
      };
    }
  }
}

export const mikrotikService = new MikrotikService();
```

## Router Configuration

### Enable API-REST (RouterOS v7+)

```bash
# Enable REST API
/ip service enable rest

# Set API port (default 443)
/ip service set rest port=443

# Configure SSL certificate
/certificate import file-name=certificate.crt
/certificate import file-name=private.key

# Assign certificate to API
/ip service set rest certificate=your-cert

# Restrict API access by IP
/ip service set rest address=192.168.1.0/24,10.0.0.0/8
```

### PPPoE Server Setup

```bash
# Create IP pool
/ip pool add name=pppoe-pool ranges=10.0.0.2-10.0.0.254

# Create PPP profile
/ppp profile add name="5Mbps" local-address=10.0.0.1 remote-address=pppoe-pool rate-limit=5M/5M dns-server=8.8.8.8,8.8.4.4
/ppp profile add name="10Mbps" local-address=10.0.0.1 remote-address=pppoe-pool rate-limit=10M/10M dns-server=8.8.8.8,8.8.4.4
/ppp profile add name="20Mbps" local-address=10.0.0.1 remote-address=pppoe-pool rate-limit=20M/20M dns-server=8.8.8.8,8.8.4.4

# Configure PPPoE server
/interface pppoe-server server add service-name="ISP-Internet" interface=ether2 max-mtu=1480 max-mru=1480 authentication=pap,chap,mschap1,mschap2 profile=default one-session-per-host=yes max-sessions=0 disabled=no

# Enable RADIUS
/radius add service=ppp address=radius-server-ip secret=shared-secret authentication-port=1812 accounting-port=1813
/ppp aaa set use-radius=yes accounting=yes interim-update=5m
```

### Hotspot Setup

```bash
# Create hotspot profile
/ip hotspot profile add name="hotspot1" hotspot-address=10.5.50.1 dns-name=login.isp.com smtp-server=0.0.0.0 login-by=http-chap,trial radius-accounting=yes radius-interim-update=5m

# Setup hotspot on interface
/ip hotspot add name=hotspot1 interface=ether3 profile=hotspot1 addresses-per-mac=2 idle-timeout=5m keepalive-timeout=15m

# Add RADIUS
/radius add service=hotspot address=radius-server-ip secret=shared-secret
/ip hotspot profile set [find name=hotspot1] use-radius=yes
```

## API Routes

```typescript
// src/routes/mikrotik.ts
import { Router } from 'express';
import { mikrotikService } from '../services/mikrotikService';
import { database } from '../config/database';
import { authenticate, authorize } from '../middleware/auth';

const router = Router();

// Get all routers
router.get('/routers', authenticate, async (req, res, next) => {
  try {
    const routers = await database('routers')
      .where({ company_id: req.user!.companyId, is_active: true })
      .select('id', 'name', 'ip_address', 'model', 'status', 'last_seen_at');

    res.json({ success: true, data: routers });
  } catch (error) {
    next(error);
  }
});

// Get router details
router.get('/routers/:id', authenticate, async (req, res, next) => {
  try {
    const router = await database('routers')
      .where({ id: req.params.id, company_id: req.user!.companyId })
      .first();

    if (!router) {
      return res.status(404).json({ success: false, message: 'Router not found' });
    }

    // Get real-time stats
    const health = await mikrotikService.checkHealth(router);
    const interfaces = await mikrotikService.getInterfaces(router);

    res.json({
      success: true,
      data: {
        ...router,
        health,
        interfaces
      }
    });
  } catch (error) {
    next(error);
  }
});

// Sync customer to router
router.post('/sync-user', authenticate, async (req, res, next) => {
  try {
    const { customerId, routerId } = req.body;

    const customer = await database('customers')
      .where({ id: customerId, company_id: req.user!.companyId })
      .first();

    if (!customer) {
      return res.status(404).json({ success: false, message: 'Customer not found' });
    }

    const router = await database('routers')
      .where({ id: routerId, company_id: req.user!.companyId })
      .first();

    if (!router) {
      return res.status(404).json({ success: false, message: 'Router not found' });
    }

    // Get credentials
    const credentials = await database('customer_credentials')
      .where({ customer_id: customerId, type: 'pppoe' })
      .first();

    if (!credentials) {
      return res.status(400).json({ success: false, message: 'No PPPoE credentials found' });
    }

    // Get plan profile
    const plan = await database('plans')
      .where({ id: customer.plan_id })
      .first();

    // Add/update user on router
    const result = await mikrotikService.addPPPoEUser(router, {
      name: credentials.username,
      password: credentials.password_hash, // Should decrypt or use plaintext
      profile: plan?.profile_name || 'default'
    });

    res.json({ success: true, data: result });
  } catch (error) {
    next(error);
  }
});

// Get active sessions
router.get('/sessions/:routerId', authenticate, async (req, res, next) => {
  try {
    const router = await database('routers')
      .where({ id: req.params.routerId, company_id: req.user!.companyId })
      .first();

    if (!router) {
      return res.status(404).json({ success: false, message: 'Router not found' });
    }

    const [pppoeActive, hotspotActive] = await Promise.all([
      mikrotikService.getPPPoEActive(router),
      mikrotikService.getHotspotActive(router)
    ]);

    res.json({
      success: true,
      data: {
        pppoe: pppoeActive,
        hotspot: hotspotActive,
        total: pppoeActive.length + hotspotActive.length
      }
    });
  } catch (error) {
    next(error);
  }
});

// Disconnect user
router.post('/disconnect', authenticate, authorize('admin', 'technician'), async (req, res, next) => {
  try {
    const { routerId, sessionId, type } = req.body;

    const router = await database('routers')
      .where({ id: routerId, company_id: req.user!.companyId })
      .first();

    if (!router) {
      return res.status(404).json({ success: false, message: 'Router not found' });
    }

    if (type === 'pppoe') {
      await mikrotikService.disconnectPPPoEUser(router, sessionId);
    } else {
      await mikrotikService.disconnectHotspotUser(router, sessionId);
    }

    res.json({ success: true, message: 'User disconnected' });
  } catch (error) {
    next(error);
  }
});

export default router;
```

## Troubleshooting

### Common Issues

1. **Connection Refused**
   - Verify API service is enabled: `/ip service print`
   - Check firewall rules: `/ip firewall filter print`
   - Verify port: `/ip service print where name=rest`

2. **Authentication Failed**
   - Check credentials
   - Verify user has API permissions
   - Check `/user print` for active users

3. **SSL Certificate Errors**
   - Import valid certificate
   - Use `rejectUnauthorized: false` for testing only

4. **Rate Limiting**
   - Implement request caching
   - Use connection pooling
   - Add retry logic with exponential backoff

### Debug Commands

```bash
# Check API connections
/ip service print

# Monitor API requests
/log print where topics~"api"

# Check active connections
/ip firewall connection print

# Monitor PPPoE
/ppp active print
/log print where topics~"ppp"
```
