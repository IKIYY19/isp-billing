# FreeRADIUS Integration Guide

## Overview

FreeRADIUS is the most popular open-source RADIUS server, providing authentication, authorization, and accounting (AAA) services for network access.

## Architecture

```
┌─────────────┐     ┌──────────────┐     ┌─────────────┐
│   Client    │────▶│  FreeRADIUS  │────▶│  PostgreSQL │
│  (Router)   │◀────│   Server     │◀────│   Database  │
└─────────────┘     └──────────────┘     └─────────────┘
                           │
                           ▼
                    ┌──────────────┐
                    │ ISP Billing  │
                    │     API      │
                    └──────────────┘
```

## Installation

### Option 1: Docker (Recommended)

```bash
# Start with FreeRADIUS
docker-compose --profile with-radius up -d
```

### Option 2: Manual Installation (Ubuntu/Debian)

```bash
# Install FreeRADIUS and PostgreSQL modules
sudo apt-get update
sudo apt-get install -y freeradius freeradius-postgresql freeradius-utils

# Enable and start service
sudo systemctl enable freeradius
sudo systemctl start freeradius

# Verify installation
sudo freeradius -v
radtest username password localhost 0 testing123
```

## Configuration

### 1. Database Configuration

Edit `/etc/freeradius/3.0/mods-available/sql`:

```sql
sql {
    driver = "rlm_sql_postgresql"
    dialect = "postgresql"
    
    server = "localhost"
    port = 5432
    login = "radius"
    password = "radius_password"
    radius_db = "isp_billing"
    
    # Connection pooling
    pool {
        start = 5
        min = 5
        max = 32
        spare = 3
        uses = 0
        lifetime = 0
        cleanup_interval = 30
        idle_timeout = 60
        retry_delay = 30
    }
    
    # Table names (matching our schema)
    acct_table1 = "radius_accounting"
    acct_table2 = "radius_accounting"
    postauth_table = "radius_postauth"
    authcheck_table = "radius_users"
    authreply_table = "radius_reply"
    groupcheck_table = "radius_groups"
    groupreply_table = "radius_groups"
    usergroup_table = "radius_user_group"
    
    # Read clients from database
    read_clients = yes
    client_table = "radius_nas"
    
    # Group membership
    group_attribute = "SQL-Group"
    
    # Allow multiple groups per user
    allow_multiple_groups = yes
}
```

Enable the module:
```bash
sudo ln -s /etc/freeradius/3.0/mods-available/sql /etc/freeradius/3.0/mods-enabled/sql
```

### 2. Site Configuration

Edit `/etc/freeradius/3.0/sites-enabled/default`:

```
server default {
    listen {
        type = auth
        ipaddr = *
        port = 1812
    }
    
    listen {
        type = acct
        ipaddr = *
        port = 1813
    }
    
    authorize {
        # Preprocess the request
        preprocess
        
        # Filter by NAS
        filter_username
        
        # Check against SQL database
        sql
        
        # Check user groups
        group {
            sql
        }
        
        # Apply bandwidth limits
        if (control:Pool-Name) {
            update reply {
                Framed-Pool := control:Pool-Name
            }
        }
        
        # MikroTik specific attributes
        if (NAS-Identifier =~ /mikrotik/i) {
            update reply {
                Mikrotik-Group := control:Group-Name
            }
        }
        
        pap
    }
    
    authenticate {
        Auth-Type PAP {
            pap
        }
    }
    
    post-auth {
        # Log to SQL
        sql
        
        # Post-auth logging
        Post-Auth-Type Challenge {
        }
        
        # Insert post-auth record
        sql
        
        # Update online status in billing system
        if (success) {
            update reply {
                Reply-Message := "Welcome to ISP Network"
            }
        }
    }
    
    accounting {
        # Detailed accounting
        sql
        
        # Update usage in billing system
        if (Acct-Status-Type == "Stop") {
            # Trigger usage sync
        }
    }
    
    session {
        sql
    }
    
    post-auth {
        sql
    }
    
    pre-proxy {
    }
    
    post-proxy {
    }
}
```

### 3. Client Configuration (NAS)

Edit `/etc/freeradius/3.0/clients.conf` or use database:

```
client router_mikrotik_1 {
    ipaddr = 192.168.1.1
    secret = shared_secret_key
    shortname = mikrotik_main
    nas_type = mikrotik
    limit {
        max_connections = 16
        lifetime = 0
        idle_timeout = 30
    }
}
```

## MikroTik Router Configuration

### PPPoE Server Setup

```bash
# Create PPPoE profile
/ppp profile
add name="5Mbps-Plan" local-address=10.0.0.1 remote-address=pppoe-pool \
    rate-limit=5M/5M dns-server=8.8.8.8,8.8.4.4

# Configure PPPoE server
/interface pppoe-server server
add service-name="ISP-Internet" interface=ether2 max-mtu=1480 max-mru=1480 \
    authentication=pap,chap,mschap1,mschap2 profile=5Mbps-Plan \
    one-session-per-host=yes max-sessions=0

# Enable RADIUS
/radius
add service=ppp address=radius_server_ip secret=shared_secret_key \
    authentication-port=1812 accounting-port=1813 timeout=5s

# Configure RADIUS settings
/radius incoming
set accept=yes port=1700

# Enable accounting
/ppp aaa
set use-radius=yes accounting=yes interim-update=5m
```

### Hotspot Configuration

```bash
# Create hotspot profile
/ip hotspot profile
add name="hotspot-radius" hotspot-address=10.5.50.1 dns-name=login.isp.com \
    smtp-server=0.0.0.0 login-by=http-chap,trial \
    radius-accounting=yes radius-interim-update=5m \
    radius-default-group=read-only

# Configure hotspot
/ip hotspot
add name=hotspot1 interface=ether3 profile=hotspot-radius addresses-per-mac=2 \
    idle-timeout=5m keepalive-timeout=15m

# Enable RADIUS for hotspot
/ip hotspot profile set [find name=hotspot-radius] use-radius=yes

# Add RADIUS server
/radius
add service=hotspot address=radius_server_ip secret=shared_secret_key \
    authentication-port=1812 accounting-port=1813
```

## RADIUS Attributes Reference

### Standard Attributes

| Attribute | Type | Description |
|-----------|------|-------------|
| User-Name | string | Username |
| User-Password | string | Password |
| Framed-IP-Address | ipaddr | Assigned IP |
| Framed-Pool | string | IP Pool name |
| Session-Timeout | integer | Session limit (seconds) |
| Idle-Timeout | integer | Idle timeout (seconds) |
| Acct-Input-Octets | integer | Bytes received |
| Acct-Output-Octets | integer | Bytes sent |

### MikroTik Vendor-Specific Attributes (VSA)

| Attribute | Type | Description |
|-----------|------|-------------|
| Mikrotik-Recv-Limit | integer | Total receive limit |
| Mikrotik-Xmit-Limit | integer | Total transmit limit |
| Mikrotik-Rate-Limit | string | Speed limit (e.g., "5M/5M") |
| Mikrotik-Group | string | User group |
| Mikrotik-Advertise-URL | string | Redirect URL |
| Mikrotik-Mark-Id | string | Firewall mark |

## Bandwidth Profiles Examples

```sql
-- 5 Mbps Plan
INSERT INTO radius_groups (groupname, attribute, op, value, priority)
VALUES 
('plan_5mbps', 'Mikrotik-Rate-Limit', ':=', '5M/5M', 1),
('plan_5mbps', 'Session-Timeout', ':=', '86400', 2),
('plan_5mbps', 'Idle-Timeout', ':=', '900', 3);

-- 10 Mbps Plan with 20M burst
INSERT INTO radius_groups (groupname, attribute, op, value, priority)
VALUES 
('plan_10mbps', 'Mikrotik-Rate-Limit', ':=', '10M/10M 20M/20M 10M/10M 60/60', 1),
('plan_10mbps', 'Session-Timeout', ':=', '86400', 2);

-- Unlimited Night Plan (7PM - 7AM)
INSERT INTO radius_groups (groupname, attribute, op, value, priority)
VALUES 
('plan_night_unlimited', 'Mikrotik-Rate-Limit', ':=', '100M/100M', 1);
```

## Troubleshooting

### Check RADIUS Logs

```bash
# Enable debug mode
sudo freeradius -X

# Check logs
sudo tail -f /var/log/freeradius/radius.log

# Test authentication
radtest username password localhost 0 testing123
```

### Common Issues

1. **Authentication Failures**
   ```bash
   # Check SQL connection
   sudo radiusd -C
   
   # Verify user exists
   sudo radsqlrelay -x -b postgresql -h localhost -u radius -p radius_password isp_billing
   ```

2. **Accounting Not Working**
   - Verify accounting port (1813) is open
   - Check SQL table permissions
   - Ensure `acctuniqueid` is unique

3. **Bandwidth Limits Not Applied**
   - Verify MikroTik-Rate-Limit format
   - Check profile exists on router
   - Ensure RADIUS returns attributes

### Performance Tuning

```sql
-- Add indexes for better performance
CREATE INDEX idx_radius_accounting_username ON radius_accounting(username);
CREATE INDEX idx_radius_accounting_dates ON radius_accounting(acctstarttime, acctstoptime);
CREATE INDEX idx_radius_users_username ON radius_users(username);

-- Partition accounting table (for large deployments)
CREATE TABLE radius_accounting_y2024m01 PARTITION OF radius_accounting
    FOR VALUES FROM ('2024-01-01') TO ('2024-02-01');
```

## Security Best Practices

1. **Use strong shared secrets** (minimum 32 characters)
2. **Enable IP whitelisting** for NAS devices
3. **Use TLS for RADIUS** (RadSec) when possible
4. **Regularly rotate secrets**
5. **Monitor failed authentication attempts**
6. **Implement rate limiting** on authentication endpoints

## Monitoring

```bash
# Check active sessions
radwho

# Show server statistics
radclient -x localhost status testing123

# Monitor in real-time
sudo tail -f /var/log/freeradius/radius.log | grep -E "(Login OK|Login incorrect)"
```
