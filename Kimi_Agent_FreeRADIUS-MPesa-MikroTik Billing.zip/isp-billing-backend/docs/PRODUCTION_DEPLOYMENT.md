# Production Deployment Guide

## Pre-Deployment Checklist

### Infrastructure Requirements

| Component | Minimum | Recommended |
|-----------|---------|-------------|
| CPU | 2 cores | 4+ cores |
| RAM | 4 GB | 8+ GB |
| Storage | 50 GB SSD | 100+ GB SSD |
| Network | 100 Mbps | 1 Gbps |
| OS | Ubuntu 22.04 LTS | Ubuntu 22.04 LTS |

### Domain & SSL

- [ ] Purchase domain name
- [ ] Configure DNS A records
- [ ] Obtain SSL certificate (Let's Encrypt)
- [ ] Configure reverse DNS

### External Services

- [ ] M-Pesa Daraja API credentials
- [ ] SMS gateway account (Africa's Talking/Twilio)
- [ ] Email SMTP service
- [ ] Backup storage (AWS S3/MinIO)
- [ ] Monitoring service (optional)

## Deployment Steps

### 1. Server Setup

```bash
# Update system
sudo apt-get update && sudo apt-get upgrade -y

# Install dependencies
sudo apt-get install -y \
  curl wget git nginx certbot python3-certbot-nginx \
  postgresql-client redis-tools htop net-tools \
  docker.io docker-compose-plugin

# Enable Docker
sudo systemctl enable docker
sudo systemctl start docker
sudo usermod -aG docker $USER

# Configure firewall
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow ssh
sudo ufw allow http
sudo ufw allow https
sudo ufw allow 1812/udp  # RADIUS Auth
sudo ufw allow 1813/udp  # RADIUS Accounting
sudo ufw enable
```

### 2. SSL Certificate

```bash
# Obtain certificate
sudo certbot certonly --standalone -d your-domain.com -d www.your-domain.com

# Auto-renewal
echo "0 12 * * * /usr/bin/certbot renew --quiet" | sudo crontab -

# Copy certificates
sudo mkdir -p /opt/isp-billing/nginx/ssl
sudo cp /etc/letsencrypt/live/your-domain.com/fullchain.pem /opt/isp-billing/nginx/ssl/
sudo cp /etc/letsencrypt/live/your-domain.com/privkey.pem /opt/isp-billing/nginx/ssl/
```

### 3. Application Deployment

```bash
# Create directory
sudo mkdir -p /opt/isp-billing
cd /opt/isp-billing

# Clone repository
git clone https://your-repo.git .

# Create environment file
sudo nano .env
# (Paste environment variables from .env.example)

# Start services
docker-compose up -d

# Verify deployment
docker-compose ps
docker-compose logs -f api
```

### 4. Database Setup

```bash
# Run migrations
docker-compose exec api npm run migrate

# Seed initial data (optional)
docker-compose exec api npm run seed

# Create first admin user
docker-compose exec api node scripts/create-admin.js
```

### 5. Backup Configuration

```bash
# Create backup script
sudo tee /opt/isp-billing/scripts/backup.sh > /dev/null << 'EOF'
#!/bin/bash
BACKUP_DIR="/opt/isp-billing/backups"
DATE=$(date +%Y%m%d_%H%M%S)

# Database backup
docker-compose exec -T postgres pg_dump -U postgres isp_billing > "$BACKUP_DIR/db_$DATE.sql"

# Compress
gzip "$BACKUP_DIR/db_$DATE.sql"

# Upload to S3 (optional)
aws s3 cp "$BACKUP_DIR/db_$DATE.sql.gz" s3://your-backup-bucket/

# Clean old backups (keep 30 days)
find "$BACKUP_DIR" -name "db_*.sql.gz" -mtime +30 -delete
EOF

sudo chmod +x /opt/isp-billing/scripts/backup.sh

# Schedule backups
echo "0 2 * * * /opt/isp-billing/scripts/backup.sh >> /var/log/isp-billing-backup.log 2>&1" | sudo crontab -
```

## Security Hardening

### 1. System Security

```bash
# Disable root login
sudo passwd -l root

# Create deploy user
sudo adduser deploy
sudo usermod -aG sudo deploy
sudo usermod -aG docker deploy

# Configure SSH
sudo nano /etc/ssh/sshd_config
# Set: PermitRootLogin no
# Set: PasswordAuthentication no
# Set: PubkeyAuthentication yes

sudo systemctl restart sshd
```

### 2. Database Security

```bash
# Strong PostgreSQL password
# In docker-compose.yml, use strong password

# Restrict database access
# Only allow connections from app network

# Enable SSL for database connections
# Set DB_SSL=true in .env
```

### 3. Application Security

```bash
# Generate strong JWT secret
openssl rand -base64 64

# Set secure headers in nginx
# Already configured in nginx.conf

# Enable rate limiting
# Already configured in docker-compose.yml
```

## Monitoring Setup

### 1. Enable Monitoring Stack

```bash
# Start with monitoring
docker-compose --profile monitoring up -d

# Access Grafana
# http://your-domain.com:3000
# Default: admin/admin
```

### 2. Configure Alerts

```yaml
# monitoring/prometheus/alerts.yml
groups:
  - name: isp-billing
    rules:
      - alert: HighErrorRate
        expr: rate(http_requests_total{status=~"5.."}[5m]) > 0.1
        for: 5m
        labels:
          severity: critical
        annotations:
          summary: "High error rate detected"
      
      - alert: DatabaseDown
        expr: up{job="postgres"} == 0
        for: 1m
        labels:
          severity: critical
        annotations:
          summary: "Database is down"
      
      - alert: DiskSpaceLow
        expr: (node_filesystem_avail_bytes / node_filesystem_size_bytes) < 0.1
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: "Disk space is low"
```

### 3. Log Aggregation

```bash
# View logs
docker-compose logs -f --tail 100 api

# Search logs
docker-compose logs api | grep ERROR

# Export logs
docker-compose logs --since 24h api > /tmp/api_logs.txt
```

## Maintenance Procedures

### Daily

- [ ] Check system health: `docker-compose ps`
- [ ] Review error logs
- [ ] Monitor disk space: `df -h`
- [ ] Check backup completion

### Weekly

- [ ] Review security logs
- [ ] Update SSL certificates if needed
- [ ] Clean up old logs
- [ ] Verify backup integrity

### Monthly

- [ ] Update system packages
- [ ] Review user access
- [ ] Analyze performance metrics
- [ ] Test disaster recovery

## Troubleshooting

### Common Issues

1. **Container Won't Start**
   ```bash
   # Check logs
   docker-compose logs <service-name>
   
   # Restart service
   docker-compose restart <service-name>
   
   # Rebuild if needed
   docker-compose up -d --build <service-name>
   ```

2. **Database Connection Failed**
   ```bash
   # Check PostgreSQL
   docker-compose exec postgres pg_isready -U postgres
   
   # Reset database (CAUTION: Data loss!)
   docker-compose down -v
   docker-compose up -d postgres
   ```

3. **Out of Memory**
   ```bash
   # Check memory usage
   free -h
   docker stats
   
   # Add swap
   sudo fallocate -l 4G /swapfile
   sudo chmod 600 /swapfile
   sudo mkswap /swapfile
   sudo swapon /swapfile
   ```

4. **Disk Full**
   ```bash
   # Check disk usage
   du -sh /opt/isp-billing/*
   docker system df
   
   # Clean up
   docker system prune -a
   docker volume prune
   ```

### Emergency Procedures

**Database Corruption:**
```bash
# Stop services
docker-compose down

# Restore from backup
gunzip < backup_file.sql.gz | docker-compose exec -T postgres psql -U postgres isp_billing

# Restart
docker-compose up -d
```

**Complete System Failure:**
```bash
# On new server
# 1. Install Docker
# 2. Clone repository
# 3. Restore .env file
# 4. Restore database
# 5. Start services
docker-compose up -d
```

## Performance Tuning

### PostgreSQL

```sql
-- Add to postgresql.conf
shared_buffers = 2GB
effective_cache_size = 6GB
work_mem = 16MB
maintenance_work_mem = 512MB
max_connections = 200
```

### Nginx

```nginx
# In nginx.conf
worker_processes auto;
worker_connections 4096;
keepalive_timeout 30;
```

### Node.js

```bash
# Set in docker-compose.yml
environment:
  - NODE_OPTIONS=--max-old-space-size=4096
  - UV_THREADPOOL_SIZE=128
```

## Scaling

### Horizontal Scaling

```yaml
# docker-compose.scale.yml
version: '3.8'

services:
  api:
    deploy:
      replicas: 3
    
  nginx:
    ports:
      - "80:80"
      - "443:443"
```

### Database Replication

```yaml
# Add read replica
postgres-replica:
  image: postgres:16-alpine
  environment:
    - POSTGRES_DB=isp_billing
    - POSTGRES_USER=postgres
    - POSTGRES_PASSWORD=${DB_PASSWORD}
  volumes:
    - postgres_replica_data:/var/lib/postgresql/data
```

## Support Contacts

- **Technical Support**: support@your-isp.com
- **Emergency Hotline**: +254 XXX XXX XXX
- **Documentation**: https://docs.your-isp.com

## License & Legal

- Software License: MIT
- Data Protection: GDPR Compliant
- Terms of Service: https://your-isp.com/terms
