# M-Pesa Daraja API Integration Guide

## Overview

M-Pesa Daraja API allows businesses to integrate with Safaricom's M-Pesa platform for:
- **STK Push** (Customer-initiated payments)
- **C2B** (Customer to Business payments)
- **B2C** (Business to Customer disbursements)
- **Transaction Status Query**
- **Account Balance Query**

## Prerequisites

1. Safaricom Developer Account (https://developer.safaricom.co.ke)
2. Approved M-Pesa Shortcode (Paybill or Till Number)
3. Consumer Key and Consumer Secret
4. Passkey (for STK Push)
5. Valid SSL certificate for callback URLs

## Configuration

### 1. Environment Variables

```bash
# M-Pesa Configuration
MPESA_ENV=sandbox          # or 'production'
MPESA_CONSUMER_KEY=your_consumer_key
MPESA_CONSUMER_SECRET=your_consumer_secret
MPESA_SHORTCODE=174379     # Your Paybill/Till number
MPESA_PASSKEY=your_passkey
MPESA_CALLBACK_URL=https://your-domain.com/api/mpesa/callback
MPESA_TIMEOUT_URL=https://your-domain.com/api/mpesa/timeout
MPESA_RESULT_URL=https://your-domain.com/api/mpesa/result
```

### 2. API Service Implementation

```typescript
// src/services/mpesaService.ts
import axios from 'axios';
import crypto from 'crypto';
import { logger } from '../utils/logger';

export class MpesaService {
  private consumerKey: string;
  private consumerSecret: string;
  private shortcode: string;
  private passkey: string;
  private baseUrl: string;
  private callbackUrl: string;

  constructor() {
    this.consumerKey = process.env.MPESA_CONSUMER_KEY!;
    this.consumerSecret = process.env.MPESA_CONSUMER_SECRET!;
    this.shortcode = process.env.MPESA_SHORTCODE!;
    this.passkey = process.env.MPESA_PASSKEY!;
    this.baseUrl = process.env.MPESA_ENV === 'production'
      ? 'https://api.safaricom.co.ke'
      : 'https://sandbox.safaricom.co.ke';
    this.callbackUrl = process.env.MPESA_CALLBACK_URL!;
  }

  // Generate access token
  async getAccessToken(): Promise<string> {
    const auth = Buffer.from(`${this.consumerKey}:${this.consumerSecret}`).toString('base64');
    
    try {
      const response = await axios.get(
        `${this.baseUrl}/oauth/v1/generate?grant_type=client_credentials`,
        {
          headers: {
            Authorization: `Basic ${auth}`
          }
        }
      );
      return response.data.access_token;
    } catch (error) {
      logger.error('M-Pesa access token error:', error);
      throw new Error('Failed to get M-Pesa access token');
    }
  }

  // Generate password for STK Push
  private generatePassword(timestamp: string): string {
    const data = `${this.shortcode}${this.passkey}${timestamp}`;
    return Buffer.from(data).toString('base64');
  }

  // STK Push (Customer pays via phone)
  async stkPush(
    phoneNumber: string,
    amount: number,
    accountReference: string,
    transactionDesc: string,
    callbackUrl?: string
  ): Promise<any> {
    const accessToken = await this.getAccessToken();
    const timestamp = new Date().toISOString().replace(/[^0-9]/g, '').slice(0, 14);
    const password = this.generatePassword(timestamp);

    // Format phone number (remove + and add 254 prefix)
    const formattedPhone = phoneNumber.replace(/^\+?254/, '254').replace(/^0/, '254');

    const payload = {
      BusinessShortCode: this.shortcode,
      Password: password,
      Timestamp: timestamp,
      TransactionType: 'CustomerPayBillOnline',
      Amount: Math.round(amount),
      PartyA: formattedPhone,
      PartyB: this.shortcode,
      PhoneNumber: formattedPhone,
      CallBackURL: callbackUrl || this.callbackUrl,
      AccountReference: accountReference.slice(0, 12),
      TransactionDesc: transactionDesc.slice(0, 13)
    };

    try {
      const response = await axios.post(
        `${this.baseUrl}/mpesa/stkpush/v1/processrequest`,
        payload,
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
          }
        }
      );

      logger.info('STK Push initiated', {
        phoneNumber: formattedPhone,
        amount,
        accountReference,
        checkoutRequestID: response.data.CheckoutRequestID
      });

      return response.data;
    } catch (error: any) {
      logger.error('STK Push failed:', error.response?.data || error.message);
      throw new Error(`STK Push failed: ${error.response?.data?.errorMessage || error.message}`);
    }
  }

  // Query STK Push status
  async queryStkStatus(checkoutRequestId: string): Promise<any> {
    const accessToken = await this.getAccessToken();
    const timestamp = new Date().toISOString().replace(/[^0-9]/g, '').slice(0, 14);
    const password = this.generatePassword(timestamp);

    const payload = {
      BusinessShortCode: this.shortcode,
      Password: password,
      Timestamp: timestamp,
      CheckoutRequestID: checkoutRequestId
    };

    try {
      const response = await axios.post(
        `${this.baseUrl}/mpesa/stkpushquery/v1/query`,
        payload,
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
          }
        }
      );

      return response.data;
    } catch (error: any) {
      logger.error('STK Query failed:', error.response?.data || error.message);
      throw error;
    }
  }

  // Register C2B URLs
  async registerC2BUrls(
    confirmationUrl: string,
    validationUrl: string,
    responseType: 'Completed' | 'Cancelled' = 'Completed'
  ): Promise<any> {
    const accessToken = await this.getAccessToken();

    const payload = {
      ShortCode: this.shortcode,
      ResponseType: responseType,
      ConfirmationURL: confirmationUrl,
      ValidationURL: validationUrl
    };

    try {
      const response = await axios.post(
        `${this.baseUrl}/mpesa/c2b/v1/registerurl`,
        payload,
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
          }
        }
      );

      logger.info('C2B URLs registered', response.data);
      return response.data;
    } catch (error: any) {
      logger.error('C2B registration failed:', error.response?.data || error.message);
      throw error;
    }
  }

  // Simulate C2B Payment (Sandbox only)
  async simulateC2BPayment(
    phoneNumber: string,
    amount: number,
    accountReference: string
  ): Promise<any> {
    if (process.env.MPESA_ENV === 'production') {
      throw new Error('C2B simulation is only available in sandbox');
    }

    const accessToken = await this.getAccessToken();
    const formattedPhone = phoneNumber.replace(/^\+?254/, '254').replace(/^0/, '254');

    const payload = {
      ShortCode: this.shortcode,
      CommandID: 'CustomerPayBillOnline',
      Amount: Math.round(amount),
      Msisdn: formattedPhone,
      BillRefNumber: accountReference
    };

    try {
      const response = await axios.post(
        `${this.baseUrl}/mpesa/c2b/v1/simulate`,
        payload,
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
          }
        }
      );

      return response.data;
    } catch (error: any) {
      logger.error('C2B simulation failed:', error.response?.data || error.message);
      throw error;
    }
  }

  // B2C Payment (Business to Customer)
  async b2cPayment(
    phoneNumber: string,
    amount: number,
    occasion: string,
    remarks: string,
    resultUrl: string,
    timeoutUrl: string
  ): Promise<any> {
    const accessToken = await this.getAccessToken();
    const formattedPhone = phoneNumber.replace(/^\+?254/, '254').replace(/^0/, '254');

    const payload = {
      InitiatorName: process.env.MPESA_INITIATOR_NAME,
      SecurityCredential: process.env.MPESA_SECURITY_CREDENTIAL,
      CommandID: 'BusinessPayment',
      Amount: Math.round(amount),
      PartyA: this.shortcode,
      PartyB: formattedPhone,
      Remarks: remarks,
      QueueTimeOutURL: timeoutUrl,
      ResultURL: resultUrl,
      Occasion: occasion
    };

    try {
      const response = await axios.post(
        `${this.baseUrl}/mpesa/b2c/v1/paymentrequest`,
        payload,
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
          }
        }
      );

      logger.info('B2C payment initiated', {
        phoneNumber: formattedPhone,
        amount,
        conversationID: response.data.ConversationID
      });

      return response.data;
    } catch (error: any) {
      logger.error('B2C payment failed:', error.response?.data || error.message);
      throw error;
    }
  }

  // Transaction Status Query
  async queryTransactionStatus(
    transactionId: string,
    resultUrl: string,
    timeoutUrl: string
  ): Promise<any> {
    const accessToken = await this.getAccessToken();

    const payload = {
      Initiator: process.env.MPESA_INITIATOR_NAME,
      SecurityCredential: process.env.MPESA_SECURITY_CREDENTIAL,
      CommandID: 'TransactionStatusQuery',
      TransactionID: transactionId,
      PartyA: this.shortcode,
      IdentifierType: '4',
      ResultURL: resultUrl,
      QueueTimeOutURL: timeoutUrl,
      Remarks: 'Transaction status query',
      Occasion: 'Query'
    };

    try {
      const response = await axios.post(
        `${this.baseUrl}/mpesa/transactionstatus/v1/query`,
        payload,
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
          }
        }
      );

      return response.data;
    } catch (error: any) {
      logger.error('Transaction status query failed:', error.response?.data || error.message);
      throw error;
    }
  }

  // Account Balance Query
  async queryAccountBalance(resultUrl: string, timeoutUrl: string): Promise<any> {
    const accessToken = await this.getAccessToken();

    const payload = {
      Initiator: process.env.MPESA_INITIATOR_NAME,
      SecurityCredential: process.env.MPESA_SECURITY_CREDENTIAL,
      CommandID: 'AccountBalance',
      PartyA: this.shortcode,
      IdentifierType: '4',
      Remarks: 'Account balance query',
      QueueTimeOutURL: timeoutUrl,
      ResultURL: resultUrl
    };

    try {
      const response = await axios.post(
        `${this.baseUrl}/mpesa/accountbalance/v1/query`,
        payload,
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
          }
        }
      );

      return response.data;
    } catch (error: any) {
      logger.error('Account balance query failed:', error.response?.data || error.message);
      throw error;
    }
  }
}

export const mpesaService = new MpesaService();
```

### 3. Callback Handlers

```typescript
// src/routes/mpesa.ts
import { Router } from 'express';
import { mpesaService } from '../services/mpesaService';
import { database } from '../config/database';
import { logger } from '../utils/logger';
import { jobQueue } from '../config/queue';

const router = Router();

// STK Push Callback
router.post('/callback', async (req, res) => {
  // Respond immediately to M-Pesa
  res.json({ ResultCode: 0, ResultDesc: 'Success' });

  const { Body } = req.body;
  
  if (!Body || !Body.stkCallback) {
    logger.warn('Invalid M-Pesa callback received');
    return;
  }

  const callback = Body.stkCallback;
  const {
    MerchantRequestID,
    CheckoutRequestID,
    ResultCode,
    ResultDesc,
    CallbackMetadata
  } = callback;

  try {
    // Extract metadata
    let amount = 0;
    let mpesaReceiptNumber = '';
    let transactionDate = '';
    let phoneNumber = '';

    if (CallbackMetadata && CallbackMetadata.Item) {
      CallbackMetadata.Item.forEach((item: any) => {
        switch (item.Name) {
          case 'Amount':
            amount = item.Value;
            break;
          case 'MpesaReceiptNumber':
            mpesaReceiptNumber = item.Value;
            break;
          case 'TransactionDate':
            transactionDate = item.Value;
            break;
          case 'PhoneNumber':
            phoneNumber = item.Value;
            break;
        }
      });
    }

    // Find pending payment
    const payment = await database('payments')
      .where({
        transaction_id: CheckoutRequestID,
        status: 'pending'
      })
      .first();

    if (!payment) {
      logger.warn('Payment not found for callback', { CheckoutRequestID });
      return;
    }

    if (ResultCode === 0) {
      // Payment successful
      await database.transaction(async (trx) => {
        // Update payment
        await trx('payments')
          .where({ id: payment.id })
          .update({
            status: 'completed',
            mpesa_receipt: mpesaReceiptNumber,
            mpesa_phone: phoneNumber,
            processed_at: new Date(),
            metadata: JSON.stringify({
              merchantRequestID: MerchantRequestID,
              transactionDate,
              resultDesc: ResultDesc
            })
          });

        // Update customer balance
        await trx('customers')
          .where({ id: payment.customer_id })
          .increment('balance', amount);

        // Update invoice if applicable
        if (payment.invoice_id) {
          const invoice = await trx('invoices')
            .where({ id: payment.invoice_id })
            .first();

          const newPaidAmount = parseFloat(invoice.paid_amount) + amount;
          const newBalance = parseFloat(invoice.total_amount) - newPaidAmount;

          await trx('invoices')
            .where({ id: payment.invoice_id })
            .update({
              paid_amount: newPaidAmount,
              balance: newBalance,
              status: newBalance <= 0 ? 'paid' : 'partial',
              paid_date: newBalance <= 0 ? new Date() : null
            });
        }
      });

      // Send notification
      await jobQueue.addNotificationJob({
        type: 'payment_received',
        customerId: payment.customer_id,
        amount,
        receiptNumber: mpesaReceiptNumber
      });

      logger.info('M-Pesa payment processed successfully', {
        paymentId: payment.id,
        receiptNumber: mpesaReceiptNumber,
        amount
      });
    } else {
      // Payment failed
      await database('payments')
        .where({ id: payment.id })
        .update({
          status: 'failed',
          metadata: JSON.stringify({
            resultCode: ResultCode,
            resultDesc: ResultDesc
          })
        });

      logger.warn('M-Pesa payment failed', {
        paymentId: payment.id,
        resultCode: ResultCode,
        resultDesc: ResultDesc
      });
    }
  } catch (error) {
    logger.error('Error processing M-Pesa callback:', error);
  }
});

// C2B Confirmation URL
router.post('/c2b/confirm', async (req, res) => {
  res.json({ ResultCode: 0, ResultDesc: 'Success' });

  const {
    TransactionType,
    TransID,
    TransTime,
    TransAmount,
    BusinessShortCode,
    BillRefNumber,
    InvoiceNumber,
    MSISDN,
    FirstName,
    MiddleName,
    LastName
  } = req.body;

  try {
    // Find customer by phone or account number
    let customer = await database('customers')
      .where({
        $or: [
          { phone: MSISDN.replace(/^254/, '0') },
          { phone: MSISDN },
          { account_number: BillRefNumber }
        ]
      })
      .first();

    if (!customer) {
      logger.warn('Customer not found for C2B payment', {
        phone: MSISDN,
        accountNumber: BillRefNumber
      });
      return;
    }

    // Create payment record
    await database('payments').insert({
      company_id: customer.company_id,
      transaction_id: TransID,
      customer_id: customer.id,
      amount: TransAmount,
      method: 'mpesa',
      status: 'completed',
      mpesa_receipt: TransID,
      mpesa_phone: MSISDN,
      processed_at: new Date(),
      metadata: JSON.stringify({
        transactionType: TransactionType,
        transactionTime: TransTime,
        businessShortCode: BusinessShortCode,
        billRefNumber: BillRefNumber,
        firstName: FirstName,
        middleName: MiddleName,
        lastName: LastName
      })
    });

    // Update customer balance
    await database('customers')
      .where({ id: customer.id })
      .increment('balance', TransAmount);

    logger.info('C2B payment processed', {
      transactionId: TransID,
      customerId: customer.id,
      amount: TransAmount
    });
  } catch (error) {
    logger.error('Error processing C2B confirmation:', error);
  }
});

// C2B Validation URL (Optional - for pre-validation)
router.post('/c2b/validate', async (req, res) => {
  const { BillRefNumber, MSISDN } = req.body;

  try {
    // Validate customer exists
    const customer = await database('customers')
      .where({
        $or: [
          { phone: MSISDN.replace(/^254/, '0') },
          { phone: MSISDN },
          { account_number: BillRefNumber }
        ]
      })
      .first();

    if (customer) {
      res.json({
        ResultCode: 0,
        ResultDesc: 'Accepted'
      });
    } else {
      res.json({
        ResultCode: 1,
        ResultDesc: 'Rejected - Invalid account number'
      });
    }
  } catch (error) {
    logger.error('C2B validation error:', error);
    res.json({
      ResultCode: 1,
      ResultDesc: 'Rejected - System error'
    });
  }
});

// Initiate STK Push
router.post('/stkpush', async (req, res, next) => {
  try {
    const { phoneNumber, amount, accountReference, description } = req.body;

    const result = await mpesaService.stkPush(
      phoneNumber,
      amount,
      accountReference,
      description || 'Internet Payment'
    );

    // Create pending payment record
    await database('payments').insert({
      company_id: req.user!.companyId,
      transaction_id: result.CheckoutRequestID,
      customer_id: req.body.customerId,
      amount,
      method: 'mpesa',
      status: 'pending',
      mpesa_phone: phoneNumber,
      metadata: JSON.stringify({
        merchantRequestID: result.MerchantRequestID,
        accountReference
      })
    });

    res.json({
      success: true,
      data: result
    });
  } catch (error) {
    next(error);
  }
});

export default router;
```

## Testing

### Sandbox Testing

```bash
# 1. Get access token
curl -X GET "https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials" \
  -H "Authorization: Basic $(echo -n 'consumer_key:consumer_secret' | base64)"

# 2. STK Push
curl -X POST "https://sandbox.safaricom.co.ke/mpesa/stkpush/v1/processrequest" \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "BusinessShortCode": "174379",
    "Password": "base64_encoded_password",
    "Timestamp": "20240129120000",
    "TransactionType": "CustomerPayBillOnline",
    "Amount": "100",
    "PartyA": "254708374149",
    "PartyB": "174379",
    "PhoneNumber": "254708374149",
    "CallBackURL": "https://your-domain.com/api/mpesa/callback",
    "AccountReference": "INV001",
    "TransactionDesc": "Payment for Invoice 001"
  }'

# 3. Simulate C2B (Sandbox only)
curl -X POST "https://sandbox.safaricom.co.ke/mpesa/c2b/v1/simulate" \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "ShortCode": "174379",
    "CommandID": "CustomerPayBillOnline",
    "Amount": "100",
    "Msisdn": "254708374149",
    "BillRefNumber": "INV001"
  }'
```

## Security Considerations

1. **HTTPS Only**: All callback URLs must use HTTPS
2. **Validate Callbacks**: Verify request origin and signatures
3. **Idempotency**: Handle duplicate callbacks gracefully
4. **Timeout Handling**: Implement timeout URL handlers
5. **Log Security**: Don't log sensitive data (passwords, credentials)
6. **IP Whitelisting**: Only accept callbacks from M-Pesa IPs

## Common Result Codes

| Code | Description |
|------|-------------|
| 0 | Success |
| 1 | Insufficient funds |
| 2 | Less than minimum transaction value |
| 3 | More than maximum transaction value |
| 4 | Would exceed daily transfer limit |
| 5 | Would exceed minimum balance |
| 6 | Unresolved primary party |
| 7 | Unresolved receiver party |
| 8 | Would exceed maximum balance |
| 11 | Debit account invalid |
| 12 | Credit account invalid |
| 13 | Unresolved debit account |
| 14 | Unresolved credit account |
| 15 | Duplicate detected |
| 17 | Internal failure |
| 20 | Unresolved initiator |
| 26 | Traffic blocking condition in place |
| 1032 | Request cancelled by user |
| 1037 | DS timeout user cannot be reached |

## Production Checklist

- [ ] Approved Paybill/Till number from Safaricom
- [ ] Valid SSL certificate
- [ ] Callback URLs accessible from internet
- [ ] Consumer Key and Secret from Daraja portal
- [ ] Passkey for STK Push
- [ ] Security credentials for B2C (if needed)
- [ ] IP whitelisting configured
- [ ] Error handling and retry logic
- [ ] Logging and monitoring setup
- [ ] Transaction reconciliation process
