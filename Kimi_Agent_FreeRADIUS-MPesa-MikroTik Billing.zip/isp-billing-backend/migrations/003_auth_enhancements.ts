import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  // Add OAuth fields to users table
  await knex.schema.alterTable('users', (table) => {
    // OAuth provider fields
    table.string('oauth_provider', 50).nullable();
    table.string('oauth_id', 255).nullable();
    table.text('oauth_access_token').nullable();
    table.text('oauth_refresh_token').nullable();
    
    // Email verification
    table.string('email_verification_token', 255).nullable();
    table.timestamp('email_verification_sent_at').nullable();
    
    // Password reset
    table.string('password_reset_token', 255).nullable();
    table.timestamp('password_reset_sent_at').nullable();
    
    // Two-factor authentication
    table.boolean('two_factor_enabled').defaultTo(false);
    table.string('two_factor_secret', 255).nullable();
    table.jsonb('two_factor_backup_codes').nullable();
    
    // Session tracking
    table.string('session_id', 255).nullable();
    table.jsonb('session_metadata').nullable();
    
    // Failed login attempts
    table.integer('failed_login_attempts').defaultTo(0);
    table.timestamp('locked_until').nullable();
    
    // Add indexes
    table.index(['oauth_provider', 'oauth_id'], 'idx_users_oauth');
    table.index(['email_verification_token'], 'idx_users_email_verify');
    table.index(['password_reset_token'], 'idx_users_password_reset');
  });

  // Create user_sessions table for tracking active sessions
  await knex.schema.createTable('user_sessions', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('uuid_generate_v4()'));
    table.uuid('user_id').references('id').inTable('users').onDelete('CASCADE');
    table.string('session_token', 255).notNullable().unique();
    table.string('refresh_token', 255).nullable();
    table.string('ip_address', 45).nullable();
    table.text('user_agent').nullable();
    table.string('device_type', 50).nullable();
    table.string('browser', 100).nullable();
    table.string('os', 100).nullable();
    table.string('location', 255).nullable();
    table.timestamp('last_active_at').defaultTo(knex.fn.now());
    table.timestamp('expires_at').notNullable();
    table.timestamp('created_at').defaultTo(knex.fn.now());
    table.boolean('is_active').defaultTo(true);
    
    table.index(['user_id'], 'idx_sessions_user');
    table.index(['session_token'], 'idx_sessions_token');
    table.index(['expires_at'], 'idx_sessions_expires');
  });

  // Create login_attempts table for security tracking
  await knex.schema.createTable('login_attempts', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('uuid_generate_v4()'));
    table.string('identifier', 255).notNullable(); // email or phone
    table.enum('identifier_type', ['email', 'phone']).notNullable();
    table.boolean('success').defaultTo(false);
    table.string('ip_address', 45).nullable();
    table.text('user_agent').nullable();
    table.string('failure_reason', 255).nullable();
    table.timestamp('created_at').defaultTo(knex.fn.now());
    
    table.index(['identifier'], 'idx_login_attempts_identifier');
    table.index(['ip_address'], 'idx_login_attempts_ip');
    table.index(['created_at'], 'idx_login_attempts_created');
  });

  // Create oauth_connections table for multiple OAuth providers per user
  await knex.schema.createTable('oauth_connections', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('uuid_generate_v4()'));
    table.uuid('user_id').references('id').inTable('users').onDelete('CASCADE');
    table.enum('provider', ['google', 'microsoft', 'apple', 'facebook']).notNullable();
    table.string('provider_user_id', 255).notNullable();
    table.string('email', 255).nullable();
    table.text('access_token').nullable();
    table.text('refresh_token').nullable();
    table.timestamp('token_expires_at').nullable();
    table.jsonb('profile_data').nullable();
    table.timestamp('created_at').defaultTo(knex.fn.now());
    table.timestamp('updated_at').defaultTo(knex.fn.now());
    
    table.unique(['user_id', 'provider'], 'idx_oauth_user_provider');
    table.unique(['provider', 'provider_user_id'], 'idx_oauth_provider_user');
  });

  // Create password_history table for preventing password reuse
  await knex.schema.createTable('password_history', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('uuid_generate_v4()'));
    table.uuid('user_id').references('id').inTable('users').onDelete('CASCADE');
    table.string('password_hash', 255).notNullable();
    table.timestamp('created_at').defaultTo(knex.fn.now());
    
    table.index(['user_id', 'created_at'], 'idx_password_history_user');
  });

  // Create api_keys table for external API access
  await knex.schema.createTable('api_keys', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('uuid_generate_v4()'));
    table.uuid('user_id').references('id').inTable('users').onDelete('CASCADE');
    table.uuid('company_id').references('id').inTable('companies').onDelete('CASCADE');
    table.string('name', 255).notNullable();
    table.string('key_hash', 255).notNullable().unique();
    table.text('key_prefix').nullable();
    table.jsonb('permissions').defaultTo('[]');
    table.jsonb('allowed_ips').nullable();
    table.timestamp('last_used_at').nullable();
    table.string('last_used_ip', 45).nullable();
    table.timestamp('expires_at').nullable();
    table.timestamp('created_at').defaultTo(knex.fn.now());
    table.boolean('is_active').defaultTo(true);
    
    table.index(['key_hash'], 'idx_api_keys_hash');
    table.index(['user_id'], 'idx_api_keys_user');
    table.index(['company_id'], 'idx_api_keys_company');
  });
}

export async function down(knex: Knex): Promise<void> {
  // Drop tables in reverse order
  await knex.schema.dropTableIfExists('api_keys');
  await knex.schema.dropTableIfExists('password_history');
  await knex.schema.dropTableIfExists('oauth_connections');
  await knex.schema.dropTableIfExists('login_attempts');
  await knex.schema.dropTableIfExists('user_sessions');

  // Remove OAuth fields from users table
  await knex.schema.alterTable('users', (table) => {
    table.dropIndex(['oauth_provider', 'oauth_id'], 'idx_users_oauth');
    table.dropIndex(['email_verification_token'], 'idx_users_email_verify');
    table.dropIndex(['password_reset_token'], 'idx_users_password_reset');
    
    table.dropColumn('oauth_provider');
    table.dropColumn('oauth_id');
    table.dropColumn('oauth_access_token');
    table.dropColumn('oauth_refresh_token');
    table.dropColumn('email_verification_token');
    table.dropColumn('email_verification_sent_at');
    table.dropColumn('password_reset_token');
    table.dropColumn('password_reset_sent_at');
    table.dropColumn('two_factor_enabled');
    table.dropColumn('two_factor_secret');
    table.dropColumn('two_factor_backup_codes');
    table.dropColumn('session_id');
    table.dropColumn('session_metadata');
    table.dropColumn('failed_login_attempts');
    table.dropColumn('locked_until');
  });
}
