import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  // Create M-Pesa requests table
  await knex.schema.createTable('mpesa_requests', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.string('merchant_request_id', 100);
    table.string('checkout_request_id', 100).unique().notNullable();
    table.string('phone_number', 20).notNullable();
    table.decimal('amount', 10, 2).notNullable();
    table.string('account_reference', 50).notNullable();
    table.text('description');
    table.uuid('customer_id').references('id').inTable('customers');
    table.uuid('invoice_id').references('id').inTable('invoices');
    table.enum('status', ['pending', 'completed', 'failed', 'cancelled']).defaultTo('pending');
    table.string('result_code', 10);
    table.text('result_desc');
    table.string('mpesa_receipt_number', 100);
    table.string('transaction_date', 20);
    table.timestamp('callback_received_at');
    table.integer('retry_count').defaultTo(0);
    table.timestamps(true, true);

    // Indexes
    table.index('customer_id');
    table.index('invoice_id');
    table.index('status');
    table.index('checkout_request_id');
    table.index('account_reference');
    table.index('created_at');
  });

  // Create M-Pesa transactions table (for C2B payments)
  await knex.schema.createTable('mpesa_transactions', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.string('transaction_type', 50); // Pay Bill, Buy Goods, etc.
    table.string('transaction_id', 100).unique().notNullable();
    table.string('transaction_time', 50);
    table.decimal('amount', 10, 2).notNullable();
    table.string('business_short_code', 20);
    table.string('bill_ref_number', 50);
    table.string('invoice_number', 50);
    table.string('msisdn', 20);
    table.string('first_name', 100);
    table.string('middle_name', 100);
    table.string('last_name', 100);
    table.uuid('customer_id').references('id').inTable('customers');
    table.uuid('payment_id').references('id').inTable('payments');
    table.enum('status', ['pending', 'processed', 'failed']).defaultTo('pending');
    table.text('raw_data'); // Store full callback data
    table.timestamps(true, true);

    // Indexes
    table.index('transaction_id');
    table.index('bill_ref_number');
    table.index('msisdn');
    table.index('customer_id');
    table.index('status');
    table.index('created_at');
  });

  // Update payments table to add M-Pesa specific fields
  await knex.schema.alterTable('payments', (table) => {
    table.string('mpesa_checkout_request_id', 100);
    table.string('mpesa_merchant_request_id', 100);
    table.timestamp('mpesa_request_sent_at');
    table.timestamp('mpesa_callback_received_at');
    
    table.index('mpesa_checkout_request_id');
  });
}

export async function down(knex: Knex): Promise<void> {
  // Remove added columns from payments
  await knex.schema.alterTable('payments', (table) => {
    table.dropColumn('mpesa_checkout_request_id');
    table.dropColumn('mpesa_merchant_request_id');
    table.dropColumn('mpesa_request_sent_at');
    table.dropColumn('mpesa_callback_received_at');
  });

  await knex.schema.dropTableIfExists('mpesa_transactions');
  await knex.schema.dropTableIfExists('mpesa_requests');
}
