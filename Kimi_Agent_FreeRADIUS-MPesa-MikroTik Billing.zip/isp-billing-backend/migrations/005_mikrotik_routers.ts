import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  // Create mikrotik_routers table
  await knex.schema.createTable('mikrotik_routers', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.string('name', 255).notNullable();
    table.string('ip_address', 45).notNullable();
    table.integer('port').defaultTo(22);
    table.string('username', 100).notNullable();
    table.text('password').notNullable();
    table.integer('api_port').defaultTo(8728);
    table.boolean('api_use_ssl').defaultTo(false);
    table.string('location', 255);
    table.text('description');
    table.boolean('is_active').defaultTo(true);
    table.timestamp('last_connected');
    table.string('version', 50);
    table.uuid('company_id').references('id').inTable('companies').onDelete('CASCADE');
    table.timestamps(true, true);

    // Indexes
    table.index('company_id');
    table.index('is_active');
    table.index('ip_address');
  });

  // Create table for command history
  await knex.schema.createTable('mikrotik_commands', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.uuid('router_id').references('id').inTable('mikrotik_routers').onDelete('CASCADE');
    table.text('command').notNullable();
    table.uuid('executed_by').references('id').inTable('users');
    table.text('output');
    table.boolean('success').defaultTo(true);
    table.timestamps(true, true);

    table.index('router_id');
    table.index('executed_by');
    table.index('created_at');
  });

  // Create table for troubleshooting sessions
  await knex.schema.createTable('mikrotik_troubleshooting', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.uuid('router_id').references('id').inTable('mikrotik_routers').onDelete('CASCADE');
    table.integer('issues_found').defaultTo(0);
    table.integer('recommendations').defaultTo(0);
    table.jsonb('details');
    table.timestamps(true, true);

    table.index('router_id');
    table.index('created_at');
  });

  // Create table for router monitoring history
  await knex.schema.createTable('mikrotik_monitoring', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.uuid('router_id').references('id').inTable('mikrotik_routers').onDelete('CASCADE');
    table.integer('cpu_usage');
    table.integer('memory_usage');
    table.integer('disk_usage');
    table.integer('active_users');
    table.jsonb('interfaces');
    table.jsonb('health');
    table.timestamp('recorded_at').defaultTo(knex.fn.now());

    table.index('router_id');
    table.index('recorded_at');
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTableIfExists('mikrotik_monitoring');
  await knex.schema.dropTableIfExists('mikrotik_troubleshooting');
  await knex.schema.dropTableIfExists('mikrotik_commands');
  await knex.schema.dropTableIfExists('mikrotik_routers');
}
