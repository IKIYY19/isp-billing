import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  // OLTs table
  await knex.schema.createTable('olts', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('uuid_generate_v4()'));
    table.uuid('company_id').references('id').inTable('companies').onDelete('CASCADE');
    table.string('name', 255).notNullable();
    table.enum('vendor', ['huawei', 'zte', 'nokia', 'fiberhome', 'calix', 'dasan', 'edgecore', 'bdcom']).notNullable();
    table.string('model', 100);
    table.string('ip_address', 45).notNullable();
    table.integer('port').defaultTo(22);
    table.enum('protocol', ['telnet', 'ssh', 'snmp', 'netconf', 'rest', 'tr069']).defaultTo('ssh');
    table.string('username', 100).notNullable();
    table.string('password_encrypted', 500).notNullable();
    table.string('enable_password_encrypted', 500);
    table.string('snmp_community', 100);
    table.enum('snmp_version', ['v1', 'v2c', 'v3']);
    table.string('location', 255);
    table.jsonb('coordinates');
    table.jsonb('capacity').defaultTo(JSON.stringify({ maxPonPorts: 16, maxOnusPerPort: 128 }));
    table.string('firmware_version', 100);
    table.bigInteger('system_uptime');
    table.boolean('is_active').defaultTo(true);
    table.timestamp('last_seen_at');
    table.timestamp('created_at').defaultTo(knex.fn.now());
    table.timestamp('updated_at').defaultTo(knex.fn.now());
    
    table.index(['company_id'], 'idx_olts_company');
    table.index(['vendor'], 'idx_olts_vendor');
    table.index(['is_active'], 'idx_olts_active');
  });

  // PON Ports table
  await knex.schema.createTable('pon_ports', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('uuid_generate_v4()'));
    table.uuid('olt_id').references('id').inTable('olts').onDelete('CASCADE');
    table.integer('port_number').notNullable();
    table.integer('shelf').defaultTo(0);
    table.integer('slot').defaultTo(0);
    table.integer('sub_slot').defaultTo(0);
    table.enum('status', ['online', 'offline', 'disabled']).defaultTo('offline');
    table.enum('type', ['gpon', 'xgpon', 'xgspon', 'epon']).defaultTo('gpon');
    table.integer('max_distance').defaultTo(20000);
    table.float('transmit_power');
    table.float('receive_power');
    table.float('temperature');
    table.float('voltage');
    table.float('bias_current');
    table.integer('onu_count').defaultTo(0);
    table.integer('max_onus').defaultTo(128);
    table.string('description', 255);
    table.timestamp('last_updated').defaultTo(knex.fn.now());
    table.timestamp('created_at').defaultTo(knex.fn.now());
    
    table.unique(['olt_id', 'shelf', 'slot', 'port_number'], 'idx_pon_ports_unique');
    table.index(['olt_id'], 'idx_pon_ports_olt');
    table.index(['status'], 'idx_pon_ports_status');
  });

  // ONUs table
  await knex.schema.createTable('onus', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('uuid_generate_v4()'));
    table.uuid('olt_id').references('id').inTable('olts').onDelete('CASCADE');
    table.uuid('pon_port_id').references('id').inTable('pon_ports').onDelete('CASCADE');
    table.uuid('customer_id').references('id').inTable('customers');
    table.integer('onu_id').notNullable();
    table.string('serial_number', 100).notNullable();
    table.string('mac_address', 17);
    table.string('vendor_id', 50);
    table.string('model', 100);
    table.string('firmware_version', 100);
    table.enum('status', ['online', 'offline', 'dying-gasp', 'los', 'auth-fail', 'config-fail', 'mismatch']).defaultTo('offline');
    table.enum('admin_state', ['enabled', 'disabled']).defaultTo('enabled');
    table.enum('auth_mode', ['sn', 'password', 'loid', 'mac']).defaultTo('sn');
    table.string('auth_info', 255);
    table.string('service_profile', 100);
    table.string('line_profile', 100);
    table.string('traffic_profile', 100);
    table.float('rx_power');
    table.float('tx_power');
    table.float('olt_rx_power');
    table.float('distance');
    table.float('temperature');
    table.float('voltage');
    table.timestamp('last_online_at');
    table.timestamp('last_offline_at');
    table.integer('offline_count').defaultTo(0);
    table.bigInteger('uptime');
    table.string('description', 255);
    table.timestamp('created_at').defaultTo(knex.fn.now());
    table.timestamp('updated_at').defaultTo(knex.fn.now());
    
    table.unique(['olt_id', 'serial_number'], 'idx_onus_serial');
    table.index(['olt_id'], 'idx_onus_olt');
    table.index(['pon_port_id'], 'idx_onus_pon_port');
    table.index(['customer_id'], 'idx_onus_customer');
    table.index(['status'], 'idx_onus_status');
  });

  // OLT Alarms table
  await knex.schema.createTable('olt_alarms', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('uuid_generate_v4()'));
    table.uuid('olt_id').references('id').inTable('olts').onDelete('CASCADE');
    table.uuid('onu_id').references('id').inTable('onus');
    table.uuid('pon_port_id').references('id').inTable('pon_ports');
    table.enum('severity', ['critical', 'major', 'minor', 'warning', 'info']).notNullable();
    table.enum('category', ['communication', 'equipment', 'processing', 'environmental', 'service']).notNullable();
    table.string('type', 100).notNullable();
    table.text('description').notNullable();
    table.string('source', 255).notNullable();
    table.boolean('acknowledged').defaultTo(false);
    table.uuid('acknowledged_by').references('id').inTable('users');
    table.timestamp('acknowledged_at');
    table.boolean('cleared').defaultTo(false);
    table.timestamp('cleared_at');
    table.timestamp('created_at').defaultTo(knex.fn.now());
    
    table.index(['olt_id'], 'idx_olt_alarms_olt');
    table.index(['severity'], 'idx_olt_alarms_severity');
    table.index(['acknowledged'], 'idx_olt_alarms_ack');
    table.index(['cleared'], 'idx_olt_alarms_cleared');
    table.index(['created_at'], 'idx_olt_alarms_created');
  });

  // OLT Performance History
  await knex.schema.createTable('olt_performance_history', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('uuid_generate_v4()'));
    table.uuid('olt_id').references('id').inTable('olts').onDelete('CASCADE');
    table.float('cpu_usage');
    table.float('memory_usage');
    table.float('temperature');
    table.jsonb('pon_port_stats');
    table.timestamp('created_at').defaultTo(knex.fn.now());
    
    table.index(['olt_id', 'created_at'], 'idx_olt_perf_history');
  });

  // OLT Provisioning Logs
  await knex.schema.createTable('olt_provisioning_logs', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('uuid_generate_v4()'));
    table.uuid('olt_id').references('id').inTable('olts').onDelete('CASCADE');
    table.uuid('onu_id').references('id').inTable('onus');
    table.string('serial_number', 100);
    table.enum('action', ['provision', 'deprovision', 'update', 'reset']).notNullable();
    table.enum('status', ['success', 'failed', 'pending']).notNullable();
    table.text('details');
    table.uuid('performed_by').references('id').inTable('users');
    table.timestamp('created_at').defaultTo(knex.fn.now());
    
    table.index(['olt_id'], 'idx_olt_prov_logs_olt');
    table.index(['created_at'], 'idx_olt_prov_logs_created');
  });

  // OLT Commands Log
  await knex.schema.createTable('olt_commands', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('uuid_generate_v4()'));
    table.uuid('olt_id').references('id').inTable('olts').onDelete('CASCADE');
    table.text('command').notNullable();
    table.enum('status', ['success', 'failed']).notNullable();
    table.text('output');
    table.uuid('executed_by').references('id').inTable('users');
    table.timestamp('created_at').defaultTo(knex.fn.now());
    
    table.index(['olt_id'], 'idx_olt_commands_olt');
    table.index(['created_at'], 'idx_olt_commands_created');
  });

  // OLT Actions Log
  await knex.schema.createTable('olt_actions', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('uuid_generate_v4()'));
    table.uuid('olt_id').references('id').inTable('olts').onDelete('CASCADE');
    table.uuid('onu_id').references('id').inTable('onus');
    table.enum('action', ['reset', 'reboot', 'enable', 'disable', 'config_update']).notNullable();
    table.enum('status', ['success', 'failed']).notNullable();
    table.text('details');
    table.uuid('performed_by').references('id').inTable('users');
    table.timestamp('created_at').defaultTo(knex.fn.now());
    
    table.index(['olt_id'], 'idx_olt_actions_olt');
    table.index(['created_at'], 'idx_olt_actions_created');
  });

  // OLT Self-Healing Logs
  await knex.schema.createTable('olt_self_healing_logs', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('uuid_generate_v4()'));
    table.uuid('olt_id').references('id').inTable('olts').onDelete('CASCADE');
    table.jsonb('actions').defaultTo('[]');
    table.jsonb('issues').defaultTo('[]');
    table.timestamp('created_at').defaultTo(knex.fn.now());
    
    table.index(['olt_id'], 'idx_olt_healing_olt');
    table.index(['created_at'], 'idx_olt_healing_created');
  });

  // Add ONU fields to customers table
  await knex.schema.alterTable('customers', (table) => {
    table.uuid('olt_id').references('id').inTable('olts');
    table.uuid('onu_id').references('id').inTable('onus');
    table.string('onu_serial', 100);
    table.string('pon_port', 50);
    
    table.index(['olt_id'], 'idx_customers_olt');
    table.index(['onu_id'], 'idx_customers_onu');
  });
}

export async function down(knex: Knex): Promise<void> {
  // Remove ONU fields from customers
  await knex.schema.alterTable('customers', (table) => {
    table.dropIndex(['olt_id'], 'idx_customers_olt');
    table.dropIndex(['onu_id'], 'idx_customers_onu');
    table.dropColumn('olt_id');
    table.dropColumn('onu_id');
    table.dropColumn('onu_serial');
    table.dropColumn('pon_port');
  });

  // Drop tables in reverse order
  await knex.schema.dropTableIfExists('olt_self_healing_logs');
  await knex.schema.dropTableIfExists('olt_actions');
  await knex.schema.dropTableIfExists('olt_commands');
  await knex.schema.dropTableIfExists('olt_provisioning_logs');
  await knex.schema.dropTableIfExists('olt_performance_history');
  await knex.schema.dropTableIfExists('olt_alarms');
  await knex.schema.dropTableIfExists('onus');
  await knex.schema.dropTableIfExists('pon_ports');
  await knex.schema.dropTableIfExists('olts');
}
