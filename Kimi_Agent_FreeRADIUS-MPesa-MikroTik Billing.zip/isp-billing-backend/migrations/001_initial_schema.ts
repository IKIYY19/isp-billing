import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  // Enable extensions
  await knex.raw('CREATE EXTENSION IF NOT EXISTS "uuid-ossp"');
  await knex.raw('CREATE EXTENSION IF NOT EXISTS "pgcrypto"');

  // Companies table (for multi-tenant support)
  await knex.schema.createTable('companies', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('uuid_generate_v4()'));
    table.string('name', 255).notNullable();
    table.string('slug', 100).unique().notNullable();
    table.text('address');
    table.string('phone', 50);
    table.string('email', 255);
    table.string('website', 255);
    table.string('tax_number', 100);
    table.string('registration_number', 100);
    table.string('logo_url', 500);
    table.string('timezone', 50).defaultTo('Africa/Nairobi');
    table.string('currency', 10).defaultTo('KES');
    table.jsonb('settings').defaultTo('{}');
    table.boolean('is_active').defaultTo(true);
    table.timestamp('created_at').defaultTo(knex.fn.now());
    table.timestamp('updated_at').defaultTo(knex.fn.now());
  });

  // Users table
  await knex.schema.createTable('users', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('uuid_generate_v4()'));
    table.uuid('company_id').references('id').inTable('companies').onDelete('CASCADE');
    table.string('email', 255).unique().notNullable();
    table.string('password_hash', 255).notNullable();
    table.string('first_name', 100).notNullable();
    table.string('last_name', 100).notNullable();
    table.string('phone', 50);
    table.string('avatar_url', 500);
    table.enum('role', ['admin', 'manager', 'support', 'technician', 'agent']).defaultTo('support');
    table.jsonb('permissions').defaultTo('[]');
    table.enum('status', ['active', 'inactive', 'suspended']).defaultTo('active');
    table.timestamp('last_login_at');
    table.string('last_login_ip', 45);
    table.boolean('two_factor_enabled').defaultTo(false);
    table.string('two_factor_secret', 255);
    table.timestamp('email_verified_at');
    table.timestamp('created_at').defaultTo(knex.fn.now());
    table.timestamp('updated_at').defaultTo(knex.fn.now());
  });

  // Internet plans/packages
  await knex.schema.createTable('plans', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('uuid_generate_v4()'));
    table.uuid('company_id').references('id').inTable('companies').onDelete('CASCADE');
    table.string('name', 255).notNullable();
    table.text('description');
    table.enum('type', ['pppoe', 'hotspot', 'fiber', 'wireless']).notNullable();
    table.decimal('price', 10, 2).notNullable();
    table.enum('billing_cycle', ['daily', 'weekly', 'monthly', 'quarterly', 'yearly']).defaultTo('monthly');
    table.integer('download_speed').notNullable(); // in Mbps
    table.integer('upload_speed').notNullable(); // in Mbps
    table.bigInteger('data_limit'); // in MB, null for unlimited
    table.enum('data_limit_type', ['daily', 'weekly', 'monthly']).defaultTo('monthly');
    table.integer('burst_limit'); // in Mbps
    table.integer('burst_threshold');
    table.integer('burst_time');
    table.integer('priority').defaultTo(8);
    table.string('pool_name', 100); // IP pool for RADIUS
    table.string('profile_name', 100); // MikroTik profile name
    table.jsonb('radius_attributes').defaultTo('{}');
    table.boolean('is_promotional').defaultTo(false);
    table.timestamp('promo_start_date');
    table.timestamp('promo_end_date');
    table.decimal('promo_price', 10, 2);
    table.boolean('is_active').defaultTo(true);
    table.timestamp('created_at').defaultTo(knex.fn.now());
    table.timestamp('updated_at').defaultTo(knex.fn.now());
  });

  // Customers table
  await knex.schema.createTable('customers', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('uuid_generate_v4()'));
    table.uuid('company_id').references('id').inTable('companies').onDelete('CASCADE');
    table.string('account_number', 50).unique().notNullable();
    table.string('first_name', 100).notNullable();
    table.string('last_name', 100).notNullable();
    table.string('email', 255);
    table.string('phone', 50).notNullable();
    table.string('phone_secondary', 50);
    table.string('id_number', 100); // National ID/Passport
    table.enum('id_type', ['national_id', 'passport', 'driving_license', 'alien_id']);
    table.date('date_of_birth');
    table.enum('gender', ['male', 'female', 'other']);
    table.text('address');
    table.string('city', 100);
    table.string('postal_code', 20);
    table.string('coordinates', 100); // lat,lng
    table.enum('customer_type', ['residential', 'business', 'corporate']).defaultTo('residential');
    table.enum('status', ['active', 'inactive', 'suspended', 'terminated']).defaultTo('active');
    table.uuid('plan_id').references('id').inTable('plans');
    table.timestamp('plan_started_at');
    table.timestamp('plan_expires_at');
    table.decimal('balance', 10, 2).defaultTo(0);
    table.decimal('credit_limit', 10, 2).defaultTo(0);
    table.boolean('auto_renew').defaultTo(true);
    table.enum('payment_method', ['mpesa', 'bank', 'cash', 'cheque', 'card']).defaultTo('mpesa');
    table.string('mpesa_number', 50);
    table.string('referral_code', 50);
    table.uuid('referred_by').references('id').inTable('customers');
    table.uuid('agent_id').references('id').inTable('users');
    table.text('notes');
    table.jsonb('custom_fields').defaultTo('{}');
    table.timestamp('last_login_at');
    table.timestamp('created_at').defaultTo(knex.fn.now());
    table.timestamp('updated_at').defaultTo(knex.fn.now());
  });

  // Customer credentials (PPPoE/Hotspot)
  await knex.schema.createTable('customer_credentials', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('uuid_generate_v4()'));
    table.uuid('customer_id').references('id').inTable('customers').onDelete('CASCADE');
    table.enum('type', ['pppoe', 'hotspot']).notNullable();
    table.string('username', 255).unique().notNullable();
    table.string('password_hash', 255).notNullable();
    table.string('ip_address', 45);
    table.string('mac_address', 17);
    table.string('caller_id', 100);
    table.boolean('is_active').defaultTo(true);
    table.timestamp('last_connected_at');
    table.string('last_connected_from', 45);
    table.bigInteger('total_bytes_in').defaultTo(0);
    table.bigInteger('total_bytes_out').defaultTo(0);
    table.integer('session_count').defaultTo(0);
    table.timestamp('created_at').defaultTo(knex.fn.now());
    table.timestamp('updated_at').defaultTo(knex.fn.now());
  });

  // Invoices table
  await knex.schema.createTable('invoices', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('uuid_generate_v4()'));
    table.uuid('company_id').references('id').inTable('companies').onDelete('CASCADE');
    table.string('invoice_number', 50).unique().notNullable();
    table.uuid('customer_id').references('id').inTable('customers').onDelete('CASCADE');
    table.enum('type', ['subscription', 'installation', 'hardware', 'support', 'other']).defaultTo('subscription');
    table.decimal('subtotal', 10, 2).notNullable();
    table.decimal('tax_amount', 10, 2).defaultTo(0);
    table.decimal('discount_amount', 10, 2).defaultTo(0);
    table.decimal('total_amount', 10, 2).notNullable();
    table.decimal('paid_amount', 10, 2).defaultTo(0);
    table.decimal('balance', 10, 2).defaultTo(0);
    table.enum('status', ['draft', 'sent', 'paid', 'partial', 'overdue', 'cancelled']).defaultTo('draft');
    table.date('invoice_date').notNullable();
    table.date('due_date').notNullable();
    table.date('paid_date');
    table.text('notes');
    table.text('terms');
    table.jsonb('line_items').defaultTo('[]');
    table.uuid('created_by').references('id').inTable('users');
    table.timestamp('sent_at');
    table.timestamp('created_at').defaultTo(knex.fn.now());
    table.timestamp('updated_at').defaultTo(knex.fn.now());
  });

  // Payments table
  await knex.schema.createTable('payments', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('uuid_generate_v4()'));
    table.uuid('company_id').references('id').inTable('companies').onDelete('CASCADE');
    table.string('transaction_id', 100).unique().notNullable();
    table.uuid('customer_id').references('id').inTable('customers').onDelete('CASCADE');
    table.uuid('invoice_id').references('id').inTable('invoices');
    table.decimal('amount', 10, 2).notNullable();
    table.enum('method', ['mpesa', 'bank', 'cash', 'cheque', 'card', 'wallet', 'other']).notNullable();
    table.enum('status', ['pending', 'completed', 'failed', 'refunded', 'cancelled']).defaultTo('pending');
    table.string('mpesa_receipt', 100);
    table.string('mpesa_phone', 50);
    table.string('bank_reference', 100);
    table.string('cheque_number', 100);
    table.string('card_last_four', 4);
    table.text('notes');
    table.jsonb('metadata').defaultTo('{}');
    table.uuid('processed_by').references('id').inTable('users');
    table.timestamp('processed_at');
    table.timestamp('created_at').defaultTo(knex.fn.now());
    table.timestamp('updated_at').defaultTo(knex.fn.now());
  });

  // MikroTik routers
  await knex.schema.createTable('routers', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('uuid_generate_v4()'));
    table.uuid('company_id').references('id').inTable('companies').onDelete('CASCADE');
    table.string('name', 255).notNullable();
    table.string('ip_address', 45).notNullable();
    table.integer('api_port').defaultTo(8728);
    table.integer('winbox_port').defaultTo(8291);
    table.integer('ssh_port').defaultTo(22);
    table.string('username', 100).notNullable();
    table.string('password_encrypted', 500).notNullable();
    table.string('model', 100);
    table.string('serial_number', 100);
    table.string('firmware_version', 100);
    table.string('location', 255);
    table.text('description');
    table.enum('status', ['online', 'offline', 'unknown']).defaultTo('unknown');
    table.timestamp('last_seen_at');
    table.jsonb('interfaces').defaultTo('[]');
    table.jsonb('resources').defaultTo('{}');
    table.boolean('is_active').defaultTo(true);
    table.timestamp('created_at').defaultTo(knex.fn.now());
    table.timestamp('updated_at').defaultTo(knex.fn.now());
  });

  // Hotspot locations
  await knex.schema.createTable('hotspot_locations', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('uuid_generate_v4()'));
    table.uuid('company_id').references('id').inTable('companies').onDelete('CASCADE');
    table.uuid('router_id').references('id').inTable('routers');
    table.string('name', 255).notNullable();
    table.text('description');
    table.string('address', 500);
    table.string('coordinates', 100);
    table.string('ssid', 100);
    table.string('nas_identifier', 100);
    table.string('secret', 255); // RADIUS secret
    table.enum('type', ['indoor', 'outdoor', 'mobile']).defaultTo('indoor');
    table.integer('max_users').defaultTo(100);
    table.string('splash_page', 255);
    table.jsonb('captive_portal_settings').defaultTo('{}');
    table.boolean('is_active').defaultTo(true);
    table.timestamp('created_at').defaultTo(knex.fn.now());
    table.timestamp('updated_at').defaultTo(knex.fn.now());
  });

  // Vouchers
  await knex.schema.createTable('vouchers', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('uuid_generate_v4()'));
    table.uuid('company_id').references('id').inTable('companies').onDelete('CASCADE');
    table.uuid('plan_id').references('id').inTable('plans');
    table.uuid('hotspot_location_id').references('id').inTable('hotspot_locations');
    table.string('code', 100).unique().notNullable();
    table.string('username', 100);
    table.string('password', 100);
    table.enum('status', ['unused', 'used', 'expired', 'disabled']).defaultTo('unused');
    table.uuid('used_by').references('id').inTable('customers');
    table.timestamp('used_at');
    table.timestamp('expires_at');
    table.bigInteger('data_used').defaultTo(0);
    table.integer('session_duration').defaultTo(0); // in minutes
    table.uuid('generated_by').references('id').inTable('users');
    table.timestamp('created_at').defaultTo(knex.fn.now());
    table.timestamp('updated_at').defaultTo(knex.fn.now());
  });

  // Support tickets
  await knex.schema.createTable('tickets', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('uuid_generate_v4()'));
    table.uuid('company_id').references('id').inTable('companies').onDelete('CASCADE');
    table.string('ticket_number', 50).unique().notNullable();
    table.uuid('customer_id').references('id').inTable('customers').onDelete('CASCADE');
    table.string('subject', 255).notNullable();
    table.text('description').notNullable();
    table.enum('category', ['technical', 'billing', 'sales', 'general', 'complaint']).defaultTo('general');
    table.enum('priority', ['low', 'medium', 'high', 'urgent']).defaultTo('medium');
    table.enum('status', ['open', 'in_progress', 'waiting', 'resolved', 'closed', 'escalated']).defaultTo('open');
    table.uuid('assigned_to').references('id').inTable('users');
    table.uuid('created_by').references('id').inTable('users');
    table.timestamp('resolved_at');
    table.timestamp('closed_at');
    table.integer('satisfaction_rating');
    table.text('satisfaction_comment');
    table.timestamp('created_at').defaultTo(knex.fn.now());
    table.timestamp('updated_at').defaultTo(knex.fn.now());
  });

  // Ticket comments
  await knex.schema.createTable('ticket_comments', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('uuid_generate_v4()'));
    table.uuid('ticket_id').references('id').inTable('tickets').onDelete('CASCADE');
    table.text('comment').notNullable();
    table.boolean('is_internal').defaultTo(false);
    table.uuid('created_by').references('id').inTable('users');
    table.jsonb('attachments').defaultTo('[]');
    table.timestamp('created_at').defaultTo(knex.fn.now());
  });

  // Inventory items
  await knex.schema.createTable('inventory', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('uuid_generate_v4()'));
    table.uuid('company_id').references('id').inTable('companies').onDelete('CASCADE');
    table.string('sku', 100).unique().notNullable();
    table.string('name', 255).notNullable();
    table.text('description');
    table.enum('category', ['router', 'access_point', 'cable', 'connector', 'antenna', 'power_supply', 'other']).notNullable();
    table.string('brand', 100);
    table.string('model', 100);
    table.decimal('cost_price', 10, 2);
    table.decimal('selling_price', 10, 2);
    table.integer('quantity').defaultTo(0);
    table.integer('min_stock_level').defaultTo(5);
    table.integer('reorder_point').defaultTo(10);
    table.string('unit', 50).defaultTo('piece');
    table.string('supplier', 255);
    table.string('location', 255);
    table.text('notes');
    table.boolean('is_active').defaultTo(true);
    table.timestamp('created_at').defaultTo(knex.fn.now());
    table.timestamp('updated_at').defaultTo(knex.fn.now());
  });

  // Inventory transactions
  await knex.schema.createTable('inventory_transactions', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('uuid_generate_v4()'));
    table.uuid('inventory_id').references('id').inTable('inventory').onDelete('CASCADE');
    table.enum('type', ['in', 'out', 'adjustment', 'return', 'transfer']).notNullable();
    table.integer('quantity').notNullable();
    table.integer('stock_after').notNullable();
    table.string('reference', 100); // invoice, ticket, etc.
    table.uuid('reference_id');
    table.text('notes');
    table.uuid('created_by').references('id').inTable('users');
    table.timestamp('created_at').defaultTo(knex.fn.now());
  });

  // Agents/Resellers
  await knex.schema.createTable('agents', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('uuid_generate_v4()'));
    table.uuid('company_id').references('id').inTable('companies').onDelete('CASCADE');
    table.uuid('user_id').references('id').inTable('users');
    table.string('code', 50).unique().notNullable();
    table.enum('type', ['individual', 'business']).defaultTo('individual');
    table.string('business_name', 255);
    table.decimal('commission_rate', 5, 2).defaultTo(5.00); // percentage
    table.enum('commission_type', ['percentage', 'fixed']).defaultTo('percentage');
    table.decimal('total_earned', 10, 2).defaultTo(0);
    table.decimal('total_paid', 10, 2).defaultTo(0);
    table.decimal('balance', 10, 2).defaultTo(0);
    table.enum('status', ['active', 'inactive', 'suspended']).defaultTo('active');
    table.text('notes');
    table.timestamp('created_at').defaultTo(knex.fn.now());
    table.timestamp('updated_at').defaultTo(knex.fn.now());
  });

  // Agent commissions
  await knex.schema.createTable('agent_commissions', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('uuid_generate_v4()'));
    table.uuid('agent_id').references('id').inTable('agents').onDelete('CASCADE');
    table.uuid('customer_id').references('id').inTable('customers');
    table.uuid('invoice_id').references('id').inTable('invoices');
    table.decimal('amount', 10, 2).notNullable();
    table.enum('status', ['pending', 'approved', 'paid', 'cancelled']).defaultTo('pending');
    table.timestamp('approved_at');
    table.uuid('approved_by').references('id').inTable('users');
    table.timestamp('paid_at');
    table.string('payment_reference', 100);
    table.text('notes');
    table.timestamp('created_at').defaultTo(knex.fn.now());
    table.timestamp('updated_at').defaultTo(knex.fn.now());
  });

  // Audit logs
  await knex.schema.createTable('audit_logs', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('uuid_generate_v4()'));
    table.uuid('company_id').references('id').inTable('companies').onDelete('CASCADE');
    table.string('action', 100).notNullable();
    table.string('entity', 100).notNullable();
    table.uuid('entity_id');
    table.uuid('user_id').references('id').inTable('users');
    table.jsonb('old_values');
    table.jsonb('new_values');
    table.string('ip_address', 45);
    table.string('user_agent', 500);
    table.timestamp('created_at').defaultTo(knex.fn.now());
  });

  // System settings
  await knex.schema.createTable('settings', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('uuid_generate_v4()'));
    table.uuid('company_id').references('id').inTable('companies').onDelete('CASCADE');
    table.string('key', 100).notNullable();
    table.text('value');
    table.enum('type', ['string', 'number', 'boolean', 'json']).defaultTo('string');
    table.string('category', 50).defaultTo('general');
    table.text('description');
    table.unique(['company_id', 'key']);
    table.timestamp('created_at').defaultTo(knex.fn.now());
    table.timestamp('updated_at').defaultTo(knex.fn.now());
  });

  // Create indexes
  await knex.schema.raw('CREATE INDEX idx_customers_company ON customers(company_id)');
  await knex.schema.raw('CREATE INDEX idx_customers_status ON customers(status)');
  await knex.schema.raw('CREATE INDEX idx_customers_plan ON customers(plan_id)');
  await knex.schema.raw('CREATE INDEX idx_invoices_customer ON invoices(customer_id)');
  await knex.schema.raw('CREATE INDEX idx_invoices_status ON invoices(status)');
  await knex.schema.raw('CREATE INDEX idx_invoices_due_date ON invoices(due_date)');
  await knex.schema.raw('CREATE INDEX idx_payments_customer ON payments(customer_id)');
  await knex.schema.raw('CREATE INDEX idx_payments_status ON payments(status)');
  await knex.schema.raw('CREATE INDEX idx_tickets_customer ON tickets(customer_id)');
  await knex.schema.raw('CREATE INDEX idx_tickets_status ON tickets(status)');
  await knex.schema.raw('CREATE INDEX idx_audit_logs_company ON audit_logs(company_id)');
  await knex.schema.raw('CREATE INDEX idx_audit_logs_entity ON audit_logs(entity, entity_id)');
  await knex.schema.raw('CREATE INDEX idx_audit_logs_created ON audit_logs(created_at)');
}

export async function down(knex: Knex): Promise<void> {
  // Drop tables in reverse order
  await knex.schema.dropTableIfExists('settings');
  await knex.schema.dropTableIfExists('audit_logs');
  await knex.schema.dropTableIfExists('agent_commissions');
  await knex.schema.dropTableIfExists('agents');
  await knex.schema.dropTableIfExists('inventory_transactions');
  await knex.schema.dropTableIfExists('inventory');
  await knex.schema.dropTableIfExists('ticket_comments');
  await knex.schema.dropTableIfExists('tickets');
  await knex.schema.dropTableIfExists('vouchers');
  await knex.schema.dropTableIfExists('hotspot_locations');
  await knex.schema.dropTableIfExists('routers');
  await knex.schema.dropTableIfExists('payments');
  await knex.schema.dropTableIfExists('invoices');
  await knex.schema.dropTableIfExists('customer_credentials');
  await knex.schema.dropTableIfExists('customers');
  await knex.schema.dropTableIfExists('plans');
  await knex.schema.dropTableIfExists('users');
  await knex.schema.dropTableIfExists('companies');
}
