import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  // RADIUS NAS (Network Access Servers) table
  await knex.schema.createTable('radius_nas', (table) => {
    table.increments('id').primary();
    table.string('nasname', 128).notNullable();
    table.string('shortname', 32);
    table.string('type', 30).defaultTo('other');
    table.integer('ports').defaultTo(0);
    table.string('secret', 60).notNullable();
    table.string('server', 64);
    table.string('community', 50);
    table.text('description');
    table.uuid('router_id').references('id').inTable('routers');
    table.uuid('company_id').references('id').inTable('companies').onDelete('CASCADE');
    table.boolean('is_active').defaultTo(true);
    table.timestamp('created_at').defaultTo(knex.fn.now());
    table.timestamp('updated_at').defaultTo(knex.fn.now());
  });

  // RADIUS users/radcheck table (authentication)
  await knex.schema.createTable('radius_users', (table) => {
    table.increments('id').primary();
    table.uuid('customer_id').references('id').inTable('customers').onDelete('CASCADE');
    table.string('username', 64).notNullable();
    table.string('attribute', 64).notNullable().defaultTo('Cleartext-Password');
    table.string('op', 2).notNullable().defaultTo(':=');
    table.string('value', 253).notNullable();
    table.uuid('company_id').references('id').inTable('companies').onDelete('CASCADE');
    table.timestamp('created_at').defaultTo(knex.fn.now());
    table.timestamp('updated_at').defaultTo(knex.fn.now());
    table.unique(['username', 'attribute']);
  });

  // RADIUS reply attributes (authorization)
  await knex.schema.createTable('radius_reply', (table) => {
    table.increments('id').primary();
    table.string('username', 64).notNullable();
    table.string('attribute', 64).notNullable();
    table.string('op', 2).notNullable().defaultTo(':=');
    table.string('value', 253).notNullable();
    table.uuid('company_id').references('id').inTable('companies').onDelete('CASCADE');
    table.timestamp('created_at').defaultTo(knex.fn.now());
  });

  // RADIUS group definitions
  await knex.schema.createTable('radius_groups', (table) => {
    table.increments('id').primary();
    table.string('groupname', 64).notNullable();
    table.string('attribute', 64).notNullable();
    table.string('op', 2).notNullable().defaultTo(':=');
    table.string('value', 253).notNullable();
    table.uuid('plan_id').references('id').inTable('plans');
    table.uuid('company_id').references('id').inTable('companies').onDelete('CASCADE');
    table.integer('priority').defaultTo(1);
    table.timestamp('created_at').defaultTo(knex.fn.now());
    table.unique(['groupname', 'attribute']);
  });

  // User-Group mapping
  await knex.schema.createTable('radius_user_group', (table) => {
    table.increments('id').primary();
    table.string('username', 64).notNullable();
    table.string('groupname', 64).notNullable();
    table.integer('priority').defaultTo(1);
    table.uuid('company_id').references('id').inTable('companies').onDelete('CASCADE');
    table.timestamp('created_at').defaultTo(knex.fn.now());
    table.unique(['username', 'groupname']);
  });

  // RADIUS accounting table
  await knex.schema.createTable('radius_accounting', (table) => {
    table.bigIncrements('radacctid').primary();
    table.string('acctsessionid', 64).notNullable();
    table.string('acctuniqueid', 32).notNullable();
    table.string('username', 64).notNullable();
    table.string('realm', 64);
    table.string('nasipaddress', 15).notNullable();
    table.string('nasportid', 15);
    table.string('nasporttype', 32);
    table.timestamp('acctstarttime');
    table.timestamp('acctupdatetime');
    table.timestamp('acctstoptime');
    table.integer('acctinterval');
    table.bigInteger('acctsessiontime');
    table.string('acctauthentic', 32);
    table.string('connectinfo_start', 128);
    table.string('connectinfo_stop', 128);
    table.bigInteger('acctinputoctets').defaultTo(0);
    table.bigInteger('acctoutputoctets').defaultTo(0);
    table.string('calledstationid', 50);
    table.string('callingstationid', 50);
    table.string('acctterminatecause', 32);
    table.string('servicetype', 32);
    table.string('framedprotocol', 32);
    table.string('framedipaddress', 15);
    table.string('framedipv6address', 45);
    table.string('framedipv6prefix', 45);
    table.string('framedinterfaceid', 44);
    table.string('delegatedipv6prefix', 45);
    table.string('class', 64);
    table.uuid('company_id').references('id').inTable('companies').onDelete('CASCADE');
    table.unique(['acctuniqueid']);
    table.index(['username']);
    table.index(['acctstarttime']);
    table.index(['acctsessionid', 'username']);
  });

  // RADIUS post-auth log
  await knex.schema.createTable('radius_postauth', (table) => {
    table.increments('id').primary();
    table.string('username', 64).notNullable();
    table.string('pass', 64);
    table.string('reply', 32).notNullable();
    table.string('authdate', 29).defaultTo(knex.raw('NOW()'));
    table.string('class', 64);
    table.string('nasipaddress', 15);
    table.string('nasportid', 15);
    table.uuid('company_id').references('id').inTable('companies').onDelete('CASCADE');
    table.index(['username']);
    table.index(['authdate']);
  });

  // Bandwidth usage tracking
  await knex.schema.createTable('bandwidth_usage', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('uuid_generate_v4()'));
    table.uuid('customer_id').references('id').inTable('customers').onDelete('CASCADE');
    table.string('username', 64).notNullable();
    table.date('date').notNullable();
    table.bigInteger('bytes_in').defaultTo(0);
    table.bigInteger('bytes_out').defaultTo(0);
    table.bigInteger('total_bytes').defaultTo(0);
    table.integer('session_count').defaultTo(0);
    table.bigInteger('session_time').defaultTo(0); // in seconds
    table.uuid('company_id').references('id').inTable('companies').onDelete('CASCADE');
    table.timestamp('created_at').defaultTo(knex.fn.now());
    table.timestamp('updated_at').defaultTo(knex.fn.now());
    table.unique(['customer_id', 'date']);
    table.index(['date']);
  });

  // FUP (Fair Usage Policy) rules
  await knex.schema.createTable('fup_rules', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('uuid_generate_v4()'));
    table.uuid('company_id').references('id').inTable('companies').onDelete('CASCADE');
    table.uuid('plan_id').references('id').inTable('plans');
    table.string('name', 255).notNullable();
    table.enum('type', ['data_cap', 'time_cap', 'speed_throttle']).notNullable();
    table.bigInteger('threshold'); // bytes or seconds
    table.integer('throttle_speed'); // throttled speed in Mbps
    table.enum('reset_period', ['daily', 'weekly', 'monthly']).defaultTo('monthly');
    table.boolean('notify_customer').defaultTo(true);
    table.text('notification_message');
    table.boolean('is_active').defaultTo(true);
    table.timestamp('created_at').defaultTo(knex.fn.now());
    table.timestamp('updated_at').defaultTo(knex.fn.now());
  });

  // FUP violations
  await knex.schema.createTable('fup_violations', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('uuid_generate_v4()'));
    table.uuid('customer_id').references('id').inTable('customers').onDelete('CASCADE');
    table.uuid('fup_rule_id').references('id').inTable('fup_rules');
    table.bigInteger('usage_at_violation');
    table.timestamp('violation_at').defaultTo(knex.fn.now());
    table.timestamp('resolved_at');
    table.enum('status', ['active', 'resolved', 'appealed']).defaultTo('active');
    table.text('notes');
    table.timestamp('created_at').defaultTo(knex.fn.now());
    table.timestamp('updated_at').defaultTo(knex.fn.now());
  });

  // Create indexes
  await knex.schema.raw('CREATE INDEX idx_radius_users_username ON radius_users(username)');
  await knex.schema.raw('CREATE INDEX idx_radius_users_customer ON radius_users(customer_id)');
  await knex.schema.raw('CREATE INDEX idx_radius_reply_username ON radius_reply(username)');
  await knex.schema.raw('CREATE INDEX idx_radius_user_group_username ON radius_user_group(username)');
  await knex.schema.raw('CREATE INDEX idx_radius_accounting_dates ON radius_accounting(acctstarttime, acctstoptime)');
  await knex.schema.raw('CREATE INDEX idx_bandwidth_usage_customer ON bandwidth_usage(customer_id)');
  await knex.schema.raw('CREATE INDEX idx_bandwidth_usage_date ON bandwidth_usage(date)');
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTableIfExists('fup_violations');
  await knex.schema.dropTableIfExists('fup_rules');
  await knex.schema.dropTableIfExists('bandwidth_usage');
  await knex.schema.dropTableIfExists('radius_postauth');
  await knex.schema.dropTableIfExists('radius_accounting');
  await knex.schema.dropTableIfExists('radius_user_group');
  await knex.schema.dropTableIfExists('radius_groups');
  await knex.schema.dropTableIfExists('radius_reply');
  await knex.schema.dropTableIfExists('radius_users');
  await knex.schema.dropTableIfExists('radius_nas');
}
