# 🚀 ISP Billing System - Launch Guide

This guide will help you launch your ISP Billing System in production with scaling capabilities.

## 📋 Quick Start (Choose Your Deployment)

### Option 1: Docker Compose (Single Server - Easiest)
```bash
# 1. Get a VPS (4GB RAM, 2 CPU recommended)
# 2. SSH into your server
ssh root@your-server-ip

# 3. Install Docker
curl -fsSL https://get.docker.com | sh

# 4. Download and launch
git clone https://your-repo.git isp-billing
cd isp-billing

# 5. Configure environment
cp .env.example .env
nano .env  # Add your M-Pesa keys, domain, etc.

# 6. Launch!
./scripts/launch.sh compose
```

### Option 2: Docker Swarm (Multi-Server - Scalable)
```bash
# Initialize Swarm on manager node
docker swarm init --advertise-addr <MANAGER-IP>

# Join worker nodes (run on each worker)
docker swarm join --token <TOKEN> <MANAGER-IP>:2377

# Deploy
./scripts/launch.sh swarm billing.yourdomain.com
```

### Option 3: Kubernetes (Enterprise - Most Scalable)
```bash
# Requires Kubernetes cluster
kubectl apply -f k8s/
```

---

## 🏗️ Architecture Overview

### Single Server (Docker Compose)
```
┌─────────────────────────────────────┐
│           Your Server               │
│  ┌─────────┐  ┌─────────┐          │
│  │  Nginx  │  │   API   │          │
│  │ (SSL)   │  │ (x1)    │          │
│  └────┬────┘  └────┬────┘          │
│       │            │                │
│  ┌────┴────────────┴────┐          │
│  │    PostgreSQL        │          │
│  │    Redis             │          │
│  └──────────────────────┘          │
└─────────────────────────────────────┘
```

### Multi-Server (Docker Swarm)
```
┌─────────────────────────────────────────────────────┐
│                  Docker Swarm Cluster               │
│                                                     │
│  ┌─────────────┐    ┌─────────────┐                │
│  │   Manager   │    │   Worker 1  │                │
│  │  (API x3)   │    │  (API x3)   │                │
│  │  (DB Primary)│   │  (DB Replica)│               │
│  └─────────────┘    └─────────────┘                │
│                                                     │
│  ┌─────────────┐    ┌─────────────┐                │
│  │   Worker 2  │    │   Worker 3  │                │
│  │  (Workers)  │    │  (Workers)  │                │
│  │  (Redis)    │    │  (Monitoring)│               │
│  └─────────────┘    └─────────────┘                │
└─────────────────────────────────────────────────────┘
```

---

## 📦 Pre-Deployment Checklist

### Required
- [ ] VPS/Server (Ubuntu 22.04 LTS recommended)
- [ ] Domain name (e.g., `billing.yourisp.com`)
- [ ] M-Pesa Daraja API credentials
- [ ] Email SMTP credentials

### Optional but Recommended
- [ ] SSL certificate (Let's Encrypt - free)
- [ ] SMS gateway account (Africa's Talking)
- [ ] Backup storage (AWS S3 or similar)

---

## 🔧 Configuration

### 1. Environment Variables (.env)

```bash
# Required - Application
NODE_ENV=production
DOMAIN=billing.yourisp.com

# Required - Database
DB_PASSWORD=your_secure_password_here

# Required - Security
JWT_SECRET=$(openssl rand -base64 64)

# Required - M-Pesa (Get from https://developer.safaricom.co.ke)
MPESA_ENV=production
MPESA_CONSUMER_KEY=your_consumer_key
MPESA_CONSUMER_SECRET=your_consumer_secret
MPESA_SHORTCODE=your_paybill_number
MPESA_PASSKEY=your_passkey
MPESA_CALLBACK_URL=https://billing.yourisp.com/api/mpesa/callback

# Required - Email
SMTP_HOST=smtp.gmail.com
SMTP_USER=your-email@gmail.com
SMTP_PASS=your_app_password

# Optional - SMS
SMS_PROVIDER=africastalking
SMS_API_KEY=your_api_key
SMS_SENDER_ID=YOURBRAND
```

### 2. Get M-Pesa Credentials

1. Go to https://developer.safaricom.co.ke
2. Create an account
3. Create a new app
4. Get Consumer Key and Secret
5. Apply for a Paybill/Till number
6. Get the Passkey from your M-Pesa portal

### 3. Configure Domain

Point your domain to your server:
```
A Record: billing.yourisp.com → YOUR_SERVER_IP
```

---

## 🚀 Launch Commands

### Docker Compose (Recommended for Start)
```bash
# Basic launch
./scripts/launch.sh compose

# With SSL (specify domain)
./scripts/launch.sh compose billing.yourisp.com
```

**Scaling:**
```bash
# Scale API to 3 instances
docker-compose up -d --scale api=3

# View logs
docker-compose logs -f api

# Update
docker-compose pull && docker-compose up -d
```

### Docker Swarm (For Growth)
```bash
# Initialize swarm (on manager)
docker swarm init

# Join workers
docker swarm join --token <TOKEN> <MANAGER-IP>:2377

# Deploy
./scripts/launch.sh swarm billing.yourisp.com

# Scale services
docker service scale isp-billing_api=5
docker service scale isp-billing_worker=3

# Rolling update
docker service update --image isp-billing/api:v2 isp-billing_api
```

### Kubernetes (Enterprise)
```bash
# Deploy all
kubectl apply -f k8s/

# Auto-scale based on CPU
kubectl autoscale deployment isp-billing-api --min=3 --max=20 --cpu-percent=70

# View pods
kubectl get pods -n isp-billing

# View logs
kubectl logs -f deployment/isp-billing-api -n isp-billing
```

---

## 📊 Scaling Guide

### When to Scale

| Metric | Scale API | Scale Workers | Scale DB |
|--------|-----------|---------------|----------|
| CPU > 70% | ✅ | ✅ | - |
| Memory > 80% | ✅ | ✅ | ✅ |
| Response time > 500ms | ✅ | - | - |
| Queue backlog > 1000 | - | ✅ | - |
| DB connections > 80% | - | - | ✅ |

### Scaling Commands

**Docker Compose:**
```bash
# Vertical scaling (more resources)
docker-compose up -d --scale api=3
```

**Docker Swarm:**
```bash
# Horizontal scaling
docker service scale isp-billing_api=5
docker service scale isp-billing_worker=4

# Update with zero downtime
docker service update --update-parallelism 1 --update-delay 10s isp-billing_api
```

**Kubernetes:**
```bash
# Auto-scaling
kubectl apply -f k8s/api-deployment.yml  # Already has HPA

# Manual scaling
kubectl scale deployment isp-billing-api --replicas=10 -n isp-billing

# View HPA status
kubectl get hpa -n isp-billing
```

---

## 🔐 SSL Certificate Setup

### Automatic (Let's Encrypt)
```bash
# Install certbot
apt-get install certbot

# Obtain certificate
certbot certonly --standalone -d billing.yourisp.com

# Auto-renewal
echo "0 12 * * * /usr/bin/certbot renew --quiet" | crontab -
```

### Manual
Place your certificates in:
```
nginx/ssl/
├── fullchain.pem
└── privkey.pem
```

---

## 📈 Monitoring

### Access Dashboards

| Service | URL | Default Login |
|---------|-----|---------------|
| Application | https://billing.yourisp.com | - |
| Grafana | https://grafana.yourisp.com | admin/admin |
| Prometheus | https://prometheus.yourisp.com | - |
| Traefik | http://your-server:8080 | - |

### Key Metrics to Watch

1. **API Performance**
   - Request rate
   - Response time (p50, p95, p99)
   - Error rate

2. **Database**
   - Connection count
   - Query performance
   - Replication lag

3. **Business Metrics**
   - Active customers
   - Daily revenue
   - Failed payments
   - System errors

---

## 💾 Backup & Recovery

### Automated Backups
```bash
# Daily backup at 2 AM (already configured)
# Backups saved to: ./backups/

# Manual backup
docker-compose exec postgres pg_dump -U postgres isp_billing > backup.sql

# Restore
cat backup.sql | docker-compose exec -T postgres psql -U postgres isp_billing
```

### S3 Backup (Recommended)
```bash
# Configure in .env
BACKUP_S3_BUCKET=your-backup-bucket
BACKUP_S3_ACCESS_KEY=your-key
BACKUP_S3_SECRET_KEY=your-secret
```

---

## 🛠️ Troubleshooting

### Common Issues

**1. Container won't start**
```bash
# Check logs
docker-compose logs <service-name>

# Restart
docker-compose restart <service-name>
```

**2. Database connection failed**
```bash
# Check PostgreSQL
docker-compose exec postgres pg_isready -U postgres

# Reset (CAUTION: Data loss!)
docker-compose down -v
docker-compose up -d postgres
```

**3. M-Pesa callback not working**
- Verify callback URL uses HTTPS
- Check firewall allows port 443
- Verify domain points to server

**4. High memory usage**
```bash
# Check usage
docker stats

# Scale down temporarily
docker-compose up -d --scale api=1
```

---

## 🔄 Updates

### Zero-Downtime Update
```bash
# Docker Compose
docker-compose pull
docker-compose up -d

# Docker Swarm
docker service update --image isp-billing/api:latest isp-billing_api

# Kubernetes
kubectl set image deployment/isp-billing-api api=isp-billing/api:v2 -n isp-billing
```

### Database Migrations
```bash
# Run migrations
docker-compose exec api npm run migrate

# Rollback (if needed)
docker-compose exec api npx knex migrate:rollback
```

---

## 📞 Support

### Documentation
- FreeRADIUS: `docs/FREERADIUS_INTEGRATION.md`
- M-Pesa: `docs/MPESA_INTEGRATION.md`
- MikroTik: `docs/MIKROTIK_INTEGRATION.md`

### Logs
```bash
# All services
docker-compose logs -f

# Specific service
docker-compose logs -f api

# Last 100 lines
docker-compose logs --tail 100 api
```

---

## 🎉 You're Ready!

Your ISP Billing System is now configured for production with scaling capabilities!

**Next Steps:**
1. ✅ Launch the system
2. ✅ Create admin user
3. ✅ Add your first router
4. ✅ Configure M-Pesa
5. ✅ Add customers
6. ✅ Start billing!

**Happy Billing! 🚀**
