# ISP Billing System - API Documentation

## Base URL
```
Production: https://api.your-domain.com
Development: http://localhost:3001
```

## Authentication

All API requests require authentication using JWT tokens.

### Login
```http
POST /api/auth/login
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "yourpassword"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "token": "eyJhbGciOiJIUzI1NiIs...",
    "refreshToken": "eyJhbGciOiJIUzI1NiIs...",
    "user": {
      "id": "1",
      "email": "user@example.com",
      "firstName": "John",
      "lastName": "Doe",
      "role": "admin"
    }
  }
}
```

### Using the Token
```http
GET /api/customers
Authorization: Bearer eyJhbGciOiJIUzI1NiIs...
```

---

## Customers API

### List Customers
```http
GET /api/customers?page=1&limit=20&search=john&status=active
```

**Response:**
```json
{
  "success": true,
  "data": {
    "customers": [
      {
        "id": "1",
        "accountNumber": "ISP001",
        "firstName": "John",
        "lastName": "Doe",
        "email": "john@example.com",
        "phone": "+254712345678",
        "status": "active",
        "balance": 0,
        "planName": "Premium 20Mbps",
        "createdAt": "2024-01-15T10:30:00Z"
      }
    ],
    "total": 150,
    "page": 1,
    "limit": 20
  }
}
```

### Get Customer
```http
GET /api/customers/:id
```

### Create Customer
```http
POST /api/customers
Content-Type: application/json

{
  "firstName": "John",
  "lastName": "Doe",
  "email": "john@example.com",
  "phone": "+254712345678",
  "planId": "1",
  "address": "123 Main St",
  "city": "Nairobi"
}
```

### Update Customer
```http
PUT /api/customers/:id
Content-Type: application/json

{
  "firstName": "John",
  "lastName": "Smith",
  "phone": "+254723456789"
}
```

### Delete Customer
```http
DELETE /api/customers/:id
```

---

## Invoices API

### List Invoices
```http
GET /api/invoices?customerId=1&status=unpaid&page=1&limit=20
```

**Response:**
```json
{
  "success": true,
  "data": {
    "invoices": [
      {
        "id": "1",
        "invoiceNumber": "INV-2401-0001",
        "customerId": "1",
        "customerName": "John Doe",
        "amount": 4000,
        "tax": 640,
        "total": 4640,
        "balance": 4640,
        "status": "unpaid",
        "dueDate": "2024-02-05",
        "createdAt": "2024-01-01T00:00:00Z"
      }
    ],
    "total": 50,
    "page": 1,
    "limit": 20
  }
}
```

### Create Invoice
```http
POST /api/invoices
Content-Type: application/json

{
  "customerId": "1",
  "amount": 4000,
  "description": "Monthly subscription - January 2024",
  "dueDate": "2024-02-05"
}
```

### Get Invoice PDF
```http
GET /api/invoices/:id/pdf
```

---

## Payments API

### List Payments
```http
GET /api/payments?customerId=1&page=1&limit=20
```

### Create Payment
```http
POST /api/payments
Content-Type: application/json

{
  "customerId": "1",
  "invoiceId": "1",
  "amount": 4640,
  "method": "mpesa",
  "mpesaPhoneNumber": "+254712345678"
}
```

### M-Pesa Callback
```http
POST /api/payments/mpesa/callback
Content-Type: application/json

{
  "Body": {
    "stkCallback": {
      "MerchantRequestID": "12345",
      "CheckoutRequestID": "67890",
      "ResultCode": 0,
      "ResultDesc": "Success",
      "CallbackMetadata": {
        "Item": [
          { "Name": "Amount", "Value": 4640 },
          { "Name": "MpesaReceiptNumber", "Value": "MPESA123456" },
          { "Name": "PhoneNumber", "Value": "254712345678" }
        ]
      }
    }
  }
}
```

---

## Plans API

### List Plans
```http
GET /api/plans
```

**Response:**
```json
{
  "success": true,
  "data": {
    "plans": [
      {
        "id": "1",
        "name": "Basic 5Mbps",
        "description": "Perfect for light browsing",
        "price": 1500,
        "speed": "5Mbps",
        "type": "hotspot",
        "status": "active"
      }
    ]
  }
}
```

### Create Plan
```http
POST /api/plans
Content-Type: application/json

{
  "name": "Enterprise 100Mbps",
  "description": "For large businesses",
  "price": 50000,
  "downloadSpeed": 100,
  "uploadSpeed": 50,
  "type": "pppoe",
  "dataLimit": 1000
}
```

---

## OLT Management API

### List OLTs
```http
GET /api/olt
```

### Add OLT
```http
POST /api/olt
Content-Type: application/json

{
  "name": "OLT-Main-Office",
  "vendor": "huawei",
  "model": "MA5800",
  "ipAddress": "192.168.100.10",
  "port": 22,
  "protocol": "ssh",
  "username": "admin",
  "password": "securepassword",
  "location": "Main Office, Nairobi"
}
```

### Get OLT Status
```http
GET /api/olt/:id/status
```

**Response:**
```json
{
  "success": true,
  "data": {
    "status": {
      "oltId": "1",
      "connected": true,
      "system": {
        "cpuUsage": 32,
        "memoryUsage": 58,
        "temperature": 45,
        "uptime": 2592000
      },
      "ponPorts": 8,
      "onuCount": 234,
      "health": "healthy",
      "issues": []
    }
  }
}
```

### Get PON Ports
```http
GET /api/olt/:id/ports
```

### Get ONUs
```http
GET /api/olt/:id/onu?portId=0/1/1
```

### Provision ONU
```http
POST /api/olt/:id/onu
Content-Type: application/json

{
  "serialNumber": "HWTC12345678",
  "ponPortId": "0/1/1",
  "serviceProfile": "1",
  "lineProfile": "1",
  "description": "Customer ONU"
}
```

### Run Self-Healing
```http
POST /api/olt/:id/self-healing
```

### Get AI Optimizations
```http
GET /api/olt/:id/ai-optimizations
```

---

## MikroTik API

### List Routers
```http
GET /api/mikrotik/routers
```

### Add Router
```http
POST /api/mikrotik/routers
Content-Type: application/json

{
  "name": "Main Tower",
  "ipAddress": "192.168.100.1",
  "port": 8291,
  "username": "admin",
  "password": "securepassword",
  "location": "Nairobi CBD"
}
```

### Get Router Status
```http
GET /api/mikrotik/routers/:id/status
```

### Get Active Users
```http
GET /api/mikrotik/routers/:id/users
```

---

## Analytics API

### Dashboard Stats
```http
GET /api/analytics/dashboard
```

**Response:**
```json
{
  "success": true,
  "data": {
    "totalCustomers": 1247,
    "activeCustomers": 892,
    "monthlyRevenue": 2400000,
    "outstandingBalance": 450000,
    "todayPayments": 125000,
    "newCustomersThisMonth": 45
  }
}
```

### Revenue Analytics
```http
GET /api/analytics/revenue?period=monthly&startDate=2024-01-01&endDate=2024-12-31
```

### Customer Growth
```http
GET /api/analytics/customer-growth?period=monthly
```

### Churn Risk Analysis
```http
GET /api/analytics/churn-risk/:customerId
```

**Response:**
```json
{
  "success": true,
  "data": {
    "score": 65,
    "factors": ["2 overdue invoices", "No payment in 50 days"],
    "recommendations": ["Send payment reminder", "Offer payment plan"]
  }
}
```

---

## Notifications API

### Send Notification
```http
POST /api/notifications/send
Content-Type: application/json

{
  "customerId": "1",
  "type": "payment_reminder",
  "channels": ["whatsapp", "sms", "email"],
  "data": {
    "amount": 4640,
    "dueDate": "2024-02-05"
  }
}
```

### Get Notification Status
```http
GET /api/notifications/status
```

---

## Webhooks

### M-Pesa Webhook
```http
POST /api/webhooks/mpesa
Content-Type: application/json

{
  "TransactionType": "Pay Bill",
  "TransID": "MPESA123456",
  "TransTime": "20240101120000",
  "TransAmount": "4640.00",
  "BusinessShortCode": "174379",
  "BillRefNumber": "ISP001",
  "MSISDN": "254712345678"
}
```

### WhatsApp Webhook
```http
POST /api/webhooks/whatsapp
Content-Type: application/json

{
  "object": "whatsapp_business_account",
  "entry": [{
    "changes": [{
      "value": {
        "messages": [{
          "from": "254712345678",
          "type": "text",
          "text": { "body": "Hello" }
        }]
      }
    }]
  }]
}
```

---

## Error Responses

### 400 Bad Request
```json
{
  "success": false,
  "error": "Validation failed",
  "details": {
    "email": "Email is required",
    "phone": "Phone number is invalid"
  }
}
```

### 401 Unauthorized
```json
{
  "success": false,
  "error": "Unauthorized",
  "message": "Invalid or expired token"
}
```

### 403 Forbidden
```json
{
  "success": false,
  "error": "Forbidden",
  "message": "You don't have permission to access this resource"
}
```

### 404 Not Found
```json
{
  "success": false,
  "error": "Not found",
  "message": "Customer not found"
}
```

### 500 Internal Server Error
```json
{
  "success": false,
  "error": "Internal server error",
  "message": "An unexpected error occurred"
}
```

---

## Rate Limits

| Endpoint | Limit |
|----------|-------|
| `/api/auth/*` | 5 requests/minute |
| `/api/*` | 100 requests/minute |
| `/api/payments/mpesa/callback` | No limit |

---

## Pagination

All list endpoints support pagination:

```http
GET /api/customers?page=1&limit=20
```

**Response includes:**
```json
{
  "data": [...],
  "total": 150,
  "page": 1,
  "limit": 20,
  "totalPages": 8
}
```

---

## Filtering & Search

```http
# Search customers
GET /api/customers?search=john

# Filter by status
GET /api/customers?status=active

# Filter invoices
GET /api/invoices?status=unpaid&customerId=1

# Date range
GET /api/payments?startDate=2024-01-01&endDate=2024-01-31
```

---

## SDK Examples

### JavaScript/Node.js
```javascript
const axios = require('axios');

const api = axios.create({
  baseURL: 'https://api.your-domain.com',
  headers: {
    'Authorization': 'Bearer YOUR_TOKEN'
  }
});

// Get customers
const customers = await api.get('/api/customers');

// Create invoice
const invoice = await api.post('/api/invoices', {
  customerId: '1',
  amount: 4000
});
```

### Python
```python
import requests

headers = {
    'Authorization': 'Bearer YOUR_TOKEN'
}

# Get customers
response = requests.get(
    'https://api.your-domain.com/api/customers',
    headers=headers
)
customers = response.json()

# Create invoice
invoice = requests.post(
    'https://api.your-domain.com/api/invoices',
    headers=headers,
    json={
        'customerId': '1',
        'amount': 4000
    }
)
```

### cURL
```bash
# Get customers
curl -H "Authorization: Bearer YOUR_TOKEN" \
  https://api.your-domain.com/api/customers

# Create invoice
curl -X POST \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"customerId":"1","amount":4000}' \
  https://api.your-domain.com/api/invoices
```
