# Complete ISP Billing System - Deployment & Integration Guide

## Table of Contents
1. [Quick Start](#quick-start)
2. [System Requirements](#system-requirements)
3. [Installation](#installation)
4. [Configuration](#configuration)
5. [Theme Customization](#theme-customization)
6. [Router Monitoring Setup](#router-monitoring-setup)
7. [OLT Integration](#olt-integration)
8. [Scaling & Production](#scaling--production)
9. [Troubleshooting](#troubleshooting)
10. [Maintenance](#maintenance)

---

## Quick Start

### One-Command Setup (Ubuntu/Debian)

```bash
# Download and run the setup script
curl -fsSL https://your-domain.com/setup.sh | bash

# Or manually:
git clone https://github.com/your-repo/isp-billing.git
cd isp-billing
./scripts/setup.sh
```

---

## System Requirements

### Minimum Requirements
- **CPU**: 2 cores
- **RAM**: 4 GB
- **Storage**: 50 GB SSD
- **OS**: Ubuntu 20.04+ / Debian 11+ / CentOS 8+
- **Node.js**: 18.x or higher
- **PostgreSQL**: 14.x or higher
- **Redis**: 6.x or higher

### Recommended for Production
- **CPU**: 4+ cores
- **RAM**: 8+ GB
- **Storage**: 100 GB SSD
- **Network**: 1 Gbps

---

## Installation

### Step 1: Install Dependencies

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# Install PostgreSQL
sudo apt install -y postgresql postgresql-contrib

# Install Redis
sudo apt install -y redis-server

# Install Nginx (for production)
sudo apt install -y nginx

# Install Git
sudo apt install -y git
```

### Step 2: Setup Database

```bash
# Create database and user
sudo -u postgres psql << EOF
CREATE DATABASE isp_billing;
CREATE USER isp_user WITH ENCRYPTED PASSWORD 'your_secure_password';
GRANT ALL PRIVILEGES ON DATABASE isp_billing TO isp_user;
\q
EOF

# Enable required PostgreSQL extensions
sudo -u postgres psql -d isp_billing -c "CREATE EXTENSION IF NOT EXISTS uuid-ossp;"
sudo -u postgres psql -d isp_billing -c "CREATE EXTENSION IF NOT EXISTS pgcrypto;"
```

### Step 3: Clone and Setup Application

```bash
# Create application directory
sudo mkdir -p /opt/isp-billing
sudo chown $USER:$USER /opt/isp-billing
cd /opt/isp-billing

# Clone repositories
git clone https://github.com/your-repo/isp-billing-backend.git backend
git clone https://github.com/your-repo/isp-billing-frontend.git frontend

# Setup Backend
cd backend
npm install
npm run build

# Setup Frontend
cd ../frontend
npm install
npm run build
```

### Step 4: Environment Configuration

Create `/opt/isp-billing/backend/.env`:

```env
# Server
NODE_ENV=production
PORT=5000
HOST=0.0.0.0

# Database
DB_HOST=localhost
DB_PORT=5432
DB_NAME=isp_billing
DB_USER=isp_user
DB_PASSWORD=your_secure_password
DB_SSL=false

# Redis
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_PASSWORD=

# JWT
JWT_SECRET=your_super_secret_jwt_key_change_this_in_production
JWT_EXPIRES_IN=24h
JWT_REFRESH_EXPIRES_IN=7d

# Frontend URL
FRONTEND_URL=https://your-domain.com
CORS_ORIGIN=https://your-domain.com

# M-Pesa (Safaricom)
MPESA_CONSUMER_KEY=your_consumer_key
MPESA_CONSUMER_SECRET=your_consumer_secret
MPESA_PASSKEY=your_passkey
MPESA_SHORTCODE=your_shortcode
MPESA_ENVIRONMENT=sandbox

# SMS (Africa's Talking)
AFRICASTALKING_API_KEY=your_api_key
AFRICASTALKING_USERNAME=your_username
AFRICASTALKING_SENDER_ID=your_sender_id

# Email (SMTP)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password
SMTP_FROM=noreply@your-domain.com

# Google OAuth
GOOGLE_CLIENT_ID=your_google_client_id
GOOGLE_CLIENT_SECRET=your_google_client_secret

# File Upload
UPLOAD_MAX_SIZE=10485760
UPLOAD_PATH=./uploads

# Logging
LOG_LEVEL=info
LOG_FILE=./logs/app.log
```

### Step 5: Database Migration

```bash
cd /opt/isp-billing/backend
npm run migrate
npm run seed  # Optional: Add sample data
```

### Step 6: Start Services

```bash
# Using PM2 for process management
sudo npm install -g pm2

# Start backend
cd /opt/isp-billing/backend
pm2 start dist/server.js --name "isp-backend"

# Serve frontend (using a simple server)
cd /opt/isp-billing/frontend
pm install -g serve
pm2 start "serve -s dist -l 3000" --name "isp-frontend"

# Save PM2 config
pm2 save
pm2 startup
```

---

## Configuration

### Nginx Configuration

Create `/etc/nginx/sites-available/isp-billing`:

```nginx
# Backend API
server {
    listen 80;
    server_name api.your-domain.com;
    
    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}

# Frontend
server {
    listen 80;
    server_name your-domain.com;
    
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

Enable the site:
```bash
sudo ln -s /etc/nginx/sites-available/isp-billing /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

### SSL with Let's Encrypt

```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.com -d api.your-domain.com
```

---

## Theme Customization

### Available Themes

Your ISP Billing System comes with **8 built-in themes**:

1. **Default** - Classic blue professional theme
2. **Dark Mode** - Sleek dark theme for night work
3. **Ocean** - Calming blue-green coastal theme
4. **Forest** - Natural green earthy theme
5. **Sunset** - Warm orange and purple gradient theme
6. **Cyberpunk** - Neon futuristic dark theme
7. **Minimal** - Clean grayscale minimalist theme
8. **Luxury** - Premium gold and dark theme

### How to Change Theme

1. Go to **Settings** → **Appearance**
2. Click on any theme preview to apply
3. Changes are saved automatically to localStorage

### Creating Custom Themes

Edit `/app/src/contexts/ThemeContext.tsx`:

```typescript
export const themes: Record<ThemeType, Theme> = {
  // Add your custom theme
  mytheme: {
    id: 'mytheme',
    name: 'My Custom Theme',
    description: 'Description of your theme',
    colors: {
      primary: 'hsl(220 90% 56%)',
      secondary: 'hsl(215 20% 65%)',
      accent: 'hsl(262 83% 58%)',
      background: 'hsl(0 0% 100%)',
      foreground: 'hsl(222 47% 11%)',
      card: 'hsl(0 0% 100%)',
      cardForeground: 'hsl(222 47% 11%)',
      border: 'hsl(214 32% 91%)',
      muted: 'hsl(210 40% 96%)',
      mutedForeground: 'hsl(215 16% 47%)',
      success: 'hsl(142 76% 36%)',
      warning: 'hsl(38 92% 50%)',
      destructive: 'hsl(0 84% 60%)',
      info: 'hsl(199 89% 48%)'
    },
    fontFamily: 'Inter, sans-serif', // Optional
    borderRadius: '8px' // Optional
  }
};
```

---

## Router Monitoring Setup

### Adding a MikroTik Router

1. Go to **MikroTik** → **Add Router**
2. Fill in the details:
   - **Name**: Router identifier (e.g., "Main Tower")
   - **IP Address**: Router's management IP
   - **Port**: SSH port (default: 22)
   - **Username**: Admin username
   - **Password**: Admin password
   - **API Port**: WinBox API port (default: 8728)
   - **Location**: Physical location (optional)

3. Click **Test Connection** before saving

### Features Available

- ✅ Real-time status monitoring
- ✅ CPU, Memory, Disk usage
- ✅ Interface statistics
- ✅ Active users (PPPoE + Hotspot)
- ✅ Route table view
- ✅ System logs
- ✅ Custom command execution
- ✅ Troubleshooting diagnostics
- ✅ Auto-fix common issues

### Troubleshooting Commands

The system can automatically detect and fix:
- High CPU/Memory usage
- Interface errors
- Missing DNS configuration
- Disabled NTP
- Missing firewall rules
- Available RouterOS updates

---

## OLT Integration

### Supported OLT Vendors

- **Huawei**: MA5600T, MA5800, EA5800
- **ZTE**: C220, C300, C320, C350, C600
- **Nokia**: ISAM 7302, ISAM 7330, ISAM 7360
- **FiberHome**: AN5516 series

### Adding an OLT

1. Go to **OLT Management** → **Add OLT**
2. Configure:
   - **Name**: OLT identifier
   - **Vendor**: Select from dropdown
   - **Model**: Select specific model
   - **IP Address**: Management IP
   - **Protocol**: SSH/Telnet/SNMP
   - **Credentials**: Username/Password

3. The system will test the connection before saving

### AI-Powered Features

- **Self-Healing**: Automatically resets offline ONUs
- **Auto-Discovery**: Finds unprovisioned ONUs
- **AI Optimization**: Bandwidth, failure prediction, upgrade suggestions
- **Anomaly Detection**: Identifies unusual patterns

---

## Scaling & Production

### Docker Deployment

```bash
# Build and run with Docker Compose
docker-compose up -d

# Scale backend instances
docker-compose up -d --scale backend=3
```

### Docker Swarm

```bash
# Initialize swarm
docker swarm init

# Deploy stack
docker stack deploy -c docker-compose.swarm.yml isp-billing

# Scale services
docker service scale isp-billing_backend=5
```

### Kubernetes

```bash
# Apply manifests
kubectl apply -f k8s/

# Scale deployment
kubectl scale deployment backend --replicas=5
```

### Load Balancing

```nginx
# /etc/nginx/nginx.conf
upstream backend {
    least_conn;
    server localhost:5000;
    server localhost:5001;
    server localhost:5002;
}

server {
    location /api/ {
        proxy_pass http://backend;
    }
}
```

### Database Optimization

```sql
-- Add indexes for common queries
CREATE INDEX idx_customers_company ON customers(company_id);
CREATE INDEX idx_invoices_status ON invoices(status);
CREATE INDEX idx_payments_date ON payments(created_at);
CREATE INDEX idx_routers_company ON mikrotik_routers(company_id);
CREATE INDEX idx_olts_company ON olts(company_id);

-- Enable query logging for slow queries
ALTER SYSTEM SET log_min_duration_statement = 1000;
```

---

## Troubleshooting

### Common Issues

#### Backend Won't Start
```bash
# Check logs
pm2 logs isp-backend

# Check database connection
npm run db:test

# Verify environment variables
npm run env:check
```

#### Frontend Build Fails
```bash
# Clear cache
rm -rf node_modules package-lock.json
npm install

# Check for TypeScript errors
npm run type-check
```

#### Database Connection Failed
```bash
# Test connection
psql -h localhost -U isp_user -d isp_billing -c "SELECT 1;"

# Check PostgreSQL status
sudo systemctl status postgresql

# Check logs
sudo tail -f /var/log/postgresql/postgresql-14-main.log
```

#### Redis Connection Failed
```bash
# Test Redis
redis-cli ping

# Check status
sudo systemctl status redis

# Restart Redis
sudo systemctl restart redis
```

### MikroTik Connection Issues

1. **Verify SSH is enabled** on the router:
   ```
   /ip service enable ssh
   /ip service set ssh port=22
   ```

2. **Check firewall rules**:
   ```
   /ip firewall filter print
   ```

3. **Test from server**:
   ```bash
   ssh admin@router-ip
   ```

### OLT Connection Issues

1. **Verify management VLAN** is configured
2. **Check SNMP/SSH is enabled**
3. **Test connectivity**:
   ```bash
   ping olt-ip
   ssh user@olt-ip
   ```

---

## Maintenance

### Backup Strategy

```bash
#!/bin/bash
# /opt/isp-billing/scripts/backup.sh

BACKUP_DIR="/backups/isp-billing"
DATE=$(date +%Y%m%d_%H%M%S)

# Database backup
pg_dump -U isp_user isp_billing > $BACKUP_DIR/db_$DATE.sql

# File backup
tar -czf $BACKUP_DIR/files_$DATE.tar.gz /opt/isp-billing/backend/uploads

# Keep only last 7 days
find $BACKUP_DIR -name "*.sql" -mtime +7 -delete
find $BACKUP_DIR -name "*.tar.gz" -mtime +7 -delete
```

Add to crontab:
```bash
0 2 * * * /opt/isp-billing/scripts/backup.sh
```

### Updates

```bash
# Update backend
cd /opt/isp-billing/backend
git pull
npm install
npm run build
npm run migrate
pm2 restart isp-backend

# Update frontend
cd /opt/isp-billing/frontend
git pull
npm install
npm run build
pm2 restart isp-frontend
```

### Monitoring

```bash
# Install monitoring tools
npm install -g clinic
npm install -g 0x

# Performance profiling
clinic doctor -- node dist/server.js
```

---

## Support

For technical support:
- **Email**: support@yourisp.com
- **Documentation**: https://docs.yourisp.com
- **API Reference**: https://api.yourisp.com/docs
- **Community Forum**: https://community.yourisp.com

---

## License

Copyright © 2024 ISP Solutions Ltd. All rights reserved.

---

**Version**: 2.0.0  
**Last Updated**: February 2024  
**Compatible With**: Node.js 18+, PostgreSQL 14+, Redis 6+
