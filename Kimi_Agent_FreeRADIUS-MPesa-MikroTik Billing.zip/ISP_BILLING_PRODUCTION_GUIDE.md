# ISP Billing System - Complete Production Guide

## Overview

This guide provides everything you need to deploy your ISP Billing System for self-hosting and production use. The system includes:

- **Frontend**: React + TypeScript + Tailwind CSS + shadcn/ui
- **Backend**: Node.js + Express + TypeScript
- **Database**: PostgreSQL 16
- **Cache/Queue**: Redis 7
- **Authentication**: FreeRADIUS
- **Payments**: M-Pesa Daraja API
- **Router Management**: MikroTik RouterOS API

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                         CLIENTS                                  │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐        │
│  │  Web App │  │  Mobile  │  │  Router  │  │  M-Pesa  │        │
│  └────┬─────┘  └────┬─────┘  └────┬─────┘  └────┬─────┘        │
└───────┼─────────────┼─────────────┼─────────────┼──────────────┘
        │             │             │             │
        ▼             ▼             ▼             ▼
┌─────────────────────────────────────────────────────────────────┐
│                      LOAD BALANCER (Nginx)                       │
│              SSL Termination, Rate Limiting, Caching             │
└─────────────────────────────────────────────────────────────────┘
        │
        ▼
┌─────────────────────────────────────────────────────────────────┐
│                         DOCKER HOST                              │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────────┐ │   │
│  │  │   API   │  │ Worker  │  │Scheduler│  │   Frontend  │ │   │
│  │  │  (x3)   │  │  (x2)   │  │  (x1)   │  │   (Nginx)   │ │   │
│  │  └────┬────┘  └────┬────┘  └────┬────┘  └──────┬──────┘ │   │
│  └───────┼────────────┼────────────┼──────────────┼────────┘   │
│          │            │            │              │             │
│          ▼            ▼            ▼              │             │
│  ┌────────────────────────────────────────────────┐             │
│  │           PostgreSQL (Primary + Replica)       │             │
│  └────────────────────────────────────────────────┘             │
│          ▲            ▲            ▲                            │
│          │            │            │                            │
│  ┌────────────────────────────────────────────────┐             │
│  │              Redis (Cluster)                   │             │
│  │    Cache / Sessions / PubSub / Job Queue      │             │
│  └────────────────────────────────────────────────┘             │
└─────────────────────────────────────────────────────────────────┘
        │
        ▼
┌─────────────────────────────────────────────────────────────────┐
│                    EXTERNAL INTEGRATIONS                         │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────────┐  │
│  │ FreeRADIUS  │  │    M-Pesa   │  │      MikroTik Routers   │  │
│  │  (Auth)     │  │  (Payments) │  │    (PPPoE / Hotspot)    │  │
│  └─────────────┘  └─────────────┘  └─────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
```

## File Structure

```
/mnt/okcomputer/output/
├── app/                              # Frontend React Application
│   ├── src/
│   │   ├── pages/                    # 20+ feature pages
│   │   ├── components/               # Reusable components
│   │   └── App.tsx                   # Main router
│   └── dist/                         # Built frontend
│
└── isp-billing-backend/              # Production Backend
    ├── src/
    │   ├── config/                   # Database, Redis, Queue config
    │   ├── middleware/               # Auth, error handling
    │   ├── routes/                   # API endpoints
    │   ├── services/                 # Business logic
    │   └── server.ts                 # Entry point
    ├── migrations/                   # Database schema
    ├── docs/                         # Integration guides
    ├── nginx/                        # Reverse proxy config
    ├── docker-compose.yml            # Full stack orchestration
    ├── Dockerfile                    # API container
    └── scripts/
        └── deploy.sh                 # One-click deployment
```

## Quick Start (Production Deployment)

### Step 1: Server Requirements

**Minimum:**
- 2 CPU cores
- 4 GB RAM
- 50 GB SSD
- Ubuntu 22.04 LTS

**Recommended:**
- 4+ CPU cores
- 8+ GB RAM
- 100+ GB SSD
- Ubuntu 22.04 LTS

### Step 2: Install Dependencies

```bash
# Update system
sudo apt-get update && sudo apt-get upgrade -y

# Install Docker
sudo apt-get install -y docker.io docker-compose-plugin
sudo systemctl enable docker
sudo usermod -aG docker $USER
newgrp docker

# Install utilities
sudo apt-get install -y git curl wget nginx certbot
```

### Step 3: Deploy Application

```bash
# Create directory
sudo mkdir -p /opt/isp-billing
cd /opt/isp-billing

# Copy backend files
sudo cp -r /mnt/okcomputer/output/isp-billing-backend/* .

# Copy frontend build
sudo mkdir -p frontend/dist
sudo cp -r /mnt/okcomputer/output/app/dist/* frontend/dist/

# Configure environment
sudo cp .env.example .env
sudo nano .env
# Edit with your configuration

# Deploy
sudo ./scripts/deploy.sh production
```

### Step 4: Configure SSL

```bash
# Get SSL certificate
sudo certbot certonly --standalone -d your-domain.com

# Copy certificates
sudo cp /etc/letsencrypt/live/your-domain.com/*.pem nginx/ssl/

# Restart
sudo docker-compose restart frontend
```

## Configuration

### Environment Variables (.env)

```bash
# Application
NODE_ENV=production
API_PORT=5000
FRONTEND_URL=https://your-domain.com

# Database
DB_HOST=postgres
DB_PORT=5432
DB_NAME=isp_billing
DB_USER=postgres
DB_PASSWORD=your_secure_password

# Redis
REDIS_HOST=redis
REDIS_PORT=6379
REDIS_PASSWORD=your_redis_password

# JWT
JWT_SECRET=your_super_secret_key_min_32_characters

# M-Pesa (Get from Daraja Portal)
MPESA_ENV=production
MPESA_CONSUMER_KEY=your_consumer_key
MPESA_CONSUMER_SECRET=your_consumer_secret
MPESA_SHORTCODE=your_paybill_number
MPESA_PASSKEY=your_passkey
MPESA_CALLBACK_URL=https://your-domain.com/api/mpesa/callback

# Email (SMTP)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password

# SMS (Africa's Talking)
SMS_PROVIDER=africastalking
SMS_API_KEY=your_api_key
SMS_SENDER_ID=YOURBRAND
```

## Integration Guides

### 1. FreeRADIUS Integration

See: `docs/FREERADIUS_INTEGRATION.md`

**Key Points:**
- Install FreeRADIUS with PostgreSQL support
- Configure SQL module to use `radius_*` tables
- Set up MikroTik as NAS client
- Configure PPPoE/Hotspot profiles

**Quick Setup:**
```bash
# Start with FreeRADIUS
docker-compose --profile with-radius up -d

# Configure MikroTik
/radius add service=ppp,hotspot address=radius-ip secret=shared-secret
```

### 2. M-Pesa Integration

See: `docs/MPESA_INTEGRATION.md`

**Key Points:**
- Register at https://developer.safaricom.co.ke
- Get approved Paybill/Till number
- Configure callback URLs
- Test in sandbox first

**API Endpoints:**
- `POST /api/mpesa/stkpush` - Initiate payment
- `POST /api/mpesa/callback` - Payment callback
- `POST /api/mpesa/c2b/confirm` - C2B confirmation

### 3. MikroTik Integration

See: `docs/MIKROTIK_INTEGRATION.md`

**Key Points:**
- Enable REST API on RouterOS v7+
- Configure SSL certificate
- Set up PPPoE/Hotspot profiles
- Add router credentials to system

**Router Configuration:**
```bash
/ip service enable rest
/ip service set rest port=443 certificate=your-cert
```

## Features Available

### Core Features
- ✅ Customer Management (PPPoE & Hotspot)
- ✅ Plan/Package Management
- ✅ Automated Invoicing
- ✅ Payment Processing (M-Pesa integration)
- ✅ Router Management (MikroTik)
- ✅ RADIUS Authentication (FreeRADIUS)
- ✅ Real-time Session Monitoring
- ✅ Bandwidth Usage Tracking

### Advanced Features
- ✅ Customer Self-Service Portal
- ✅ Support Ticket System
- ✅ Inventory Management
- ✅ Hotspot Voucher System
- ✅ Agent/Commission System
- ✅ AI Analytics Dashboard
- ✅ WhatsApp Integration
- ✅ Fair Usage Policy (FUP) Management
- ✅ Bulk Operations (SMS, Email, Invoices)
- ✅ Automation Workflows
- ✅ Audit Logs
- ✅ Network Monitoring

## API Endpoints

### Authentication
- `POST /api/auth/login`
- `POST /api/auth/refresh`
- `POST /api/auth/logout`

### Customers
- `GET /api/customers` - List all customers
- `POST /api/customers` - Create customer
- `GET /api/customers/:id` - Get customer details
- `PUT /api/customers/:id` - Update customer

### Billing
- `GET /api/invoices` - List invoices
- `POST /api/invoices` - Create invoice
- `POST /api/invoices/:id/pay` - Record payment

### Network
- `GET /api/routers` - List routers
- `GET /api/network/sessions` - Active sessions
- `POST /api/mikrotik/sync-user` - Sync user to router

### Reports
- `GET /api/reports/revenue`
- `GET /api/reports/usage`
- `GET /api/reports/customers`

## Background Jobs

| Job | Schedule | Description |
|-----|----------|-------------|
| Invoice Generation | Monthly 1st @ 00:00 | Generate recurring invoices |
| Payment Reminders | Daily @ 09:00 | Send overdue reminders |
| Account Suspension | Daily @ 00:30 | Suspend expired accounts |
| Usage Sync | Every 5 minutes | Sync RADIUS usage data |
| Backup | Daily @ 02:00 | Database backup |
| FUP Check | Hourly | Enforce fair usage policy |
| Router Health | Every 10 minutes | Check router status |

## Monitoring & Maintenance

### Health Check
```bash
curl https://your-domain.com/health
```

### View Logs
```bash
# All services
docker-compose logs -f

# Specific service
docker-compose logs -f api
```

### Backup
```bash
# Manual backup
docker-compose exec postgres pg_dump -U postgres isp_billing > backup.sql

# Restore
cat backup.sql | docker-compose exec -T postgres psql -U postgres isp_billing
```

### Updates
```bash
# Pull latest images
docker-compose pull

# Restart with new images
docker-compose up -d

# Run migrations
docker-compose exec api npm run migrate
```

## Security Checklist

- [ ] Change default passwords
- [ ] Enable firewall (UFW)
- [ ] Configure SSL certificate
- [ ] Set strong JWT secret
- [ ] Enable API rate limiting
- [ ] Restrict database access
- [ ] Configure backup encryption
- [ ] Set up log monitoring
- [ ] Enable 2FA for admin accounts
- [ ] Regular security updates

## Troubleshooting

### Common Issues

1. **Container won't start**
   ```bash
   docker-compose logs <service-name>
   docker-compose restart <service-name>
   ```

2. **Database connection failed**
   ```bash
   docker-compose exec postgres pg_isready -U postgres
   ```

3. **M-Pesa callback not working**
   - Verify callback URL is HTTPS
   - Check firewall allows external access
   - Verify M-Pesa portal configuration

4. **MikroTik connection failed**
   - Verify REST API is enabled
   - Check credentials
   - Ensure router is accessible

## Support & Resources

### Documentation
- FreeRADIUS: `docs/FREERADIUS_INTEGRATION.md`
- M-Pesa: `docs/MPESA_INTEGRATION.md`
- MikroTik: `docs/MIKROTIK_INTEGRATION.md`
- Deployment: `docs/PRODUCTION_DEPLOYMENT.md`

### External Resources
- [MikroTik Wiki](https://wiki.mikrotik.com)
- [FreeRADIUS Documentation](https://freeradius.org/documentation/)
- [M-Pesa Daraja API](https://developer.safaricom.co.ke)

## License

MIT License - Feel free to use for your ISP business.

---

**Ready to deploy your ISP Billing System!** 🚀

For questions or issues, refer to the documentation files or create an issue in your repository.
